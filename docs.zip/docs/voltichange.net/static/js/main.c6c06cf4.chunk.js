/*! For license information please see main.c6c06cf4.chunk.js.LICENSE.txt */
(this.webpackJsonpmyapp = this.webpackJsonpmyapp || []).push([
    [0], {
        1003: function(e, t) {},
        1095: function(e, t, n) {},
        1416: function(e, t, n) {
            "use strict";
            n.r(t);
            var r = n(0),
                a = n.n(r),
                i = n(171),
                o = n.n(i),
                s = (n(707), n(3)),
                c = n(13),
                l = n(1432),
                u = n(21),
                p = n(74),
                d = n.n(p),
                m = n(47),
                y = n(193),
                f = n(28),
                h = (n(182), n(719), n(1), n(203)),
                g = n(184),
                b = n(145),
                v = n(163),
                x = n(142),
                w = n(460),
                k = n(380),
                E = n(461),
                T = n(462),
                O = n(463),
                j = n(381),
                L = n(382),
                S = n(183),
                N = n.n(S);

            function _() {
                _ = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var A = N.a.create({
                baseURL: "https://api.voltichange.net"
            });
            A.interceptors.request.use(function() {
                var e = Object(s.a)(_().mark((function e(t) {
                    var n;
                    return _().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = localStorage.getItem("@WALLET"), t.headers.wallet = n, e.abrupt("return", t);
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })));
                return function(t) {
                    return e.apply(this, arguments)
                }
            }(), (function(e) {
                return Promise.reject(e)
            }));
            var I = {
                    get: function() {
                        var e = Object(s.a)(_().mark((function e(t) {
                            var n;
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return console.log("pathpathpath", t), e.next = 3, A.post("/api/call/moralis", {
                                            method: "get",
                                            path: t
                                        });
                                    case 3:
                                        return n = e.sent, e.abrupt("return", n);
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }(),
                    post: function() {
                        var e = Object(s.a)(_().mark((function e(t, n) {
                            var r;
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return console.log("pathpathpath", t), e.next = 3, A.post("/api/call/moralis", {
                                            method: "post",
                                            path: t,
                                            body: n
                                        });
                                    case 3:
                                        return r = e.sent, e.abrupt("return", r);
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t, n) {
                            return e.apply(this, arguments)
                        }
                    }()
                },
                C = {
                    get: function() {
                        var e = Object(s.a)(_().mark((function e(t) {
                            var n;
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return console.log("pathpathpath2", t), e.next = 3, A.post("/api/call/coingecko", {
                                            method: "get",
                                            path: t
                                        });
                                    case 3:
                                        return n = e.sent, e.abrupt("return", n);
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }()
                },
                M = {
                    get: function() {
                        var e = Object(s.a)(_().mark((function e(t) {
                            var n;
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return console.log("pathpathpath2", t), e.next = 3, A.post("/api/call/etherscanApi", {
                                            method: "get",
                                            path: t
                                        });
                                    case 3:
                                        return n = e.sent, e.abrupt("return", n);
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }()
                },
                D = {
                    get: function() {
                        var e = Object(s.a)(_().mark((function e(t) {
                            var n;
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return console.log("pathpathpath2", t), e.next = 3, A.post("/api/call/bscscanApi", {
                                            method: "get",
                                            path: t
                                        });
                                    case 3:
                                        return n = e.sent, e.abrupt("return", n);
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }()
                },
                P = (N.a.create({
                    baseURL: "https://li.quest/v1/"
                }), A),
                F = n(473),
                B = n(122),
                G = (n(1413), n(7), n(695)),
                H = (n(1415), n(466)),
                W = n.n(H);
            n(1414);

            function U() {
                U = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var R = "1;56".split(";"),
                z = new d.a(d.a.givenProvider),
                V = "0x263294ab2260883d09cD13b85dC983062805517C",
                q = "0x51dE2038bD4bE66723156f776204149c0876f849",
                Y = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
                J = "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
                K = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
                X = "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d",
                $ = "0x203393330560Cf43893Ae7051d1b787844f13080",
                Z = "edf40ec311c64590b7115ef4b388bc48",
                Q = "0x6dFCAab27f29eBF8f4bBe1595a245919a02D6AD1",
                ee = "0x7754eE4b040f2E6bbEd8885994B54a086C857a56",
                te = (new B.a("https://bsc-mainnet.gateway.pokt.network/v1/lb/539cf7341c78a6cf915b39a3"), new m.ethers.providers.JsonRpcProvider("https://mainnet.infura.io/v3/".concat(Z)), {
                    3: "kwei",
                    6: "mwei",
                    9: "gwei",
                    12: "szabo",
                    15: "finney",
                    18: "ether"
                }),
                ne = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, s, c, l, p, m, y, f, h;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (n = t.token, r = void 0 === n ? "" : n, a = t.abi, i = void 0 === a ? g : a, o = t.functionName, s = t.argumments, c = void 0 === s ? [] : s, l = t.chain, p = void 0 === l ? "eth" : l, e.prev = 1, "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2" !== r || "decimals" !== o) {
                                        e.next = 4;
                                        break
                                    }
                                    return e.abrupt("return", "18");
                                case 4:
                                    return y = "eth" === String(p).toLowerCase() ? "https://mainnet.infura.io/v3/edf40ec311c64590b7115ef4b388bc48" : "https://bsc-dataseed2.binance.org/", f = new d.a(y), console.log("token, abi, functionName, argumments, chain", {
                                        token: r,
                                        abi: i,
                                        functionName: o,
                                        argumments: c,
                                        chain: p
                                    }), e.next = 9, (m = new f.eth.Contract(i, r).methods)[o].apply(m, Object(u.a)(c)).call();
                                case 9:
                                    return h = e.sent, console.log("1111token, abi, functionName, argumments, chain", {
                                        token: r,
                                        res: h,
                                        abi: i,
                                        functionName: o,
                                        argumments: c,
                                        chain: p
                                    }), e.abrupt("return", h);
                                case 14:
                                    e.prev = 14, e.t0 = e.catch(1), console.log("error token, abi, functionName, argumments, chain", {
                                        token: r,
                                        abi: i,
                                        functionName: o,
                                        argumments: c,
                                        chain: p
                                    }), console.log(e.t0);
                                case 18:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [1, 14]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                re = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, s, c, l, p, m, y, f, g, b, v, x, w;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    r = t.provider, a = t.method, i = t.argumments, o = t.chain, s = t.abi, c = t.address, l = t.account, p = t.value, e.prev = 1, m = (null === r || void 0 === r ? void 0 : r.method) ? null === r || void 0 === r ? void 0 : r.method : r, console.log({
                                        Provider: m,
                                        provider: r,
                                        method: a,
                                        argumments: i,
                                        chain: o,
                                        abi: s,
                                        address: c,
                                        account: l,
                                        value: p
                                    }), y = localStorage.getItem("@WALLET_TYPE"), f = "eth" === String(o).toLowerCase() ? "https://mainnet.infura.io/v3/edf40ec311c64590b7115ef4b388bc48" : "https://bsc-dataseed2.binance.org/", g = new d.a(f), console.log("connectionWalletType", {
                                        connectionWalletType: y,
                                        provider: r,
                                        method: a,
                                        argumments: i,
                                        chain: o,
                                        abi: s,
                                        address: c,
                                        account: l
                                    }), e.t0 = y, e.next = "okx" === e.t0 ? 11 : 21;
                                    break;
                                case 11:
                                    return e.next = 13, new g.eth.Contract(s, c);
                                case 13:
                                    return b = e.sent, v = (n = b.methods)[a].apply(n, Object(u.a)(i)).encodeABI(), x = {
                                        to: c,
                                        from: l,
                                        data: v,
                                        chainId: "0x" + h.filter((function(e) {
                                            return String(e.chainName).toLowerCase() === String(o).toLowerCase()
                                        }))[0].id || !1
                                    }, console.log(), e.next = 19, window.okexchain.request({
                                        method: "eth_sendTransaction",
                                        params: [x]
                                    });
                                case 19:
                                    return w = e.sent, e.abrupt("return", {
                                        transactionHash: w
                                    });
                                case 21:
                                    return e.abrupt("return", m[a].apply(m, Object(u.a)(i)).send({
                                        value: p,
                                        from: l
                                    }));
                                case 22:
                                    e.next = 27;
                                    break;
                                case 24:
                                    e.prev = 24, e.t1 = e.catch(1), console.log(e.t1);
                                case 27:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [1, 24]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                ae = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, z.eth.getChainId();
                                case 2:
                                    if (n = e.sent, "eth" !== String(t).toLowerCase()) {
                                        e.next = 5;
                                        break
                                    }
                                    return e.abrupt("return", 1 === +n);
                                case 5:
                                    if ("bsc" !== String(t).toLowerCase() && "bnb" !== String(t).toLowerCase()) {
                                        e.next = 7;
                                        break
                                    }
                                    return e.abrupt("return", 56 === +n);
                                case 7:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                ie = function() {
                    var e = localStorage.getItem("@WALLET_TYPE");
                    switch (e) {
                        case "metamask":
                            se.apply(void 0, arguments);
                            break;
                        case "coinbase":
                            le.apply(void 0, arguments);
                            break;
                        case "wallet_connect":
                            ce.apply(void 0, arguments)
                    }
                },
                oe = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    t.chainid, r = t.setWalletIsConnected, a = t.setWalletDataIsOpened, i = t.setWalletAddress, o = localStorage.getItem("@WALLET_TYPE"), localStorage.clear(), e.t0 = o, e.next = "metamask" === e.t0 ? 6 : "coinbase" === e.t0 ? 11 : "wallet_connect" === e.t0 ? 17 : 23;
                                    break;
                                case 6:
                                    return window.ethereum._handleDisconnect(), r(!1), a(!1), i(), e.abrupt("break", 24);
                                case 11:
                                    return e.next = 13, null === (n = z.currentProvider) || void 0 === n ? void 0 : n.disconnect();
                                case 13:
                                    return r(!1), a(!1), i(), e.abrupt("break", 24);
                                case 17:
                                    return r(!1), a(!1), i(), e.next = 22, z.currentProvider.disconnect();
                                case 22:
                                case 23:
                                    return e.abrupt("break", 24);
                                case 24:
                                    window.location.reload();
                                case 25:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                se = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, s, l, u, p, m, y, f, h;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = t.setWalletAddress, r = t.setNetworkId, a = t.setWalletIsConnected, i = t.walletIsConnected, e.next = 3, z.eth.getChainId();
                                case 3:
                                    if (o = e.sent, s = "1;56".split(";"), l = s.filter((function(e) {
                                            return +e === +o
                                        })), u = Object(c.a)(l, 1), u[0]) {
                                        e.next = 8;
                                        break
                                    }
                                    return e.abrupt("return", pe(1, (function() {
                                        return null
                                    }), (function() {
                                        return null
                                    }), (function() {
                                        return null
                                    }), !0));
                                case 8:
                                    if (!i) {
                                        e.next = 12;
                                        break
                                    }
                                    a(!1), e.next = 46;
                                    break;
                                case 12:
                                    if (!window.ethereum) {
                                        e.next = 44;
                                        break
                                    }
                                    return e.next = 15, null === (p = window.ethereum) || void 0 === p ? void 0 : p.request({
                                        method: "eth_requestAccounts"
                                    });
                                case 15:
                                    return window.web3 = new d.a(window.ethereum), e.next = 18, window.web3.eth.getAccounts();
                                case 18:
                                    return m = e.sent, y = Object(c.a)(m, 1), f = y[0], e.next = 23, window.web3.eth.getChainId();
                                case 23:
                                    return h = e.sent, R.includes(String(h)) || pe(1, (function() {
                                        return null
                                    }), (function() {
                                        return null
                                    }), (function() {
                                        return null
                                    }), !0), localStorage.setItem("@WALLET", f), n(f), e.t0 = r, e.next = 31, window.web3.eth.getChainId();
                                case 31:
                                    return e.t1 = e.sent, (0, e.t0)(e.t1), a(!0), localStorage.setItem("@WALLET_TYPE", "metamask"), e.t2 = Promise, e.t3 = f, e.next = 39, window.web3.eth.getChainId();
                                case 39:
                                    return e.t4 = e.sent, e.t5 = {
                                        wallet: e.t3,
                                        network: e.t4
                                    }, e.abrupt("return", e.t2.resolve.call(e.t2, e.t5));
                                case 44:
                                    return console.log("No wallet"), e.abrupt("return", Promise.reject("Error"));
                                case 46:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                ce = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, s, l, u, p, m, y;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = t.setWalletAddress, r = void 0 === n ? function() {
                                        return null
                                    } : n, a = t.setNetworkId, i = void 0 === a ? function() {
                                        return null
                                    } : a, o = t.setWalletIsConnected, s = void 0 === o ? function() {
                                        return null
                                    } : o, t.walletIsConnected, l = t.chainid, t.chainData, u = new F.a({
                                        infuraId: Z,
                                        rpc: {
                                            56: "https://bsc-dataseed.binance.org/"
                                        },
                                        chainId: l
                                    }), e.next = 4, u.enable();
                                case 4:
                                    return p = e.sent, m = Object(c.a)(p, 1), y = m[0], u, z = new d.a(u), window.web3 = new d.a(u), r(y), e.t0 = i, e.next = 14, window.web3.eth.getChainId();
                                case 14:
                                    return e.t1 = e.sent, (0, e.t0)(e.t1), s(!0), localStorage.setItem("@WALLET_TYPE", "wallet_connect"), localStorage.setItem("@WALLET", y), e.t2 = Promise, e.t3 = y, e.next = 23, window.web3.eth.getChainId();
                                case 23:
                                    return e.t4 = e.sent, e.t5 = {
                                        wallet: e.t3,
                                        network: e.t4
                                    }, e.abrupt("return", e.t2.resolve.call(e.t2, e.t5));
                                case 26:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                le = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, s, l, u;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = t.setWalletAddress, r = t.setNetworkId, a = t.setWalletIsConnected, t.walletIsConnected, e.prev = 1, i = new W.a({
                                        appName: "Voltichange",
                                        appLogoUrl: "/img/logo-mobile",
                                        darkMode: !1
                                    }), o = i.makeWeb3Provider("https://mainnet.infura.io/v3/".concat(Z), 1), e.next = 6, o.enable();
                                case 6:
                                    return s = e.sent, l = Object(c.a)(s, 1), u = l[0], z = new d.a(o), window.web3 = new d.a(o), n(u), e.t0 = r, e.next = 15, window.web3.eth.getChainId();
                                case 15:
                                    return e.t1 = e.sent, (0, e.t0)(e.t1), a(!0), localStorage.setItem("@WALLET_TYPE", "coinbase"), e.t2 = Promise, e.t3 = u, e.next = 23, window.web3.eth.getChainId();
                                case 23:
                                    return e.t4 = e.sent, e.t5 = {
                                        wallet: e.t3,
                                        network: e.t4
                                    }, e.abrupt("return", e.t2.resolve.call(e.t2, e.t5));
                                case 28:
                                    return e.prev = 28, e.t6 = e.catch(1), e.abrupt("return", console.log(e.t6));
                                case 31:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [1, 28]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                ue = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, c, l;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    n = t.setWalletAddress, r = t.setNetworkId, a = t.setWalletIsConnected, t.walletIsConnected, "undefined" == typeof window.okxwallet && alert("PLEASE INSTALL OKX WALLET TO USE THIS OPTION."), i = function() {
                                        var e = Object(s.a)(U().mark((function e(t) {
                                            return U().wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        n(t.addresses.ethereum.address), r(1), a(!0), localStorage.setItem("@WALLET_TYPE", "okx");
                                                    case 4:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e)
                                        })));
                                        return function(t) {
                                            return e.apply(this, arguments)
                                        }
                                    }(), o = function(e) {
                                        console.log(e)
                                    }, c = function(e) {
                                        console.log(e)
                                    }, l = function() {}, G.a.init({
                                        success: i,
                                        changed: o,
                                        error: c,
                                        uninstall: l
                                    }).then((function(e) {
                                        console.log(e)
                                    })).catch((function(e) {
                                        console.error(e)
                                    }));
                                case 7:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                pe = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, c, l, u, p, m, y, f = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (n = f.length > 1 && void 0 !== f[1] ? f[1] : function() {
                                            return null
                                        }, r = f.length > 2 ? f[2] : void 0, a = f.length > 3 ? f[3] : void 0, f.length > 4 ? f[4] : void 0) {
                                        e.next = 9;
                                        break
                                    }
                                    return localStorage.setItem("@CHAIN_ID", t), e.abrupt("return", n(t));
                                case 9:
                                    if (i = localStorage.getItem("@WALLET"), o = localStorage.getItem("@WALLET_TYPE"), !(i && i.length >= 1)) {
                                        e.next = 59;
                                        break
                                    }
                                    c = R.includes(String(t)), r(), e.t0 = o, e.next = "metamask" === e.t0 ? 17 : "coinbase" === e.t0 ? 36 : "wallet_connect" === e.t0 ? 51 : 56;
                                    break;
                                case 17:
                                    if (e.prev = 17, !c) {
                                        e.next = 26;
                                        break
                                    }
                                    return e.next = 21, null === (l = window.ethereum) || void 0 === l ? void 0 : l.request({
                                        method: "wallet_switchEthereumChain",
                                        params: [{
                                            chainId: d.a.utils.toHex(t)
                                        }]
                                    }).catch(Object(s.a)(U().mark((function e() {
                                        var n;
                                        return U().wrap((function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                                case 0:
                                                    if (56 != +t) {
                                                        e.next = 4;
                                                        break
                                                    }
                                                    return window.ethereum.request({
                                                        method: "wallet_addEthereumChain",
                                                        params: [{
                                                            chainId: "0x38",
                                                            chainName: "Binance Smart Chain",
                                                            nativeCurrency: {
                                                                name: "Binance Coin",
                                                                symbol: "BNB",
                                                                decimals: 18
                                                            },
                                                            rpcUrls: ["https://bsc-dataseed.binance.org/"],
                                                            blockExplorerUrls: ["https://bscscan.com"]
                                                        }]
                                                    }).catch((function(e) {
                                                        console.log(e)
                                                    })), e.next = 4, null === (n = window.ethereum) || void 0 === n ? void 0 : n.request({
                                                        method: "wallet_switchEthereumChain",
                                                        params: [{
                                                            chainId: d.a.utils.toHex(t)
                                                        }]
                                                    });
                                                case 4:
                                                case "end":
                                                    return e.stop()
                                            }
                                        }), e)
                                    }))));
                                case 21:
                                    localStorage.setItem("@CHAIN_ID", t), n(t), a(), e.next = 30;
                                    break;
                                case 26:
                                    return e.next = 28, null === (u = window.ethereum) || void 0 === u ? void 0 : u.request({
                                        method: "wallet_switchEthereumChain",
                                        params: [{
                                            chainId: d.a.utils.toHex("1")
                                        }]
                                    });
                                case 28:
                                    n("1"), a();
                                case 30:
                                    e.next = 35;
                                    break;
                                case 32:
                                    e.prev = 32, e.t1 = e.catch(17), a();
                                case 35:
                                    return e.abrupt("break", 57);
                                case 36:
                                    return p = new W.a({
                                        appName: "Voltichange",
                                        appLogoUrl: "/img/logo-mobile",
                                        darkMode: !1
                                    }), e.next = 39, p.makeWeb3Provider(1 == +t ? "https://mainnet.infura.io/v3/".concat(Z) : "https://bsc-dataseed1.binance.org/", t);
                                case 39:
                                    return m = e.sent, e.next = 42, m.enable();
                                case 42:
                                    return z = new d.a(m), window.web3 = new d.a(m), e.t2 = n, e.next = 47, window.web3.eth.getChainId();
                                case 47:
                                    return e.t3 = e.sent, (0, e.t2)(e.t3), localStorage.setItem("@WALLET_TYPE", "coinbase"), e.abrupt("break", 57);
                                case 51:
                                    return y = new F.a({
                                        chainId: t,
                                        rpc: {
                                            56: "https://bsc-dataseed.binance.org/"
                                        },
                                        infuraId: Z
                                    }), e.next = 54, y.close();
                                case 54:
                                    return ce({
                                        walletIsConnected: !0,
                                        chainid: t,
                                        setNetworkId: n,
                                        setWalletAddress: function() {
                                            return null
                                        },
                                        setWalletIsConnected: function() {
                                            return null
                                        }
                                    }), e.abrupt("break", 57);
                                case 56:
                                    return e.abrupt("break", 57);
                                case 57:
                                    e.next = 62;
                                    break;
                                case 59:
                                    a(), localStorage.setItem("@CHAIN_ID", t), n(t);
                                case 62:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [17, 32]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                de = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r) {
                        var a, i, o, s, c, l;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (t) {
                                        e.next = 2;
                                        break
                                    }
                                    return e.abrupt("return", "0");
                                case 2:
                                    if (!n) {
                                        e.next = 12;
                                        break
                                    }
                                    return e.next = 5, z.eth.getBalance(t);
                                case 5:
                                    return a = e.sent, i = z.utils.fromWei(a), e.next = 9, i;
                                case 9:
                                    return e.abrupt("return", e.sent);
                                case 12:
                                    return e.next = 14, ye(r);
                                case 14:
                                    return e.sent, e.next = 17, ne({
                                        functionName: "decimals",
                                        abi: g,
                                        argumments: [],
                                        chain: (null === (o = h.filter((function(e) {
                                            return +e.id === +localStorage.getItem("@CHAIN_ID")
                                        }))[0]) || void 0 === o ? void 0 : o.chainName) || "eth",
                                        token: r
                                    });
                                case 17:
                                    return c = e.sent, e.next = 20, ne({
                                        functionName: "balanceOf",
                                        abi: g,
                                        argumments: [t],
                                        chain: (null === (s = h.filter((function(e) {
                                            return +e.id === +localStorage.getItem("@CHAIN_ID")
                                        }))[0]) || void 0 === s ? void 0 : s.chainName) || "eth",
                                        token: r
                                    });
                                case 20:
                                    return l = e.sent, e.t0 = Number, e.next = 24, y.utils.formatUnits(l, +c);
                                case 24:
                                    return e.t1 = e.sent, e.abrupt("return", (0, e.t0)(e.t1).toFixed(c));
                                case 26:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n, r) {
                        return e.apply(this, arguments)
                    }
                }(),
                me = function(e) {
                    var t, n, r, a, i, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 5;
                    return !+e || +e <= 0 ? 0 : new Intl.NumberFormat("en-us", {
                        currency: "USD",
                        minimumFractionDigits: o
                    }).format(+((null === (t = String(e)) || void 0 === t ? void 0 : t.split(".")[0]) + "." + ((null === (n = String(e)) || void 0 === n || null === (r = n.split(".")[1]) || void 0 === r ? void 0 : r.length) >= 1 ? null === (a = String(e)) || void 0 === a || null === (i = a.split(".")[1]) || void 0 === i ? void 0 : i.slice(0, o) : 0) || 0))
                },
                ye = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = a.length > 1 && void 0 !== a[1] ? a[1] : g, e.next = 3, localStorage.getItem("@WALLET");
                                case 3:
                                    return e.sent, e.next = 6, new z.eth.Contract(n, t);
                                case 6:
                                    return r = e.sent, e.abrupt("return", r);
                                case 8:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                fe = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r) {
                        var a, i, o;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (t && n && r) {
                                        e.next = 2;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 2:
                                    return e.prev = 2, e.next = 5, ye(n);
                                case 5:
                                    return a = e.sent, i = "ETH" === String(r).toUpperCase() ? q : V, e.next = 9, ne({
                                        functionName: "allowance",
                                        abi: g,
                                        argumments: [t, i],
                                        chain: r,
                                        token: n
                                    });
                                case 9:
                                    return o = e.sent, e.t0 = console, e.next = 13, a.methods.allowance(t, i);
                                case 13:
                                    return e.t1 = e.sent, e.t2 = Object, e.next = 17, a.methods.allowance(t, i);
                                case 17:
                                    return e.t3 = e.sent, e.t4 = e.t2.keys.call(e.t2, e.t3), e.t0.log.call(e.t0, "await tokenContract.methods.allowance(account, addr)", e.t1, e.t4), e.abrupt("return", +o >= 1);
                                case 23:
                                    return e.prev = 23, e.t5 = e.catch(2), e.abrupt("return", !1);
                                case 26:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [2, 23]
                        ])
                    })));
                    return function(t, n, r) {
                        return e.apply(this, arguments)
                    }
                }(),
                he = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r, a, i, o) {
                        var s, c, l, u, p, d = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (s = d.length > 6 && void 0 !== d[6] ? d[6] : "eth", c = d.length > 7 ? d[7] : void 0, l = d.length > 8 ? d[8] : void 0, u = d.length > 9 ? d[9] : void 0, d.length > 10 ? d[10] : void 0, .5, p = a && (null === a || void 0 === a ? void 0 : a.length) >= 1 ? a : "0x9D8c87Af93992B0555442E775AA79b1b21925E30", "ETH" === String(s).toUpperCase()) {
                                        e.next = 14;
                                        break
                                    }
                                    return e.next = 10, be(t, n, r, p, i, o, s, c, l, u, !0);
                                case 10:
                                    return e.t0 = e.sent, e.abrupt("return", {
                                        inputAmount: e.t0
                                    });
                                case 14:
                                    return e.next = 16, ve(t, n, r, p, i, o, s, c, l, !0, !0);
                                case 16:
                                    return e.t1 = e.sent, e.abrupt("return", {
                                        inputAmount: e.t1
                                    });
                                case 18:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n, r, a, i, o) {
                        return e.apply(this, arguments)
                    }
                }(),
                ge = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r, a, i, o, s, c, l) {
                        var u, p, d = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (u = !(d.length > 9 && void 0 !== d[9]) || d[9], d.length > 10 ? d[10] : void 0, p = a && (null === a || void 0 === a ? void 0 : a.length) >= 1 ? a : "0x9D8c87Af93992B0555442E775AA79b1b21925E30", "ETH" === String(s).toUpperCase()) {
                                        e.next = 9;
                                        break
                                    }
                                    return e.next = 6, be(t, n, r, p, i, o, s, c, l, u);
                                case 6:
                                    return e.abrupt("return", e.sent);
                                case 9:
                                    return e.next = 11, ve(t, n, r, p, i, o, s, c, l);
                                case 11:
                                    return e.abrupt("return", e.sent);
                                case 12:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n, r, a, i, o, s, c, l) {
                        return e.apply(this, arguments)
                    }
                }(),
                be = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r, a, i, o, s, c, l) {
                        var u, p, d = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (!(d.length > 9 && void 0 !== d[9]) || d[9], d.length > 10 && void 0 !== d[10] && d[10], n !== r) {
                                        e.next = 4;
                                        break
                                    }
                                    return e.abrupt("return", t);
                                case 4:
                                    return e.t0 = console, e.t1 = t, e.next = 8, Ee(n);
                                case 8:
                                    return e.t2 = e.sent, e.t3 = n, e.t0.log.call(e.t0, "inAmount, await getDecimalsToken(tokenin)", e.t1, e.t2, e.t3), e.t4 = I, e.t5 = "/".concat("0x10ED43C718714eb63d5aA57B78B54704E256024E", "/function?chain=bsc&function_name=getAmountsOut"), e.t6 = [{
                                        inputs: [{
                                            internalType: "uint256",
                                            name: "amountIn",
                                            type: "uint256"
                                        }, {
                                            internalType: "address[]",
                                            name: "path",
                                            type: "address[]"
                                        }],
                                        name: "getAmountsOut",
                                        outputs: [{
                                            internalType: "uint256[]",
                                            name: "amounts",
                                            type: "uint256[]"
                                        }],
                                        stateMutability: "view",
                                        type: "function"
                                    }], e.t7 = y.utils, e.t8 = t, e.next = 18, Ee(n);
                                case 18:
                                    if (e.t9 = e.sent, e.t9) {
                                        e.next = 21;
                                        break
                                    }
                                    e.t9 = 9;
                                case 21:
                                    return e.t10 = +e.t9, e.t11 = e.t7.parseUnits.call(e.t7, e.t8, e.t10).toString(), e.next = 25, Se(n, r, a, t, "bsc", c);
                                case 25:
                                    return e.t12 = e.sent, e.t13 = {
                                        amountIn: e.t11,
                                        path: e.t12
                                    }, e.t14 = {
                                        abi: e.t6,
                                        params: e.t13
                                    }, e.next = 30, e.t4.post.call(e.t4, e.t5, e.t14);
                                case 30:
                                    return u = e.sent, p = u.data, e.t16 = +p[p.length - 1], e.t17 = Math, e.next = 36, Ee(r);
                                case 36:
                                    return e.t18 = e.sent, e.t19 = +e.t17.pow.call(e.t17, 10, e.t18), e.t15 = e.t16 / e.t19, e.next = 41, Ee(r);
                                case 41:
                                    return e.t20 = e.sent, e.abrupt("return", e.t15.toFixed.call(e.t15, e.t20).toString());
                                case 43:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n, r, a, i, o, s, c, l) {
                        return e.apply(this, arguments)
                    }
                }(),
                ve = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r, a, i, o, s, c, l) {
                        var u, p, d, m, f, h, g, b, v, x = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return !(x.length > 9 && void 0 !== x[9]) || x[9], x.length > 10 && void 0 !== x[10] && x[10], u = localStorage.getItem("@CHAIN_ID"), e.next = 5, P.get("/api/prices/token/".concat(1 === +u ? "eth" : "bsc", "/").concat(n));
                                case 5:
                                    return p = e.sent, d = p.data, e.next = 9, P.get("/api/prices/token/".concat(1 === +u ? "eth" : "bsc", "/").concat(r));
                                case 9:
                                    if (m = e.sent, f = m.data, h = i || d, g = o || f, n !== r) {
                                        e.next = 15;
                                        break
                                    }
                                    return e.abrupt("return", t);
                                case 15:
                                    if (n && n) {
                                        e.next = 17;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 17:
                                    return console.log(h, g, n, r), console.log(Number(t).toFixed(h.decimals), t, h.decimals, n), e.t0 = I, e.t1 = "/".concat("0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D", "/function?chain=eth&function_name=getAmountsOut"), e.t2 = [{
                                        inputs: [{
                                            internalType: "uint256",
                                            name: "amountIn",
                                            type: "uint256"
                                        }, {
                                            internalType: "address[]",
                                            name: "path",
                                            type: "address[]"
                                        }],
                                        name: "getAmountsOut",
                                        outputs: [{
                                            internalType: "uint256[]",
                                            name: "amounts",
                                            type: "uint256[]"
                                        }],
                                        stateMutability: "view",
                                        type: "function"
                                    }], e.t3 = y.utils.parseUnits(Number(t).toFixed(h.decimals), h.decimals).toString(), e.next = 25, Se(n, r, a, t, "eth", c);
                                case 25:
                                    return e.t4 = e.sent, e.t5 = {
                                        amountIn: e.t3,
                                        path: e.t4
                                    }, e.t6 = {
                                        abi: e.t2,
                                        params: e.t5
                                    }, e.next = 30, e.t0.post.call(e.t0, e.t1, e.t6);
                                case 30:
                                    return b = e.sent, v = b.data, e.t8 = +v[v.length - 1], e.t9 = Math, e.next = 36, Ee(r);
                                case 36:
                                    return e.t10 = e.sent, e.t11 = +e.t9.pow.call(e.t9, 10, e.t10), e.t7 = e.t8 / e.t11, e.next = 41, Ee(r);
                                case 41:
                                    return e.t12 = e.sent, e.abrupt("return", e.t7.toFixed.call(e.t7, e.t12).toString());
                                case 43:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n, r, a, i, o, s, c, l) {
                        return e.apply(this, arguments)
                    }
                }(),
                xe = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r, a, i) {
                        var o, s, c;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, ye(t);
                                case 2:
                                    return o = e.sent, s = "BNB" === i ? V : q, "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff", e.next = 7, re({
                                        provider: o.methods,
                                        abi: g,
                                        address: t,
                                        account: a,
                                        argumments: [s, "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"],
                                        chain: i,
                                        method: "approve",
                                        value: 0
                                    });
                                case 7:
                                    return c = e.sent, e.abrupt("return", c);
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n, r, a, i) {
                        return e.apply(this, arguments)
                    }
                }(),
                we = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, s, c, l, u, p, d, m, y, f, h, g, k;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (!(navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i)) || !(null === (n = window) || void 0 === n ? void 0 : n.web3)) {
                                        e.next = 52;
                                        break
                                    }
                                    if ("BNB" !== t) {
                                        e.next = 8;
                                        break
                                    }
                                    return e.next = 4, new window.web3.eth.Contract(v, V);
                                case 4:
                                    return r = e.sent, e.abrupt("return", r);
                                case 8:
                                    if ("PANCKAKESWAP" !== t) {
                                        e.next = 15;
                                        break
                                    }
                                    return e.next = 11, new window.web3.eth.Contract(T, "0x10ED43C718714eb63d5aA57B78B54704E256024E");
                                case 11:
                                    return a = e.sent, e.abrupt("return", a);
                                case 15:
                                    if ("UNISWAPWAP" !== t) {
                                        e.next = 22;
                                        break
                                    }
                                    return e.next = 18, new window.web3.eth.Contract(O, "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D");
                                case 18:
                                    return i = e.sent, e.abrupt("return", i);
                                case 22:
                                    if ("WETH" !== t) {
                                        e.next = 29;
                                        break
                                    }
                                    return e.next = 25, new window.web3.eth.Contract(x, Y);
                                case 25:
                                    return o = e.sent, e.abrupt("return", o);
                                case 29:
                                    if ("WBNB" !== t) {
                                        e.next = 36;
                                        break
                                    }
                                    return e.next = 32, new window.web3.eth.Contract(w, J);
                                case 32:
                                    return s = e.sent, e.abrupt("return", s);
                                case 36:
                                    if (!String(t).includes("burn-")) {
                                        e.next = 46;
                                        break
                                    }
                                    return e.next = 39, new window.web3.eth.Contract(j, Q);
                                case 39:
                                    return c = e.sent, e.next = 42, new window.web3.eth.Contract(L, ee);
                                case 42:
                                    return l = e.sent, e.abrupt("return", "eth" === String(t).split("-")[1] ? c : l);
                                case 46:
                                    return e.next = 48, new window.web3.eth.Contract(b, q);
                                case 48:
                                    return u = e.sent, e.abrupt("return", u);
                                case 50:
                                    e.next = 101;
                                    break;
                                case 52:
                                    if ("BNB" !== t) {
                                        e.next = 59;
                                        break
                                    }
                                    return e.next = 55, new z.eth.Contract(v, V);
                                case 55:
                                    return p = e.sent, e.abrupt("return", p);
                                case 59:
                                    if ("PANCKAKESWAP" !== t) {
                                        e.next = 66;
                                        break
                                    }
                                    return e.next = 62, new z.eth.Contract(T, "0x10ED43C718714eb63d5aA57B78B54704E256024E");
                                case 62:
                                    return d = e.sent, e.abrupt("return", d);
                                case 66:
                                    if ("UNISWAPWAP" !== t) {
                                        e.next = 73;
                                        break
                                    }
                                    return e.next = 69, new z.eth.Contract(O, "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D");
                                case 69:
                                    return m = e.sent, e.abrupt("return", m);
                                case 73:
                                    if ("WETH" !== t) {
                                        e.next = 80;
                                        break
                                    }
                                    return e.next = 76, new z.eth.Contract(x, Y);
                                case 76:
                                    return y = e.sent, e.abrupt("return", y);
                                case 80:
                                    if ("WBNB" !== t) {
                                        e.next = 87;
                                        break
                                    }
                                    return e.next = 83, new z.eth.Contract(w, J);
                                case 83:
                                    return f = e.sent, e.abrupt("return", f);
                                case 87:
                                    if (!String(t).includes("burn-")) {
                                        e.next = 97;
                                        break
                                    }
                                    return e.next = 90, new z.eth.Contract(j, Q);
                                case 90:
                                    return h = e.sent, e.next = 93, new z.eth.Contract(L, ee);
                                case 93:
                                    return g = e.sent, e.abrupt("return", "eth" === String(t).split("-")[1] ? h : g);
                                case 97:
                                    return e.next = 99, new z.eth.Contract(b, q);
                                case 99:
                                    return k = e.sent, e.abrupt("return", k);
                                case 101:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                ke = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r, a, i, o, s, c, l, u, p) {
                        var d, m, h, w, k, E, T, O, j, L, S, N, _, A, I, C, M, D, P, F, B, G, H = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return d = H.length > 11 && void 0 !== H[11] && H[11], m = H.length > 12 ? H[12] : void 0, H.length > 13 ? H[13] : void 0, H.length > 14 ? H[14] : void 0, e.prev = 4, e.next = 7, Se(t, n, c, a, o, p, !1);
                                case 7:
                                    if (h = e.sent, w = String(Number(a.split(".")[1]).toFixed(0)).length >= 6 ? (+a - +a / 100 * .04).toString() : a, !m) {
                                        e.next = 13;
                                        break
                                    }
                                    e.t0 = "0", e.next = 18;
                                    break;
                                case 13:
                                    return e.t1 = Number(+i - +i / 100 * .02), e.next = 16, Ee(n);
                                case 16:
                                    e.t2 = e.sent, e.t0 = e.t1.toFixed.call(e.t1, e.t2).toString();
                                case 18:
                                    if (k = e.t0, console.log("pathpathpathpathpath", h), !d || "ethin" !== s && "ethout" !== s) {
                                        e.next = 35;
                                        break
                                    }
                                    return e.next = 23, ye(Y, x);
                                case 23:
                                    if (E = e.sent, "ethin" !== s) {
                                        e.next = 31;
                                        break
                                    }
                                    return T = y.utils.parseUnits(w, 18).toString(), e.next = 28, re({
                                        abi: x,
                                        address: Y,
                                        account: c,
                                        argumments: [],
                                        chain: o,
                                        method: "deposit",
                                        provider: E,
                                        value: T
                                    });
                                case 28:
                                    return e.abrupt("return", e.sent);
                                case 31:
                                    return O = m ? 0 : y.utils.parseUnits(k, 18).toString(), e.next = 34, re({
                                        abi: x,
                                        address: Y,
                                        account: c,
                                        argumments: [O],
                                        chain: o,
                                        method: "withdraw",
                                        provider: E,
                                        value: 0
                                    });
                                case 34:
                                    return e.abrupt("return", e.sent);
                                case 35:
                                    return e.next = 37, we(o);
                                case 37:
                                    return j = e.sent, e.next = 40, we("UNISWAPWAP");
                                case 40:
                                    return e.sent, e.next = 43, we("eth" === String(o).toLowerCase() ? "WETH" : "WBNB");
                                case 43:
                                    return L = e.sent, e.next = 46, ye(t);
                                case 46:
                                    return e.sent, e.next = 49, ne({
                                        functionName: "decimals",
                                        abi: g,
                                        argumments: [],
                                        chain: o,
                                        token: t
                                    });
                                case 49:
                                    return S = e.sent, e.next = 52, ye(n);
                                case 52:
                                    return e.sent, e.next = 55, ne({
                                        functionName: "decimals",
                                        abi: g,
                                        argumments: [],
                                        chain: o,
                                        token: n
                                    });
                                case 55:
                                    if (N = e.sent, console.log("tokenindecimals,tokenoutdecimals", {
                                            tokenindecimals: S,
                                            tokenoutdecimals: N
                                        }), "ethereum" !== l.id || n != ("eth" === String(o).toLowerCase() ? Y : J)) {
                                        e.next = 68;
                                        break
                                    }
                                    return e.t3 = y.utils, e.t4 = a, e.next = 62, Ee(n);
                                case 62:
                                    return e.t5 = e.sent, _ = e.t3.parseUnits.call(e.t3, e.t4, e.t5), A = _.toString(), e.next = 67, re({
                                        abi: x,
                                        address: Y,
                                        account: c,
                                        argumments: [],
                                        chain: o,
                                        method: "deposit",
                                        provider: L,
                                        value: A
                                    });
                                case 67:
                                    return e.abrupt("return", e.sent);
                                case 68:
                                    if ("ethereum" !== u.id || t != ("eth" === String(o).toLowerCase() ? Y : J)) {
                                        e.next = 78;
                                        break
                                    }
                                    return e.t6 = y.utils, e.t7 = a, e.next = 73, Ee(n);
                                case 73:
                                    return e.t8 = e.sent, I = e.t6.parseUnits.call(e.t6, e.t7, e.t8).toString(), e.next = 77, re({
                                        abi: x,
                                        address: Y,
                                        account: c,
                                        argumments: [I],
                                        chain: o,
                                        method: "withdraw",
                                        provider: L,
                                        value: 0
                                    });
                                case 77:
                                    return e.abrupt("return", e.sent);
                                case 78:
                                    if (!r) {
                                        e.next = 123;
                                        break
                                    }
                                    return y.utils.parseUnits(k, +N || 18).toString(), e.next = 82, he(k, t, n, c, l, u, o, p, null, !1, !0);
                                case 82:
                                    if (C = e.sent, M = C.inputAmount, C._fee, D = M, 0 !== +p) {
                                        e.next = 97;
                                        break
                                    }
                                    return e.t10 = f.a, e.t11 = y.utils, e.t12 = k, e.next = 92, Ee(n);
                                case 92:
                                    e.t13 = e.sent, e.t14 = e.t11.parseUnits.call(e.t11, e.t12, e.t13).toString(), e.t9 = e.t10.from.call(e.t10, e.t14), e.next = 105;
                                    break;
                                case 97:
                                    return e.t15 = f.a, e.t16 = y.utils, e.t17 = k, e.next = 102, Ee(n);
                                case 102:
                                    e.t18 = e.sent, e.t19 = e.t16.parseUnits.call(e.t16, e.t17, e.t18).toString(), e.t9 = e.t15.from.call(e.t15, e.t19).mul(100 - +p).div(100);
                                case 105:
                                    if (P = e.t9, "ethin" !== s) {
                                        e.next = 112;
                                        break
                                    }
                                    return e.next = 109, re({
                                        abi: "eth" === String(o).toLowerCase() ? b : v,
                                        address: "eth" === String(o).toLowerCase() ? q : V,
                                        account: c,
                                        argumments: [P, h],
                                        chain: o,
                                        method: "swapETHforExactToken",
                                        provider: j,
                                        value: D.toString()
                                    });
                                case 109:
                                    return e.abrupt("return", e.sent);
                                case 112:
                                    if ("ethout" !== s) {
                                        e.next = 118;
                                        break
                                    }
                                    return e.next = 115, re({
                                        abi: "eth" === String(o).toLowerCase() ? b : v,
                                        address: "eth" === String(o).toLowerCase() ? q : V,
                                        account: c,
                                        argumments: [P, D.toString(), h],
                                        chain: o,
                                        method: "swapTokenForExactETH",
                                        provider: j,
                                        value: 0
                                    });
                                case 115:
                                    return e.abrupt("return", e.sent);
                                case 118:
                                    return e.next = 120, re({
                                        abi: "eth" === String(o).toLowerCase() ? b : v,
                                        address: "eth" === String(o).toLowerCase() ? q : V,
                                        account: c,
                                        argumments: [P, D.toString(), h],
                                        chain: o,
                                        method: "swapTokenForExactToken",
                                        provider: j,
                                        value: 0
                                    });
                                case 120:
                                    return e.abrupt("return", e.sent);
                                case 121:
                                    e.next = 188;
                                    break;
                                case 123:
                                    if (F = y.utils.parseUnits(Number(w).toFixed(+S || 18), +S || 18).toString(), 0, t === n) {
                                        e.next = 145;
                                        break
                                    }
                                    if ("ETH" !== String(o).toUpperCase()) {
                                        e.next = 142;
                                        break
                                    }
                                    return e.t20 = console, e.next = 130, ge(w, t, n, c, l, u, o, p, null, !1);
                                case 130:
                                    return e.t21 = e.sent, e.t20.log.call(e.t20, "\xe7\xe7\xe7\xe7asefll\xe7adf", e.t21), e.t22 = y.utils, e.next = 135, ge(w, t, n, c, l, u, o, p, null, !1);
                                case 135:
                                    return e.t23 = e.sent, e.next = 138, Ee(n);
                                case 138:
                                    e.t24 = e.sent, e.t22.parseUnits.call(e.t22, e.t23, e.t24).toString(), e.next = 145;
                                    break;
                                case 142:
                                    return e.next = 144, ne({
                                        functionName: "getAmountOutMinWithFees",
                                        abi: b,
                                        argumments: [F, h],
                                        chain: o,
                                        token: "eth" === String(o) ? q : V
                                    });
                                case 144:
                                    e.sent;
                                case 145:
                                    if (0 !== +p) {
                                        e.next = 156;
                                        break
                                    }
                                    return e.t26 = f.a, e.t27 = y.utils, e.t28 = k, e.next = 151, Ee(n);
                                case 151:
                                    e.t29 = e.sent, e.t30 = e.t27.parseUnits.call(e.t27, e.t28, e.t29).toString(), e.t25 = e.t26.from.call(e.t26, e.t30), e.next = 164;
                                    break;
                                case 156:
                                    return e.t31 = f.a, e.t32 = y.utils, e.t33 = k, e.next = 161, Ee(n);
                                case 161:
                                    e.t34 = e.sent, e.t35 = e.t32.parseUnits.call(e.t32, e.t33, e.t34).toString(), e.t25 = e.t31.from.call(e.t31, e.t35).mul(100 - +p).div(100);
                                case 164:
                                    if (B = e.t25, G = B.toString(), "ethin" !== s) {
                                        e.next = 173;
                                        break
                                    }
                                    return console.log("SwapContract", j), e.next = 170, re({
                                        abi: "eth" === String(o).toLowerCase() ? b : v,
                                        address: "eth" === String(o).toLowerCase() ? q : V,
                                        account: c,
                                        argumments: [G, h],
                                        chain: o,
                                        method: "swapETHForToken",
                                        provider: null === j || void 0 === j ? void 0 : j.methods,
                                        value: F
                                    });
                                case 170:
                                    return e.abrupt("return", e.sent);
                                case 173:
                                    if ("ethout" !== s) {
                                        e.next = 179;
                                        break
                                    }
                                    return e.next = 176, re({
                                        abi: "eth" === String(o).toLowerCase() ? b : v,
                                        address: "eth" === String(o).toLowerCase() ? q : V,
                                        account: c,
                                        argumments: [F, G, h],
                                        chain: o,
                                        method: "swapTokenForETH",
                                        provider: null === j || void 0 === j ? void 0 : j.methods,
                                        value: 0
                                    });
                                case 176:
                                    return e.abrupt("return", e.sent);
                                case 179:
                                    if ("ETH" !== String(o).toUpperCase()) {
                                        e.next = 185;
                                        break
                                    }
                                    return e.next = 182, re({
                                        abi: "eth" === String(o).toLowerCase() ? b : v,
                                        address: "eth" === String(o).toLowerCase() ? q : V,
                                        account: c,
                                        argumments: [F, G, h],
                                        chain: o,
                                        method: "swapTokenForToken",
                                        provider: null === j || void 0 === j ? void 0 : j.methods,
                                        value: 0
                                    });
                                case 182:
                                    return e.abrupt("return", e.sent);
                                case 185:
                                    return e.next = 187, re({
                                        abi: "eth" === String(o).toLowerCase() ? b : v,
                                        address: "eth" === String(o).toLowerCase() ? q : V,
                                        account: c,
                                        argumments: [F, G, h],
                                        chain: o,
                                        method: "swapTokenForToken",
                                        provider: null === j || void 0 === j ? void 0 : j.methods,
                                        value: 0
                                    });
                                case 187:
                                    return e.abrupt("return", e.sent);
                                case 188:
                                    e.next = 193;
                                    break;
                                case 190:
                                    e.prev = 190, e.t36 = e.catch(4), console.error(e.t36);
                                case 193:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [4, 190]
                        ])
                    })));
                    return function(t, n, r, a, i, o, s, c, l, u, p) {
                        return e.apply(this, arguments)
                    }
                }(),
                Ee = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = localStorage.getItem("@CHAIN_ID"), e.next = 3, P.get("/api/prices/token/".concat(1 === +n ? "eth" : "bsc", "/").concat(t));
                                case 3:
                                    return r = e.sent, a = r.data, console.log("klsdfklasdfklasdfkl", a), e.abrupt("return", +a.decimals);
                                case 7:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                Te = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = localStorage.getItem("@CHAIN_ID"), e.next = 3, P.get("/api/prices/token/".concat(1 === +n ? "eth" : "bsc", "/").concat(t));
                                case 3:
                                    return r = e.sent, a = r.data, e.abrupt("return", {
                                        name: a.name,
                                        symbol: a.symbol
                                    });
                                case 6:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                Oe = function() {
                    var e = Object(s.a)(U().mark((function e(t) {
                        var n, r, a, i, o, s, c, l;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, P.get("/api/prices/gasPrice");
                                case 2:
                                    return n = e.sent, r = n.data, a = f.a.from(+r.mid), i = f.a.from(+r.low), o = f.a.from(+r.hight), s = f.a.from(+r.gasLimit), e.next = 10, C.get("/simple/price?ids=".concat("ETH" === String(t).toUpperCase() ? "ethereum" : "wbnb", "&vs_currencies=usd"));
                                case 10:
                                    return c = e.sent, l = c.data["ETH" === String(t).toUpperCase() ? "ethereum" : "wbnb"].usd, e.abrupt("return", {
                                        gwei: {
                                            low: a.toString(),
                                            mid: i.toString(),
                                            high: o.toString()
                                        },
                                        eth: {
                                            low: Number(y.utils.formatUnits(y.utils.parseUnits(a.mul(s).toString(), 9).toString(), 18).toString()).toFixed(4),
                                            mid: Number(y.utils.formatUnits(y.utils.parseUnits(i.mul(s).toString(), 9).toString(), 18).toString()).toFixed(4),
                                            high: Number(y.utils.formatUnits(y.utils.parseUnits(o.mul(s).toString(), 9).toString(), 18).toString()).toFixed(4)
                                        },
                                        usd: {
                                            low: Number(+l * +y.utils.formatUnits(y.utils.parseUnits(a.mul(s).toString(), 9).toString(), 18).toString()).toFixed(2),
                                            mid: Number(+l * +y.utils.formatUnits(y.utils.parseUnits(i.mul(s).toString(), 9).toString(), 18).toString()).toFixed(2),
                                            high: Number(+l * +y.utils.formatUnits(y.utils.parseUnits(o.mul(s).toString(), 9).toString(), 18).toString()).toFixed(2)
                                        }
                                    });
                                case 13:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                je = function() {
                    var e = Object(s.a)(U().mark((function e() {
                        var t, n, r, a = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (t = a.length > 0 && void 0 !== a[0] ? a[0] : "", n = a.length > 1 && void 0 !== a[1] ? a[1] : "eth", "ETH" === String(n).toUpperCase()) {
                                        e.next = 4;
                                        break
                                    }
                                    return e.abrupt("return", 0);
                                case 4:
                                    if (!(t.length <= 0)) {
                                        e.next = 6;
                                        break
                                    }
                                    return e.abrupt("return", 0);
                                case 6:
                                    return e.next = 8, ye($, k);
                                case 8:
                                    return e.sent, e.next = 11, ne({
                                        functionName: "balanceOf",
                                        abi: k,
                                        argumments: [t],
                                        chain: n,
                                        token: $
                                    });
                                case 11:
                                    return r = e.sent, console.log({
                                        functionName: "balanceOf",
                                        abi: k,
                                        argumments: [t],
                                        chain: n,
                                        token: $,
                                        res: r
                                    }), e.abrupt("return", r);
                                case 14:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                Le = function() {
                    var e = Object(s.a)(U().mark((function e(t, n) {
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if ("BNB" !== n.symbol) {
                                        e.next = 2;
                                        break
                                    }
                                    return e.abrupt("return", !0);
                                case 2:
                                    return e.next = 4, ye("BNB" === n.symbol ? "0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73" : "0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f", E);
                                case 4:
                                    return e.sent, e.next = 7, ne({
                                        functionName: "getPair",
                                        abi: E,
                                        argumments: ["BNB" === n.symbol ? X : K, t],
                                        chain: n.symbol,
                                        token: "BNB" === n.symbol ? "0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73" : "0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f"
                                    });
                                case 7:
                                    return e.t0 = e.sent, e.abrupt("return", "0x0000000000000000000000000000000000000000" === e.t0);
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }(),
                Se = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r, a, i, o) {
                        var s, c, l, u, p, d, m, f, h, g = arguments;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (g.length > 6 && void 0 !== g[6] && g[6], console.log(a), "eth" !== String(i).toLowerCase()) {
                                        e.next = 29;
                                        break
                                    }
                                    return e.t0 = "https://api.0x.org/swap/v1/quote?buyToken=".concat(n, "&sellToken=").concat(t, "&sellAmount="), e.t1 = y.utils, e.t2 = Number(a), e.next = 8, Ee(t);
                                case 8:
                                    return e.t3 = e.sent, e.t4 = e.t2.toFixed.call(e.t2, e.t3), e.next = 12, Ee(t);
                                case 12:
                                    return e.t5 = e.sent, e.t6 = e.t1.parseUnits.call(e.t1, e.t4, e.t5), c = e.t0.concat.call(e.t0, e.t6, "&excludedSources=Native,Eth2Dai,Kyber,Curve,LiquidityProvider,MultiBridge,Balancer,Balancer_V2,CREAM,Bancor,MakerPsm,mStable,Mooniswap,MultiHop,Shell,Swerve,SnowSwap,SushiSwap,DODO,DODO_V2,CryptoCom,Linkswap,KyberDMM,Smoothy,Component,Saddle,xSigma,Curve_V2,Lido,ShibaSwap,Clipper,MDex"), e.next = 17, N.a.get(c);
                                case 17:
                                    return l = e.sent, u = l.data, e.t7 = console, e.t8 = a, e.t9 = t, e.next = 24, Ee(t);
                                case 24:
                                    return e.t10 = e.sent, e.t7.log.call(e.t7, e.t8, e.t9, e.t10), e.abrupt("return", null === (s = u.orders.filter((function(e) {
                                        return e.source.includes("Uniswap")
                                    }))[0]) || void 0 === s ? void 0 : s.fillData.tokenAddressPath);
                                case 29:
                                    return e.t11 = "https://bsc.api.0x.org/swap/v1/quote?buyToken=".concat(n, "&sellToken=").concat(t, "&sellAmount="), e.t12 = y.utils, e.t13 = a, e.next = 34, Ee(t);
                                case 34:
                                    return e.t14 = e.sent, e.t15 = e.t12.parseUnits.call(e.t12, e.t13, e.t14), m = e.t11.concat.call(e.t11, e.t15, "&excludedSources=BakerySwap,Belt,DODO,DODO_V2,Ellipsis,Mooniswap,MultiHop,Nerve,SushiSwap,Smoothy,ApeSwap,CafeSwap,CheeseSwap,JulSwap,LiquidityProvider,MDex,BiSwap"), e.next = 39, N.a.get(m);
                                case 39:
                                    return f = e.sent, h = f.data, console.log(h), console.log(h.orders), console.log(h.orders.filter((function(e) {
                                        return e.source.includes("PancakeSwap")
                                    }))[0]), console.log(null === (p = h.orders.filter((function(e) {
                                        return e.source.includes("PancakeSwap")
                                    }))[0]) || void 0 === p ? void 0 : p.fillData.tokenAddressPath), e.abrupt("return", null === (d = h.orders.filter((function(e) {
                                        return e.source.includes("PancakeSwap")
                                    }))[0]) || void 0 === d ? void 0 : d.fillData.tokenAddressPath);
                                case 46:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n, r, a, i, o) {
                        return e.apply(this, arguments)
                    }
                }();
            var Ne, _e = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r, a) {
                        var i, o, s, l, u, p, d, m, y;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (e.prev = 0, console.log("token, chaintoken, chaintoken, chaintoken, chaintoken, chain", t, n), t && n) {
                                        e.next = 4;
                                        break
                                    }
                                    return e.abrupt("return", null);
                                case 4:
                                    if (l = {}, "ETH" !== String(n).toUpperCase()) {
                                        e.next = 14;
                                        break
                                    }
                                    return e.next = 8, M.get("?module=token&action=tokeninfo&contractaddress=".concat(t));
                                case 8:
                                    u = e.sent, p = u.data.result, console.log("data = response[0];", p), l = p[0], e.next = 21;
                                    break;
                                case 14:
                                    return e.next = 16, D.get("?module=token&action=tokeninfo&contractaddress=".concat(t));
                                case 16:
                                    d = e.sent, m = Object(c.a)(d.data.result, 1), y = m[0], console.log("data = response", y), l = y;
                                case 21:
                                    return console.log("datadatadata", l, t), e.t0 = (null === (i = l.website) || void 0 === i ? void 0 : i.length) >= 1 ? l.website : null, e.t1 = "ETH" === String(n).toUpperCase() ? "https://etherscan.io/address/".concat(t) : "https://bscscan.com/address/".concat(t), e.t2 = {
                                        usd: l.tokenPriceUSD
                                    }, e.t4 = +l.totalSupply, e.t5 = Math, e.next = 29, Ee(t);
                                case 29:
                                    if (e.t6 = +e.sent, e.t7 = e.t5.pow.call(e.t5, 10, e.t6), e.t3 = e.t4 / e.t7, e.t3) {
                                        e.next = 34;
                                        break
                                    }
                                    e.t3 = 0;
                                case 34:
                                    return e.t8 = e.t3, e.t9 = r ? "ETH" === String(n).toUpperCase() ? "Ethereum" : "BNB" : l.tokenName, e.t10 = (null === (o = l.discord) || void 0 === o ? void 0 : o.length) >= 1 ? l.discord : null, e.t11 = (null === (s = l.twitter) || void 0 === s ? void 0 : s.length) >= 1 ? l.twitter : null, e.t12 = l, e.abrupt("return", {
                                        tokenurl: e.t0,
                                        blockchain_site: e.t1,
                                        current_price: e.t2,
                                        total_supply: e.t8,
                                        token_name: e.t9,
                                        discord: e.t10,
                                        twitter: e.t11,
                                        data: e.t12
                                    });
                                case 42:
                                    return e.prev = 42, e.t13 = e.catch(0), console.log("errorerrorerrorerror", e.t13), e.abrupt("return", Promise.reject(e.t13));
                                case 46:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [0, 42]
                        ])
                    })));
                    return function(t, n, r, a) {
                        return e.apply(this, arguments)
                    }
                }(),
                Ae = function() {
                    var e = Object(s.a)(U().mark((function e(t, n) {
                        var r, a, i;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, Ee(t);
                                case 2:
                                    return a = e.sent, e.next = 5, Te(t);
                                case 5:
                                    return i = e.sent, e.next = 8, null === (r = window.ethereum) || void 0 === r ? void 0 : r.request({
                                        method: "wallet_watchAsset",
                                        params: {
                                            type: "ERC20",
                                            options: {
                                                address: t,
                                                symbol: i.symbol,
                                                decimals: a,
                                                image: n
                                            }
                                        }
                                    });
                                case 8:
                                    return e.abrupt("return", e.sent);
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }(),
                Ie = function() {
                    var e = Object(s.a)(U().mark((function e(t, n, r) {
                        var a, i;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (r && !((null === n || void 0 === n ? void 0 : n.length) <= 0)) {
                                        e.next = 2;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 2:
                                    if ("eth" !== String(t).toLowerCase()) {
                                        e.next = 17;
                                        break
                                    }
                                    return e.next = 5, ge(n, r, K, null, null, null, t);
                                case 5:
                                    return a = e.sent, console.log("data.priceUSD, amount", 1, n, a, r, t), e.t0 = console, e.t1 = a, e.next = 11, Ee(r);
                                case 11:
                                    return e.t2 = e.sent, e.t3 = te[e.t2], e.t0.log.call(e.t0, e.t1, e.t3), e.abrupt("return", +a);
                                case 17:
                                    return e.next = 19, ge(n, r, X, null, null, null, t);
                                case 19:
                                    return i = e.sent, console.log("data.priceUSD, amount", 1, n, i, r, t), e.t4 = console, e.t5 = i, e.next = 25, Ee(r);
                                case 25:
                                    return e.t6 = e.sent, e.t7 = te[e.t6], e.t4.log.call(e.t4, e.t5, e.t7), e.abrupt("return", +i);
                                case 29:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n, r) {
                        return e.apply(this, arguments)
                    }
                }(),
                Ce = function() {
                    var e = Object(s.a)(U().mark((function e(t, n) {
                        var r, a, i, o, s, l;
                        return U().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (t) {
                                        e.next = 2;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 2:
                                    if ("ETH" !== String(n).toUpperCase()) {
                                        e.next = 11;
                                        break
                                    }
                                    return e.next = 5, M.get("?module=token&action=tokeninfo&contractaddress=".concat(t));
                                case 5:
                                    a = e.sent, i = a.data.result, console.log("data = response[0];", i), r = i[0], e.next = 18;
                                    break;
                                case 11:
                                    return e.next = 13, D.get("?module=token&action=tokeninfo&contractaddress=".concat(t));
                                case 13:
                                    o = e.sent, s = Object(c.a)(o.data.result, 1), l = s[0], console.log("data = response", l), r = l;
                                case 18:
                                    return e.abrupt("return", r.tokenPriceUSD);
                                case 19:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }(),
                Me = n(10),
                De = n(36),
                Pe = n(39),
                Fe = Pe.b.div(Ne || (Ne = Object(De.a)(["\n  translate: -50% -50%;\n  display: ", ';\n  flex-direction: column;\n  position: absolute;\n  top: calc(50%);\n  left: calc(50vw);\n  height: 560px;\n  width: 768px;\n  background: var(--bg-color-swap);\n  border-radius: 27px;\n  z-index: 100000;\n  .content {\n    width: 100%;\n    height: 100%;\n    display: flex;\n    /* align-items: center; */\n    justify-content: center;\n    position: relative;\n    flex-direction: column;\n    /* background-color: #aaa; */\n  }\n  .title-list {\n    display: none;\n    color: var(--color-text);\n  }\n  .hide-1 {\n    display: flex !important;\n  }\n  .hide-0 {\n    display: none !important;\n  }\n  @media (max-width: 830px) {\n    .hide-0 {\n      display: flex !important;\n    }\n    .hide-1 {\n      display: none !important;\n    }\n    width: 95vw;\n    /* left: 2.5vw; */\n    transform: 0 -50% !important;\n  }\n  /* @media (max-width: 539px) {\n    .body {\n      display: flex !important;\n      flex-direction: column !important;\n      align-items: center !important;\n      justify-content: space-between;\n\n      button {\n        flex-direction: row-reverse !important;\n        width: 100%;\n        padding: 0 20px;\n        flex: 1;\n        &:nth-child(2) {\n          border-top: 1px solid #ebebeb;\n          img {\n            width: 40px !important;\n          }\n        }\n        p {\n          display: none !important;\n        }\n\n        img {\n          width: 30px !important;\n          margin: 0 10px !important;\n        }\n      }\n      button:last-child {\n        border-top: none !important;\n        border-left: none !important;\n      }\n    }\n  } */\n\n  h4 {\n    font-size: 18px;\n  }\n\n  .title-list {\n    display: flex;\n    justify-content: space-between;\n    padding: 10px 20px;\n  }\n\n  .title-list {\n    h1 {\n      font-size: 20px;\n    }\n  }\n\n  .exit {\n    width: 40px;\n    background-color: transparent;\n    border: none;\n    position: absolute;\n    top: 40px;\n    right: 40px;\n\n    img {\n      width: 100%;\n    }\n  }\n  .exit2 {\n    width: 30px;\n    background-color: transparent;\n    border: none;\n\n    img {\n      width: 100%;\n    }\n  }\n\n  .slippage-title {\n    display: flex;\n    align-items: center;\n    margin: 0 30px;\n\n    img {\n      width: 20px;\n      margin-right: 15px;\n    }\n\n    h4 {\n      margin: 0;\n      padding: 0;\n    }\n  }\n  .slippage-data {\n    display: grid;\n    grid-template-columns: 1fr 1fr 1fr 1fr 1.5fr;\n    gap: 15px;\n    justify-content: center;\n    align-items: center;\n    /* background-color: var(--bg-gray-swap-head); */\n    color: var(--color-text);\n    margin: 20px 30px;\n\n    .slippage-item {\n      display: flex;\n      justify-content: center;\n      align-items: center;\n      height: 50px;\n      border-radius: 12px;\n      background-color: var(--bg-gray-swap-head);\n      cursor: pointer;\n      p {\n        vertical-align: middle;\n        margin: 0;\n        padding: 0;\n        text-align: center;\n      }\n      &.active {\n        background-color: #c7e53c;\n        color: #000;\n      }\n    }\n\n    .slippage-input {\n      display: flex;\n      background-color: var(--bg-gray-swap-head);\n      border-radius: 12px;\n      input {\n        width: 100%;\n        background-color: transparent;\n        border: none;\n        font-size: 20px;\n        outline: none;\n        border-radius: 12px;\n        padding-left: 10px;\n        margin-right: 10px;\n        color: var(--color-text);\n\n        &:focus {\n          border: 1px solid rgb(139 183 48);\n        }\n      }\n    }\n  }\n\n  .compatibility-mode {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    padding: 0 30px;\n\n    > div {\n      display: flex;\n      align-items: center;\n      gap: 15px;\n    }\n\n    img {\n      width: 20px;\n      height: 28px;\n    }\n    /* The switch - the box around the slider */\n    .switch {\n      position: relative;\n      display: inline-block;\n      width: 60px;\n      height: 34px;\n    }\n\n    /* Hide default HTML checkbox */\n    .switch input {\n      opacity: 0;\n      width: 0;\n      height: 0;\n    }\n\n    /* The slider */\n    .slider {\n      position: absolute;\n      cursor: pointer;\n      top: 0;\n      left: 0;\n      right: 0;\n      bottom: 0;\n      background-color: #ccc;\n      -webkit-transition: 0.4s;\n      transition: 0.4s;\n    }\n\n    .slider:before {\n      position: absolute;\n      content: "";\n      height: 26px;\n      width: 26px;\n      left: 4px;\n      bottom: 4px;\n      background-color: white;\n      -webkit-transition: 0.4s;\n      transition: 0.4s;\n    }\n\n    input:checked + .slider {\n      background-color: #c7e53c;\n    }\n\n    input:focus + .slider {\n      box-shadow: 0 0 1px #c7e53c;\n    }\n\n    input:checked + .slider:before {\n      -webkit-transform: translateX(26px);\n      -ms-transform: translateX(26px);\n      transform: translateX(26px);\n    }\n\n    /* Rounded sliders */\n    .slider.round {\n      border-radius: 34px;\n    }\n\n    .slider.round:before {\n      border-radius: 50%;\n    }\n  }\n\n  h1.title {\n    text-align: center;\n    font-size: 30px;\n    color: var(--color-text);\n    margin-bottom: 60px;\n  }\n\n  .body {\n    display: flex;\n    flex-direction: column;\n\n    gap: 20px;\n\n    > button {\n      display: flex;\n      flex-direction: row-reverse;\n      align-items: center;\n      border: none;\n      background-color: transparent;\n      justify-content: space-between;\n      padding: 15px 20px;\n      background-color: #aaa;\n      border-radius: 10px;\n      width: 100%;\n      max-width: 400px;\n      margin: 0 auto;\n      transition: all 0.5s;\n      position: relative;\n\n      &:hover {\n        transform: scale(1.1);\n      }\n\n      &.metamask {\n        background: linear-gradient(\n          -90deg,\n          rgba(255, 216, 0, 1) 0%,\n          rgba(224, 169, 9, 1) 100%\n        );\n\n        img {\n          width: 30px;\n        }\n      }\n\n      &.walletconnect {\n        background: linear-gradient(\n          90deg,\n          rgba(0, 123, 255, 1) 36%,\n          rgba(102, 176, 255, 1) 100%\n        );\n        img {\n          width: 30px;\n        }\n      }\n      &.cb {\n        background: linear-gradient(\n          90deg,\n          rgba(0, 31, 64, 1) 0%,\n          rgba(32, 90, 227, 1) 100%\n        ) !important;\n        img {\n          width: 30px;\n        }\n      }\n\n      &.okx {\n        background: linear-gradient(\n          90deg,\n          rgba(0, 0, 0, 1) 0%,\n          rgba(108, 108, 108, 1) 100%\n        );\n        img {\n          width: 30px;\n        }\n      }\n      &.browser {\n        background: #fff;\n        border: 2px solid #9997;\n        img {\n          width: 30px;\n        }\n        h2 {\n          color: #000;\n        }\n      }\n      h2 {\n        font-weight: 600;\n        font-size: 17px;\n      }\n\n      img,\n      h2,\n      p {\n        margin: 0;\n        padding: 0;\n        color: #fff;\n      }\n    }\n  }\n'])), (function(e) {
                    return e.mostModal.isOpened ? "flex" : "none"
                }));

            function Be() {
                Be = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var Ge, He, We = function(e) {
                    var t = e.mostModal,
                        n = void 0 === t ? {
                            isOpened: !0
                        } : t,
                        i = e.setMostModal,
                        o = void 0 === i ? function() {
                            return null
                        } : i,
                        c = Object(r.useContext)(Ze);
                    return Object(r.useEffect)((function() {
                        document.onkeydown = function(e) {
                            "27" == (e = e || window.event).keyCode && n.isOpened && o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                isOpened: !1
                            }))
                        }
                    }), [n, o]), a.a.createElement(Fe, {
                        mostModal: n
                    }, a.a.createElement("div", {
                        className: "content"
                    }, a.a.createElement("div", {
                        className: "title-list"
                    }, a.a.createElement("h1", null), a.a.createElement("button", {
                        onClick: function() {
                            return o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                isOpened: !1
                            }))
                        },
                        className: "exit"
                    }, a.a.createElement("img", {
                        src: c.isDarkTheme ? "/img/close.png" : "/img/close-dark.png",
                        alt: "",
                        style: {
                            width: 20
                        }
                    }))), a.a.createElement("h1", {
                        className: "title"
                    }, "Select Wallet Provider"), a.a.createElement("div", {
                        className: "body"
                    }, window.ethereum && a.a.createElement("button", {
                        className: "wallet hide-0 browser",
                        onClick: Object(s.a)(Be().mark((function e() {
                            return Be().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, se(c);
                                    case 2:
                                        o({
                                            isOpened: !1
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))
                    }, a.a.createElement("img", {
                        src: "/img/wallet.png",
                        alt: ""
                    }), a.a.createElement("div", null, a.a.createElement("h2", null, "Injected wallet"))), window.ethereum && a.a.createElement("button", {
                        className: "wallet hide-1 metamask",
                        onClick: Object(s.a)(Be().mark((function e() {
                            return Be().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, se(c);
                                    case 2:
                                        o({
                                            isOpened: !1
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))
                    }, a.a.createElement("img", {
                        src: "/img/metamask.svg",
                        alt: ""
                    }), a.a.createElement("div", null, a.a.createElement("h2", null, "Metamask"))), a.a.createElement("button", {
                        className: "wallet walletconnect",
                        onClick: Object(s.a)(Be().mark((function e() {
                            return Be().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, ce(c);
                                    case 2:
                                        o({
                                            isOpened: !1
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))
                    }, a.a.createElement("img", {
                        src: "https://seeklogo.com/images/W/walletconnect-logo-EE83B50C97-seeklogo.com.png",
                        alt: ""
                    }), a.a.createElement("div", null, a.a.createElement("h2", null, "WalletConnect"))), a.a.createElement("button", {
                        className: "wallet cb",
                        onClick: Object(s.a)(Be().mark((function e() {
                            return Be().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, le(c);
                                    case 2:
                                        o({
                                            isOpened: !1
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))
                    }, a.a.createElement("img", {
                        src: "/img/coinbase.png",
                        alt: ""
                    }), a.a.createElement("div", null, a.a.createElement("h2", null, "Coinbase Wallet"))), a.a.createElement("button", {
                        onClick: Object(s.a)(Be().mark((function e() {
                            return Be().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, ue(c);
                                    case 2:
                                        o({
                                            isOpened: !1
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        }))),
                        className: "wallet okx"
                    }, a.a.createElement("img", {
                        src: "https://img.api.cryptorank.io/exchanges/okex1642496657190.png",
                        alt: ""
                    }), a.a.createElement("div", null, a.a.createElement("h2", null, "OKX"))))))
                },
                Ue = (Pe.b.div(Ge || (Ge = Object(De.a)(["\n  position: absolute;\n  \n  background-color: var(--bg-color-back);\n  /* padding: 0 30px; */\n  top: 50vh;\n  left: calc(50vw - 15px);\n  transform: translateY(-50%) translateX(-50%);\n  z-index: 2000 !important;\n  border-radius: 25px;\n  box-shadow: 0px 2px 20px 0px rgb(12 21 35 / 15%);\n  border: 2px solid var(--bc-app);\n  padding-bottom: 30px;\n\n  .btns {\n    display: flex;\n    flex-direction: column;\n    padding: 0 30px;\n    gap: 20px;\n\n    button {\n      width: 100%;\n    }\n  }\n\n  h1,\n  h2,\n  p {\n    color: var(--color-text);\n    text-align: center;\n    margin: 20px auto;\n  }\n\n  h1 {\n  }\n\n  p {\n    width: 80%;\n    margin-bottom: 40px;\n  }\n"]))), n(88)),
                Re = Pe.b.button(He || (He = Object(De.a)(["\n  background-color: #d1fd00;\n  border: none;\n  padding: 5px 15px;\n  border-radius: 12px;\n  font-weight: 600;\n  font-size: 12px;\n"]))),
                ze = ["children", "styles"];
            var Ve, qe = function(e) {
                    var t = e.children,
                        n = e.styles,
                        r = Object(Ue.a)(e, ze);
                    return a.a.createElement(Re, Object.assign({}, r, {
                        style: n
                    }), t)
                },
                Ye = Pe.b.button(Ve || (Ve = Object(De.a)(['\n  border: none;\n  color: var(--bg-color-back);\n  background-color: var(--bg-swap-btn);\n  font-weight: 600;\n  height: 56px;\n  width: 200px;\n  border-radius: 12px;\n  font-family: "Montserrat", sans-serif !important;\n  font-size: 16px;\n  cursor: pointer;\n']))),
                Je = ["styles", "children"];

            function Ke() {
                Ke = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var Xe = function(e) {
                var t = e.styles,
                    n = e.children,
                    i = Object(Ue.a)(e, Je),
                    o = Object(r.useContext)(Ze);
                return a.a.createElement(Ye, Object.assign({
                    style: Object(Me.a)({}, t),
                    onClick: Object(s.a)(Ke().mark((function e() {
                        return Ke().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, ie(o);
                                case 2:
                                    return e.abrupt("return", e.sent);
                                case 3:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))
                }, i), n)
            };

            function $e() {
                $e = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var Ze = Object(r.createContext)({
                language: "en",
                balance: "0",
                setBalance: function() {
                    return null
                },
                walletIsConnected: !1,
                setWalletIsConnected: function() {
                    return null
                },
                walletAddress: "",
                chainData: {},
                networkId: "",
                setWalletAddress: function() {
                    return null
                },
                setNetworkId: function() {
                    return null
                },
                networkIsAvaliable: !0,
                setNetworkIsAvaliable: function() {
                    return null
                },
                languages: [{
                    name: "English",
                    id: "en",
                    flag: ""
                }],
                setLanguages: function() {
                    return null
                },
                updateLanguage: function() {
                    return null
                },
                tokenSelectedIn: {
                    image: "",
                    id: "",
                    name: "",
                    symbol: "",
                    contractAddress: "",
                    token_type: "",
                    decimals: "9"
                },
                setTokenSelectedIn: function() {
                    return null
                },
                tokenSelectedOut: {
                    image: "",
                    id: "",
                    name: "",
                    symbol: "",
                    contractAddress: "0x7db5af2B9624e1b3B4Bb69D6DeBd9aD1016A58Ac",
                    token_type: "",
                    decimals: "9"
                },
                setTokenSelectedOut: function() {
                    return null
                },
                favoritedPairs: [{
                    tokenin: {
                        liquiditytype: "",
                        _id: "",
                        id: "",
                        name: "",
                        chain: "",
                        image: "",
                        symbol: "",
                        decimals: "",
                        contractAddress: "",
                        tokenType: "",
                        importer_addresses: [],
                        __v: 0
                    },
                    tokenout: {
                        liquiditytype: "",
                        _id: "",
                        id: "",
                        name: "",
                        chain: "",
                        image: "",
                        symbol: "",
                        decimals: "",
                        contractAddress: "",
                        tokenType: "",
                        importer_addresses: [],
                        __v: 0
                    }
                }],
                setFavoritedPairs: function() {
                    return null
                },
                isDarkTheme: !0,
                setIsDarkTheme: function() {
                    return null
                },
                hasError: {},
                setHasError: function() {
                    return null
                },
                updateTokens: {
                    tokenin: {
                        liquiditytype: "",
                        _id: "",
                        id: "",
                        name: "",
                        chain: "",
                        image: "",
                        symbol: "",
                        decimals: "",
                        contractAddress: "",
                        tokenType: "",
                        importer_addresses: [],
                        __v: 0
                    },
                    tokenout: {
                        liquiditytype: "",
                        _id: "",
                        id: "",
                        name: "",
                        chain: "",
                        image: "",
                        symbol: "",
                        decimals: "",
                        contractAddress: "",
                        tokenType: "",
                        importer_addresses: [],
                        __v: 0
                    },
                    slippage: "0",
                    iscompatibilitymode: !1
                },
                setUpdateTokens: function() {
                    return null
                },
                historyTransaction: [],
                setHistoryTransaction: function() {
                    return null
                },
                mostConnectWallet: !1,
                setMostConnectWallet: function() {
                    return null
                },
                tokenIsLoading: !1,
                setTokenIsLoading: function() {
                    return null
                },
                slippage: "3",
                setSlippage: function() {
                    return null
                }
            });
            var Qe = function(e) {
                    var t = e.children,
                        n = Object(l.a)().i18n,
                        i = Object(r.useState)({}),
                        o = Object(c.a)(i, 2),
                        u = o[0],
                        p = o[1],
                        m = Object(r.useState)("en"),
                        y = Object(c.a)(m, 2),
                        f = y[0],
                        g = y[1],
                        b = Object(r.useState)(!0),
                        v = Object(c.a)(b, 2),
                        x = v[0],
                        w = v[1],
                        k = Object(r.useState)(!1),
                        E = Object(c.a)(k, 2),
                        T = E[0],
                        O = E[1],
                        j = Object(r.useState)(!1),
                        L = Object(c.a)(j, 2),
                        S = L[0],
                        N = L[1],
                        _ = Object(r.useState)(""),
                        A = Object(c.a)(_, 2),
                        I = A[0],
                        C = A[1],
                        M = Object(r.useState)(""),
                        D = Object(c.a)(M, 2),
                        P = D[0],
                        F = D[1],
                        B = Object(r.useState)(!1),
                        G = Object(c.a)(B, 2),
                        H = G[0],
                        W = G[1],
                        U = Object(r.useState)(!0),
                        R = Object(c.a)(U, 2),
                        z = R[0],
                        V = R[1],
                        q = Object(r.useState)(0),
                        Y = Object(c.a)(q, 2),
                        J = Y[0],
                        K = Y[1],
                        X = Object(r.useState)("3"),
                        $ = Object(c.a)(X, 2),
                        Z = $[0],
                        Q = $[1],
                        ee = Object(r.useState)([{
                            flag: "https://cdn-icons-png.flaticon.com/512/4628/4628635.png",
                            name: "English",
                            id: "en"
                        }, {
                            flag: "https://cdn-icons-png.flaticon.com/512/197/197375.png",
                            name: "\u4e2d\u6587\uff08\u7b80\u4f53)",
                            id: "mandarim"
                        }, {
                            flag: "https://cdn-icons-png.flaticon.com/512/4855/4855806.png",
                            name: "German",
                            id: "german"
                        }, {
                            flag: "https://cdn-icons-png.flaticon.com/512/197/197518.png",
                            name: "Turkish",
                            id: "turko"
                        }, {
                            flag: "https://cdn-icons-png.flaticon.com/512/197/197593.png",
                            name: "Spanish",
                            id: "spanish"
                        }]),
                        te = Object(c.a)(ee, 2),
                        ne = te[0],
                        re = te[1],
                        ae = Object(r.useState)([]),
                        ie = Object(c.a)(ae, 2),
                        oe = ie[0],
                        se = ie[1],
                        ce = h.filter((function(e) {
                            return +e.id === +P
                        })),
                        le = Object(c.a)(ce, 1)[0],
                        ue = Object(r.useState)([]),
                        pe = Object(c.a)(ue, 2),
                        ye = pe[0],
                        fe = pe[1],
                        he = Object(r.useState)([]),
                        ge = Object(c.a)(he, 2),
                        be = ge[0],
                        ve = ge[1],
                        xe = Object(r.useState)({
                            image: "",
                            id: "",
                            name: "",
                            symbol: "",
                            contractAddress: "",
                            token_type: "",
                            decimals: "9"
                        }),
                        we = Object(c.a)(xe, 2),
                        ke = we[0],
                        Ee = we[1],
                        Te = Object(r.useState)({
                            image: "",
                            id: "",
                            name: "",
                            symbol: "",
                            contractAddress: "",
                            token_type: "",
                            decimals: "9"
                        }),
                        Oe = Object(c.a)(Te, 2),
                        je = Oe[0],
                        Le = Oe[1];
                    Object(r.useEffect)((function() {
                        Object(s.a)($e().mark((function e() {
                            var t, n, r, a, i, o, s, l, u, p, m, y, f;
                            return $e().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return window.ethereum ? s = new d.a(window.ethereum) : window.web3 && (s = new d.a(window.web3.currentProvider)), e.next = 3, null === (t = s) || void 0 === t || null === (n = t.eth) || void 0 === n ? void 0 : n.getAccounts()[0];
                                    case 3:
                                        return l = e.sent, localStorage.setItem("@WALLET", l), O(l && (null === l || void 0 === l ? void 0 : l.length) >= 1), C(l), e.next = 9, null === (r = s) || void 0 === r || null === (a = r.eth) || void 0 === a ? void 0 : a.getChainId();
                                    case 9:
                                        return u = e.sent, p = "1;56".split(";"), m = p.filter((function(e) {
                                            return +e === +u
                                        })), y = Object(c.a)(m, 1), f = y[0], F(f || 1), V(f), e.t0 = localStorage, e.next = 17, null === (i = s) || void 0 === i || null === (o = i.eth) || void 0 === o ? void 0 : o.getChainId();
                                    case 17:
                                        if (e.t1 = e.sent, e.t1) {
                                            e.next = 20;
                                            break
                                        }
                                        e.t1 = 1;
                                    case 20:
                                        e.t2 = e.t1, e.t0.setItem.call(e.t0, "@CHAIN_ID", e.t2);
                                    case 22:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), []), Object(r.useEffect)((function() {
                        var e = localStorage.getItem("@LANGUAGE"),
                            t = ne.filter((function(t) {
                                return t.id === e
                            })),
                            r = Object(c.a)(t, 1)[0];
                        g((null === r || void 0 === r ? void 0 : r.id) || "en"), n.changeLanguage((null === r || void 0 === r ? void 0 : r.id) || "en")
                    }), []), Object(r.useEffect)((function() {
                        setInterval(Object(s.a)($e().mark((function e() {
                            return $e().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        window.ethereum && window.ethereum.on("chainChanged", function() {
                                            var e = Object(s.a)($e().mark((function e(t) {
                                                var n, r, a, i, o;
                                                return $e().wrap((function(e) {
                                                    for (;;) switch (e.prev = e.next) {
                                                        case 0:
                                                            n = t, r = "1;56".split(";"), a = r.filter((function(e) {
                                                                return +e === +n
                                                            })), i = Object(c.a)(a, 1), o = i[0], +t !== P && V(o), console.log("jkaDJKJK", o, P, t, le);
                                                        case 5:
                                                        case "end":
                                                            return e.stop()
                                                    }
                                                }), e)
                                            })));
                                            return function(t) {
                                                return e.apply(this, arguments)
                                            }
                                        }());
                                    case 1:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        }))), 1e3)
                    }), [I, le]), Object(r.useEffect)((function() {
                        Object(s.a)($e().mark((function e() {
                            var t;
                            return $e().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, de(I, !0, le);
                                    case 2:
                                        t = e.sent, K(me(t));
                                    case 4:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), [P, le, I]), Object(r.useEffect)((function() {
                        var e = localStorage.getItem("@APPTHEREISDARK");
                        w("true" === e)
                    }), []);
                    var Se = function() {
                        var e = Object(s.a)($e().mark((function e(t) {
                            var r, a, i;
                            return $e().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        r = ne.filter((function(e) {
                                            return e.id === t
                                        })), a = Object(c.a)(r, 1), i = a[0], g(i.id || "en"), n.changeLanguage(i.id || "en"), localStorage.setItem("@LANGUAGE", i.id || "en");
                                    case 4:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }();
                    return a.a.createElement(Ze.Provider, {
                        value: {
                            language: f,
                            walletIsConnected: T,
                            setWalletIsConnected: O,
                            walletAddress: I,
                            setWalletAddress: C,
                            networkId: P,
                            setNetworkId: F,
                            networkIsAvaliable: z,
                            setNetworkIsAvaliable: V,
                            languages: ne,
                            setLanguages: re,
                            updateLanguage: Se,
                            balance: J,
                            setBalance: K,
                            chainData: le,
                            tokenSelectedIn: ke,
                            setTokenSelectedIn: Ee,
                            tokenSelectedOut: je,
                            setTokenSelectedOut: Le,
                            favoritedPairs: oe,
                            setFavoritedPairs: se,
                            isDarkTheme: x,
                            setIsDarkTheme: function(e) {
                                w(e), localStorage.setItem("@APPTHEREISDARK", !!e)
                            },
                            hasError: u,
                            setHasError: p,
                            updateTokens: ye,
                            setUpdateTokens: fe,
                            historyTransaction: be,
                            setHistoryTransaction: ve,
                            mostConnectWallet: S,
                            setMostConnectWallet: N,
                            tokenIsLoading: H,
                            setTokenIsLoading: W,
                            slippage: Z,
                            setSlippage: Q
                        }
                    }, t, a.a.createElement(We, {
                        mostModal: S,
                        setMostModal: N
                    }))
                },
                et = n(1430),
                tt = n(40),
                nt = n(231),
                rt = n(672),
                at = n(673),
                it = n(674),
                ot = n(675),
                st = n(676);
            tt.a.use(nt.e).init({
                compatibilityJSON: "v3",
                lng: "en",
                resources: {
                    en: {
                        translation: rt
                    },
                    mandarim: {
                        translation: at
                    },
                    german: {
                        translation: it
                    },
                    turko: {
                        translation: ot
                    },
                    spanish: {
                        translation: st
                    }
                },
                react: {
                    useSuspense: !1
                }
            });
            var ct, lt, ut, pt = tt.a,
                dt = Pe.b.div(ct || (ct = Object(De.a)(['\n  display: flex;\n  justify-content: space-between;\n  flex-direction: column;\n  align-items: center;\n  padding: 0px 0px 30px;\n  /* max-width: 1340px; */\n  width: 100%;\n  color: var(--color-text);\n\n  .btn-data {\n    background: var(--bg-color-swap);\n    backdrop-filter: blur(9.5px);\n    height: 50px;\n    width: 50px;\n    border: none;\n    border-radius: 12px;\n\n    img {\n      height: 40%;\n    }\n  }\n\n  .exit {\n    border: none;\n    background-color: transparent;\n    margin-left: auto;\n    margin-right: 30px;\n  }\n  .theme {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    cursor: pointer;\n\n    p {\n      cursor: pointer;\n      display: flex;\n      align-items: center;\n      gap: 10px;\n      cursor: pointer;\n    }\n    img {\n      cursor: pointer;\n    }\n\n    .selected {\n      border: 2px solid rgb(139 183 48);\n      padding: 8px;\n      border-radius: 12px;\n    }\n  }\n\n  > div {\n    display: flex;\n    justify-content: space-between;\n\n    align-items: center;\n    padding: 30px 0px;\n    max-width: 1340px;\n    width: 75%;\n    color: var(--color-text);\n\n    p {\n      color: var(--color-text);\n    }\n\n    a {\n      color: var(--color-text);\n      text-decoration: none;\n    }\n\n    .desktop-mobile {\n      display: none;\n    }\n\n    > img {\n      width: 150px;\n      height: fit-content;\n    }\n\n    a {\n      margin: 0;\n      padding: 0;\n    }\n    > div {\n      display: flex;\n      align-items: center;\n      gap: 40px 20px;\n\n      .wallet-data {\n        backdrop-filter: blur(9.5px);\n        background: var(--bg-gray-settings);\n        color: var(--color-text);\n        display: flex;\n        align-items: center;\n        gap: 15px;\n        border-radius: 40px;\n        padding: 0 5px 0 0;\n        height: 50px;\n        position: relative;\n        z-index: 10000;\n      }\n\n      .wallet {\n        font-size: 20px;\n        text-align: center;\n        display: flex;\n        align-items: center;\n        gap: 10px;\n        justify-content: center;\n        margin: 10px !important;\n      }\n\n      .ml-2 {\n        margin-left: 10px !important;\n      }\n      img {\n        width: 25px;\n      }\n\n      input[type="checkbox"] {\n        display: none;\n      }\n      .dropdown {\n        display: flex;\n        flex-direction: column;\n        position: fixed;\n        top: 55px;\n        right: 0;\n        background-color: var(--bg-color-swap);\n        padding: 20px 20px 30px;\n        border-radius: 20px;\n        z-index: 1000;\n\n        p {\n          margin: 0%;\n          padding: 0%;\n          color: var(--color-text);\n        }\n\n        .btns {\n          display: flex;\n          justify-content: center;\n          margin: 10px 0 15px;\n          gap: 30px;\n          button,\n          a {\n            display: flex;\n            align-items: center;\n            justify-content: center;\n            background-color: var(--bg-gray-settings);\n            padding: 8px;\n            border-radius: 50%;\n            border: none;\n            cursor: pointer;\n\n            img {\n              width: 15px;\n            }\n          }\n        }\n\n        .border {\n          width: 100%;\n          height: 2px;\n          background-color: #ddd2;\n        }\n\n        .coin-data {\n          margin: 20px 20px 0;\n          display: flex;\n          align-items: center;\n          justify-content: space-between;\n          gap: 50px;\n\n          p {\n            display: flex;\n            align-items: center;\n            gap: 10px;\n            cursor: pointer;\n          }\n\n          .selected {\n            border: 2px solid rgb(139 183 48);\n            padding: 8px;\n            border-radius: 12px;\n          }\n        }\n        .theme-modes {\n          margin: 20px 20px 0;\n          display: flex;\n          align-items: center;\n          justify-content: center;\n          gap: 50px;\n\n          p {\n            display: flex;\n            align-items: center;\n            gap: 10px;\n          }\n\n          .selected {\n            border: 2px solid var(--bg-swap-btn);\n            padding: 8px;\n            border-radius: 12px;\n          }\n        }\n      }\n\n      .account {\n        display: flex;\n        align-items: center;\n        padding: 3px 20px;\n        border-radius: 40px;\n        gap: 8px;\n\n        p {\n          margin: 0;\n          padding: 0;\n        }\n\n        img {\n          width: 40px;\n          height: 40px;\n        }\n\n        .down {\n          width: 20px;\n          height: auto;\n        }\n      }\n    }\n    .buttom-mobile {\n      display: none;\n    }\n\n    .desktop-logo {\n      width: 190px;\n      height: 61px;\n    }\n\n    @media (max-width: 741px) {\n      padding: 20px 10px 30px;\n      .balance {\n        display: none;\n      }\n      .wallet-data {\n        background: transparent !important;\n        padding: 0 !important;\n      }\n      .account {\n        padding: 16px 20px !important;\n      }\n      .desktop-logo {\n        display: none;\n      }\n      .desktop-mobile {\n        display: block;\n        width: 50px;\n        height: auto;\n      }\n    }\n    .menu-data {\n      height: calc(100vh - 99px);\n      width: 100vw;\n      background-color: var(--bg-color-swap);\n      backdrop-filter: blur(17px);\n      position: absolute;\n      top: 65px;\n      left: 0;\n      right: 0;\n      z-index: 100000;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      padding: 30px 0 0;\n      color: var(--color-text);\n\n      .dropdown {\n        background: transparent !important;\n      }\n    }\n\n    @media (max-width: 768px) {\n      display: flex;\n      justify-content: space-between;\n      align-items: center;\n      .buttom-mobile {\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        background-color: transparent;\n        border: none;\n        img {\n          width: 35px;\n        }\n      }\n      .dropdown {\n        max-width: 600px;\n        width: 90%;\n        padding: 0 20px;\n\n        font-size: 18px;\n        position: relative !important;\n        top: -50px !important;\n      }\n      .menu-data {\n        display: flex;\n        flex-direction: column;\n        justify-content: flex-start;\n        align-items: flex-start;\n        margin-top: 40px !important;\n        p {\n          font-size: 20px !important;\n        }\n      }\n\n      .footer {\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        padding: 0 15px;\n        width: 100%;\n        border-top: 2px solid #ddd2;\n\n        .block-number {\n          position: relative;\n        }\n\n        .block-number::before {\n          content: "";\n          position: absolute;\n          top: 7px;\n          left: -10px;\n          width: 8px;\n          height: 8px;\n          border-radius: 8px;\n          background-color: #64812b;\n        }\n\n        a {\n          color: #64812b;\n          margin-left: 20px;\n        }\n      }\n\n      > div {\n        display: none;\n      }\n    }\n  }\n  .mobileData {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n    gap: 30px;\n    .row {\n      display: flex;\n    }\n  }\n']))),
                mt = Pe.b.button(lt || (lt = Object(De.a)(["\n  background-color: var(--bg-gray-swap-head);\n  display: flex;\n  align-items: center;\n  width: 300px;\n  font-size: 18px;\n  z-index: 100000;\n  color: var(--color-text);\n  border: none;\n  z-index: 10;\n\n  > div {\n    padding-right: 20px;\n  }\n\n  p {\n    margin: 0;\n  }\n\n  a {\n    color: var(--color-text);\n    margin-top: 20px;\n  }\n\n  img {\n    width: 40px;\n    margin-right: 20px;\n  }\n\n  .close {\n    background-color: transparent;\n    color: var(--color-text);\n    border: none;\n    position: absolute;\n    top: 9px;\n    right: 15px;\n    cursor: pointer;\n  }\n"]))),
                yt = n(232),
                ft = n.n(yt),
                ht = Pe.b.button(ut || (ut = Object(De.a)(['\n  border: none;\n  color: #191a17;\n  background-color: #d1fd00;\n  font-weight: 600;\n  padding: 0;\n  height: 50px;\n  width: 200px;\n  border-radius: 12px;\n  font-family: "Montserrat", sans-serif !important;\n  font-size: 16px;\n  cursor: pointer;\n  text-transform: capitalize;\n'])));

            function gt() {
                gt = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var bt, vt = function(e) {
                    var t = e.styles,
                        n = e.callback,
                        i = void 0 === n ? function() {
                            return null
                        } : n,
                        o = (Object(r.useContext)(Ze), Object(l.a)()),
                        c = o.t;
                    return o.i18n, a.a.createElement(ht, {
                        style: Object(Me.a)({}, t),
                        onClick: Object(s.a)(gt().mark((function e() {
                            return gt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        i();
                                    case 1:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))
                    }, c("connect_wallet"))
                },
                xt = n(204),
                wt = n.n(xt),
                kt = Pe.b.section(bt || (bt = Object(De.a)(["\n  display: flex;\n  color: var(--color-text);\n  background-color: var(--bg-gray-swap-head);\n  /* margin-right: -10%; */\n  @keyframes scroll {\n    0% {\n      transform: translateX(0);\n    }\n    100% {\n      transform: translateX(calc(-50px * ", '));\n    }\n  }\n\n  @media (max-width: 500px) {\n    display: flex;\n    flex-direction: column-reverse;\n\n    .banner {\n      width: 109vw !important;\n      height: 75px !important;\n    }\n\n    .slider {\n      width: 100vw !important;\n    }\n  }\n\n  .banner {\n    width: 240px;\n    height: 50px;\n    background-color: #aaa;\n  }\n\n  // Styling\n  .slider {\n    box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.125);\n    height: 50px;\n    margin: auto;\n    overflow: hidden;\n    position: relative;\n    width: calc(100vw - 260px);\n    padding-right: 20px;\n\n    &::before,\n    &::after {\n      @include white-gradient;\n      content: "";\n      height: 50px;\n      position: absolute;\n\n      z-index: 2;\n    }\n\n    &::after {\n      right: 0;\n      top: 0;\n      transform: rotateZ(180deg);\n    }\n\n    &::before {\n      left: 0;\n      top: 0;\n    }\n\n    .slide-track {\n      animation: scroll 25s linear infinite;\n      display: flex;\n      width: calc(130px * ', ");\n    }\n\n    .slide {\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      gap: 5px;\n      margin-right: 80px;\n      width: 50px;\n      white-space: nowrap;\n\n      p {\n        white-space: nowrap;\n        color: var(--color-text);\n        text-transform: uppercase;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        gap: 5px;\n\n        p {\n          margin: 0;\n          padding: 0;\n        }\n      }\n\n      img {\n        width: 35px;\n      }\n    }\n  }\n\n  .partnerAd {\n    width: 10.1vw;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    background-color: #fff;\n    color: var(--color-text);\n    height: 60px;\n    background-color: #d9d9d9;\n  }\n"])), (function(e) {
                    return e.total
                }), (function(e) {
                    return e.total
                }));

            function Et() {
                Et = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var Tt, Ot = function() {
                    var e = Object(r.useContext)(Ze),
                        t = Object(r.useState)({
                            data: [{
                                img: "",
                                title: ""
                            }],
                            pages: 1
                        }),
                        n = Object(c.a)(t, 2),
                        i = n[0],
                        o = n[1],
                        l = Object(r.useState)(),
                        u = Object(c.a)(l, 2),
                        p = u[0],
                        d = (u[1], Object(r.useState)(0)),
                        m = Object(c.a)(d, 2),
                        y = (m[0], m[1], Object(r.useState)(!1)),
                        f = Object(c.a)(y, 2),
                        h = f[0],
                        g = f[1];
                    return Object(r.useEffect)((function() {
                        Object(s.a)(Et().mark((function t() {
                            var n, r;
                            return Et().wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, P.get("/api/prices/tokensburns?chain=".concat("eth" === String(e.chainData.symbol).toLowerCase() ? "eth" : "bnb" === String(e.chainData.symbol).toLowerCase() ? "bnb" : "eth", "&page=").concat(p));
                                    case 2:
                                        n = t.sent, r = n.data, o(r);
                                    case 5:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        })))()
                    }), [e.chainData, p, h]), Object(r.useEffect)((function() {
                        var e = document.getElementsByClassName("slide-track");
                        e[0].addEventListener("mouseover", (function() {
                            e[0].style.animationPlayState = "paused", g(!0)
                        })), e[0].addEventListener("mouseout", (function() {
                            e[0].style.animationPlayState = "running", g(!1)
                        }))
                    }), []), a.a.createElement(a.a.Fragment, null, a.a.createElement(kt, {
                        total: i.data.length + 20
                    }, a.a.createElement("div", {
                        className: "slider"
                    }, a.a.createElement("div", {
                        className: "slide-track"
                    }, a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), a.a.createElement("div", {
                        className: "slide"
                    }), i.data.map((function(e, t) {
                        return a.a.createElement("div", {
                            className: "slide",
                            key: t
                        }, a.a.createElement("span", {
                            className: "slide"
                        }, a.a.createElement("p", {
                            style: {
                                color: "var(--bg-swap-btn)"
                            }
                        }, "#", +t + 1), e.symbol))
                    })))), a.a.createElement("img", {
                        src: "/img/animation-mobile.gif",
                        alt: "thumbnail",
                        className: "banner"
                    })))
                },
                jt = Pe.b.div(Tt || (Tt = Object(De.a)(["\n  width: 180px;\n\n  .country-option {\n    display: flex;\n    align-items: center;\n    gap: 10px;\n  }\n"]))),
                Lt = n(694);
            var St = function() {
                var e = Object(r.useContext)(Ze);
                return a.a.createElement(jt, null, a.a.createElement(Lt.a, {
                    defaultValue: e.languages.map((function(e) {
                        return {
                            id: e.id,
                            label: e.name,
                            image: e.flag
                        }
                    })).filter((function(t) {
                        return t.id === e.language
                    }))[0],
                    placeholder: e.languages.filter((function(t) {
                        return t.id === e.language
                    }))[0].name,
                    options: e.languages.map((function(e) {
                        return {
                            id: e.id,
                            label: e.name,
                            image: e.flag
                        }
                    })),
                    onChange: function(t) {
                        e.updateLanguage(t.id)
                    },
                    isSearchable: !1,
                    styles: {
                        option: function(e, t) {
                            t.isFocused, t.isSelected;
                            return Object(Me.a)(Object(Me.a)({}, e), {}, {
                                backgroundColor: "var(--bg-color-swap)",
                                color: "var(--color-text)",
                                margin: "0"
                            })
                        },
                        container: function(e) {
                            return Object(Me.a)(Object(Me.a)({}, e), {}, {
                                backgroundColor: "var(--bg-color-swap)",
                                borderRadius: 12
                            })
                        },
                        control: function(e) {
                            return Object(Me.a)(Object(Me.a)({}, e), {}, {
                                borderRadius: 12,
                                backgroundColor: "var(--bg-color-swap)",
                                border: "none",
                                padding: "5px 0",
                                color: "var(--color-text)"
                            })
                        },
                        menu: function(e) {
                            return Object(Me.a)(Object(Me.a)({}, e), {}, {
                                backgroundColor: "var(--bg-color-swap)"
                            })
                        }
                    },
                    formatOptionLabel: function(e) {
                        return a.a.createElement("div", {
                            className: "country-option"
                        }, a.a.createElement("img", {
                            src: e.image
                        }), a.a.createElement("span", {
                            style: {
                                color: "var(--color-text)"
                            }
                        }, e.label))
                    }
                }))
            };

            function Nt() {
                Nt = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var _t, At = function() {
                    var e = Object(r.useRef)(),
                        t = Object(l.a)().t,
                        n = Object(r.useContext)(Ze),
                        i = n.walletAddress,
                        o = n.chainData,
                        u = n.setWalletIsConnected,
                        p = n.setWalletAddress,
                        d = n.isDarkTheme,
                        m = n.setIsDarkTheme,
                        y = n.setMostConnectWallet,
                        f = Object(r.useContext)(Ze),
                        h = Object(r.useState)(0),
                        g = Object(c.a)(h, 2),
                        b = g[0],
                        v = g[1],
                        x = Object(r.useState)(0),
                        w = Object(c.a)(x, 2),
                        k = w[0],
                        E = w[1],
                        T = Object(r.useState)(0),
                        O = Object(c.a)(T, 2),
                        j = O[0],
                        L = O[1],
                        S = Object(r.useState)(!1),
                        N = Object(c.a)(S, 2),
                        _ = N[0],
                        A = N[1],
                        I = Object(r.useState)(!1),
                        C = Object(c.a)(I, 2),
                        M = C[0],
                        D = C[1],
                        F = Object(r.useState)(""),
                        B = Object(c.a)(F, 2),
                        G = B[0],
                        H = B[1];
                    Object(r.useEffect)((function() {
                        Object(s.a)(Nt().mark((function e() {
                            var t, n;
                            return Nt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, P.get("/api/prices/blockNumber?chain=".concat(o.symbol));
                                    case 2:
                                        t = e.sent, n = t.data.block, H(+n);
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), [o.symbol]), Object(r.useEffect)((function() {
                        Object(s.a)(Nt().mark((function e() {
                            return Nt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.t0 = v, e.next = 3, je(i, o.symbol);
                                    case 3:
                                        return e.t1 = e.sent, (0, e.t0)(e.t1), e.t2 = E, e.next = 8, de(i, !0, o);
                                    case 8:
                                        return e.t3 = e.sent, (0, e.t2)(e.t3), e.t4 = L, e.next = 13, de(i, !1, "0x7db5af2B9624e1b3B4Bb69D6DeBd9aD1016A58Ac");
                                    case 13:
                                        e.t5 = e.sent, (0, e.t4)(e.t5);
                                    case 15:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), [i, o]);
                    var W, U = function(e, t) {
                        navigator.clipboard.writeText(e),
                            function(e, t) {
                                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
                                wt()((function(r) {
                                    return a.a.createElement(mt, null, a.a.createElement("button", {
                                        onClick: function() {
                                            return wt.a.dismiss(r.id)
                                        },
                                        className: "close"
                                    }, "X"), t ? a.a.createElement("img", {
                                        src: "/img/success.png",
                                        alt: ""
                                    }) : a.a.createElement("img", {
                                        src: "/img/error.png",
                                        alt: ""
                                    }), a.a.createElement("div", null, a.a.createElement("p", null, e), (null === n || void 0 === n ? void 0 : n.length) >= 1 && a.a.createElement("a", {
                                        href: n,
                                        target: "_blank",
                                        rel: "noopener noreferrer"
                                    }, "View in explorer")))
                                }), {
                                    duration: 1e4,
                                    style: {
                                        borderRadius: "10px",
                                        background: "var(--bg-gray-swap-head)",
                                        color: "#fff",
                                        zIndex: 1e16
                                    }
                                })
                            }("Copied!", !0)
                    };
                    return a.a.createElement(a.a.Fragment, null, a.a.createElement(dt, null, a.a.createElement(Ot, null), a.a.createElement("div", null, a.a.createElement("div", {
                        style: {
                            display: "flex",
                            alignItems: "center"
                        }
                    }, a.a.createElement("img", {
                        className: "desktop-logo",
                        src: d ? "/img/VOLTICHANGE_TRANSPARENT_VOLT-GREEN.png" : "/img/VOLTICHANGE_TRANSPARENT_BLACK.png",
                        alt: "",
                        onClick: function() {
                            window.location.href = "/"
                        }
                    }), a.a.createElement("img", {
                        className: "desktop-mobile",
                        src: "/img/logo-mobile.png",
                        alt: "",
                        onClick: function() {
                            window.location.href = "/"
                        }
                    }), a.a.createElement("a", {
                        href: "/widget",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        style: {
                            marginTop: -10
                        }
                    }, t("widget"))), a.a.createElement("button", {
                        className: "buttom-mobile",
                        onClick: function() {
                            return D((function(e) {
                                return !e
                            }))
                        }
                    }, a.a.createElement("img", {
                        src: "/img/menu.png",
                        alt: ""
                    })), a.a.createElement("div", null, i ? a.a.createElement(a.a.Fragment, null, a.a.createElement("div", {
                        className: "wallet-data"
                    }, a.a.createElement("div", {
                        className: "account"
                    }, a.a.createElement("a", {
                        target: "_blank",
                        href: "https://opensea.io/collection/volteddragonssailorsclub"
                    }, a.a.createElement("img", {
                        src: "/img/4.png",
                        alt: ""
                    })), a.a.createElement("p", {
                        className: "ml-2"
                    }, b))), a.a.createElement("div", {
                        className: "wallet-data"
                    }, a.a.createElement("div", {
                        className: "account",
                        style: {
                            cursor: "pointer"
                        },
                        onClick: function() {
                            return A((function(e) {
                                return !e
                            }))
                        }
                    }, a.a.createElement(ft.a, {
                        diameter: 25,
                        seed: Object(yt.jsNumberForAddress)(i)
                    }), a.a.createElement("p", null, (W = i).slice(0, 6) + "..." + W.slice(-4)), a.a.createElement("img", {
                        src: "/img/down.png",
                        alt: "",
                        className: "down"
                    })), _ && a.a.createElement("div", {
                        className: "dropdown"
                    }, a.a.createElement("p", {
                        className: "wallet",
                        ref: e
                    }, a.a.createElement(ft.a, {
                        diameter: 25,
                        seed: Object(yt.jsNumberForAddress)(i)
                    }), i.slice(0, 10), "...", i.slice(-5)), a.a.createElement("div", {
                        className: "btns"
                    }, a.a.createElement("button", {
                        onClick: function() {
                            return U(i)
                        }
                    }, a.a.createElement("img", {
                        src: d ? "/img/copy.png" : "/img/copy-gray.png",
                        alt: ""
                    })), a.a.createElement("button", {
                        onClick: function() {
                            oe({
                                setWalletIsConnected: u,
                                setWalletDataIsOpened: A,
                                setWalletAddress: p,
                                chainid: o.id
                            })
                        }
                    }, a.a.createElement("img", {
                        src: d ? "/img/disconect.png" : "/img/disconnect-gray.png",
                        alt: ""
                    })), a.a.createElement("a", {
                        href: "https://etherscan.io/address/".concat(i),
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, a.a.createElement("img", {
                        src: d ? "/img/share.png" : "/img/share-gray.png",
                        alt: ""
                    }))), a.a.createElement("div", {
                        className: "border"
                    }), a.a.createElement("div", {
                        className: "coin-data"
                    }, a.a.createElement("p", null, a.a.createElement("img", {
                        src: o.img || "/img/ethlogo.png",
                        alt: ""
                    }), " ", String(o.symbol || "ETH").toUpperCase()), a.a.createElement("p", null, Number(k).toFixed(4))), a.a.createElement("div", {
                        className: "coin-data"
                    }, a.a.createElement("p", null, a.a.createElement("img", {
                        src: "https://assets.coingecko.com/coins/images/25201/small/logo200.png?1653635992",
                        alt: ""
                    }), " ", "VOLT"), a.a.createElement("p", null, me(j, 2))), a.a.createElement("br", null)))) : a.a.createElement(vt, {
                        callback: function() {
                            var e;
                            y({
                                isOpened: !(null === (e = f.walletAddress) || void 0 === e ? void 0 : e.length) >= 1
                            })
                        }
                    }), a.a.createElement("div", {
                        className: "theme"
                    }, !d && a.a.createElement("button", {
                        onClick: function() {
                            return m(!0)
                        },
                        className: "".concat(d ? "selected" : "", " btn-data")
                    }, a.a.createElement("img", {
                        src: d ? "/img/moon.png" : "/img/moon-gray.png",
                        alt: ""
                    })), d && a.a.createElement("button", {
                        onClick: function() {
                            return m(!1)
                        },
                        className: "".concat(d ? "" : "selected", " btn-data")
                    }, a.a.createElement("img", {
                        src: d ? "/img/sun.png" : "/img/sun-gray.png",
                        alt: ""
                    }))), a.a.createElement(St, null)), M && a.a.createElement("div", {
                        className: "menu-data"
                    }, a.a.createElement("button", {
                        onClick: function() {
                            return D(!1)
                        },
                        className: "exit"
                    }, a.a.createElement("img", {
                        src: f.isDarkTheme ? "/img/close.png" : "/img/close-dark.png",
                        alt: "",
                        style: {
                            width: 20
                        }
                    })), i ? a.a.createElement(a.a.Fragment, null, a.a.createElement("div", {
                        className: "dropdown"
                    }, a.a.createElement("p", {
                        className: "wallet",
                        ref: e
                    }, a.a.createElement(ft.a, {
                        diameter: 25,
                        seed: Object(yt.jsNumberForAddress)(i)
                    }), i.slice(0, 10), "...", i.slice(-5)), a.a.createElement("div", {
                        className: "btns"
                    }, a.a.createElement("button", {
                        onClick: function() {
                            return U(i)
                        }
                    }, a.a.createElement("img", {
                        src: d ? "/img/copy.png" : "/img/copy-gray.png",
                        alt: ""
                    })), a.a.createElement("button", {
                        onClick: function() {
                            oe({
                                setWalletIsConnected: u,
                                setWalletDataIsOpened: A,
                                setWalletAddress: p,
                                chainid: o.id
                            })
                        }
                    }, a.a.createElement("img", {
                        src: d ? "/img/disconect.png" : "/img/disconnect-gray.png",
                        alt: ""
                    })), a.a.createElement("a", {
                        href: "https://etherscan.io/address/".concat(i),
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, a.a.createElement("img", {
                        src: d ? "/img/share.png" : "/img/share-gray.png",
                        alt: ""
                    }))), a.a.createElement("div", {
                        className: "border"
                    }), a.a.createElement("div", {
                        className: "coin-data"
                    }, a.a.createElement("p", null, a.a.createElement("img", {
                        src: o.img || "/img/ethlogo.png",
                        alt: ""
                    }), " ", String(o.symbol || "ETH").toUpperCase()), a.a.createElement("p", null, Number(k).toFixed(4))), a.a.createElement("div", {
                        className: "coin-data"
                    }, a.a.createElement("p", null, a.a.createElement("img", {
                        src: "https://assets.coingecko.com/coins/images/25201/small/logo200.png?1653635992",
                        alt: ""
                    }), " ", "VOLT"), a.a.createElement("p", null, me(j, 2))), a.a.createElement("div", {
                        className: "coin-data"
                    }, a.a.createElement("p", null, a.a.createElement("img", {
                        src: "/img/4.png",
                        alt: ""
                    }), " VDSC"), a.a.createElement("p", null, b)), a.a.createElement("br", null), a.a.createElement("div", {
                        className: "border"
                    }), a.a.createElement("div", {
                        className: "theme-modes"
                    }, a.a.createElement("p", {
                        onClick: function() {
                            return m(!0)
                        },
                        className: d ? "selected" : ""
                    }, a.a.createElement("img", {
                        src: "/img/moon.png",
                        alt: ""
                    }), "Dark theme"), a.a.createElement("p", {
                        onClick: function() {
                            return m(!1)
                        },
                        className: d ? "" : "selected"
                    }, a.a.createElement("img", {
                        src: "/img/sun.png",
                        alt: ""
                    }), "Light theme")))) : a.a.createElement("div", {
                        className: "mobileData"
                    }, a.a.createElement("div", {
                        className: "row"
                    }, a.a.createElement("div", {
                        className: "theme"
                    }, !d && a.a.createElement("button", {
                        onClick: function() {
                            return m(!0)
                        },
                        className: "".concat(d ? "selected" : "", " btn-data")
                    }, a.a.createElement("img", {
                        src: d ? "/img/moon.png" : "/img/moon-gray.png",
                        alt: ""
                    })), d && a.a.createElement("button", {
                        onClick: function() {
                            return m(!1)
                        },
                        className: "".concat(d ? "" : "selected", " btn-data")
                    }, a.a.createElement("img", {
                        src: d ? "/img/sun.png" : "/img/sun-gray.png",
                        alt: ""
                    }))), a.a.createElement(St, null)), a.a.createElement(vt, {
                        styles: {
                            margin: "0 auto"
                        },
                        callback: function() {
                            var e;
                            y({
                                isOpened: !(null === (e = f.walletAddress) || void 0 === e ? void 0 : e.length) >= 1
                            })
                        }
                    })), a.a.createElement("div", {
                        className: "footer"
                    }, a.a.createElement("div", {
                        className: "divider"
                    }), a.a.createElement("p", {
                        className: "copy"
                    }, "\xa9 VOLT INU 2022"), a.a.createElement("p", {
                        className: "block",
                        style: {
                            display: G ? "block" : "none"
                        }
                    }, "Last block:", a.a.createElement("a", {
                        href: "https://etherscan.io/block/".concat(G),
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "block-number"
                    }, G)))))))
                },
                It = Pe.b.div(_t || (_t = Object(De.a)(["\n  /* background: #1c1b1a; */\n  color: #d1fd00;\n  cursor: pointer;\n  border-radius: 12px;\n  position: relative;\n  background: var(--bg-gray-settings);\n  display: flex;\n  align-items: center;\n  padding: 0 10px;\n  z-index: 1 !important;\n\n  .down {\n    width: 20px;\n    margin-left: 5px;\n  }\n\n  .loading {\n    img {\n      height: 25px;\n      width: 25px;\n      padding: 5px 10px;\n    }\n  }\n\n  img {\n    width: 30px;\n  }\n  p {\n    text-align: center;\n    margin: 0;\n    padding: 10px 4px;\n    font-size: 20px;\n    color: var(--color-text);\n    font-weight: 500;\n    white-space: nowrap;\n  }\n  .items {\n    display: none;\n  }\n  .item-selected {\n    display: flex;\n    flex-direction: row;\n    align-items: center;\n    justify-content: center;\n    gap: 10px;\n  }\n  @media (max-width: 499px) {\n    align-items: center;\n    justify-content: center;\n\n    .item-selected {\n      align-items: center;\n    }\n  }\n"])));
            var Ct, Mt = function(e) {
                    var t, n = e.data,
                        i = void 0 === n ? {} : n,
                        o = e.onClick,
                        s = void 0 === o ? function() {
                            return null
                        } : o,
                        c = (e.selectedId, e.isEnter),
                        l = void 0 === c || c,
                        u = Object(r.useContext)(Ze),
                        p = u.networkId;
                    return u.setNetworkId, u.tokenIsLoading, a.a.createElement(It, {
                        onClick: s,
                        isEnter: l
                    }, a.a.createElement("div", {
                        className: "item-selected"
                    }, "" === p ? a.a.createElement("div", {
                        className: "loading"
                    }, a.a.createElement("img", {
                        src: "/img/loading.gif",
                        alt: "Loading..."
                    })) : a.a.createElement(a.a.Fragment, null, a.a.createElement("img", {
                        src: null === i || void 0 === i ? void 0 : i.image,
                        alt: ""
                    }), a.a.createElement("p", null, null === i || void 0 === i || null === (t = i.symbol) || void 0 === t ? void 0 : t.slice(0, 7)))), a.a.createElement("img", {
                        src: "/img/down.png",
                        alt: "",
                        className: "down"
                    }))
                },
                Dt = Pe.b.div(Ct || (Ct = Object(De.a)(["\n  display: ", ';\n  flex-direction: column;\n  justify-content: start;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  height: 100%;\n  width: 100%;\n  background: var(--bg-color-back);\n  border-radius: 27px;\n  z-index: 100000;\n\n  h4 {\n    font-size: 18px;\n  }\n\n  .title-list {\n    display: flex;\n    justify-content: space-between;\n    padding: 10px 20px;\n  }\n\n  .title-list {\n    h1 {\n      font-size: 20px;\n    }\n  }\n\n  .exit {\n    width: 40px;\n    background-color: transparent;\n    border: none;\n\n    img {\n      width: 100%;\n    }\n  }\n  .exit2 {\n    width: 30px;\n    background-color: transparent;\n    border: none;\n\n    img {\n      width: 100%;\n    }\n  }\n\n  .slippage-title {\n    display: flex;\n    align-items: center;\n    margin: 0 30px;\n\n    img {\n      width: 20px;\n      margin-right: 15px;\n    }\n\n    h4 {\n      margin: 0;\n      padding: 0;\n    }\n  }\n  .slippage-data {\n    display: grid;\n    grid-template-columns: 1fr 1fr 1fr 1fr 1.5fr;\n    gap: 15px;\n    justify-content: center;\n    align-items: center;\n    /* background-color: var(--bg-gray-swap-head); */\n    color: var(--color-text);\n    margin: 20px 30px;\n\n    .slippage-item {\n      display: flex;\n      justify-content: center;\n      align-items: center;\n      height: 50px;\n      border-radius: 12px;\n      background-color: var(--bg-gray-swap-head);\n      cursor: pointer;\n      p {\n        vertical-align: middle;\n        margin: 0;\n        padding: 0;\n        text-align: center;\n      }\n      &.active {\n        background-color: #c7e53c;\n        color: #000;\n      }\n    }\n\n    .slippage-input {\n      display: flex;\n      background-color: var(--bg-gray-swap-head);\n      border-radius: 12px;\n      input {\n        width: 100%;\n        background-color: transparent;\n        border: none;\n        font-size: 20px;\n        outline: none;\n        border-radius: 12px;\n        padding-left: 10px;\n        margin-right: 10px;\n        color: var(--color-text);\n\n        &:focus {\n          border: 1px solid rgb(139 183 48);\n        }\n      }\n    }\n  }\n\n  .compatibility-mode {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    padding: 0 30px;\n\n    > div {\n      display: flex;\n      align-items: center;\n      gap: 15px;\n    }\n\n    img {\n      width: 20px;\n      height: 28px;\n    }\n    /* The switch - the box around the slider */\n    .switch {\n      position: relative;\n      display: inline-block;\n      width: 60px;\n      height: 34px;\n    }\n\n    /* Hide default HTML checkbox */\n    .switch input {\n      opacity: 0;\n      width: 0;\n      height: 0;\n    }\n\n    /* The slider */\n    .slider {\n      position: absolute;\n      cursor: pointer;\n      top: 0;\n      left: 0;\n      right: 0;\n      bottom: 0;\n      background-color: #ccc;\n      -webkit-transition: 0.4s;\n      transition: 0.4s;\n    }\n\n    .slider:before {\n      position: absolute;\n      content: "";\n      height: 26px;\n      width: 26px;\n      left: 4px;\n      bottom: 4px;\n      background-color: white;\n      -webkit-transition: 0.4s;\n      transition: 0.4s;\n    }\n\n    input:checked + .slider {\n      background-color: #c7e53c;\n    }\n\n    input:focus + .slider {\n      box-shadow: 0 0 1px #c7e53c;\n    }\n\n    input:checked + .slider:before {\n      -webkit-transform: translateX(26px);\n      -ms-transform: translateX(26px);\n      transform: translateX(26px);\n    }\n\n    /* Rounded sliders */\n    .slider.round {\n      border-radius: 34px;\n    }\n\n    .slider.round:before {\n      border-radius: 50%;\n    }\n  }\n'])), (function(e) {
                    return e.mostSettings.isOpened ? "flex" : "none"
                }));
            var Pt, Ft = function(e) {
                    var t = e.mostSettings,
                        n = void 0 === t ? {
                            isOpened: !0
                        } : t,
                        i = e.setMostSettings,
                        o = void 0 === i ? function() {
                            return null
                        } : i,
                        s = e.onChange,
                        c = void 0 === s ? function() {
                            return null
                        } : s,
                        l = e.slippage,
                        u = e.compatibilityMode,
                        p = e.setCompatibilityMode,
                        d = [{
                            id: "1",
                            label: "0.1%",
                            value: .1
                        }, {
                            id: "2",
                            label: "0.5%",
                            value: .5
                        }, {
                            id: "3",
                            label: "1%",
                            value: 1
                        }, {
                            id: "4",
                            label: Object(tt.b)("AUTO"),
                            value: 3
                        }],
                        m = Object(r.useContext)(Ze);
                    return Object(r.useEffect)((function() {
                        document.onkeydown = function(e) {
                            "27" == (e = e || window.event).keyCode && n.isOpened && o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                isOpened: !1
                            }))
                        }
                    }), [n, o]), a.a.createElement(Dt, {
                        mostSettings: n
                    }, a.a.createElement("div", {
                        className: "title-list"
                    }, a.a.createElement("button", {
                        onClick: function() {
                            return o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                isOpened: !1
                            }))
                        },
                        className: "exit"
                    }, a.a.createElement("img", {
                        src: m.isDarkTheme ? "/img/left.png" : "/img/left-light.png",
                        alt: ""
                    })), a.a.createElement("h1", null, Object(tt.b)("Settings")), a.a.createElement("button", {
                        onClick: function() {
                            return o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                isOpened: !1
                            }))
                        },
                        className: "exit2"
                    }, a.a.createElement("img", {
                        src: "/img/close.png",
                        alt: ""
                    }))), a.a.createElement("div", {
                        className: "slippage-title"
                    }, a.a.createElement("img", {
                        src: "/img/gas.png",
                        alt: ""
                    }), a.a.createElement("h4", null, Object(tt.b)("Slippage tolerance"))), a.a.createElement("div", {
                        className: "slippage-data"
                    }, d.slice(0, 4).map((function(e, t) {
                        return a.a.createElement("div", {
                            key: t,
                            className: "slippage-item ".concat(+e.value === +l ? "active" : ""),
                            onClick: function() {
                                return c(e.value)
                            }
                        }, a.a.createElement("p", null, e.label))
                    })), a.a.createElement("div", {
                        className: "slippage-input"
                    }, a.a.createElement("input", {
                        type: "text",
                        placeholder: l,
                        onChange: function(e) {
                            return c(e.target.value.replace(",", "."))
                        },
                        value: l
                    }), a.a.createElement("p", null, "%"))), a.a.createElement("div", {
                        className: "compatibility-mode"
                    }, a.a.createElement("div", null, a.a.createElement("img", {
                        src: "/img/swap.png",
                        alt: ""
                    }), a.a.createElement("h4", null, Object(tt.b)("Compatibility mode"))), a.a.createElement("label", {
                        className: "switch"
                    }, a.a.createElement("input", {
                        checked: u,
                        onChange: function() {
                            return p(!u)
                        },
                        type: "checkbox"
                    }), a.a.createElement("span", {
                        className: "slider round"
                    }))))
                },
                Bt = Pe.b.div(Pt || (Pt = Object(De.a)(["\n  display: ", ";\n  flex-direction: column;\n  justify-content: start;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  height: 100%;\n  max-height: 700px;\n  min-height: calc(75vh - 135px);\n  width: 100%;\n  background: var(--bg-color-back);\n  border-radius: 12px;\n  z-index: 100000;\n\n  .title-list {\n    display: flex;\n    justify-content: space-between;\n    padding: 10px 20px;\n  }\n\n  .title-list {\n    h1 {\n      font-size: 20px;\n    }\n  }\n\n  .exit {\n    width: 40px;\n    background-color: transparent;\n    border: none;\n\n    img {\n      width: 100%;\n    }\n  }\n  .exit2 {\n    width: 30px;\n    background-color: transparent;\n    border: none;\n\n    img {\n      width: 100%;\n    }\n  }\n\n  .input-token {\n    background-color: transparent;\n    border: 2px solid var(--bg-gray-swap-head);\n    margin: 10px 30px;\n    font-size: 20px;\n    padding: 15px 0 15px 20px;\n    border-radius: 12px;\n    color: var(--color-text);\n  }\n\n  .main-tokens {\n    display: grid;\n    grid-template-columns: repeat(3, 1fr);\n    gap: 15px;\n    margin: 8px 20px 0;\n    border-bottom: 2px solid #aaa;\n    padding: 0 15px 20px;\n\n    @media (max-width: 420px) {\n      grid-template-columns: repeat(2, 1fr);\n    }\n\n    .main-token-item {\n      display: flex;\n      justify-content: center;\n      align-items: center;\n      background-color: var(--bg-gray-swap-head);\n      border-radius: 12px;\n      gap: 10px;\n      padding: 10px;\n      cursor: pointer;\n      img {\n        width: 20px;\n      }\n      p {\n        margin: 0;\n        padding: 0;\n        font-size: 15px;\n      }\n    }\n  }\n  .tokens {\n    overflow-y: auto;\n    padding: 0 40px;\n    margin-top: 30px;\n    .token {\n      display: flex;\n      justify-content: space-between;\n      align-items: center;\n      gap: 20px;\n      margin-bottom: 5px;\n      padding-bottom: 5px;\n      cursor: pointer;\n      transition: all 0.2s;\n      p {\n        flex: 1;\n        width: 100%;\n      }\n      .brand-token {\n        width: 40px;\n      }\n      .arrow {\n        width: 10px;\n      }\n\n      &:hover {\n        transform: scale(1.1);\n      }\n    }\n  }\n"])), (function(e) {
                    return e.mostTokenList.isOpened ? "flex" : "none"
                }));

            function Gt() {
                Gt = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var Ht, Wt, Ut, Rt, zt = function(e) {
                    var t = e.mostTokenList,
                        n = void 0 === t ? {
                            isOpened: !0,
                            type: "in"
                        } : t,
                        i = e.setMostTokenList,
                        o = void 0 === i ? function() {
                            return null
                        } : i,
                        l = e.tokenList,
                        u = void 0 === l ? [{
                            image: "",
                            id: "",
                            name: "",
                            symbol: "",
                            contractAddress: "",
                            token_type: "",
                            decimals: ""
                        }] : l,
                        p = e.mainTokens,
                        d = void 0 === p ? [{
                            image: "",
                            id: "",
                            name: "",
                            symbol: "",
                            contractAddress: "",
                            token_type: "",
                            decimals: ""
                        }] : p,
                        m = e.onChange,
                        y = void 0 === m ? function() {
                            return null
                        } : m,
                        f = e.searchToken,
                        h = Object(r.useContext)(Ze),
                        g = Object(r.useState)(""),
                        b = Object(c.a)(g, 2),
                        v = b[0],
                        x = b[1];
                    return Object(r.useEffect)((function() {
                        document.onkeydown = function(e) {
                            "27" == (e = e || window.event).keyCode && n.isOpened && (x(""), o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                isOpened: !1
                            })))
                        }
                    }), [n, o]), Object(r.useEffect)((function() {
                        var e = setTimeout((function() {
                            v.length >= 1 && f(v)
                        }), 2e3);
                        return function() {
                            return clearTimeout(e)
                        }
                    }), [v]), a.a.createElement(Bt, {
                        mostTokenList: n
                    }, a.a.createElement("div", {
                        className: "title-list"
                    }, a.a.createElement("button", {
                        onClick: function() {
                            x(""), o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                isOpened: !1
                            }))
                        },
                        className: "exit"
                    }, a.a.createElement("img", {
                        src: h.isDarkTheme ? "/img/left.png" : "/img/left-light.png",
                        alt: ""
                    })), a.a.createElement("h1", null, "Select an ", "in" === n.type ? "input " : "out", " token"), a.a.createElement("button", {
                        onClick: function() {
                            x(""), o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                isOpened: !1
                            }))
                        },
                        className: "exit2"
                    }, a.a.createElement("img", {
                        src: "/img/close.png",
                        alt: ""
                    }))), a.a.createElement("input", {
                        type: "text",
                        name: "",
                        id: "",
                        className: "input-token",
                        placeholder: "Search by name or paste address",
                        value: v,
                        onChange: function(e) {
                            return x(e.target.value)
                        }
                    }), a.a.createElement("div", {
                        className: "main-tokens"
                    }, d.slice(0, 4).map((function(e, t) {
                        return a.a.createElement("div", {
                            key: t,
                            className: "main-token-item",
                            onClick: function() {
                                y(n.type, e), x(""), o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                    isOpened: !1
                                }))
                            }
                        }, a.a.createElement("img", {
                            src: e.image,
                            alt: ""
                        }), a.a.createElement("p", null, e.symbol))
                    }))), a.a.createElement("div", {
                        className: "tokens"
                    }, u.map((function(e, t) {
                        return a.a.createElement("div", {
                            key: t,
                            className: "token",
                            onClick: Object(s.a)(Gt().mark((function t() {
                                var r;
                                return Gt().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            if (o(Object(Me.a)(Object(Me.a)({}, n), {}, {
                                                    isOpened: !1
                                                })), !(v.length >= 1)) {
                                                t.next = 7;
                                                break
                                            }
                                            return t.next = 4, Le(e.contractAddress, h.chainData);
                                        case 4:
                                            return r = t.sent, t.next = 7, P.post("/api/prices/addToken", {
                                                contractAddress: e.contractAddress,
                                                userAddress: h.walletAddress,
                                                chain: String(h.chainData.chainName).toLocaleLowerCase(),
                                                liquiditytype: r ? "eth" : "usd"
                                            }).catch((function(e) {
                                                return console.log("errerr", e)
                                            }));
                                        case 7:
                                            y(n.type, e), x("");
                                        case 9:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))
                        }, a.a.createElement("img", {
                            className: "brand-token",
                            src: e.image,
                            alt: ""
                        }), a.a.createElement("p", null, e.name), a.a.createElement("img", {
                            src: "/img/right-arrow.png",
                            alt: "",
                            className: "arrow"
                        }))
                    }))))
                },
                Vt = n(299),
                qt = n(468),
                Yt = Pe.b.div(Ht || (Ht = Object(De.a)(["\n  max-width: 99%;\n  height: ", ";\n  overflow: ", ";\n  width: 100%;\n  /* height: 600px; */\n  color: var(--color-text);\n\n  background-color: var(--bg-color-swap);\n\n  border-radius: 25px;\n  border: 2px solid var(--bc-app);\n  margin: auto;\n  position: relative;\n  /* margin-top: ", "; */\n  box-shadow: 0px 2px 20px 0px rgba(12, 21, 35, 0.15);\n\n  .small-value {\n    font-size: 25px;\n    width: 100%;\n  }\n\n  .item-menu p {\n    text-transform: uppercase;\n  }\n\n  .title {\n    z-index: 1000;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    gap: 20px;\n    padding: 0 20px;\n    h1 {\n      font-size: 28px;\n    }\n    button {\n      background: var(--bg-gray-settings);\n      backdrop-filter: blur(9.5px);\n      margin-top: 20px;\n      height: 60px;\n      width: 60px;\n      border: none;\n      border-radius: 12px;\n\n      img {\n        height: 40%;\n      }\n    }\n  }\n  .content {\n    height: 100%;\n    padding: 26px 20px 20px;\n    margin: 0 0px 20px;\n    border-radius: 20px;\n  }\n  .in-value {\n    display: flex;\n    flex-direction: column;\n    background-color: var(--bg-color-back);\n    padding: 20px 20px 0;\n    border-radius: 22px;\n    z-index: 1 !important;\n    input {\n      background-color: transparent;\n      border: none;\n      outline: none;\n      font-size: 25px;\n      width: 100%;\n      color: var(--color-text);\n      padding-right: 10px;\n    }\n    .inputs {\n      display: flex;\n      align-items: center;\n    }\n    .balance {\n      display: flex;\n      align-items: center;\n      justify-content: space-between;\n      > div {\n        display: flex;\n        align-items: center;\n        justify-content: end;\n        margin: 15px 10px;\n\n        gap: 15px;\n\n        p {\n          margin: 0;\n          padding: 0;\n        }\n      }\n    }\n  }\n  .invert-container {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    margin-top: -8px;\n    margin-bottom: -8px;\n  }\n  .invert {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    background-color: #d1fd00;\n    border: 2px solid #1c1c18;\n    margin: 0 auto 0;\n    padding: 3px 0;\n    border-radius: 6px;\n    width: 28px;\n    height: 28px;\n    img {\n      width: 20px;\n    }\n\n    /* &:hover{\n      transform: rotate();\n    } */\n  }\n  .out-value {\n    z-index: 1;\n    display: flex;\n    flex-direction: column;\n    background-color: #000;\n    padding: 20px 20px 0;\n    border-radius: 12px;\n    margin-top: 10px;\n    input {\n      background-color: transparent;\n      border: none;\n      outline: none;\n      font-size: 20px;\n      width: 100%;\n      color: var(--color-text);\n      padding-right: 10px;\n    }\n    .inputs {\n      display: flex;\n      align-items: center;\n    }\n    .balance {\n      display: flex;\n      align-items: center;\n      justify-content: end;\n      margin: 15px 10px;\n\n      gap: 15px;\n\n      p {\n        margin: 0;\n        padding: 0;\n      }\n    }\n  }\n\n  .buttons-container {\n    /* position: absolute;\n    right: 0;\n    left: 0;\n    top: -100px; */\n    background-color: var(--bg-gray-swap-head);\n    backdrop-filter: blur(17px);\n    padding: 15px;\n    border-radius: 25px 25px 0 0;\n    border-bottom: 2px solid #ddd2;\n    display: ", ';\n    justify-content: space-between;\n    align-items: center;\n\n    > div {\n      display: flex;\n      flex-direction: column;\n      align-items: center;\n      color: rgba(212, 221, 224, 0.6);\n      padding: 0 30px;\n      gap: 5px;\n      position: relative;\n      cursor: not-allowed;\n      opacity: 0.7;\n      &.active {\n        color: rgb(139 183 48);\n        cursor: pointer;\n        opacity: 1;\n      }\n      &.active::before {\n        content: "";\n        height: 5px;\n        background-color: var(--bg-swap-btn);\n        border-radius: 5px 5px 0 0;\n        position: absolute;\n        bottom: -20px;\n        right: auto;\n        left: auto;\n        width: 60%;\n      }\n      img {\n        width: 30px;\n      }\n      p {\n        margin: 0%;\n        padding: 0%;\n        font-size: 18px;\n        margin-top: 5px;\n        color: var(--color-text);\n        font-weight: 600;\n      }\n    }\n  }\n\n  .slippage {\n    width: 100%;\n    text-align: center;\n    font-size: 14px;\n  }\n\n  @media (max-width: 550px) {\n    .buttons-container {\n      display: none;\n    }\n  }\n\n  @media (max-width: 499px) {\n    margin: 0 auto 0 0;\n    max-width: 94vw;\n    width: 94vw;\n\n    .data-container {\n      margin: auto;\n      max-width: 85vw !important;\n      width: 85vw !important;\n    }\n    .inputs {\n      flex-direction: column-reverse !important;\n\n      input {\n        text-align: center;\n        margin-top: 8px;\n        border: 2px solid var(--bc-app);\n        border-radius: 12px;\n        padding: 12px 0;\n      }\n    }\n  }\n\n  @media (max-width: 382px) {\n    .item-footer {\n      display: flex;\n      align-items: center;\n      flex-direction: column !important;\n    }\n  }\n'])), (function(e) {
                    return e.mostData ? "auto" : "95vh"
                }), (function(e) {
                    return e.mostData ? "auto" : "hidden"
                }), (function(e) {
                    return e.mostData ? " -100px" : "-100px"
                }), (function(e) {
                    return e.mostData ? "flex" : "none"
                })),
                Jt = Pe.b.div(Wt || (Wt = Object(De.a)(["\n  color: var(--color-text);\n  margin-right: 0;\n  overflow: ", ";\n  margin-top: ", ";\n  @media screen and (max-width: 500px) {\n    max-width: ", " !important;\n    margin-top: 0 !important;\n  }\n  @media screen and (min-width: 501px) and (max-width: 1440px) {\n    width: 475px !important;\n  }\n  .data-container {\n    background-color: var(--bg-color-swap);\n\n    border: 2px solid var(--bc-app);\n    padding: 15px;\n    border-radius: 20px;\n    margin: 30px auto 30px 0;\n    width: 525px;\n    box-shadow: 0px 2px 20px 0px rgba(12, 21, 35, 0.15);\n\n    .item-footer {\n      display: flex;\n      align-items: center;\n      justify-content: space-between;\n      p {\n        display: flex;\n        align-items: flex-start;\n        font-size: 18px;\n        img {\n          height: 25px;\n        }\n      }\n    }\n    .gas-prices {\n      background-color: var(--bg-color-back);\n      border-radius: 12px;\n      .gas-item {\n        padding: 0 20px;\n        margin: 0 10px;\n        display: flex;\n        justify-content: space-between;\n        align-items: center;\n        border-bottom: 2px solid #ddd2;\n        &:last-child {\n          border-bottom: 0;\n        }\n        p {\n          display: flex;\n          align-items: flex-start;\n          font-size: 18px;\n          img {\n            height: 25px;\n          }\n        }\n      }\n    }\n  }\n\n  @media (max-width: 1440px) {\n    .data-container {\n      width: 440px !important;\n      max-width: 440px !important;\n    }\n  }\n\n  @media (max-width: 499px) {\n    .data-container {\n      max-width: calc(93vw - 25px) !important;\n      width: calc(93vw - 28px) !important;\n    }\n  }\n\n  @media (max-width: 382px) {\n    .item-footer {\n      display: flex;\n      align-items: center;\n    }\n  }\n"])), (function(e) {
                    return e.mostData ? "auto" : "hidden"
                }), (function(e) {
                    return e.mostData ? "-100px" : "0"
                }), (function(e) {
                    return e.mostData ? "95vw" : "100vw"
                })),
                Kt = Pe.b.div(Ut || (Ut = Object(De.a)(["\n  background-color: var(--bg-color-swap);\n  display: flex;\n  align-items: center;\n  width: 300px;\n  font-size: 18px;\n\n  > div {\n    padding-right: 20px;\n  }\n\n  p {\n    margin: 0;\n  }\n\n  a {\n    color: var(--color-text);\n    margin-top: 20px;\n  }\n\n  img {\n    width: 40px;\n    margin-right: 20px;\n  }\n\n  .close {\n    background-color: transparent;\n    color: var(--color-text);\n    border: none;\n    position: absolute;\n    top: 9px;\n    right: 15px;\n    cursor: pointer;\n  }\n"]))),
                Xt = Pe.b.div(Rt || (Rt = Object(De.a)(["\n  background: var(--bg-gray-settings);\n\n  color: #d1fd00;\n  cursor: pointer;\n  border-radius: 12px;\n  position: relative;\n  display: flex;\n  align-items: center;\n  padding: 20px 0px;\n  width: ", ";\n  gap: 8px;\n  margin-top: 20px;\n  z-index: 1000;\n\n  justify-content: space-between;\n\n  .item-selected {\n    width: 100%;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    gap: 38px;\n    padding: 0 20px;\n\n    p {\n      margin-left: -18px;\n    }\n  }\n\n  .down {\n    width: 20px;\n    margin-left: 0px;\n  }\n\n  img {\n    width: 25px;\n  }\n  p {\n    text-align: center;\n    margin: 0;\n    padding: 0;\n    color: var(--color-text);\n    text-transform: uppercase;\n    font-weight: 600;\n  }\n\n  &:hover .items {\n    display: flex;\n    flex-direction: column;\n    position: absolute;\n    padding-top: 8px;\n    border-radius: 0 0 8px 8px;\n    top: 55px;\n    left: 0;\n    right: 0;\n    background: var(--bg-color-back);\n    z-index: 9999999999999;\n  }\n  .items {\n    display: none;\n  }\n  .item {\n    padding: 15px;\n    gap: 20px;\n    display: flex;\n    flex-direction: row;\n    align-items: center;\n    justify-content: flex-start;\n    padding-left: 31px;\n    border-radius: 0 0 8px 8px;\n  }\n  .item-selected {\n    display: flex;\n    flex-direction: row;\n    align-items: center;\n    justify-content: center;\n    border-radius: 0 0 8px 8px;\n    /* gap: 10px; */\n  }\n  .token-symbol {\n    display: none;\n  }\n\n  .item:hover,\n  &:hover {\n    background-color: var(--bg-gray-settings);\n  }\n\n  @media (max-width: 440px) {\n    .down {\n      margin-left: -30px;\n    }\n    .token-symbol {\n      display: block;\n    }\n    .token-name {\n      display: none;\n    }\n  }\n"])), (function(e) {
                    return e.mostData ? "60%" : "45%"
                }));
            var $t = function(e) {
                var t = e.data,
                    n = void 0 === t ? [] : t,
                    i = e.cleanBalance,
                    o = e.getBalance,
                    s = e.mostData,
                    c = Object(r.useContext)(Ze),
                    l = c.networkId,
                    u = c.setNetworkId,
                    p = (c.setHasError, c.walletIsConnected),
                    d = n.filter((function(e) {
                        return +e.id === +l
                    }))[0];
                return a.a.createElement(Xt, {
                    mostData: s
                }, a.a.createElement("div", {
                    className: "item-selected"
                }, "" === l ? a.a.createElement(a.a.Fragment, null, a.a.createElement("img", {
                    src: "/img/loading.gif",
                    alt: "Loading..."
                })) : a.a.createElement(a.a.Fragment, null, a.a.createElement("img", {
                    src: null === d || void 0 === d ? void 0 : d.img,
                    alt: ""
                }), a.a.createElement("p", {
                    className: "token-name"
                }, s ? null === d || void 0 === d ? void 0 : d.name : null === d || void 0 === d ? void 0 : d.symbol), a.a.createElement("p", {
                    className: "token-symbol"
                }, null === d || void 0 === d ? void 0 : d.symbol)), a.a.createElement("img", {
                    src: "/img/down.png",
                    alt: "",
                    className: "down"
                })), a.a.createElement("div", {
                    className: "items"
                }, n.filter((function(e) {
                    return e.id
                })).map((function(e, t) {
                    return a.a.createElement("div", {
                        key: t,
                        className: "item",
                        onClick: function() {
                            localStorage.getItem("@WALLET_TYPE");
                            pe(e.id, u, i, o, p)
                        }
                    }, a.a.createElement("img", {
                        src: e.img,
                        alt: ""
                    }), a.a.createElement("p", {
                        className: "token-name"
                    }, s ? null === e || void 0 === e ? void 0 : e.name : null === e || void 0 === e ? void 0 : e.symbol), a.a.createElement("p", {
                        className: "token-symbol"
                    }, null === e || void 0 === e ? void 0 : e.symbol))
                }))))
            };

            function Zt() {
                Zt = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var Qt, en, tn, nn = function(e) {
                    var t = e.mostData,
                        n = void 0 === t || t,
                        i = Object(r.useContext)(Ze),
                        o = (new d.a(d.a.givenProvider), Object(r.useContext)(Ze)),
                        l = o.tokenSelectedIn,
                        u = o.setTokenSelectedIn,
                        p = o.tokenSelectedOut,
                        m = o.setTokenSelectedOut,
                        y = o.favoritedPairs,
                        f = o.setFavoritedPairs,
                        g = (o.mostConnectWallet, o.setMostConnectWallet),
                        b = o.slippage,
                        v = o.setSlippage,
                        x = Object(r.useState)([]),
                        w = Object(c.a)(x, 2),
                        k = w[0],
                        E = w[1],
                        T = (Object(r.useContext)(Ze).walletIsConnected, Object(r.useState)({
                            ETH: [{
                                image: "",
                                id: "",
                                name: "",
                                symbol: "",
                                contractAddress: "",
                                token_type: "",
                                decimals: ""
                            }],
                            BNB: [{
                                image: "",
                                id: "",
                                name: "",
                                symbol: "",
                                contractAddress: "",
                                token_type: "",
                                decimals: ""
                            }]
                        })),
                        O = Object(c.a)(T, 2),
                        j = O[0],
                        L = O[1],
                        S = Object(r.useState)({
                            isOpened: !1,
                            type: "in"
                        }),
                        N = Object(c.a)(S, 2),
                        _ = N[0],
                        A = N[1],
                        I = Object(r.useState)({
                            isOpened: !1
                        }),
                        C = Object(c.a)(I, 2),
                        M = C[0],
                        D = C[1],
                        F = Object(r.useState)("0"),
                        B = Object(c.a)(F, 2),
                        G = B[0],
                        H = B[1],
                        W = Object(r.useState)("0"),
                        U = Object(c.a)(W, 2),
                        R = (U[0], U[1]),
                        z = Object(r.useState)("0"),
                        V = Object(c.a)(z, 2),
                        q = V[0],
                        Y = V[1],
                        J = Object(r.useState)(""),
                        K = Object(c.a)(J, 2),
                        X = K[0],
                        $ = K[1],
                        Z = Object(r.useState)(""),
                        Q = Object(c.a)(Z, 2),
                        ee = Q[0],
                        te = (Q[1], Object(r.useState)("")),
                        ne = Object(c.a)(te, 2),
                        re = ne[0],
                        ie = ne[1],
                        se = Object(r.useState)(!1),
                        ce = Object(c.a)(se, 2),
                        le = ce[0],
                        ue = ce[1],
                        ye = Object(r.useState)(!1),
                        be = Object(c.a)(ye, 2),
                        ve = be[0],
                        we = be[1],
                        Ee = Object(r.useState)(!1),
                        Te = Object(c.a)(Ee, 2),
                        je = Te[0],
                        Le = Te[1],
                        Se = Object(r.useState)(!1),
                        Ne = Object(c.a)(Se, 2),
                        _e = Ne[0],
                        Ae = Ne[1],
                        Me = Object(r.useState)(!1),
                        De = Object(c.a)(Me, 2),
                        Pe = (De[0], De[1]),
                        Fe = Object(r.useState)(!1),
                        Be = Object(c.a)(Fe, 2),
                        Ge = Be[0],
                        He = Be[1],
                        We = Object(r.useState)("0"),
                        Ue = Object(c.a)(We, 2),
                        Re = Ue[0],
                        ze = Ue[1],
                        Ve = Object(r.useState)(""),
                        Ye = Object(c.a)(Ve, 2),
                        Je = Ye[0],
                        Ke = Ye[1],
                        $e = Object(r.useState)(""),
                        Qe = Object(c.a)($e, 2),
                        et = (Qe[0], Qe[1], Object(r.useState)("")),
                        nt = Object(c.a)(et, 2),
                        rt = nt[0],
                        at = nt[1],
                        it = Object(r.useState)(""),
                        ot = Object(c.a)(it, 2),
                        st = ot[0],
                        ct = ot[1],
                        lt = Object(r.useState)(""),
                        ut = Object(c.a)(lt, 2),
                        pt = ut[0],
                        dt = ut[1],
                        mt = Object(r.useState)(""),
                        yt = Object(c.a)(mt, 2),
                        ft = yt[0],
                        ht = yt[1],
                        gt = Object(r.useState)(!1),
                        bt = Object(c.a)(gt, 2),
                        wt = bt[0],
                        kt = bt[1],
                        Et = Object(r.useState)({
                            gwei: {
                                low: 0,
                                mid: 0,
                                high: 0
                            },
                            eth: {
                                low: 0,
                                mid: 0,
                                high: 0
                            },
                            usd: {
                                low: 0,
                                mid: 0,
                                high: 0
                            }
                        }),
                        Tt = Object(c.a)(Et, 2),
                        Ot = Tt[0],
                        jt = Tt[1],
                        Lt = Object(r.useState)([]),
                        St = Object(c.a)(Lt, 2),
                        Nt = (St[0], St[1]),
                        _t = Object(r.useState)(!1),
                        At = Object(c.a)(_t, 2),
                        It = At[0],
                        Ct = At[1],
                        Dt = Object(r.useState)(!1),
                        Pt = Object(c.a)(Dt, 2),
                        Bt = Pt[0];
                    Pt[1], Object(r.useEffect)((function() {
                        console.log(window.ethereum)
                    }), []), Object(r.useEffect)((function() {
                        Object(s.a)(Zt().mark((function e() {
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (!(+(null === X || void 0 === X ? void 0 : X.length) > 0 || +(null === re || void 0 === re ? void 0 : re.length) > 0)) {
                                            e.next = 11;
                                            break
                                        }
                                        return e.t0 = at, e.next = 4, Ce(l.contractAddress, i.chainData.symbol);
                                    case 4:
                                        return e.t1 = e.sent, (0, e.t0)(e.t1), e.t2 = ct, e.next = 9, Ce(p.contractAddress, i.chainData.symbol);
                                    case 9:
                                        e.t3 = e.sent, (0, e.t2)(e.t3);
                                    case 11:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), [X, re, i.chainData, l, p]), Object(r.useEffect)((function() {
                        var e = localStorage.getItem("@COMPATIBILITYMODE"),
                            t = localStorage.getItem("@SLIPPAGE");
                        v(+t || 3), He("true" === e)
                    }), []), Object(r.useEffect)((function() {
                        Object(s.a)(Zt().mark((function e() {
                            var t, n, r, a;
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, P.get("/api/prices/getList?chain=eth&userAddress=".concat(i.walletAddress));
                                    case 2:
                                        return t = e.sent, n = t.data, e.next = 6, P.get("/api/prices/getList?chain=bsc&userAddress=".concat(i.walletAddress));
                                    case 6:
                                        r = e.sent, a = r.data, L({
                                            ETH: n,
                                            BNB: a
                                        });
                                    case 9:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), [i.walletAddress, i.chainData]), Object(r.useEffect)((function() {
                        var e = Vt[i.chainData.symbol];
                        E(e), u(e[0]), m(e.filter((function(e) {
                            return "VOLT" === e.symbol
                        }))[0])
                    }), [i.chainData.symbol, u, m]), Object(r.useEffect)((function() {
                        Object(s.a)(Zt().mark((function e() {
                            var t, n, r;
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (_e) {
                                            e.next = 36;
                                            break
                                        }
                                        return e.prev = 1, we(!0), e.next = 5, de(i.walletAddress, "ethereum" === l.id, l.contractAddress);
                                    case 5:
                                        return t = e.sent, H(t), e.next = 9, de(i.walletAddress, "ethereum" === p.id, null === p || void 0 === p ? void 0 : p.contractAddress);
                                    case 9:
                                        if (n = e.sent, Y(n), "ethereum" !== l.id) {
                                            e.next = 15;
                                            break
                                        }
                                        e.t0 = !0, e.next = 28;
                                        break;
                                    case 15:
                                        if (p.contractAddress !== i.chainData.wrappedtoken || "ethereum" !== l.id) {
                                            e.next = 19;
                                            break
                                        }
                                        e.t1 = !0, e.next = 27;
                                        break;
                                    case 19:
                                        if (l.contractAddress !== i.chainData.wrappedtoken || "ethereum" !== p.id) {
                                            e.next = 23;
                                            break
                                        }
                                        e.t2 = !0, e.next = 26;
                                        break;
                                    case 23:
                                        return e.next = 25, fe(i.walletAddress, l.contractAddress, i.chainData.symbol);
                                    case 25:
                                        e.t2 = e.sent;
                                    case 26:
                                        e.t1 = e.t2;
                                    case 27:
                                        e.t0 = e.t1;
                                    case 28:
                                        r = e.t0, ue(r), we(!1), e.next = 36;
                                        break;
                                    case 33:
                                        e.prev = 33, e.t3 = e.catch(1), we(!1);
                                    case 36:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [1, 33]
                            ])
                        })))()
                    }), [i.walletAddress, p, l, i.chainData, _e]), Object(r.useEffect)((function() {
                        Object(s.a)(Zt().mark((function e() {
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.t0 = jt, e.next = 3, Oe(i.chainData.symbol);
                                    case 3:
                                        e.t1 = e.sent, (0, e.t0)(e.t1);
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), []), Object(r.useEffect)((function() {
                        Object(s.a)(Zt().mark((function e() {
                            var t, n;
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (!(null === l || void 0 === l ? void 0 : l.contractAddress) || !(null === p || void 0 === p ? void 0 : p.contractAddress)) {
                                            e.next = 6;
                                            break
                                        }
                                        return e.next = 3, P.get("/api/prices/veryfy_favorite_pair?tokenin=".concat(l.contractAddress, "&tokenout=").concat(p.contractAddress, "&tokeninisnative=").concat("ethereum" === l.id, "&tokenoutisnative=").concat("ethereum" === p.id));
                                    case 3:
                                        t = e.sent, n = t.data, Ke(n.id);
                                    case 6:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), [l, p]), Object(r.useEffect)((function() {
                        Object(s.a)(Zt().mark((function e() {
                            var t;
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        (null === l || void 0 === l ? void 0 : l.contractAddress) && (null === p || void 0 === p ? void 0 : p.contractAddress) && (t = (null === y || void 0 === y ? void 0 : y.length) >= 1 && (null === y || void 0 === y ? void 0 : y.filter((function(e) {
                                            return e.tokenin.contractAddress === l.contractAddress && e.tokenout.contractAddress === p.contractAddress && (null === e || void 0 === e ? void 0 : e.slippage) == b && (null === e || void 0 === e ? void 0 : e.iscompatibilitymode) === Ge
                                        }))), kt(t.length >= 1), t.length >= 1 && Ke(t[0].id));
                                    case 1:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), [l, p, Ge, y, b, Ke]), Object(r.useEffect)((function() {
                        var e, t, n, r, a;
                        (null === (e = i.updateTokens.tokenin) || void 0 === e || null === (t = e.contractAddress) || void 0 === t ? void 0 : t.length) >= 1 && (null === (n = i.updateTokens) || void 0 === n || null === (r = n.tokenout) || void 0 === r || null === (a = r.contractAddress) || void 0 === a ? void 0 : a.length) >= 1 && (u(i.updateTokens.tokenin), m(i.updateTokens.tokenout), v(i.updateTokens.slippage), He(i.updateTokens.iscompatibilitymode), i.setUpdateTokens({
                            tokenin: {},
                            tokenout: {},
                            slippage: "0",
                            iscompatibilitymode: !1
                        }))
                    }), [i.updateTokens, i.setUpdateTokens, u, m]);
                    var Gt = function() {
                            var e = Object(s.a)(Zt().mark((function e(t) {
                                var n, r;
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, P.get("/api/prices/searchToken?q=".concat(t, "&chain=").concat(String(i.chainData.chainName).toLowerCase(), "&userAddress=").concat(i.walletAddress));
                                        case 3:
                                            n = e.sent, r = n.data, L({
                                                ETH: r,
                                                BNB: r
                                            }), e.next = 11;
                                            break;
                                        case 8:
                                            e.prev = 8, e.t0 = e.catch(0), console.log(e.t0.response);
                                        case 11:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [0, 8]
                                ])
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        Ht = function() {
                            var e = Object(s.a)(Zt().mark((function e() {
                                var t, n, r, a, o, s, c;
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (we(!0), Ae(!0), t = l, r = q, a = G, o = X, s = re, "ethereum" !== (n = p).id) {
                                                e.next = 12;
                                                break
                                            }
                                            e.t0 = !0, e.next = 15;
                                            break;
                                        case 12:
                                            return e.next = 14, fe(i.walletAddress, n.contractAddress, i.chainData.symbol);
                                        case 14:
                                            e.t0 = e.sent;
                                        case 15:
                                            c = e.t0, ie(String(o).replace(",", "")), $(String(s).replace(",", "")), ue(c), H(a), Y(r), u(n), m(t), we(!1), Ae(!1);
                                        case 25:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        Wt = function(e, t) {
                            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
                            Object(xt.toast)((function(r) {
                                return a.a.createElement(Kt, null, a.a.createElement("button", {
                                    onClick: function() {
                                        return xt.toast.dismiss(r.id)
                                    },
                                    className: "close"
                                }, "X"), t ? a.a.createElement("img", {
                                    src: "/img/success.png",
                                    alt: ""
                                }) : a.a.createElement("img", {
                                    src: "/img/error.png",
                                    alt: ""
                                }), a.a.createElement("div", null, a.a.createElement("p", null, e), (null === n || void 0 === n ? void 0 : n.length) >= 1 && a.a.createElement("a", {
                                    href: n,
                                    target: "_blank",
                                    rel: "noopener noreferrer"
                                }, "View in explorer")))
                            }), {
                                duration: 5e3,
                                style: {
                                    borderRadius: "10px",
                                    background: "var(--bg-color-swap)",
                                    color: "var(--color-text)"
                                }
                            })
                        },
                        Ut = function() {
                            var e = Object(s.a)(Zt().mark((function e() {
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, we(!0), e.next = 4, xe(l.contractAddress, 0, b, i.walletAddress, i.chainData.symbol);
                                        case 4:
                                            we(!1), ue(!0), Wt("successfully approved token", !0), e.next = 13;
                                            break;
                                        case 9:
                                            e.prev = 9, e.t0 = e.catch(0), Wt("Operation cancelled", !1), we(!1);
                                        case 13:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [0, 9]
                                ])
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        Rt = function() {
                            var e = Object(s.a)(Zt().mark((function e() {
                                var t, n;
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return we(!0), e.next = 3, ae(i.chainData.symbol);
                                        case 3:
                                            if (e.sent) {
                                                e.next = 6;
                                                break
                                            }
                                            return pe(+i.chainData.id, null, null, null, !0), e.abrupt("return");
                                        case 6:
                                            return console.log("pathResponsepathResponse", Bt), e.next = 9, ke(l.contractAddress, null === p || void 0 === p ? void 0 : p.contractAddress, !1, null === (t = String(X)) || void 0 === t ? void 0 : t.replaceAll(",", ""), null === (n = String(re)) || void 0 === n ? void 0 : n.replaceAll(",", ""), i.chainData.symbol, "ethereum" === l.id ? "ethin" : "ethereum" === p.id ? "ethout" : "", i.walletAddress, l, p, b, "wrapped-token" === l.id || "wrapped-token" === p.id, Ge, Bt).then(function() {
                                                var e = Object(s.a)(Zt().mark((function e(t) {
                                                    var n, r, a, o, s, c, u, d;
                                                    return Zt().wrap((function(e) {
                                                        for (;;) switch (e.prev = e.next) {
                                                            case 0:
                                                                if (console.log(t), null === t || void 0 === t ? void 0 : t.transactionHash) {
                                                                    e.next = 7;
                                                                    break
                                                                }
                                                                return R(JSON.stringify(t)), we(!1), Wt("Operation cancelled", !1), console.log(t), e.abrupt("return");
                                                            case 7:
                                                                return R(JSON.stringify(t)), console.log("resresres", t), we(!1), e.prev = 10, we(!0), e.next = 14, P.get("/api/prices/blockNumber?chain=".concat(i.chainData.symbol));
                                                            case 14:
                                                                return n = e.sent, r = n.data.block, e.next = 18, de(i.walletAddress, "ethereum" === l.id, l.contractAddress);
                                                            case 18:
                                                                return a = e.sent, H(a), e.next = 22, de(i.walletAddress, "ethereum" === p.id, null === p || void 0 === p ? void 0 : p.contractAddress);
                                                            case 22:
                                                                if (o = e.sent, Y(o), "ethereum" !== l.id) {
                                                                    e.next = 28;
                                                                    break
                                                                }
                                                                e.t0 = !0, e.next = 31;
                                                                break;
                                                            case 28:
                                                                return e.next = 30, fe(i.walletAddress, l.contractAddress, i.chainData.symbol);
                                                            case 30:
                                                                e.t0 = e.sent;
                                                            case 31:
                                                                return s = e.t0, ue(s), e.next = 35, P.post("/api/prices/transaction", {
                                                                    block_number: r,
                                                                    chain: "eth" === String(i.chainData.symbol).toLowerCase() ? "eth" : "bsc",
                                                                    input: JSON.stringify({
                                                                        block_number: r,
                                                                        chain: "eth" === String(i.chainData.symbol).toLowerCase() ? "eth" : "bsc",
                                                                        input: "",
                                                                        hash: null === t || void 0 === t ? void 0 : t.transactionHash,
                                                                        nativedata: JSON.stringify(t),
                                                                        created_at: new Date,
                                                                        status: "success",
                                                                        functionname: "ethereum" === l.id ? "swapETHForToken" : "ethereum" === p.id ? "swapTokenForETH" : "swapTokenForToken",
                                                                        tokenin: l.contractAddress,
                                                                        tokenout: p.contractAddress
                                                                    }),
                                                                    hash: null === t || void 0 === t ? void 0 : t.transactionHash,
                                                                    nativedata: JSON.stringify(t),
                                                                    created_at: new Date,
                                                                    status: "success",
                                                                    functionname: "ethereum" === l.id ? "swapETHForToken" : "ethereum" === p.id ? "swapTokenForETH" : "swapTokenForToken",
                                                                    tokenin: l.contractAddress,
                                                                    tokenout: p.contractAddress
                                                                });
                                                            case 35:
                                                                return c = e.sent, c.data, e.next = 39, P.get("/api/prices/transactions?chain=".concat(String(i.chainData.chainName).toLowerCase()));
                                                            case 39:
                                                                u = e.sent, d = u.data, i.setHistoryTransaction(d.data), we(!1), e.next = 48;
                                                                break;
                                                            case 45:
                                                                e.prev = 45, e.t1 = e.catch(10), we(!1);
                                                            case 48:
                                                                $(""), ie(""), Wt("Swap done successfully!", !0, "".concat("eth" === String(i.chainData.symbol).toLowerCase() ? "https://etherscan.io/tx" : "https://bscscan.com/tx", "/").concat(null === t || void 0 === t ? void 0 : t.transactionHash));
                                                            case 51:
                                                            case "end":
                                                                return e.stop()
                                                        }
                                                    }), e, null, [
                                                        [10, 45]
                                                    ])
                                                })));
                                                return function(t) {
                                                    return e.apply(this, arguments)
                                                }
                                            }()).catch((function(e) {
                                                var t;
                                                R(JSON.stringify(e.message)), we(!1), Wt((null === (t = e.originalError) || void 0 === t ? void 0 : t.message) || "Operation cancelled", !1), console.log(e)
                                            }));
                                        case 9:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        Xt = function() {
                            var e = Object(s.a)(Zt().mark((function e() {
                                var t, n;
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, P.post("/api/prices/favorite_pair", {
                                                tokenin: l.contractAddress,
                                                tokenout: null === p || void 0 === p ? void 0 : p.contractAddress,
                                                tokeninisnative: "ethereum" === l.id,
                                                tokenoutisnative: "ethereum" === p.id,
                                                chain: "eth" === String(i.chainData.symbol).toLowerCase() ? "eth" : "bsc",
                                                slippage: b,
                                                iscompatibilitymode: Ge
                                            });
                                        case 3:
                                            return e.next = 5, P.get("/api/prices/favorite_pair?chain=".concat(i.chainData.chainName));
                                        case 5:
                                            t = e.sent, n = t.data, f(n), e.next = 12;
                                            break;
                                        case 10:
                                            e.prev = 10, e.t0 = e.catch(0);
                                        case 12:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [0, 10]
                                ])
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        Qt = function() {
                            var e = Object(s.a)(Zt().mark((function e() {
                                var t, n;
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, P.delete("/api/prices/favorite_pair?id=".concat(Je));
                                        case 3:
                                            return e.next = 5, P.get("/api/prices/favorite_pair?chain=".concat(i.chainData.chainName));
                                        case 5:
                                            t = e.sent, n = t.data, f(n), e.next = 12;
                                            break;
                                        case 10:
                                            e.prev = 10, e.t0 = e.catch(0);
                                        case 12:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [0, 10]
                                ])
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        en = function() {
                            var e = Object(s.a)(Zt().mark((function e(t) {
                                var n, r, a;
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (we(!0), !(Math.ceil(null === t || void 0 === t ? void 0 : t.replaceAll(",", "")) >= 1) || je) {
                                                e.next = 17;
                                                break
                                            }
                                            return console.log(t), e.next = 5, ge(null === t || void 0 === t ? void 0 : t.replaceAll(",", ""), l.contractAddress, null === p || void 0 === p ? void 0 : p.contractAddress, i.walletAddress, l, p, i.chainData.symbol, +b, null, !0, Nt, !1);
                                        case 5:
                                            return n = e.sent, Le(!0), ie(n), Le(!1), e.next = 11, Ie(i.chainData.symbol, null === X || void 0 === X ? void 0 : X.replaceAll(",", ""), null === l || void 0 === l ? void 0 : l.contractAddress);
                                        case 11:
                                            return r = e.sent, e.next = 14, Ie(i.chainData.symbol, null === n || void 0 === n ? void 0 : n.replaceAll(",", ""), null === p || void 0 === p ? void 0 : p.contractAddress);
                                        case 14:
                                            a = e.sent, dt(+Math.ceil(r) >= 1 ? new Intl.NumberFormat("en-us", {
                                                style: "currency",
                                                currency: "USD"
                                            }).format(r) : ""), ht(Math.ceil(a) >= 1 ? new Intl.NumberFormat("en-us", {
                                                style: "currency",
                                                currency: "USD"
                                            }).format(a) : "");
                                        case 17:
                                            we(!1);
                                        case 18:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        tn = function() {
                            var e = Object(s.a)(Zt().mark((function e(t) {
                                var n, r, a;
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (we(!0), !(Math.ceil(null === t || void 0 === t ? void 0 : t.replaceAll(",", "")) >= 1) || je) {
                                                e.next = 16;
                                                break
                                            }
                                            return e.next = 4, he(null === t || void 0 === t ? void 0 : t.replaceAll(",", ""), null === p || void 0 === p ? void 0 : p.contractAddress, l.contractAddress, i.walletAddress, p, l, i.chainData.symbol, +b, null, !0, Nt, !0);
                                        case 4:
                                            return n = e.sent, Le(!0), $(n.inputAmount), Le(!1), e.next = 10, Ie(i.chainData.symbol, n, null === l || void 0 === l ? void 0 : l.contractAddress);
                                        case 10:
                                            return r = e.sent, e.next = 13, Ie(i.chainData.symbol, re, null === p || void 0 === p ? void 0 : p.contractAddress);
                                        case 13:
                                            a = e.sent, dt(+Math.ceil(r) >= 1 ? new Intl.NumberFormat("en-us", {
                                                style: "currency",
                                                currency: "USD"
                                            }).format(r) : ""), ht(Math.ceil(a) >= 1 ? new Intl.NumberFormat("en-us", {
                                                style: "currency",
                                                currency: "USD"
                                            }).format(a) : "");
                                        case 16:
                                            we(!1);
                                        case 17:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t) {
                                return e.apply(this, arguments)
                            }
                        }();
                    return Object(r.useEffect)((function() {
                        var e = function() {
                                var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                                return Number((null === (e = t.replace("$", "")) || void 0 === e ? void 0 : e.replaceAll(",", "")) || 0) || 0
                            },
                            t = e(pt) - e(ft),
                            n = t / e(pt),
                            r = 10 * n;
                        console.log("tokeninPricetokeninPrice", { in: e(pt),
                            out: e(ft),
                            a: t,
                            b: n,
                            result: r
                        }), ze(r)
                    }), [X, re, pt, ft, rt, st]), Object(r.useEffect)((function() {
                        var e = setTimeout(Object(s.a)(Zt().mark((function e() {
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        en(X);
                                    case 1:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        }))), 2e3);
                        return function() {
                            return clearTimeout(e)
                        }
                    }), [X]), Object(r.useEffect)((function() {
                        var e = setTimeout(Object(s.a)(Zt().mark((function e() {
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        tn(re);
                                    case 1:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        }))), 2e3);
                        return function() {
                            return clearTimeout(e)
                        }
                    }), [re]), a.a.createElement(Jt, {
                        mostData: n
                    }, a.a.createElement(Yt, {
                        mostData: n
                    }, a.a.createElement("div", {
                        className: "buttons-container"
                    }, a.a.createElement("div", {
                        className: "item-menu active"
                    }, a.a.createElement("img", {
                        src: i.isDarkTheme ? "/img/swap-active.png" : "/img/swap-gray.png",
                        alt: ""
                    }), a.a.createElement("p", {
                        style: {
                            color: i.isDarkTheme ? "rgb(139 183 48)" : "#6B8E23",
                            fontWeight: i.isDarkTheme ? "normal" : "600"
                        }
                    }, Object(tt.b)("swap"))), a.a.createElement("div", {
                        className: "item-menu"
                    }, a.a.createElement("img", {
                        src: "/img/limit.png",
                        alt: ""
                    }), a.a.createElement("p", null, Object(tt.b)("limit"))), a.a.createElement("div", {
                        className: "item-menu"
                    }, a.a.createElement("img", {
                        src: "/img/p2p.png",
                        alt: ""
                    }), a.a.createElement("p", null, Object(tt.b)("p2p")))), a.a.createElement("div", {
                        className: "title"
                    }, a.a.createElement($t, {
                        data: h,
                        cleanBalance: function() {
                            H("0"), Y("0"), $(""), ie("")
                        },
                        mostData: !(!n && i.walletIsConnected),
                        getBalance: Object(s.a)(Zt().mark((function e() {
                            var t, n, r;
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, we(!0), Ae(!0), e.next = 5, de(i.walletAddress, "ethereum" === l.id, l.contractAddress);
                                    case 5:
                                        return t = e.sent, H(t), e.next = 9, de(i.walletAddress, "ethereum" === p.id, null === p || void 0 === p ? void 0 : p.contractAddress);
                                    case 9:
                                        if (n = e.sent, Y(n), "ethereum" !== l.id) {
                                            e.next = 15;
                                            break
                                        }
                                        e.t0 = !0, e.next = 18;
                                        break;
                                    case 15:
                                        return e.next = 17, fe(i.walletAddress, l.contractAddress, i.chainData.symbol);
                                    case 17:
                                        e.t0 = e.sent;
                                    case 18:
                                        r = e.t0, ue(r), we(!1), Ae(!1), e.next = 27;
                                        break;
                                    case 24:
                                        e.prev = 24, e.t1 = e.catch(0), we(!1);
                                    case 27:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [0, 24]
                            ])
                        })))
                    }), a.a.createElement("button", {
                        onClick: function() {
                            return D({
                                isOpened: !0
                            })
                        }
                    }, a.a.createElement("img", {
                        src: "/img/levels.png",
                        alt: ""
                    })), wt ? a.a.createElement("button", {
                        disabled: !i.walletIsConnected,
                        onClick: function() {
                            return Qt()
                        }
                    }, a.a.createElement("img", {
                        src: (i.isDarkTheme, "/img/heart.png"),
                        alt: ""
                    })) : a.a.createElement("button", {
                        disabled: !i.walletIsConnected,
                        onClick: Xt
                    }, a.a.createElement("img", {
                        src: i.isDarkTheme ? "/img/heart_outline.png" : "/img/heart_outline-gray.png",
                        alt: ""
                    })), !n && i.walletIsConnected && a.a.createElement("button", {
                        onClick: function() {
                            oe({
                                setWalletIsConnected: i.setWalletIsConnected,
                                setWalletDataIsOpened: function() {
                                    return null
                                },
                                setWalletAddress: i.setWalletAddress,
                                chainid: i.chainData.id
                            }), window.location.reload()
                        }
                    }, a.a.createElement("img", {
                        src: "/img/exit-door.png",
                        alt: ""
                    }))), a.a.createElement("div", {
                        className: "content"
                    }, a.a.createElement("div", {
                        className: "values"
                    }, a.a.createElement("div", {
                        className: "in-value"
                    }, a.a.createElement("div", {
                        className: "inputs"
                    }, a.a.createElement(qt.a, {
                        allowLeadingZeros: !0,
                        thousandSeparator: ",",
                        onChange: function(e) {
                            "." === e.target.value[0] ? $("0" + e.target.value) : $(e.target.value), Pe(!1)
                        },
                        value: X,
                        placeholder: "0",
                        type: "text"
                    }), a.a.createElement(Mt, {
                        data: l,
                        onClick: function() {
                            A({
                                isOpened: !0,
                                type: "in"
                            })
                        },
                        selectedId: null === l || void 0 === l ? void 0 : l.contractAddress
                    })), a.a.createElement("div", {
                        className: "balance"
                    }, a.a.createElement("p", null, pt), a.a.createElement("div", null, a.a.createElement("p", null, Object(tt.b)("Balance"), ": ", me(G)), " ", a.a.createElement(qe, {
                        styles: {
                            background: "transparent",
                            padding: 0,
                            fontSize: 16,
                            color: "var(--bg-small-btn-yellow)"
                        },
                        onClick: function() {
                            $(Number(G.replace(",", "")).toFixed(9))
                        }
                    }, Object(tt.b)("Max"))))), a.a.createElement("div", {
                        className: "invert-container"
                    }, a.a.createElement("button", {
                        className: "invert",
                        onClick: Ht
                    }, a.a.createElement("img", {
                        src: "/img/down-black.png",
                        alt: ""
                    }))), a.a.createElement("div", {
                        className: "in-value"
                    }, a.a.createElement("div", {
                        className: "inputs"
                    }, "0.00000" === (null === re || void 0 === re ? void 0 : re.toString()) ? a.a.createElement("input", {
                        value: "<0.00001",
                        placeholder: "0",
                        type: "text"
                    }) : a.a.createElement(qt.a, {
                        allowLeadingZeros: !0,
                        thousandSeparator: ",",
                        onChange: function(e) {
                            "." === e.target.value[0] ? ie("0" + e.target.value) : ie(e.target.value), Pe(!0)
                        },
                        value: re,
                        placeholder: "0",
                        type: "text"
                    }), a.a.createElement(Mt, {
                        data: p,
                        onClick: function() {
                            A({
                                isOpened: !0,
                                type: "out"
                            })
                        },
                        selectedId: null === p || void 0 === p ? void 0 : p.contractAddress
                    })), a.a.createElement("div", {
                        className: "balance"
                    }, a.a.createElement("p", null, ft), a.a.createElement("div", null, a.a.createElement("p", null, Object(tt.b)("Balance"), ": ", me(q)), " ", a.a.createElement(qe, {
                        styles: {
                            background: "transparent",
                            padding: 0,
                            fontSize: 16,
                            color: "var(--bg-small-btn-yellow)"
                        },
                        onClick: function() {
                            return ie(Number(q).toFixed(9))
                        }
                    }, Object(tt.b)("Max")))))), i.walletIsConnected ? ve ? a.a.createElement(Xe, {
                        disabled: !0,
                        styles: {
                            width: "100%",
                            marginTop: 15
                        }
                    }, "Loading...") : +(null === X || void 0 === X ? void 0 : X.replaceAll(",", "")) > 0 && +Number(null === X || void 0 === X ? void 0 : X.replaceAll(",", "")).toFixed(9) <= +Number(G.replace(",", "")).toFixed(9) ? le ? a.a.createElement(Xe, {
                        styles: {
                            width: "100%",
                            marginTop: 15
                        },
                        onClick: Rt
                    }, "ethereum" === l.id && p.contractAddress === i.chainData.wrappedtoken ? "Wrap" : "ethereum" === p.id && l.contractAddress === i.chainData.wrappedtoken ? "Unwrap" : "Swap") : a.a.createElement(Xe, {
                        styles: {
                            width: "100%",
                            marginTop: 15
                        },
                        onClick: Ut
                    }, "Approve") : Math.ceil(+(null === X || void 0 === X ? void 0 : X.replaceAll(",", ""))) <= 0 ? a.a.createElement(Xe, {
                        disabled: !0,
                        styles: {
                            width: "100%",
                            marginTop: 15
                        }
                    }, "Enter an amount") : a.a.createElement(Xe, {
                        disabled: !0,
                        styles: {
                            width: "100%",
                            marginTop: 15
                        }
                    }, "Insufficient funds") : a.a.createElement(vt, {
                        styles: {
                            width: "100%",
                            marginTop: 15
                        },
                        callback: function() {
                            var e;
                            $("0"), ie("0"), g({
                                isOpened: !(null === (e = i.walletAddress) || void 0 === e ? void 0 : e.length) >= 1
                            })
                        }
                    })), a.a.createElement(zt, {
                        mostTokenList: _,
                        setMostTokenList: Object(s.a)(Zt().mark((function e() {
                            var t, n, r, a, o = arguments;
                            return Zt().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return A.apply(void 0, o), e.next = 3, P.get("/api/prices/getList?chain=eth&userAddress=".concat(i.walletAddress));
                                    case 3:
                                        return t = e.sent, n = t.data, e.next = 7, P.get("/api/prices/getList?chain=bsc&userAddress=".concat(i.walletAddress));
                                    case 7:
                                        r = e.sent, a = r.data, L({
                                            ETH: n,
                                            BNB: a
                                        });
                                    case 10:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        }))),
                        tokenList: j[i.chainData.symbol],
                        mainTokens: k,
                        onChange: function() {
                            var e = Object(s.a)(Zt().mark((function e(t, n) {
                                var r;
                                return Zt().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if ($(""), ie(""), "in" !== t) {
                                                e.next = 13;
                                                break
                                            }
                                            if (u(n), "ethereum" !== n.id) {
                                                e.next = 8;
                                                break
                                            }
                                            e.t0 = !0, e.next = 11;
                                            break;
                                        case 8:
                                            return e.next = 10, fe(i.walletAddress, n.contractAddress, i.chainData.symbol);
                                        case 10:
                                            e.t0 = e.sent;
                                        case 11:
                                            r = e.t0, ue(r);
                                        case 13:
                                            "out" === t && m(n);
                                        case 14:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t, n) {
                                return e.apply(this, arguments)
                            }
                        }(),
                        searchToken: Gt
                    }), a.a.createElement(Ft, {
                        setMostSettings: D,
                        mostSettings: M,
                        onChange: function(e) {
                            if (Math.ceil(e) >= 50) return localStorage.setItem("@SLIPPAGE", 50), v(50);
                            localStorage.setItem("@SLIPPAGE", e), v(e)
                        },
                        slippage: b,
                        compatibilityMode: Ge,
                        setCompatibilityMode: function(e) {
                            localStorage.setItem("@COMPATIBILITYMODE", !!e), He(!!e)
                        }
                    })), n && a.a.createElement("div", {
                        className: "data-container",
                        style: {
                            display: _.isOpened ? "none" : "block"
                        }
                    }, +ee > 0 && a.a.createElement("div", {
                        className: "item-footer"
                    }, a.a.createElement("p", null, "Minimum received"), a.a.createElement("p", null, new Intl.NumberFormat("en-us", {
                        currency: "USD",
                        style: "currency"
                    }).format(ee).replace("$", ""), " ", null === p || void 0 === p ? void 0 : p.symbol)), a.a.createElement("div", {
                        className: "item-footer"
                    }, a.a.createElement("p", null, Object(tt.b)("Current Slippage"), ":"), a.a.createElement("p", null, Math.ceil(b) >= 1 ? b + "%" : "Auto")), a.a.createElement("div", {
                        className: "item-footer"
                    }, a.a.createElement("p", null, Object(tt.b)("Price Impact"), ":"), "number" === typeof Re && NaN !== +Re && +Re !== -1 / 0 && +Re !== 1 / 0 && (+X >= 0 || +re >= 0) ? a.a.createElement("p", null, Number(+Re || 0).toFixed(3), "%") : a.a.createElement("p", null, "0%")), a.a.createElement("div", {
                        className: "item-footer"
                    }, a.a.createElement("p", null, Object(tt.b)("Gas Price"), ":"), a.a.createElement("p", null, a.a.createElement(qe, {
                        styles: {
                            background: "transparent",
                            padding: 0,
                            fontSize: 16,
                            color: "var(--bg-small-btn-yellow)",
                            fontWeight: i.isDarkTheme ? "normal" : "600",
                            marginRight: 10
                        },
                        onClick: function() {
                            return Ct(!It)
                        }
                    }, It ? Object(tt.b)("Hide") : Object(tt.b)("Expand")), a.a.createElement("img", {
                        src: "/img/average-gas.png",
                        alt: ""
                    }), " ", Object(tt.b)("Average"), " ~ $", Ot.usd.mid)), It && a.a.createElement("div", {
                        className: "gas-prices"
                    }, a.a.createElement("div", {
                        className: "gas-item"
                    }, a.a.createElement("p", null, Object(tt.b)("Low"), "\xa0", a.a.createElement("img", {
                        src: "/img/average-gas.png",
                        alt: ""
                    })), a.a.createElement("p", null, "~", Ot.gwei.low, " GWEI - ", Ot.eth.low, " ", i.chainData.symbol)), a.a.createElement("div", {
                        className: "gas-item"
                    }, a.a.createElement("p", null, Object(tt.b)("Average"), "\xa0", a.a.createElement("img", {
                        src: "/img/average-gas.png",
                        alt: ""
                    }), a.a.createElement("img", {
                        src: "/img/average-gas.png",
                        alt: ""
                    })), a.a.createElement("p", null, "~", Ot.gwei.mid, " GWEI - ", Ot.eth.mid, " ", i.chainData.symbol)), a.a.createElement("div", {
                        className: "gas-item"
                    }, a.a.createElement("p", null, Object(tt.b)("High"), "\xa0", a.a.createElement("img", {
                        src: "/img/average-gas.png",
                        alt: ""
                    }), a.a.createElement("img", {
                        src: "/img/average-gas.png",
                        alt: ""
                    }), a.a.createElement("img", {
                        src: "/img/average-gas.png",
                        alt: ""
                    })), a.a.createElement("p", null, "~", Ot.gwei.high, " GWEI - ", Ot.eth.high, " ", i.chainData.symbol)))), a.a.createElement(xt.Toaster, {
                        position: "top-left"
                    }))
                },
                rn = Pe.b.div(Qt || (Qt = Object(De.a)(["\n  min-height: 100vh;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-direction: column;\n  justify-content: space-between;\n  overflow-x: hidden;\n\n  .bannerswap {\n    border-radius: 20px;\n    width: 420px;\n    height: 100px;\n    background-color: transparent;\n    border: 2px solid #d1fd0044;\n  }\n\n  .page-container-data {\n    width: 380px;\n  }\n\n  .column {\n    display: flex;\n    flex-direction: column;\n    gap: 30px;\n    margin: -100px 30px 0;\n  }\n\n  .most-in-desktop {\n    display: flex;\n    flex-direction: column;\n  }\n  .most-in-desktop-block {\n    display: block;\n  }\n\n  .most-in-mobile {\n    display: none;\n  }\n\n  .most-in-mobile-block {\n    display: none;\n  }\n\n  .iframe-app {\n    margin: 30px;\n    width: 420px;\n    height: 655px;\n  }\n  @media (max-width: 1450px) {\n    /* margin-left: -11%; */\n    .most-in-desktop {\n      display: none;\n    }\n    .most-in-desktop-block {\n      display: none;\n    }\n\n    .most-in-mobile-block {\n      display: block;\n    }\n\n    .most-in-mobile {\n      display: flex;\n      flex-direction: column;\n    }\n    /* .bannerswap.most-in-mobile {\n      margin-bottom: 125px;\n      margin-top: -100px;\n    } */\n    .bannerswap {\n      width: 475px !important;\n    }\n\n    .trade-data {\n      margin: 30px auto 0;\n      display: flex;\n      flex-direction: column;\n      gap: 30px;\n      width: 495px;\n    }\n\n    .no-margin {\n      margin: 0 !important;\n    }\n\n    .page-container-data {\n      width: 434px;\n    }\n  }\n\n  @media (max-width: 500px) {\n    .bannerswap,\n    .trade-data {\n      width: 95vw !important;\n    }\n\n    .page-container-data {\n      width: 88% !important;\n    }\n    .trade-data {\n      margin: 30px 0 0 !important;\n    }\n  }\n"]))),
                an = Pe.b.div(en || (en = Object(De.a)(["\n  display: flex;\n  justify-content: center;\n  align-items: flex-start;\n  margin-left: -16%;\n  /* margin: 100px 0 30px; */\n  /* overflow: auto; */\n  /* height: 848px; */\n\n  .no-iframe {\n    display: none;\n    width: calc(100% - 10px);\n    height: 655px;\n  }\n\n  iframe {\n    border-radius: 20px;\n    border: 2px solid #d1fd0044;\n  }\n\n  @media (max-width: 1450px) {\n    .iframe-app {\n      display: none;\n    }\n    .no-iframe {\n      display: block;\n    }\n  }\n\n  @media (min-width: 500px) {\n    margin: 100px 0 30px;\n  }\n"]))),
                on = Pe.b.div(tn || (tn = Object(De.a)(['\n  width: 85%;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  max-width: 1440px;\n  color: var(--color-text);\n  border-top: 2px solid #ddd2;\n  padding: 15px 50px 15px;\n  margin: 0 50px;\n  font-weight: 600;\n  .block-number {\n    position: relative;\n    color: var(--bg-swap-btn);\n    text-decoration: none;\n  }\n  .block-number::before {\n    content: "";\n    position: absolute;\n    top: 7px;\n    left: -12px;\n    width: 6px;\n    height: 6px;\n    border-radius: 6px;\n    background-color: var(--bg-swap-btn);\n  }\n  .buttons-container {\n    width: 100vw;\n    background-color: rgba(11, 10, 12);\n    border-bottom: 2px solid #ddd2;\n    display: none;\n    justify-content: space-between;\n    align-items: center;\n    padding: 25px 0;\n    /* position: fixed;\n    bottom: 0; */\n    z-index: 100;\n\n    > div {\n      display: flex;\n      flex-direction: column;\n      align-items: center;\n      color: rgba(212, 221, 224, 0.6);\n      padding: 0 30px;\n      gap: 5px;\n      position: relative;\n      cursor: not-allowed;\n      opacity: 0.7;\n      &.active {\n        color: #d1fd00;\n        cursor: pointer;\n        opacity: 1;\n      }\n      &.active::before {\n        content: "";\n        height: 5px;\n        background-color: #d1fd00;\n        border-radius: 0 0 5px 5px;\n        position: absolute;\n        top: -30px;\n        right: auto;\n        left: auto;\n        width: 60%;\n      }\n\n      img {\n        width: 30px;\n      }\n      p {\n        margin: 0%;\n        padding: 0%;\n        font-size: 18px;\n        margin-top: 5px;\n      }\n    }\n    .item-menu {\n      width: 33% !important;\n    }\n  }\n\n  .block {\n    display: flex;\n    align-items: center;\n    gap: 20px;\n  }\n\n  /* @media (max-width: 450px) {\n    display: flex;\n    flex-direction: column;\n    gap: 15px;\n    p {\n      margin: 0;\n      padding: 0;\n    }\n  } */\n\n  @media (max-width: 550px) {\n    border: none;\n    width: 100% !important;\n    padding: 0;\n    margin-right: -5%;\n    margin-top: 50px;\n    .block,\n    .copy {\n      display: none;\n      font-weight: 700;\n    }\n    .buttons-container {\n      display: flex;\n      margin-left: -9%;\n    }\n  }\n'])));

            function sn() {
                sn = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var cn, ln = function() {
                    var e = Object(r.useContext)(Ze),
                        t = Object(r.useState)(""),
                        n = Object(c.a)(t, 2),
                        i = n[0],
                        o = n[1];
                    return Object(r.useEffect)((function() {
                        Object(s.a)(sn().mark((function t() {
                            var n, r;
                            return sn().wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return n = new d.a("eth" === String(e.chainData.chainName).toLowerCase() ? "https://eth-mainnet.g.alchemy.com/v2/F3bZ7f3xk2NtVhLtO7bXmoWic3TGjur7" : "https://bsc-dataseed.binance.org/"), t.next = 3, n.eth.getBlockNumber();
                                    case 3:
                                        r = t.sent, o(r);
                                    case 5:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        })))()
                    }), [e.chainData]), a.a.createElement(on, null, a.a.createElement("p", {
                        className: "copy"
                    }, "\xa9 VOLT INU 2023"), a.a.createElement("p", {
                        className: "block"
                    }, Object(tt.b)("Last block"), ":", a.a.createElement("a", {
                        href: "https://etherscan.io/block/".concat(i),
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "block-number"
                    }, i)), a.a.createElement("div", {
                        className: "buttons-container"
                    }, a.a.createElement("div", {
                        className: "item-menu active"
                    }, a.a.createElement("img", {
                        src: "/img/swap-active.png",
                        alt: ""
                    }), a.a.createElement("p", null, Object(tt.b)("swap"))), a.a.createElement("div", {
                        className: "item-menu"
                    }, a.a.createElement("img", {
                        src: "/img/limit.png",
                        alt: ""
                    }), a.a.createElement("p", null, Object(tt.b)("LIMIT"))), a.a.createElement("div", {
                        className: "item-menu"
                    }, a.a.createElement("img", {
                        src: "/img/p2p.png",
                        alt: ""
                    }), a.a.createElement("p", null, Object(tt.b)("P2P")))))
                },
                un = Pe.b.div(cn || (cn = Object(De.a)(["\n  margin: 0 30px 0;\n  color: var(--color-text);\n  background-color: var(--bg-color-swap);\n  backdrop-filter: blur(17px);\n  border-radius: 20px;\n  border: 2px solid #d1fd0044;\n  position: relative;\n  margin-top: -100px;\n  padding: 30px 20px;\n  /* width: 400px; */\n  /* width: 100%; */\n  h1 {\n    font-size: 20px;\n    text-align: center;\n    margin: 0;\n    padding: 0;\n  }\n  h4 {\n    margin: 25px auto 0;\n    padding: 0;\n    width: 90%;\n    text-align: center;\n  }\n  table,\n  tr,\n  tbody {\n    width: 100%;\n  }\n  .token {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    gap: 5px;\n    margin-top: 0px;\n    border-bottom: 2px solid #aaa;\n    border-radius: 0;\n    padding: 5px 5px;\n    font-size: 14px;\n\n    @media (max-width: 550px) {\n      p {\n        font-size: 11px;\n      }\n    }\n\n    .table-data {\n      p {\n        margin: 0;\n        padding: 0;\n      }\n    }\n\n    .tokenin-td {\n      width: 100%;\n    }\n    .tokenout-td {\n      width: 100%;\n    }\n\n    button {\n      width: 30px;\n      cursor: pointer;\n      padding: 5px;\n      border-radius: 18px;\n      background-color: transparent;\n      border: none;\n      &:hover {\n        background-color: var(--bg-gray-settings);\n      }\n\n      img {\n        width: 100%;\n      }\n    }\n\n    .token-data {\n      display: flex;\n      align-items: center;\n      gap: 15px;\n    }\n    .tokenin,\n    .tokenout {\n      display: flex;\n      align-items: center;\n      justify-content: space-evenly;\n      gap: 5px;\n      width: 100%;\n      img {\n        width: 25px;\n        height: 25px;\n      }\n    }\n  }\n"])));

            function pn() {
                pn = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var dn, mn, yn = function(e) {
                    var t = e.className,
                        n = Object(r.useContext)(Ze),
                        i = Object(r.useContext)(Ze),
                        o = i.favoritedPairs,
                        c = i.setFavoritedPairs,
                        l = i.setUpdateTokens;
                    Object(r.useEffect)((function() {
                        Object(s.a)(pn().mark((function e() {
                            var t, r;
                            return pn().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, P.get("/api/prices/favorite_pair?chain=".concat(n.chainData.chainName));
                                    case 2:
                                        t = e.sent, r = t.data, c(r);
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }), [n.walletAddress, n.chainData]);
                    var u = function() {
                        var e = Object(s.a)(pn().mark((function e(t) {
                            var r, a;
                            return pn().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, e.next = 3, P.delete("/api/prices/favorite_pair?id=".concat(t));
                                    case 3:
                                        return e.next = 5, P.get("/api/prices/favorite_pair?chain=".concat(n.chainData.chainName));
                                    case 5:
                                        r = e.sent, a = r.data, c(a), e.next = 12;
                                        break;
                                    case 10:
                                        e.prev = 10, e.t0 = e.catch(0);
                                    case 12:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [0, 10]
                            ])
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }();
                    return a.a.createElement(un, {
                        className: "page-container-data " + t
                    }, a.a.createElement("h1", {
                        className: "title"
                    }, Object(tt.b)("Favorite Trades")), a.a.createElement("div", {
                        className: "pairs"
                    }, n.walletIsConnected ? o.length <= 0 ? a.a.createElement("div", {
                        className: "no-data"
                    }, a.a.createElement("h4", null, Object(tt.b)("It's time to favorite your first trade, when you click on the heart button your settings will be saved here"))) : a.a.createElement(a.a.Fragment, null, a.a.createElement("table", null, a.a.createElement("tbody", null, (null === o || void 0 === o ? void 0 : o.length) >= 1 && (null === o || void 0 === o ? void 0 : o.map((function(e) {
                        return a.a.createElement(a.a.Fragment, null, a.a.createElement("tr", {
                            className: "token"
                        }, a.a.createElement("td", {
                            className: "tokenin-td"
                        }, a.a.createElement("div", {
                            className: "tokenin"
                        }, a.a.createElement("img", {
                            src: e.tokenin.image,
                            alt: ""
                        }), a.a.createElement("p", null, e.tokenin.symbol))), a.a.createElement("td", {
                            className: "divider"
                        }, "|"), a.a.createElement("td", {
                            className: "tokenout-td"
                        }, a.a.createElement("div", {
                            className: "tokenout"
                        }, a.a.createElement("img", {
                            src: e.tokenout.image,
                            alt: ""
                        }), a.a.createElement("p", null, e.tokenout.symbol))), a.a.createElement("td", {
                            className: "table-data"
                        }, a.a.createElement("div", null, a.a.createElement("p", null, "SM"), a.a.createElement("p", null, e.slippage))), a.a.createElement("td", {
                            className: "table-data"
                        }, a.a.createElement("div", null, a.a.createElement("p", null, "CM"), a.a.createElement("p", null, e.iscompatibilitymode ? "on" : "off"))), a.a.createElement("td", null, a.a.createElement("button", {
                            onClick: function() {
                                return l(e)
                            }
                        }, a.a.createElement("img", {
                            src: "/img/share-yellow.png",
                            alt: ""
                        }))), a.a.createElement("td", null, a.a.createElement("button", {
                            onClick: function() {
                                return u(e.id)
                            }
                        }, a.a.createElement("img", {
                            src: "/img/trash-yellow.png",
                            alt: ""
                        })))))
                    })))))) : a.a.createElement("div", {
                        className: "no-connected-wallet"
                    }, a.a.createElement("h4", null, Object(tt.b)("Please, connect your wallet to view your favorite trades")))))
                },
                fn = Object(Pe.a)(dn || (dn = Object(De.a)(["\n\n  body,#root {\n    margin: 0;\n    padding: 0;\n    max-height: 100vh;\n    background: ", ";\n    overflow: auto;\n    font-family: 'Montserrat', sans-serif;\n  }\n  button{\n    cursor: pointer;\n    font-family: 'Montserrat', sans-serif;\n  }\n  button:disabled{\n    opacity: 0.6;\n    cursor: not-allowed;\n    pointer-events: all !important;\n  }\n  .block{\n    opacity: 0.6;\n    cursor: not-allowed;\n    pointer-events: all !important;\n  }\n\n  .none{\n    display: none;\n  }\n\n  .hidden{\n    visibility: hidden;\n  }\n\n  .walletconnect-qrcode__base{\n    backdrop-filter: blur(10px);\n  }\n\n  /* Chrome, Safari, Edge, Opera */\n  input::-webkit-outer-spin-button,\n  input::-webkit-inner-spin-button {\n    -webkit-appearance: none;\n    margin: 0;\n  }\n\n  /* Firefox */\n  input[type=number] {\n    -moz-appearance: textfield;\n  }\n\n  .loader {\n    border: 4px solid #f3f3f3; \n    border-top: 4px solid rgb(107, 142, 35); \n    border-radius: 50%;\n    width: 40px;\n    height: 40px;\n    animation: spin 2s linear infinite;\n  }\n\n  @keyframes spin {\n    0% { transform: rotate(0deg); }\n    100% { transform: rotate(360deg); }\n  }\n  ", "\n"])), (function(e) {
                    return e.mostData ? "transparent" : "var(--bg-color-app)"
                }), (function(e) {
                    return e.isDarkTheme ? "\n  :root {\n    --bg-color-app: #13140C;\n    --bg-color-1: #13140C;\n    --bg-color-back: #0b0a0c;\n    --bg-color-swap: #000;\n    --color-text:#fff;\n    --border-table-color:#fff2;\n    --bg-gradient:linear-gradient( 206.57deg, rgba(36,35,36,0.7) 0%, rgba(27,26,27,0.7) 83.33% );\n    --bg-gray-settings:linear-gradient( 206.57deg, rgba(36,35,36,0.7) 0%, rgba(27,26,27,0.7) 83.33% );\n    --bg-gray-swap-head:rgba(11,10,12,0.62);\n    --bg-small-btn-yellow:rgb(209, 253, 0);\n    --bc-app:#d1fd0044;\n    --bg-header-dropdown-btns:#ddd2;\n    --bg-swap-btn:rgb(209,253,0);\n    --bg-input:#282a36;\n  }\n  " : "\n  :root {\n    --bg-color-app: radial-gradient(100% 100% at 50% 0%, rgb(175 219 42 / 51%) 0%, rgba(255, 255, 255, 0) 100%), rgb(255, 255, 255);;\n    --bg-color-1: #fff;\n    --bg-color-back: #fdfdfd;\n    --bg-color-swap: #f7f7f7;\n    --color-text:#0D111C;\n    --border-table-color:#0D111C22;\n    --bg-gray-settings:#ebebeb;\n    --bg-gray-swap-head:#ebebeb;\n    --bg-small-btn-yellow:rgb(139 183 48);\n    --bc-app:rgba(224, 228, 233, 1);\n    --bg-header-dropdown-btns:#E0E4E9;\n    --bg-swap-btn:rgb(139 183 48);\n    --bg-input:#fff;\n  }\n  "
                })),
                hn = Pe.b.div(mn || (mn = Object(De.a)(["\n  color: var(--color-text);\n  background-color: var(--bg-color-swap);\n  backdrop-filter: blur(17px);\n  border-radius: 25px;\n  padding: 20px;\n  border: 2px solid #d1fd0044;\n  img {\n    width: 30px;\n  }\n\n  h2 {\n    margin: 0 0 20px;\n    padding: 0;\n    text-align: center;\n    font-size: 20px;\n    text-align: center;\n  }\n\n  .images {\n    display: flex;\n    align-items: center;\n    gap: 15px;\n\n    a {\n      cursor: pointer;\n    }\n  }\n\n  button {\n    background-color: transparent;\n    border: none;\n    padding: 0;\n  }\n"]))),
                gn = ["token", "tokentype", "isnativetoken", "className"];

            function bn() {
                bn = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var vn, xn = function(e) {
                    var t = e.token,
                        n = e.tokentype,
                        i = e.isnativetoken,
                        o = e.className,
                        l = Object(Ue.a)(e, gn),
                        u = (new d.a(d.a.givenProvider), Object(r.useContext)(Ze)),
                        p = Object(r.useState)({
                            tokenurl: "",
                            blockchain_site: "",
                            logo: "",
                            current_price: {
                                eth: "",
                                usd: ""
                            },
                            total_supply: "",
                            price_change_percentage_24h: "",
                            price_change_percentage_7d: "",
                            price_change_percentage_30d: "",
                            telegram: "",
                            twitter: "",
                            discord: "",
                            token_name: ""
                        }),
                        m = Object(c.a)(p, 2),
                        y = m[0],
                        f = m[1],
                        h = Object(r.useState)(0),
                        g = Object(c.a)(h, 2),
                        b = g[0],
                        v = g[1],
                        x = Object(r.useState)(0),
                        w = Object(c.a)(x, 2);
                    w[0], w[1], Object(r.useEffect)((function() {
                        Object(s.a)(bn().mark((function e() {
                            var n, r;
                            return bn().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, e.next = 3, _e(t, u.chainData.symbol, i, u.walletAddress);
                                    case 3:
                                        if (n = e.sent, r = {
                                                total_supply: null === n || void 0 === n ? void 0 : n.total_supply
                                            }, !n) {
                                            e.next = 10;
                                            break
                                        }
                                        f(Object(Me.a)(Object(Me.a)(Object(Me.a)({}, n), r), {}, {
                                            current_price: Object(Me.a)(Object(Me.a)({}, n.current_price), {}, {
                                                usd: n.current_price.usd
                                            })
                                        })), v(n.current_price.usd), e.next = 20;
                                        break;
                                    case 10:
                                        if (!((null === t || void 0 === t ? void 0 : t.length) >= 1)) {
                                            e.next = 20;
                                            break
                                        }
                                        return v("0"), e.t0 = f, e.t1 = "ETH" === String(u.chainData.symbol).toUpperCase() ? "https://etherscan.io/address/".concat(t) : "https://bscscan.com/address/".concat(t), e.t2 = {
                                            eth: "0",
                                            usd: "0"
                                        }, e.next = 17, Te(t).name;
                                    case 17:
                                        e.t3 = e.sent, e.t4 = {
                                            tokenurl: "",
                                            blockchain_site: e.t1,
                                            logo: "",
                                            current_price: e.t2,
                                            total_supply: "0",
                                            price_change_percentage_24h: "0",
                                            price_change_percentage_7d: "0",
                                            price_change_percentage_30d: "0",
                                            telegram: "",
                                            twitter: "",
                                            discord: "",
                                            token_name: e.t3
                                        }, (0, e.t0)(e.t4);
                                    case 20:
                                        e.next = 25;
                                        break;
                                    case 22:
                                        e.prev = 22, e.t5 = e.catch(0), console.log(e.t5);
                                    case 25:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [0, 22]
                            ])
                        })))()
                    }), [u.chainData, t, i]);
                    var k = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                        return e.length >= 18 ? e.slice(0, 18) + "e".concat(e.length - 18) : e
                    };
                    return a.a.createElement(hn, Object.assign({
                        className: "page-container-data " + o
                    }, l), a.a.createElement("h2", null, "in" === n ? Object(tt.b)("Token in data") : Object(tt.b)("Token out data")), a.a.createElement("div", {
                        className: "market-data"
                    }, a.a.createElement("p", null, Object(tt.b)("Token name"), ":\xa0", a.a.createElement("strong", null, null === y || void 0 === y ? void 0 : y.token_name)), a.a.createElement("p", null, Object(tt.b)("Current price"), ":\xa0", a.a.createElement("strong", null, Intl.NumberFormat("en-us", {
                        style: "currency",
                        currency: "USD",
                        minimumSignificantDigits: "4"
                    }).format(b))), a.a.createElement("p", null, Object(tt.b)("Total supply"), ":\xa0", a.a.createElement("strong", null, k(null === y || void 0 === y ? void 0 : y.total_supply).length >= 18 ? k(null === y || void 0 === y ? void 0 : y.total_supply) : Intl.NumberFormat("en-us", {
                        style: "currency",
                        currency: "USD"
                    }).format(k(null === y || void 0 === y ? void 0 : y.total_supply)).replace("$", "")))), a.a.createElement("div", {
                        className: "images"
                    }, y.tokenurl && !i && a.a.createElement("a", {
                        href: y.tokenurl,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, a.a.createElement("img", {
                        src: u.isDarkTheme ? "/img/website-light.png" : "/img/website-dark.png",
                        alt: ""
                    })), y.blockchain_site && !i && a.a.createElement("a", {
                        href: y.blockchain_site,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, a.a.createElement("img", {
                        src: y.blockchain_site.includes("etherscan") ? "/img/etherscan.png" : "/img/bscscan.png",
                        alt: ""
                    })), y.discord && !i && a.a.createElement("a", {
                        href: y.discord,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, a.a.createElement("img", {
                        src: "/img/discord.png",
                        alt: ""
                    })), y.twitter && !i && a.a.createElement("a", {
                        href: y.twitter,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, a.a.createElement("img", {
                        src: "/img/twitter.png",
                        alt: ""
                    })), y.telegram && !i && a.a.createElement("a", {
                        href: y.telegram,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, a.a.createElement("img", {
                        src: "/img/telegram.png",
                        alt: ""
                    })), !i && a.a.createElement("button", {
                        onClick: Object(s.a)(bn().mark((function e() {
                            return bn().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        Ae(t, y.logo);
                                    case 1:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))
                    }, a.a.createElement("img", {
                        src: "/img/metamask.svg",
                        alt: ""
                    }))))
                },
                wn = Pe.b.div(vn || (vn = Object(De.a)(["\n  margin: 0 30px 0;\n  color: var(--color-text);\n  background-color: var(--bg-color-swap);\n  backdrop-filter: blur(17px);\n  border-radius: 20px;\n  border: 2px solid #d1fd0044;\n  position: relative;\n  margin-top: 30px;\n  padding: 30px 20px;\n  /* width: 400px; */\n  /* width: 100%; */\n  h1 {\n    font-size: 20px;\n    text-align: center;\n    margin: 0;\n    padding: 0;\n  }\n  h4 {\n    margin: 25px auto 0;\n    padding: 0;\n    width: 90%;\n    text-align: center;\n  }\n  table,\n  tr,\n  tbody {\n    width: 100%;\n  }\n  .date {\n    width: 100%;\n    text-align: center;\n    p {\n      text-align: center;\n    }\n  }\n  td {\n    img {\n      width: 20px;\n    }\n  }\n  td {\n    p {\n      text-align: center;\n      margin: 8px auto;\n      padding: 0;\n\n      a {\n        text-decoration: none;\n        border-bottom: 2px solid #aaa;\n        color: var(--color-text);\n      }\n    }\n    @media (max-width: 550px) {\n      font-size: 12px;\n      p a {\n        font-size: 12px;\n      }\n    }\n  }\n\n  .divider {\n    width: 1px;\n    height: 30px;\n    background-color: #aaa;\n    margin-right: 5px;\n  }\n  .token {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    gap: 5px;\n    margin-top: 0px;\n    border-bottom: 2px solid #aaa;\n    border-radius: 0;\n    padding: 5px 5px;\n    font-size: 14px;\n\n    .table-data {\n      p {\n        margin: 0;\n        padding: 0;\n      }\n    }\n\n    .tokenin-td {\n      width: 100%;\n    }\n    .tokenout-td {\n      width: 100%;\n    }\n\n    button {\n      width: 30px;\n      cursor: pointer;\n      padding: 5px;\n      border-radius: 18px;\n      background-color: transparent;\n      border: none;\n      &:hover {\n        background-color: var(--bg-gray-settings);\n      }\n\n      img {\n        width: 100%;\n      }\n    }\n\n    .token-data {\n      display: flex;\n      align-items: center;\n      gap: 15px;\n    }\n    .tokenin,\n    .tokenout {\n      display: flex;\n      align-items: center;\n      justify-content: space-evenly;\n      gap: 5px;\n      width: 100%;\n      img {\n        width: 25px;\n        height: 25px;\n      }\n    }\n  }\n"])));

            function kn() {
                kn = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var En, Tn = function(e) {
                var t = e.className,
                    n = Object(r.useContext)(Ze),
                    i = Object(r.useContext)(Ze),
                    o = (i.favoritedPairs, i.setFavoritedPairs),
                    l = (i.setUpdateTokens, i.historyTransaction),
                    u = i.setHistoryTransaction,
                    p = Object(r.useState)({
                        data: []
                    }),
                    d = Object(c.a)(p, 2);
                return d[0], d[1], Object(r.useEffect)((function() {
                    Object(s.a)(kn().mark((function e() {
                        var t, r, a;
                        return kn().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, P.get("/api/prices/transactions?chain=".concat(String(n.chainData.chainName).toLowerCase()));
                                case 2:
                                    return t = e.sent, r = t.data, u(r.data), a = setInterval(Object(s.a)(kn().mark((function e() {
                                        var t, r;
                                        return kn().wrap((function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                                case 0:
                                                    return e.next = 2, P.get("/api/prices/transactions?chain=".concat(String(n.chainData.chainName).toLowerCase()));
                                                case 2:
                                                    t = e.sent, r = t.data, u(r.data);
                                                case 5:
                                                case "end":
                                                    return e.stop()
                                            }
                                        }), e)
                                    }))), 35e4), e.abrupt("return", (function() {
                                        return clearTimeout(a)
                                    }));
                                case 7:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))()
                }), [n.walletAddress, o, n.chainData]), a.a.createElement(wn, {
                    className: "page-container-data " + t
                }, a.a.createElement("h1", {
                    className: "title"
                }, Object(tt.b)("Trade History")), a.a.createElement("div", {
                    className: "pairs"
                }, n.walletIsConnected ? l.length <= 0 ? a.a.createElement("div", {
                    className: "no-data"
                }, a.a.createElement("h4", null, Object(tt.b)("Make a transaction to start your history"))) : a.a.createElement(a.a.Fragment, null, a.a.createElement("table", null, a.a.createElement("tbody", null, l.map((function(e) {
                    return a.a.createElement("tr", null, a.a.createElement("td", null, a.a.createElement("p", null, a.a.createElement("a", {
                        href: n.chainData.scanlink + "tx/" + e.hash,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, e.hash.slice(0, 12), "...", e.hash.slice(-12)))), a.a.createElement("td", null, new Intl.DateTimeFormat("en-us", {
                        dateStyle: "medium"
                    }).format(new Date(e.created_at))))
                }))))) : a.a.createElement("div", {
                    className: "no-connected-wallet"
                }, a.a.createElement("h4", null, Object(tt.b)("Please, connect your wallet and check your voltichange trade history")))))
            };
            Pe.b.div(En || (En = Object(De.a)(["\n    color: var(--color-text);\n    background-color: var(--bg-color-swap);\n    backdrop-filter: blur(17px);\n    border-radius: 25px;\n    padding: 50px;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n\n"])));
            var On, jn, Ln, Sn = function() {
                    var e, t, n, i, o = Object(r.useContext)(Ze);
                    return Object(r.useEffect)((function() {
                        document.getElementById("container-app").scrollTo(0, 0)
                    }), []), a.a.createElement(rn, {
                        id: "container-app"
                    }, a.a.createElement(At, null), a.a.createElement(an, null, a.a.createElement("div", {
                        className: "column"
                    }, a.a.createElement("img", {
                        className: "bannerswap most-in-desktop",
                        src: "/img/animation-mobile.gif"
                    }), a.a.createElement(xn, {
                        className: "most-in-desktop-block",
                        tokentype: "in",
                        token: null === o || void 0 === o || null === (e = o.tokenSelectedIn) || void 0 === e ? void 0 : e.contractAddress,
                        isnativetoken: "ethereum" === (null === o || void 0 === o || null === (t = o.tokenSelectedIn) || void 0 === t ? void 0 : t.id)
                    }), a.a.createElement(xn, {
                        className: "most-in-desktop-block",
                        tokentype: "out",
                        token: null === o || void 0 === o || null === (n = o.tokenSelectedOut) || void 0 === n ? void 0 : n.contractAddress,
                        isnativetoken: "ethereum" === (null === o || void 0 === o || null === (i = o.tokenSelectedOut) || void 0 === i ? void 0 : i.id)
                    })), a.a.createElement("div", null, a.a.createElement(nn, null), a.a.createElement("img", {
                        className: "bannerswap most-in-mobile",
                        src: "/img/animation-mobile.gif"
                    }), a.a.createElement("div", {
                        className: "trade-data"
                    }, a.a.createElement(yn, {
                        className: "no-margin most-in-mobile-block"
                    }), a.a.createElement(Tn, {
                        className: "no-margin most-in-mobile-block"
                    }), a.a.createElement("iframe", {
                        className: "no-iframe",
                        src: "https://volt.lynxcrypto.app/",
                        frameBorder: "0",
                        scrolling: "no"
                    }))), a.a.createElement(fn, {
                        isDarkTheme: o.isDarkTheme
                    }), a.a.createElement("div", null, a.a.createElement(yn, {
                        className: "most-in-desktop"
                    }), a.a.createElement(Tn, {
                        className: "most-in-desktop"
                    }), a.a.createElement("iframe", {
                        className: "iframe-app",
                        src: "https://volt.lynxcrypto.app/",
                        frameBorder: "0",
                        scrolling: "no"
                    }))), a.a.createElement(ln, null))
                },
                Nn = n(692),
                _n = n(230),
                An = Pe.b.div(On || (On = Object(De.a)(["\n  min-height: 100vh;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-direction: column;\n  justify-content: space-between;\n"]))),
                In = Pe.b.div(jn || (jn = Object(De.a)(["\n  display: flex;\n  justify-content: center;\n  align-items: flex-start;\n  /* margin: 100px 0 30px; */\n  /* overflow: auto; */\n  /* height: 848px; */\n\n  @media (min-width: 500px) {\n    margin: 20px 0 30px;\n  }\n"]))),
                Cn = Pe.b.label(Ln || (Ln = Object(De.a)(["\n  p {\n    margin: 0;\n    padding: 0;\n  }\n\n  input {\n    width: 100%;\n    font-size: 14px;\n    padding: 10px 5px;\n    border-radius: 5px;\n    margin-top: 5px;\n    border: 2px solid #aaa;\n  }\n"])));
            var Mn, Dn = function(e) {
                    var t = e.label,
                        n = void 0 === t ? "" : t,
                        r = e.onchange,
                        i = void 0 === r ? function() {
                            return null
                        } : r,
                        o = e.initialData,
                        s = void 0 === o ? "" : o;
                    return a.a.createElement(Cn, null, a.a.createElement("p", null, n), a.a.createElement("input", {
                        type: "text",
                        value: s,
                        onChange: function(e) {
                            return i(e.target.value)
                        }
                    }))
                },
                Pn = Pe.b.label(Mn || (Mn = Object(De.a)(["\n  p {\n    margin: 0;\n    padding: 0;\n  }\n\n  select {\n    width: 100%;\n    font-size: 14px;\n    padding: 10px 5px;\n    border-radius: 5px;\n    margin-top: 5px;\n    border: 2px solid #aaa;\n  }\n"])));
            var Fn, Bn = function(e) {
                    var t = e.label,
                        n = void 0 === t ? "" : t,
                        r = e.data,
                        i = void 0 === r ? [{
                            label: "",
                            data: ""
                        }] : r,
                        o = e.onchange,
                        s = void 0 === o ? function() {
                            return null
                        } : o,
                        c = e.initialData,
                        l = void 0 === c ? {
                            label: "",
                            data: ""
                        } : c;
                    return a.a.createElement(Pn, null, a.a.createElement("p", null, n), a.a.createElement("select", {
                        name: "",
                        id: "",
                        onChange: function(e) {
                            return s(e.target.value)
                        }
                    }, l.data.length >= 1 && a.a.createElement("option", {
                        selected: !0,
                        disabled: !0,
                        value: l.data
                    }, l.label), i.map((function(e) {
                        return a.a.createElement("option", {
                            value: e.data
                        }, e.label)
                    }))))
                },
                Gn = Pe.b.div(Fn || (Fn = Object(De.a)(["\n  /* #iframe {\n    max-width: 1000px;\n    width: 100%;\n  } */\n\n  /* iframe {\n    max-width: 500px;\n    width: 100%;\n    height: auto;\n  } */\n  @media (max-width: 1030px) {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    > div {\n      display: flex;\n      flex-direction: column;\n      align-items: center;\n\n      form {\n        width: 500px;\n      }\n    }\n\n    .example,\n    .yt-video {\n      max-width: 500px;\n      width: 100%;\n      min-width: 0 !important;\n      margin: 0 auto;\n    }\n  }\n\n  @media (max-width: 535px) {\n    > div > div {\n      margin-right: 5vw;\n    }\n    .example,\n    form {\n      max-width: 90vw;\n      width: 90vw !important;\n      /* margin-left: 5vw; */\n    }\n  }\n\n  @media (max-width: 1000px) {\n    > div {\n      min-height: auto;\n      max-width: 99vw;\n      width: 100%;\n    }\n  }\n  > div {\n    display: flex;\n    gap: 50px;\n    min-width: 1000px;\n    align-items: flex-end;\n    flex-wrap: wrap;\n    align-content: center;\n    .code {\n    }\n    > div {\n      flex: 1;\n    }\n  }\n\n  pre {\n    position: relative;\n\n    .copy {\n      cursor: pointer;\n      position: absolute;\n      top: 15px;\n      right: 15px;\n      width: 25px;\n    }\n  }\n\n  h1 {\n    color: var(--color-text);\n  }\n\n  select,\n  input {\n    border: none;\n    padding: 10px 25px 10px 15px;\n    margin-bottom: 15px !important;\n    background-color: var(--bg-input);\n    color: var(--color-text);\n  }\n\n  input {\n    width: calc(100% - 40px);\n  }\n\n  label {\n    p {\n      color: var(--color-text);\n    }\n  }\n\n  .yt-video {\n    width: 100%;\n    height: 500px;\n    margin: 15px 0 0;\n  }\n\n  #iframe {\n    width: 100%;\n    height: 400px;\n    word-wrap: break-word;\n    overflow: hidden;\n    padding: 20px 20px 0;\n    padding-top: 0;\n    border-radius: 10px;\n\n    .hljs-tag {\n      margin: 0 auto;\n    }\n    code {\n      border-radius: 10px !important;\n      -webkit-user-select: none; /* Safari */\n      -ms-user-select: none; /* IE 10 and IE 11 */\n      user-select: none; /* Standard syntax */\n    }\n  }\n\n  .example {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    justify-content: flex-start;\n    gap: 0;\n    margin-top: 0px;\n    h2 {\n      width: 100%;\n      color: var(--color-text);\n      margin-bottom: 0;\n    }\n\n    p {\n      margin: 0 0 10px;\n      text-align: left !important;\n      margin-right: auto;\n      color: var(--color-text);\n    }\n\n    .code {\n      background-color: var(--bg-gray-settings);\n      width: 500px;\n      word-wrap: break-word;\n      padding: 20px;\n      border-radius: 20px;\n      cursor: pointer;\n      color: var(--color-text);\n    }\n\n    > div {\n      width: 100%;\n    }\n  }\n"]))),
                Hn = n(469),
                Wn = n.n(Hn);
            n(1095);
            var Un = function() {
                var e = Object(r.useState)({
                        label: "Light",
                        data: "light"
                    }),
                    t = Object(c.a)(e, 2),
                    n = t[0],
                    i = t[1],
                    o = Object(r.useState)({
                        data: "1",
                        label: "Ethereum"
                    }),
                    s = Object(c.a)(o, 2),
                    l = s[0],
                    u = s[1],
                    p = Object(r.useState)("Native"),
                    d = Object(c.a)(p, 2),
                    m = d[0],
                    y = d[1],
                    f = Object(r.useState)("0x7db5af2B9624e1b3B4Bb69D6DeBd9aD1016A58Ac"),
                    h = Object(c.a)(f, 2),
                    g = h[0],
                    b = h[1],
                    v = Object(r.useState)("0.5%"),
                    x = Object(c.a)(v, 2),
                    w = x[0],
                    k = x[1],
                    E = Object(r.useState)(""),
                    T = Object(c.a)(E, 2),
                    O = T[0],
                    j = T[1],
                    L = Object(r.useState)("460px"),
                    S = Object(c.a)(L, 2),
                    N = S[0],
                    _ = (S[1], Object(r.useState)("500px")),
                    A = Object(c.a)(_, 2),
                    I = A[0],
                    C = (A[1], Object(r.useState)("")),
                    M = Object(c.a)(C, 2),
                    D = (M[0], M[1]);
                return Object(r.useEffect)((function() {
                    var e = new URLSearchParams;
                    e.append("chain", l.data), e.append("darktheme", "dark" === n.data), e.append("tokenin", m), e.append("tokenout", g), e.append("slippage", w.replace("%", "")), j("".concat(window.location.origin, "/api/widget/") + "?" + e.toString()), D(Wn.a.highlightAuto("<iframe src=".concat("".concat(window.location.origin, "/api/widget/") + "?" + e.toString(), ' frameborder="0"></iframe>')).value)
                }), [l, m, g, w, n]), Wn.a.initHighlightingOnLoad(), a.a.createElement(Gn, null, a.a.createElement("div", null, a.a.createElement("div", null, a.a.createElement("h1", null, Object(tt.b)("Setup Widget")), a.a.createElement("form", {
                    action: ""
                }, a.a.createElement(Bn, {
                    label: Object(tt.b)("Theme"),
                    data: [{
                        data: "dark",
                        label: "Dark"
                    }, {
                        data: "light",
                        label: "Light"
                    }],
                    initialData: n,
                    onchange: function(e) {
                        return i("dark" === e ? {
                            data: "dark",
                            label: "Dark"
                        } : {
                            data: "light",
                            label: "Light"
                        })
                    }
                }), a.a.createElement(Bn, {
                    label: Object(tt.b)("Blockchain"),
                    data: [{
                        data: "1",
                        label: "Ethereum"
                    }, {
                        data: "56",
                        label: "BSC"
                    }],
                    initialData: l,
                    onchange: function(e) {
                        return u(1 === +e ? {
                            data: "1",
                            label: "Ethereum"
                        } : {
                            data: "56",
                            label: "BSC"
                        })
                    }
                }), a.a.createElement(Dn, {
                    label: Object(tt.b)("Initial input token"),
                    initialData: m,
                    onchange: function(e) {
                        return y(e)
                    }
                }), a.a.createElement(Dn, {
                    label: Object(tt.b)("Initial output token"),
                    initialData: g,
                    onchange: function(e) {
                        return b(e)
                    }
                }), a.a.createElement(Dn, {
                    label: Object(tt.b)("Initial Slippage"),
                    initialData: w,
                    onchange: function(e) {
                        return k(e)
                    }
                }))), a.a.createElement("iframe", {
                    src: O,
                    title: "Voltichange Swap iframe",
                    width: I,
                    height: N,
                    frameborder: "0",
                    className: "voltichange-widget"
                })), a.a.createElement("div", {
                    className: "example"
                }, a.a.createElement("div", null, a.a.createElement("h2", null, Object(tt.b)("Installation")), a.a.createElement("p", null, Object(tt.b)("Follow the instructions bellow to install and activate the voltichange widget on your website."))), a.a.createElement("div", {
                    id: "iframe"
                }, a.a.createElement("pre", null, a.a.createElement("code", {
                    class: "language-html"
                }, '\n\x3c!-- 1. Place this link tag on the <head> of your page: --\x3e\n\n<link rel="stylesheet" href="'.concat(window.location.origin, '/css/widget.css" />\n\n\n\x3c!-- 2. Place this iframe tag at the location where the Voltichange Widget will be:  --\x3e\n\n<iframe\nsrc="').concat(O.replaceAll("&", "&\n"), '"\nframeborder="0"\nclass="voltichange-widget"></iframe>\n\n\x3c!-- END OF VOLTICHANGE WIDGET CODE --\x3e\n                ')), a.a.createElement("img", {
                    onClick: function() {
                        navigator.clipboard.writeText('\n\x3c!-- 1. Place this link tag on the <head> of your page: --\x3e\n\n<link rel="stylesheet" href="'.concat(window.location.origin, '/css/widget.css" />\n\n\n\x3c!-- 2. Place this iframe tag at the location where the Voltichange Widget will be:  --\x3e\n\n<iframe\nsrc="').concat(O, '"\nframeborder="0"\nclass="voltichange-widget"></iframe>\n\n\x3c!-- END OF VOLTICHANGE WIDGET CODE --\x3e\n                ')), alert("Copied!")
                    },
                    src: "/img/copy-yellow.png",
                    alt: "",
                    className: "copy"
                })))), a.a.createElement("div", {
                    className: "example"
                }, a.a.createElement("div", null, a.a.createElement("h2", null, Object(tt.b)("Voltichange Widget Implementation Example")), a.a.createElement("p", null, Object(tt.b)("Bellow you can watch a quick tutorial on how to install and use the widget on your own website"))), a.a.createElement("iframe", {
                    className: "yt-video",
                    src: "https://www.youtube-nocookie.com/embed/9Nyokyjuhno",
                    title: "YouTube video player",
                    frameborder: "0",
                    allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
                    allowfullscreen: !0
                })))
            };
            var Rn, zn = function() {
                    var e = Object(r.useContext)(Ze);
                    return a.a.createElement(An, null, a.a.createElement(At, null), a.a.createElement(In, null, a.a.createElement(fn, {
                        isDarkTheme: e.isDarkTheme
                    }), a.a.createElement(Un, null)), a.a.createElement(ln, null))
                },
                Vn = (n(1289), n(1424)),
                qn = n(1425),
                Yn = n(697),
                Jn = n(1429),
                Kn = n(690),
                Xn = n(691),
                $n = Pe.b.div(Rn || (Rn = Object(De.a)(["\n  min-height: 100vh;\n  /* min-width: 100vw; */\n\n  max-width: 1440px;\n  width: 100%;\n  margin: 0 auto;\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: flex-start;\n  padding: 0 20px;\n  box-sizing: border-box;\n\n  @media (max-width: 1300px) {\n    .charts {\n      display: flex;\n      flex-direction: column;\n      gap: 20px;\n      width: 100%;\n\n      .chart {\n        max-width: 100%;\n        padding: 0;\n      }\n    }\n    .chart-container-data.chart {\n      h2 {\n        padding-left: 40px;\n      }\n      .recharts-responsive-container.chart-container {\n        padding: 0 25px;\n      }\n    }\n  }\n\n  .chart-container-data {\n    border: 2px solid var(--bc-app);\n    padding: 0 20px;\n    border-radius: 25px;\n    background-color: var(--bg-color-swap);\n\n    h2 {\n      padding-left: 20px;\n    }\n  }\n  h1 {\n    color: var(--color-text);\n    margin: 0 0 45px;\n    padding: 0;\n    text-align: center;\n    width: 100%;\n  }\n\n  .chart {\n    width: 100%;\n    max-width: 600px;\n    h2 {\n      color: var(--color-text);\n    }\n    text {\n      fill: var(--color-text) !important;\n    }\n\n    ul,\n    ul li {\n      color: #000 !important;\n    }\n  }\n\n  .charts {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-end;\n    width: 100%;\n    margin: 00px 0;\n  }\n\n  .table-data {\n    color: var(--color-text);\n    width: 100%;\n    margin-top: 40px;\n    max-width: 100%;\n    overflow-x: auto;\n\n    table {\n      width: 100%;\n      border: 2px solid var(--bc-app);\n      padding: 0;\n      border-radius: 5px;\n      border-spacing: 0;\n      /* background-color: var(--bg-color-1); */\n      background-color: var(--bg-color-back);\n      min-width: 1000px;\n      overflow-x: auto;\n      thead {\n        background-color: var(--bg-color-swap);\n        border-spacing: 0;\n      }\n\n      tr td:first-child,\n      tr th:first-child {\n        padding-left: 20px;\n        text-align: center;\n      }\n\n      td img {\n        width: 30px;\n      }\n\n      tr td,\n      tr th {\n        padding: 10px;\n      }\n      th {\n        text-align: left;\n      }\n      tbody {\n        tr {\n          td {\n            border-top: 1px solid var(--border-table-color);\n          }\n        }\n      }\n    }\n  }\n"])));

            function Zn() {
                Zn = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var Qn = function() {
                var e = Object(r.useContext)(Ze),
                    t = Object(r.useState)([]),
                    n = Object(c.a)(t, 2),
                    i = n[0],
                    o = n[1],
                    l = Object(r.useState)([]),
                    u = Object(c.a)(l, 2),
                    p = u[0],
                    d = u[1],
                    m = Object(r.useState)({
                        data: [],
                        pages: 1
                    }),
                    y = Object(c.a)(m, 2),
                    f = y[0],
                    h = y[1],
                    g = Object(r.useState)(1),
                    b = Object(c.a)(g, 2),
                    v = b[0];
                return b[1], a.a.useMemo((function() {
                    return {
                        getValue: function(e) {
                            return e.date
                        }
                    }
                }), []), a.a.useMemo((function() {
                    return [{
                        getValue: function(e) {
                            return e.stars
                        }
                    }]
                }), []), Object(r.useEffect)((function() {
                    Object(s.a)(Zn().mark((function e() {
                        var t, n, r, a;
                        return Zn().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, P.get("/api/prices/burnperdays?days=7");
                                case 2:
                                    return t = e.sent, n = t.data, o(Object.keys(n).map((function(e) {
                                        return console.log(e, n[e].burnUSD), {
                                            name: e,
                                            pv: n[e].burnUSD
                                        }
                                    })).reverse()), e.next = 7, P.get("/api/prices/tradedollarperdays?days=7");
                                case 7:
                                    r = e.sent, a = r.data, d(Object.keys(a).map((function(e) {
                                        return console.log(e, a[e].amountUSD), {
                                            name: e,
                                            pv: a[e].amountUSD
                                        }
                                    })).reverse());
                                case 10:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))()
                }), []), Object(r.useEffect)((function() {
                    Object(s.a)(Zn().mark((function t() {
                        var n, r;
                        return Zn().wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, P.get("/api/prices/tokensburns?chain=".concat("eth" === String(e.chainData.symbol).toLowerCase() ? "eth" : "bsc", "&page=").concat(v));
                                case 2:
                                    n = t.sent, r = n.data, h({
                                        data: r.data,
                                        pages: r.pages
                                    });
                                case 5:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })))()
                }), [e.chainData, v]), a.a.createElement($n, null, a.a.createElement(At, null), a.a.createElement("h1", null, "Voltichange Statistics"), a.a.createElement("div", {
                    className: "charts"
                }, a.a.createElement("div", {
                    className: "chart"
                }, a.a.createElement("div", {
                    className: "chart-container-data"
                }, a.a.createElement("h2", null, "Total Burns (USD)"), i.length <= 0 ? a.a.createElement("div", {
                    style: {
                        width: "100%",
                        height: 300,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center"
                    }
                }, a.a.createElement("div", {
                    className: "loader"
                })) : a.a.createElement(Vn.a, {
                    className: "chart-container",
                    width: "100%",
                    height: 300
                }, a.a.createElement(qn.a, {
                    data: i,
                    margin: {
                        top: 5,
                        right: 20,
                        bottom: 5,
                        left: 0
                    },
                    style: {
                        borderColor: "#000"
                    }
                }, a.a.createElement(Yn.a, {
                    type: "monotone",
                    dataKey: "pv",
                    strokeWidth: 2,
                    stroke: "rgb(107, 142, 35)"
                }), a.a.createElement(Jn.a, {
                    strokeDasharray: "5 5"
                }), a.a.createElement(Kn.a, {
                    dataKey: "name"
                }), a.a.createElement(Xn.a, null))))), a.a.createElement("div", {
                    className: "chart"
                }, a.a.createElement("div", {
                    className: "chart-container-data"
                }, a.a.createElement("h2", null, "Total Trade Volume (USD)"), p.length <= 0 ? a.a.createElement("div", {
                    style: {
                        width: "100%",
                        height: 300,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center"
                    }
                }, a.a.createElement("div", {
                    className: "loader"
                })) : a.a.createElement(Vn.a, {
                    className: "chart-container",
                    width: "100%",
                    height: 300
                }, a.a.createElement(qn.a, {
                    data: p,
                    margin: {
                        top: 5,
                        right: 20,
                        bottom: 5,
                        left: 0
                    },
                    style: {
                        borderColor: "#000"
                    }
                }, a.a.createElement(Yn.a, {
                    type: "monotone",
                    dataKey: "pv",
                    strokeWidth: 2,
                    stroke: "rgb(107, 142, 35)"
                }), a.a.createElement(Jn.a, {
                    strokeDasharray: "5 5"
                }), a.a.createElement(Kn.a, {
                    dataKey: "name"
                }), a.a.createElement(Xn.a, null)))))), a.a.createElement("div", {
                    className: "table-data"
                }, a.a.createElement("table", null, a.a.createElement("thead", null, a.a.createElement("tr", null, a.a.createElement("th", null, "#"), a.a.createElement("th", null, "Name"), a.a.createElement("th", null, "Symbol"), a.a.createElement("th", null, "Burn"))), a.a.createElement("tbody", null, f.data.map((function(e, t) {
                    return a.a.createElement("tr", null, a.a.createElement("td", null, a.a.createElement("img", {
                        src: e.image,
                        alt: ""
                    })), a.a.createElement("td", null, e.name), a.a.createElement("td", null, e.symbol), a.a.createElement("td", null, new Intl.NumberFormat("en-us", {
                        style: "currency",
                        currency: "USD"
                    }).format(e.burntotal)))
                }))))), a.a.createElement(fn, {
                    isDarkTheme: e.isDarkTheme
                }))
            };

            function er() {
                er = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var tr = function() {
                var e = Object(s.a)(er().mark((function e(t, n, r) {
                    var a, i, o;
                    return er().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, P.get("/api/prices/searchToken?q=".concat(t, "&chain=").concat(String(n).toLowerCase(), "&userAddress=").concat(r));
                            case 2:
                                return a = e.sent, i = a.data, (o = i[0]).image || (o.image = "/img/no-image-token.png"), e.abrupt("return", o);
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })));
                return function(t, n, r) {
                    return e.apply(this, arguments)
                }
            }();

            function nr() {
                nr = function() {
                    return e
                };
                var e = {},
                    t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = Object.defineProperty || function(e, t, n) {
                        e[t] = n.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    i = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    s = a.toStringTag || "@@toStringTag";

                function c(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (S) {
                    c = function(e, t, n) {
                        return e[t] = n
                    }
                }

                function l(e, t, n, a) {
                    var i = t && t.prototype instanceof d ? t : d,
                        o = Object.create(i.prototype),
                        s = new O(a || []);
                    return r(o, "_invoke", {
                        value: w(e, n, s)
                    }), o
                }

                function u(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (S) {
                        return {
                            type: "throw",
                            arg: S
                        }
                    }
                }
                e.wrap = l;
                var p = {};

                function d() {}

                function m() {}

                function y() {}
                var f = {};
                c(f, i, (function() {
                    return this
                }));
                var h = Object.getPrototypeOf,
                    g = h && h(h(j([])));
                g && g !== t && n.call(g, i) && (f = g);
                var b = y.prototype = d.prototype = Object.create(f);

                function v(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function x(e, t) {
                    var a;
                    r(this, "_invoke", {
                        value: function(r, i) {
                            function o() {
                                return new t((function(a, o) {
                                    ! function r(a, i, o, s) {
                                        var c = u(e[a], e, i);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                p = l.value;
                                            return p && "object" == typeof p && n.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                                r("next", e, o, s)
                                            }), (function(e) {
                                                r("throw", e, o, s)
                                            })) : t.resolve(p).then((function(e) {
                                                l.value = e, o(l)
                                            }), (function(e) {
                                                return r("throw", e, o, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, i, a, o)
                                }))
                            }
                            return a = a ? a.then(o, o) : o()
                        }
                    })
                }

                function w(e, t, n) {
                    var r = "suspendedStart";
                    return function(a, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === a) throw i;
                            return L()
                        }
                        for (n.method = a, n.arg = i;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = k(o, n);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if ("suspendedStart" === r) throw r = "completed", n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = "executing";
                            var c = u(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = "completed", n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function k(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, k(e, t), "throw" === t.method)) return p;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return p
                    }
                    var r = u(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, p;
                    var a = r.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, p) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, p)
                }

                function E(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function T(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(E, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[i];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: L
                    }
                }

                function L() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return m.prototype = y, r(b, "constructor", {
                    value: y,
                    configurable: !0
                }), r(y, "constructor", {
                    value: m,
                    configurable: !0
                }), m.displayName = c(y, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, y) : (e.__proto__ = y, c(e, s, "GeneratorFunction")), e.prototype = Object.create(b), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, v(x.prototype), c(x.prototype, o, (function() {
                    return this
                })), e.AsyncIterator = x, e.async = function(t, n, r, a, i) {
                    void 0 === i && (i = Promise);
                    var o = new x(l(t, n, r, a), i);
                    return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                        return e.done ? e.value : o.next()
                    }))
                }, v(b), c(b, s, "Generator"), c(b, i, (function() {
                    return this
                })), c(b, "toString", (function() {
                    return "[object Generator]"
                })), e.keys = function(e) {
                    var t = Object(e),
                        n = [];
                    for (var r in t) n.push(r);
                    return n.reverse(),
                        function e() {
                            for (; n.length;) {
                                var r = n.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return o.type = "throw", o.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var i = this.tryEntries[a],
                                o = i.completion;
                            if ("root" === i.tryLoc) return r("end");
                            if (i.tryLoc <= this.prev) {
                                var s = n.call(i, "catchLoc"),
                                    c = n.call(i, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                } else if (s) {
                                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var a = this.tryEntries[r];
                            if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var i = a;
                                break
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), p
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), T(n), p
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var a = r.arg;
                                    T(n)
                                }
                                return a
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), p
                    }
                }, e
            }
            var rr = function() {
                var e = Object(r.useContext)(Ze),
                    t = (e.setTokenIsLoading, e.chainData),
                    n = e.walletAddress,
                    i = e.setTokenSelectedIn,
                    o = e.setTokenSelectedOut,
                    c = e.setIsDarkTheme,
                    l = e.isDarkTheme,
                    u = e.setNetworkId,
                    p = e.setSlippage;
                return Object(r.useEffect)((function() {
                    Object(s.a)(nr().mark((function e() {
                        var r, a, s, l, d, m;
                        return nr().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (l = new URLSearchParams(window.location.search), d = Vt[56 === +l.get("chain") ? "BNB" : "ETH"], console.log({
                                            maintoken: d,
                                            maintokensdata: Vt
                                        }), e.t0 = l.get("theme"), !((null === (r = l.get("tokenin")) || void 0 === r ? void 0 : r.length) >= 1)) {
                                        e.next = 22;
                                        break
                                    }
                                    if ("native" !== l.get("tokenin").toLowerCase()) {
                                        e.next = 9;
                                        break
                                    }
                                    e.t3 = d[0], e.next = 19;
                                    break;
                                case 9:
                                    return e.next = 11, tr(l.get("tokenin"), 56 === +l.get("chain") ? "bnb" : "eth", n);
                                case 11:
                                    if (!e.sent) {
                                        e.next = 17;
                                        break
                                    }
                                    return e.next = 14, tr(l.get("tokenin"), 56 === +l.get("chain") ? "bnb" : "eth", n);
                                case 14:
                                    e.t4 = e.sent, e.next = 18;
                                    break;
                                case 17:
                                    e.t4 = d[0];
                                case 18:
                                    e.t3 = e.t4;
                                case 19:
                                    e.t2 = e.t3, e.next = 23;
                                    break;
                                case 22:
                                    e.t2 = d[0];
                                case 23:
                                    if (e.t1 = e.t2, e.t1) {
                                        e.next = 26;
                                        break
                                    }
                                    e.t1 = d[0];
                                case 26:
                                    if (e.t5 = e.t1, !((null === (a = l.get("tokenout")) || void 0 === a ? void 0 : a.length) >= 1)) {
                                        e.next = 41;
                                        break
                                    }
                                    if ("native" !== l.get("tokenout").toLowerCase()) {
                                        e.next = 32;
                                        break
                                    }
                                    e.t7 = d[0], e.next = 38;
                                    break;
                                case 32:
                                    return e.next = 34, tr(l.get("tokenout"), 56 === +l.get("chain") ? "bnb" : "eth", n);
                                case 34:
                                    if (e.t8 = e.sent, e.t8) {
                                        e.next = 37;
                                        break
                                    }
                                    e.t8 = d[0];
                                case 37:
                                    e.t7 = e.t8;
                                case 38:
                                    e.t6 = e.t7, e.next = 42;
                                    break;
                                case 41:
                                    e.t6 = d[0];
                                case 42:
                                    e.t9 = e.t6, e.t10 = +(null === (s = l.get("slippage")) || void 0 === s ? void 0 : s.replace("%", "")) || "auto", e.t11 = l.get("iscompatibiliditymode"), m = {
                                        theme: e.t0,
                                        tokenin: e.t5,
                                        tokenout: e.t9,
                                        slippage: e.t10,
                                        iscompatibiliditymode: e.t11
                                    }, i(m.tokenin), o(m.tokenout), c("true" === l.get("darktheme")), u(56 === +l.get("chain") ? 56 : 1), p(m.slippage), localStorage.setItem("@CHAIN_ID", 56 === +l.get("chain") ? 56 : 1), console.log({
                                        paramsdata: m,
                                        inin: l.get("tokenin"),
                                        main: d[0],
                                        maintoken: d,
                                        aa: String(t.symbol).toUpperCase(),
                                        chainData: t,
                                        chain: l.get("chain")
                                    });
                                case 53:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))()
                }), [n]), a.a.createElement(a.a.Fragment, null, a.a.createElement(nn, {
                    mostData: !1
                }), a.a.createElement(fn, {
                    mostData: !0,
                    isDarkTheme: l
                }))
            };
            var ar = function() {
                return a.a.createElement(et.a, {
                    i18n: pt
                }, a.a.createElement(Qe, null, a.a.createElement(Nn.a, null, a.a.createElement(_n.c, null, a.a.createElement(_n.a, {
                    exact: !0,
                    path: "/",
                    component: Sn
                }), a.a.createElement(_n.a, {
                    exact: !0,
                    path: "/widget",
                    component: zn
                }), a.a.createElement(_n.a, {
                    exact: !0,
                    path: "/api/widget",
                    component: rr
                }), a.a.createElement(_n.a, {
                    exact: !0,
                    path: "/statistics",
                    component: Qn
                })))))
            };
            Boolean("localhost" === window.location.hostname || "[::1]" === window.location.hostname || window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/));
            o.a.render(a.a.createElement(ar, null), document.getElementById("root")), "serviceWorker" in navigator && navigator.serviceWorker.ready.then((function(e) {
                e.unregister()
            }))
        },
        142: function(e) {
            e.exports = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"guy","type":"address"},{"name":"wad","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"src","type":"address"},{"name":"dst","type":"address"},{"name":"wad","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"wad","type":"uint256"}],"name":"withdraw","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"dst","type":"address"},{"name":"wad","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"deposit","outputs":[],"payable":true,"stateMutability":"payable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":true,"name":"guy","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":true,"name":"dst","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"dst","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Withdrawal","type":"event"}]')
        },
        145: function(e) {
            e.exports = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"previousAdminRole","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"newAdminRole","type":"bytes32"}],"name":"RoleAdminChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleGranted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleRevoked","type":"event"},{"inputs":[],"name":"ADMIN","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEFAULT_ADMIN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEVELOPER","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"VOLT","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"fee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"getAmountIn","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountIn","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"getAmountOutMinWithFees","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_tokenIn","type":"address"},{"internalType":"address","name":"_tokenOut","type":"address"}],"name":"getPair","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleAdmin","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"getTokenDecimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"grantRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"hasRole","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"renounceRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"revokeRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOutMin","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapETHForToken","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapETHforExactToken","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountIn","type":"uint256"},{"internalType":"uint256","name":"_amountOutMin","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapTokenForETH","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"uint256","name":"_amountInMax","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapTokenForExactETH","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"uint256","name":"_amountInMax","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapTokenForExactToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountIn","type":"uint256"},{"internalType":"uint256","name":"_amountOutMin","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapTokenForToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"wallet","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"stateMutability":"payable","type":"receive"}]')
        },
        163: function(e) {
            e.exports = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"previousAdminRole","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"newAdminRole","type":"bytes32"}],"name":"RoleAdminChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleGranted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleRevoked","type":"event"},{"inputs":[],"name":"ADMIN","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEFAULT_ADMIN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEVELOPER","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"VOLT","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"fee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"getAmountIn","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountIn","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"getAmountOutMinWithFees","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_tokenIn","type":"address"},{"internalType":"address","name":"_tokenOut","type":"address"}],"name":"getPair","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleAdmin","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"getTokenDecimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"grantRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"hasRole","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"renounceRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"revokeRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOutMin","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapETHForToken","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapETHforExactToken","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountIn","type":"uint256"},{"internalType":"uint256","name":"_amountOutMin","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapTokenForETH","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"uint256","name":"_amountInMax","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapTokenForExactETH","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"uint256","name":"_amountInMax","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapTokenForExactToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountIn","type":"uint256"},{"internalType":"uint256","name":"_amountOutMin","type":"uint256"},{"internalType":"address[]","name":"_path","type":"address[]"}],"name":"swapTokenForToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"wallet","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"stateMutability":"payable","type":"receive"}]')
        },
        184: function(e) {
            e.exports = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]')
        },
        203: function(e) {
            e.exports = JSON.parse('[{"id":null,"contractAddress":"","name":"","symbol":"","img":"","chainName":""},{"id":1,"contractAddress":"0x98d5Bd6f3932b1cc4f979F93979308e6e9Ce1E6f","name":"Ethereum","symbol":"ETH","img":"/img/ethlogo.png","chainName":"eth","wrappedtoken":"0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2","scanlink":"http://etherscan.io/"},{"id":56,"contractAddress":"0x2ff3C630F5030F38bfF3b93a8b1E018906C290f0","name":"BSC","symbol":"BNB","img":"/img/bsc.png","chainName":"bsc","wrappedtoken":"0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c","scanlink":"https://bscscan.com/"}]')
        },
        299: function(e) {
            e.exports = JSON.parse('{"":[],"ETH":[{"image":"/img/ethlogo.png","id":"ethereum","name":"ETH","symbol":"ETH","contractAddress":"0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2","decimals":18},{"image":"/img/weth-logo.png","id":"wrapped-token","name":"WETH","symbol":"WETH","contractAddress":"0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2","decimals":18},{"image":"https://assets.coingecko.com/coins/images/25201/small/logo200.png?1653635992","id":"volt-inu-2","name":"Volt Inu","symbol":"VOLT","contractAddress":"0x7db5af2B9624e1b3B4Bb69D6DeBd9aD1016A58Ac","decimals":9}],"BNB":[{"image":"https://assets.coingecko.com/coins/images/825/small/bnb-icon2_2x.png?1644979850","id":"ethereum","name":"BNB","symbol":"BNB","contractAddress":"0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c","decimals":18},{"image":"https://assets.coingecko.com/coins/images/825/small/bnb-icon2_2x.png?1644979850","id":"bnb","name":"WBNB","symbol":"WBNB","contractAddress":"0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c","decimals":18},{"image":"https://assets.coingecko.com/coins/images/25201/small/logo200.png?1653635992","id":"volt-inu-2","name":"Volt Inu","symbol":"VOLT","contractAddress":"0x7db5af2B9624e1b3B4Bb69D6DeBd9aD1016A58Ac","decimals":9}]}')
        },
        380: function(e) {
            e.exports = JSON.parse('[{"inputs":[{"internalType":"uint64","name":"_subscriptionId","type":"uint64"},{"internalType":"uint8","name":"_step","type":"uint8"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"address","name":"have","type":"address"},{"internalType":"address","name":"want","type":"address"}],"name":"OnlyCoordinatorCanFulfill","type":"error"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"previousAdminRole","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"newAdminRole","type":"bytes32"}],"name":"RoleAdminChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleGranted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleRevoked","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"","type":"uint256"},{"indexed":false,"internalType":"address","name":"","type":"address"}],"name":"newNFTMinted","type":"event"},{"inputs":[],"name":"DEFAULT_ADMIN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEVELOPER","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"baseURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"callbackGasLimit","outputs":[{"internalType":"uint32","name":"","type":"uint32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleAdmin","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"grantRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"hasRole","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_quantity","type":"uint256"},{"internalType":"uint256[]","name":"_token_id","type":"uint256[]"},{"internalType":"address","name":"_to","type":"address"}],"name":"mintTo","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_quantity","type":"uint256"},{"internalType":"bytes32[]","name":"_merkleProof","type":"bytes32[]"}],"name":"mintToken","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"requestId","type":"uint256"},{"internalType":"uint256[]","name":"randomWords","type":"uint256[]"}],"name":"rawFulfillRandomWords","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"renounceRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"revokeRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"salePrice","type":"uint256"}],"name":"royaltyInfo","outputs":[{"internalType":"address","name":"receiver","type":"address"},{"internalType":"uint256","name":"royaltyAmount","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"royalty_amount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"royalty_receiver","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"s_subscriptionId","outputs":[{"internalType":"uint64","name":"","type":"uint64"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"},{"internalType":"address payable","name":"_to","type":"address"}],"name":"sendEthToAddr","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_newURI","type":"string"}],"name":"setBaseURI","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint32","name":"_limit","type":"uint32"}],"name":"setCallbackGasLimit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"_keyhash","type":"bytes32"}],"name":"setKeyHash","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"_newRoot","type":"bytes32"}],"name":"setMerkleRoot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"setRoyaltyAmount","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"setRoyaltyReceiver","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint8","name":"_step","type":"uint8"}],"name":"setStep","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint64","name":"_id","type":"uint64"}],"name":"setSubscriptionId","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"step","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"}]')
        },
        381: function(e) {
            e.exports = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint8","name":"version","type":"uint8"}],"name":"Initialized","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"previousAdminRole","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"newAdminRole","type":"bytes32"}],"name":"RoleAdminChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleGranted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleRevoked","type":"event"},{"inputs":[],"name":"BURN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEFAULT_ADMIN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEVELOPER_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"VOLT","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"addWhitelistAddr","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOutMin","type":"uint256"}],"name":"burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleAdmin","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"grantRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"hasRole","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"initialize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"removeWhitelistAddr","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"renounceRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_token","type":"address"}],"name":"rescue","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"revokeRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"tokenWhitelist","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"stateMutability":"payable","type":"receive"}]')
        },
        382: function(e) {
            e.exports = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint8","name":"version","type":"uint8"}],"name":"Initialized","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"previousAdminRole","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"newAdminRole","type":"bytes32"}],"name":"RoleAdminChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleGranted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleRevoked","type":"event"},{"inputs":[],"name":"BURN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEFAULT_ADMIN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"DEVELOPER_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"VOLT","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"addWhitelistAddr","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amountOutMin","type":"uint256"}],"name":"burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleAdmin","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"grantRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"hasRole","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"initialize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"removeWhitelistAddr","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"renounceRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_token","type":"address"}],"name":"rescue","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"revokeRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"tokenWhitelist","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"stateMutability":"payable","type":"receive"}]')
        },
        460: function(e) {
            e.exports = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"guy","type":"address"},{"name":"wad","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"src","type":"address"},{"name":"dst","type":"address"},{"name":"wad","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"wad","type":"uint256"}],"name":"withdraw","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"dst","type":"address"},{"name":"wad","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"deposit","outputs":[],"payable":true,"stateMutability":"payable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":true,"name":"guy","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":true,"name":"dst","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"dst","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Withdrawal","type":"event"}]')
        },
        461: function(e) {
            e.exports = JSON.parse('[{"inputs":[{"internalType":"address","name":"_feeToSetter","type":"address"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"token0","type":"address"},{"indexed":true,"internalType":"address","name":"token1","type":"address"},{"indexed":false,"internalType":"address","name":"pair","type":"address"},{"indexed":false,"internalType":"uint256","name":"","type":"uint256"}],"name":"PairCreated","type":"event"},{"constant":true,"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"allPairs","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"allPairsLength","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"}],"name":"createPair","outputs":[{"internalType":"address","name":"pair","type":"address"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"feeTo","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feeToSetter","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"getPair","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"_feeTo","type":"address"}],"name":"setFeeTo","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"_feeToSetter","type":"address"}],"name":"setFeeToSetter","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"}]')
        },
        462: function(e) {
            e.exports = JSON.parse('[{"inputs":[{"internalType":"address","name":"_factory","type":"address"},{"internalType":"address","name":"_WETH","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[],"name":"WETH","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"amountADesired","type":"uint256"},{"internalType":"uint256","name":"amountBDesired","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"addLiquidity","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"},{"internalType":"uint256","name":"liquidity","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amountTokenDesired","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"addLiquidityETH","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"},{"internalType":"uint256","name":"liquidity","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"factory","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"reserveIn","type":"uint256"},{"internalType":"uint256","name":"reserveOut","type":"uint256"}],"name":"getAmountIn","outputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"reserveIn","type":"uint256"},{"internalType":"uint256","name":"reserveOut","type":"uint256"}],"name":"getAmountOut","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"}],"name":"getAmountsIn","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"}],"name":"getAmountsOut","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"reserveA","type":"uint256"},{"internalType":"uint256","name":"reserveB","type":"uint256"}],"name":"quote","outputs":[{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidity","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidityETH","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidityETHSupportingFeeOnTransferTokens","outputs":[{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityETHWithPermit","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityETHWithPermitSupportingFeeOnTransferTokens","outputs":[{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityWithPermit","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapETHForExactTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactETHForTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactETHForTokensSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForETH","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForETHSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForTokensSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMax","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapTokensForExactETH","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMax","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapTokensForExactTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"stateMutability":"payable","type":"receive"}]')
        },
        463: function(e) {
            e.exports = JSON.parse('[{"inputs":[{"internalType":"address","name":"_factory","type":"address"},{"internalType":"address","name":"_WETH","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[],"name":"WETH","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"amountADesired","type":"uint256"},{"internalType":"uint256","name":"amountBDesired","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"addLiquidity","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"},{"internalType":"uint256","name":"liquidity","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amountTokenDesired","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"addLiquidityETH","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"},{"internalType":"uint256","name":"liquidity","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"factory","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"reserveIn","type":"uint256"},{"internalType":"uint256","name":"reserveOut","type":"uint256"}],"name":"getAmountIn","outputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"reserveIn","type":"uint256"},{"internalType":"uint256","name":"reserveOut","type":"uint256"}],"name":"getAmountOut","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"}],"name":"getAmountsIn","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"}],"name":"getAmountsOut","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"reserveA","type":"uint256"},{"internalType":"uint256","name":"reserveB","type":"uint256"}],"name":"quote","outputs":[{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidity","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidityETH","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"removeLiquidityETHSupportingFeeOnTransferTokens","outputs":[{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityETHWithPermit","outputs":[{"internalType":"uint256","name":"amountToken","type":"uint256"},{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountTokenMin","type":"uint256"},{"internalType":"uint256","name":"amountETHMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityETHWithPermitSupportingFeeOnTransferTokens","outputs":[{"internalType":"uint256","name":"amountETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"tokenA","type":"address"},{"internalType":"address","name":"tokenB","type":"address"},{"internalType":"uint256","name":"liquidity","type":"uint256"},{"internalType":"uint256","name":"amountAMin","type":"uint256"},{"internalType":"uint256","name":"amountBMin","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"bool","name":"approveMax","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"removeLiquidityWithPermit","outputs":[{"internalType":"uint256","name":"amountA","type":"uint256"},{"internalType":"uint256","name":"amountB","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapETHForExactTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactETHForTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactETHForTokensSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForETH","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForETHSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMin","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapExactTokensForTokensSupportingFeeOnTransferTokens","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMax","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapTokensForExactETH","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMax","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"name":"swapTokensForExactTokens","outputs":[{"internalType":"uint256[]","name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable","type":"function"},{"stateMutability":"payable","type":"receive"}]')
        },
        657: function(e, t) {},
        661: function(e, t) {},
        672: function(e) {
            e.exports = JSON.parse('{"connect_wallet":"Connect Wallet","widget":"widget","swap":"SWAP","limit":"LIMIT","p2p":"P2P","ethereum":"ethereum","bsc":"bsc","Token in data":"Token in data","Token out data":"Token out data","Token name":"Token name","Current price":"Current price","Total supply":"Total supply","Current Slippage":"Current Slippage","Price Impact":"Price Impact","Gas Price":"Gas Price","Expand":"Expand","Hide":"Hide","Average":"Average","Low":"Low","High ":"High ","Max":"Max","Balance":"Balance","Trade History":"Trade History","Please, connect your wallet and check your voltichange trade history":"Please, connect your wallet and check your voltichange trade history","Please, connect your wallet to view your favorite trades":"Please, connect your wallet to view your favorite trades","Favorite Trades":"Favorite Trades","":"","Slippage tolerance":"Slippage tolerance","Compatibility mode":"Compatibility mode","AUTO":"AUTO","Settings":"Settings","Setup Widget":"Setup Widget","Theme":"Theme","Blockchain":"Blockchain","Initial input token":"Initial input token","Initial output token":"Initial output token","Initial Slippage":"Initial Slippage","Installation":"Installation","Follow the instructions bellow to install and activate the voltichange widget on your website.":"Follow the instructions bellow to install and activate the voltichange widget on your website.","1. Place this link tag on the <head> of your page:":"1. Place this link tag on the <head> of your page:","2. Place this iframe tag at the location where the Voltichange Widget will be:":"2. Place this iframe tag at the location where the Voltichange Widget will be:","END OF VOLTICHANGE WIDGET CODE":"END OF VOLTICHANGE WIDGET CODE","Voltichange Widget Implementation Example":"Voltichange Widget Implementation Example","Bellow you can watch a quick tutorial on how to install and use the widget on your own website":"Bellow you can watch a quick tutorial on how to install and use the widget on your own website","Last block":"Last block","successfully approved token":"successfully approved token","Operation cancelled":"Operation cancelled","Swap done successfully!":"Swap done successfully!"}')
        },
        673: function(e) {
            e.exports = JSON.parse('{"connect_wallet":"\u8fde\u63a5\u94b1\u5305","widget":"\u5c0f\u90e8\u4ef6","swap":"\u4ea4\u6362","limit":"\u9650\u5236","p2p":"\u70b9\u5bf9\u70b9","ethereum":"\u4ee5\u592a\u574a","bsc":"\u7406\u636e","Token in data":"\u6570\u636e\u4e2d\u7684\u4ee4\u724c","Token out data":"\u6807\u8bb0\u51fa\u6570\u636e","Token name":"\u4ee3\u5e01\u540d\u79f0","Current price":"\u65f6\u4ef7","Total supply":"\u603b\u4f9b\u5e94\u91cf","Current Slippage":"\u5f53\u524d\u6ed1\u70b9","Price Impact":"\u4ef7\u683c\u5f71\u54cd","Gas Price":"\u5929\u7136\u6c14\u4ef7\u683c","Expand":"\u6269\u5f20","Hide":"\u9690\u85cf","Average":"\u5e73\u5747\u7684","Low":"\u4f4e\u7684","High ":"\u9ad8\u7684","Max":"\u6700\u5927\u9650\u5ea6","Balance":"\u5e73\u8861","Trade History":"\u4ea4\u6613\u5386\u53f2","Please, connect your wallet and check your voltichange trade history":"\u8bf7\u8fde\u63a5\u60a8\u7684\u94b1\u5305\u5e76\u68c0\u67e5\u60a8\u7684 voltichange \u4ea4\u6613\u5386\u53f2","Please, connect your wallet to view your favorite trades":"\u8bf7\u8fde\u63a5\u60a8\u7684\u94b1\u5305\u4ee5\u67e5\u770b\u60a8\u6700\u559c\u6b22\u7684\u4ea4\u6613","Favorite Trades":"\u6700\u559c\u6b22\u7684\u884c\u4e1a","":"","Slippage tolerance":"\u6ed1\u79fb\u516c\u5dee","Compatibility mode":"\u517c\u5bb9\u6a21\u5f0f","AUTO":"\u6c7d\u8f66","Settings":"\u8bbe\u7f6e","Setup Widget":"\u8bbe\u7f6e\u5c0f\u90e8\u4ef6","Theme":"\u4e3b\u9898","Blockchain":"\u533a\u5757\u94fe","Initial input token":"\u521d\u59cb\u8f93\u5165\u4ee4\u724c","Initial output token":"\u521d\u59cb\u8f93\u51fa\u4ee4\u724c","Initial Slippage":"\u521d\u59cb\u6ed1\u70b9","Installation":"\u5b89\u88c5","Follow the instructions bellow to install and activate the voltichange widget on your website.":"\u6309\u7167\u4ee5\u4e0b\u8bf4\u660e\u5728\u60a8\u7684\u7f51\u7ad9\u4e0a\u5b89\u88c5\u5e76\u6fc0\u6d3b voltichange \u5c0f\u90e8\u4ef6\u3002","1. Place this link tag on the <head> of your page:":"1. \u5c06\u6b64\u94fe\u63a5\u6807\u8bb0\u653e\u5728\u9875\u9762\u7684 <head> \u4e0a\uff1a","2. Place this iframe tag at the location where the Voltichange Widget will be:":"2. \u5c06\u6b64 iframe \u6807\u7b7e\u653e\u7f6e\u5728 Voltichange \u5c0f\u90e8\u4ef6\u6240\u5728\u7684\u4f4d\u7f6e\uff1a","END OF VOLTICHANGE WIDGET CODE":"VolTICHANGE \u5c0f\u90e8\u4ef6\u4ee3\u7801\u7ed3\u675f","Voltichange Widget Implementation Example":"Voltichange \u5c0f\u90e8\u4ef6\u5b9e\u73b0\u793a\u4f8b","Bellow you can watch a quick tutorial on how to install and use the widget on your own website":"\u60a8\u53ef\u4ee5\u5728\u4e0b\u9762\u89c2\u770b\u6709\u5173\u5982\u4f55\u5728\u60a8\u81ea\u5df1\u7684\u7f51\u7ad9\u4e0a\u5b89\u88c5\u548c\u4f7f\u7528\u5c0f\u90e8\u4ef6\u7684\u5feb\u901f\u6559\u7a0b","Last block":"\u6700\u540e\u4e00\u5757","successfully approved token":"\u6210\u529f\u6279\u51c6\u4ee4\u724c","Operation cancelled":"\u64cd\u4f5c\u53d6\u6d88","Swap done successfully!":"\u4ea4\u6362\u6210\u529f!"}')
        },
        674: function(e) {
            e.exports = JSON.parse('{"connect_wallet":"Wallet verbinden","widget":"widget","swap":"Tauschen","limit":"limit","p2p":"p2p","ethereum":"ethereum","bsc":"bsc","Token in data":"Token in Daten","Token out data":"Token aus Daten","Token name":"Token Name","Current price":"Aktueller Preis","Total supply":"Gesamtversorgung","Current Slippage":"aktuelle Abweichungstoleranz","Price Impact":"Preiseffekt","Gas Price":"Gasgeb\xfchren","Expand":"Erweitern","Hide":"Ausblinden","Average":"Durchschnitt","Low":"Gering","High ":"Hoch","Max":"Max","Balance":"Guthaben","Trade History":"Handelsverlauf","Please, connect your wallet and check your voltichange trade history":"Bitte, verbinden Sie Ihr Wallet und \xfcberpr\xfcfen Sie Ihren Voltichange- Handelsverlauf","Please, connect your wallet to view your favorite trades":"Bitte verbinden Sie Ihr Wallet , um Ihre bevorzugten Trades anzuzeigen","Favorite Trades":"Bevorzugten Trades","":"","Slippage tolerance":"Abweichungstoleranz","Compatibility mode":"Kompatibilit\xe4tsmodus","AUTO":"AUTO","Settings":"Einstellungen","Setup Widget":"Widget Einrichtung","Theme":"Theme","Blockchain":"Blockchain","Initial input token":"Urspr\xfcngliches Eingabe-Token","Initial output token":"Urspr\xfcngliches Ausgabe-Token","Initial Slippage":"Urspr\xfcnglicher Abweichungstoleranz","Installation":"Einrichtung","Follow the instructions bellow to install and activate the voltichange widget on your website.":"Folgen Sie den nachstehenden Anweisungen, um das Voltichange-Widget auf Ihrer Website zu installieren und zu aktivieren.","1. Place this link tag on the <head> of your page:":"1. Setzen Sie diesen Link-Tag in den <head> Ihrer Seite:","2. Place this iframe tag at the location where the Voltichange Widget will be:":"2. diesen iframe-Tag an der Stelle platzieren, an der das Voltichange-Widget erscheinen soll:","END OF VOLTICHANGE WIDGET CODE":"ENDE DES VOLTICHANGE-WIDGET-CODES","Voltichange Widget Implementation Example":"Beispiel f\xfcr die Implementierung des Voltichange-Widgets","Bellow you can watch a quick tutorial on how to install and use the widget on your own website":"Unten k\xf6nnen Sie sich eine kurze Anleitung ansehen, wie Sie das Widget auf Ihrer eigenen Website installieren und verwenden k\xf6nnen","Last block":"Letzter Block","successfully approved token":"Token erfolgreich genehmigt","Operation cancelled":"Operation abgebrochen","Swap done successfully!":"Swap erfolgreich abgeschlossen!"}')
        },
        675: function(e) {
            e.exports = JSON.parse('{"connect_wallet":"c\xfczdan\u0131_ba\u011fla","widget":"eklenti","swap":"takas","limit":"limit","p2p":"p2p","ethereum":"ethereum","bsc":"bsc","Token in data":"veri i\xe7indeki jeton","Token out data":"veri d\u0131\u015f\u0131ndaki jeton","Token name":"jeton ad\u0131","Current price":"anl\u0131k fiyat","Total supply":"Toplam arz","Current Slippage":"kayma oran\u0131","Price Impact":"Fiyat etkisi","Gas Price":"Gas fiyat\u0131","Expand":"Geni\u015fletme","Hide":"saklamak","Average":"Ortalama","Low":"D\xfc\u015f\xfck","High ":"Y\xfcksek ","Max":"Maksimum","Balance":"Balans","Trade History":"Ticaret Ge\xe7mi\u015fi","Please, connect your wallet and check your voltichange trade history":"L\xfctfen,c\xfczdan\u0131n\u0131z\u0131 ba\u011flay\u0131n ve voltichange ticaret ge\xe7mi\u015finizi kontrol edin","Please, connect your wallet to view your favorite trades":"Favori ticaretlerinizi g\xf6r\xfcnt\xfclemek i\xe7in l\xfctfen c\xfczdan\u0131n\u0131z\u0131 ba\u011flay\u0131n","Favorite Trades":"Favori Ticaretler","":"","Slippage tolerance":"Kayma Tolerans\u0131","Compatibility mode":"Uyumluluk Modu","AUTO":"AUTO","Settings":"Ayarlar","Setup Widget":"Kurulum Arac\u0131","Theme":"Tema","Blockchain":"Blok zinciri","Initial input token":"\u0130lk giri\u015f belirteci","Initial output token":"ilk \xe7\u0131k\u0131\u015f belirteci","Initial Slippage":"ilk kayma","Installation":"kurulum","Follow the instructions bellow to install and activate the voltichange widget on your website.":"Voltichange belirte\xe7ini web sitenize y\xfcklemek ve etkinle\u015ftirmek i\xe7in a\u015fa\u011f\u0131daki talimatlar\u0131 izleyin.","1. Place this link tag on the <head> of your page:":"1. Ba\u011flant\u0131 linkini sayfan\u0131n <ba\u015f\u0131na> yerle\u015ftirin:","2. Place this iframe tag at the location where the Voltichange Widget will be:":"2. Bu iframe etiketini Voltichange Widget\'\u0131n\u0131n olaca\u011f\u0131 konuma yerle\u015ftirin:","END OF VOLTICHANGE WIDGET CODE":"VOLTICHANGE WIDGET KODUNUN SONU","Voltichange Widget Implementation Example":"Voltichange Belirte\xe7 Uygulama \xd6rne\u011fi","Bellow you can watch a quick tutorial on how to install and use the widget on your own website":"Belirteci kendi web sitenize nas\u0131l kuraca\u011f\u0131n\u0131za ve kullanaca\u011f\u0131n\u0131za ili\u015fkin h\u0131zl\u0131 bir \xf6\u011freticiyi a\u015fa\u011f\u0131dan izleyebilirsiniz.","Last block":"Son Blok","successfully approved token":"ba\u015far\u0131yla onaylanan jeton","Operation cancelled":"\u0130\u015flem iptal edildi","Swap done successfully!":"Takas ba\u015far\u0131yla tamamland\u0131!"}')
        },
        676: function(e) {
            e.exports = JSON.parse('{"connect_wallet":"conectar","widget":"widget","swap":"cambio","limit":"limite","p2p":"p2p","ethereum":"etirium","bsc":"bsb","Token in data":"Token en datos","Token out data":"Token fuera de datos","Token name":"Nombre del Token","Current price":"Precio actual","Total supply":"Suministro Total","Current Slippage":"Deslizamiento actual","Price Impact":"Precio de impacto","Gas Price":"Precio rapido ","Expand":"Expandir","Hide":"Esconder","Average":"Averaje","Low":"Bajo","High ":"Alto","Max":"Maximo","Balance":"Saldo","Trade History":"Historial de comercio","Please, connect your wallet and check your voltichange trade history":"Porfavor, conectar su cartera y verifique su historial de comercio en voltichange","Please, connect your wallet to view your favorite trades":"Porfavor conectar su cartera para ver su comercio favorito","Favorite Trades":"Comercio favorito ","":"","Slippage tolerance":"Tolerancia de deslizamiento","Compatibility mode":"Modo de compatibilidad ","AUTO":"AUTO","Settings":"Ajustes","Setup Widget":"Widgets de configuraci\xf2n","Theme":"Tema","Blockchain":"Cadena de Bloques","Initial input token":"Ingreso inicial de Token","Initial output token":"Salida inicial de token","Initial Slippage":"Tolerancia de salida inicial","Installation":"Instalaci\xf2n ","Follow the instructions bellow to install and activate the voltichange widget on your website.":"Seguir las instrucciones abajo para instalar y activar el widget de voltichange en su sitio web voltichange","1. Place this link tag on the <head> of your page:":"1. Coloque este enlace en el < Cabeza> de su pagina:","2. Place this iframe tag at the location where the Voltichange Widget will be:":"2. Coloque esta iframe en la ubicacion donde El Voltichange widget estara:","END OF VOLTICHANGE WIDGET CODE":"FIN DEL WIDGET DE VOLTICHANGE","Voltichange Widget Implementation Example":"Ejemplo de implementaci\xf2n de Voltichange widget","Bellow you can watch a quick tutorial on how to install and use the widget on your own website":"Abajo puede ver un video tutorial breve en como instalar y usar El widget en su sitio Web.","Last block":"Ultimo bloque","successfully approved token":"Aprobacion exitoso de su token","Operation cancelled":"Operaci\xf2n cancelada","Swap done successfully!":"Intercambio realizado con exito!"}')
        },
        702: function(e, t, n) {
            e.exports = n(1416)
        },
        707: function(e, t, n) {},
        712: function(e, t) {},
        740: function(e, t) {},
        775: function(e, t) {},
        777: function(e, t) {},
        799: function(e, t) {},
        801: function(e, t) {},
        813: function(e, t) {},
        814: function(e, t) {},
        829: function(e, t) {},
        833: function(e, t) {},
        835: function(e, t) {},
        913: function(e, t) {}
    },
    [
        [702, 1, 2]
    ]
]);