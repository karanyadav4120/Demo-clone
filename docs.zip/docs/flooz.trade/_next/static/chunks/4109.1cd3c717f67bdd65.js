(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4109, 9403], {
        91296: function(e, t, i) {
            var r = 0 / 0,
                o = /^\s+|\s+$/g,
                n = /^[-+]0x[0-9a-f]+$/i,
                a = /^0b[01]+$/i,
                s = /^0o[0-7]+$/i,
                l = parseInt,
                u = "object" == typeof i.g && i.g && i.g.Object === Object && i.g,
                c = "object" == typeof self && self && self.Object === Object && self,
                f = u || c || Function("return this")(),
                d = Object.prototype.toString,
                v = Math.max,
                p = Math.min,
                m = function() {
                    return f.Date.now()
                };

            function h(e) {
                var t = typeof e;
                return !!e && ("object" == t || "function" == t)
            }

            function g(e) {
                if ("number" == typeof e) return e;
                if ("symbol" == typeof(t = e) || t && "object" == typeof t && "[object Symbol]" == d.call(t)) return r;
                if (h(e)) {
                    var t, i = "function" == typeof e.valueOf ? e.valueOf() : e;
                    e = h(i) ? i + "" : i
                }
                if ("string" != typeof e) return 0 === e ? e : +e;
                e = e.replace(o, "");
                var u = a.test(e);
                return u || s.test(e) ? l(e.slice(2), u ? 2 : 8) : n.test(e) ? r : +e
            }
            e.exports = function(e, t, i) {
                var r, o, n, a, s, l, u = 0,
                    c = !1,
                    f = !1,
                    d = !0;
                if ("function" != typeof e) throw TypeError("Expected a function");

                function b(t) {
                    var i = r,
                        n = o;
                    return r = o = void 0, u = t, a = e.apply(n, i)
                }

                function w(e) {
                    var i = e - l,
                        r = e - u;
                    return void 0 === l || i >= t || i < 0 || f && r >= n
                }

                function y() {
                    var e, i, r, o = m();
                    if (w(o)) return k(o);
                    s = setTimeout(y, (e = o - l, i = o - u, r = t - e, f ? p(r, n - i) : r))
                }

                function k(e) {
                    return (s = void 0, d && r) ? b(e) : (r = o = void 0, a)
                }

                function P() {
                    var e, i = m(),
                        n = w(i);
                    if (r = arguments, o = this, l = i, n) {
                        if (void 0 === s) return u = e = l, s = setTimeout(y, t), c ? b(e) : a;
                        if (f) return s = setTimeout(y, t), b(l)
                    }
                    return void 0 === s && (s = setTimeout(y, t)), a
                }
                return t = g(t) || 0, h(i) && (c = !!i.leading, n = (f = "maxWait" in i) ? v(g(i.maxWait) || 0, t) : n, d = "trailing" in i ? !!i.trailing : d), P.cancel = function() {
                    void 0 !== s && clearTimeout(s), u = 0, r = l = o = s = void 0
                }, P.flush = function() {
                    return void 0 === s ? a : k(m())
                }, P
            }
        },
        94109: function(e, t, i) {
            "use strict";
            i.r(t), i.d(t, {
                BackgroundProcesses: function() {
                    return J
                }
            });
            var r, o = i(67294),
                n = i(99640),
                a = i(48791),
                s = i(95894),
                l = i(39376);
            let u = e => {
                let {
                    refId: t
                } = e, {
                    selectedAccount: i
                } = (0, a.Z_)(), r = (0, l.s)();
                (0, o.useEffect)(() => {
                    i && setTimeout(() => s.DJ.emitWalletConnected(), 2e3)
                }, [i]), (0, o.useEffect)(() => {
                    t && setTimeout(() => s.DJ.emitIncomingReferral({
                        refId: t
                    }), 2e3)
                }, [t]), (0, o.useEffect)(() => {
                    n.I.updateContext({
                        mode: r ? "embed" : "platform"
                    })
                }, [r])
            };
            var c = i(51249),
                f = i(68091),
                d = i(30405),
                v = i(27722),
                p = i(90271);
            let m = [],
                h = () => {
                    let {
                        selectedAccount: e
                    } = (0, a.Z_)(), {
                        modalHistory: t
                    } = (0, v.N)(), i = (0, l.s)(), r = (0, o.useCallback)(e => {
                        t.push(p.e.startBuyAnySwapActivity, void 0, {
                            activity: e
                        }), m.push(e.quoteId)
                    }, [t]), {
                        data: n
                    } = (0, d.f)({
                        pathParameters: {
                            address: null != e ? e : ""
                        },
                        queryParameters: {
                            limit: 100,
                            skip: 0
                        }
                    }, {
                        enabled: null != e
                    });
                    (0, o.useEffect)(() => {
                        if (!(null == n ? void 0 : n.result) || !e || i) return;
                        let t = null == n ? void 0 : n.result.filter(e => {
                            if (e.type == f.L.INDIRECT && e.indirectStatus != c._H.COMPLETED && e.transactionStatus == c.kl.COMPLETED && !m.includes(e.quoteId)) return { ...e
                            }
                        });
                        t.length > 0 && r(t[0])
                    }, [n, e, r, i])
                };
            var g = i(7134);
            let b = () => {
                let e = (0, g.d)();
                (0, o.useEffect)(() => {
                    let t = "".concat((e.height - 1).toString(), "px");
                    document.documentElement.style.setProperty("--sya-application-height", t)
                }, [e])
            };
            var w = i(92738),
                y = i(87988);
            let k = () => {
                let {
                    selectedAccount: e
                } = (0, a.Z_)(), t = (0, l.s)();
                (0, y.m)(), (0, w.G)({
                    pathParameters: {
                        address: e
                    },
                    queryParameters: {}
                }, {
                    enabled: null != e && !t
                })
            };
            var P = i(74020),
                S = i(9264),
                T = i(11163),
                E = i(23284),
                C = i(51275),
                I = i(98848),
                N = i(60759),
                O = i(48228),
                F = i(50549);
            (r || (r = {})).SUBSCRIBE_FOR_NOTIFICATION = "subscribeForNotificationsUnauthenticated";
            let R = new class {
                    async subscribe(e) {
                        let {
                            token: t,
                            walletAddress: i
                        } = e, o = (0, F.V1)(E.I.firebaseFunctions, r.SUBSCRIBE_FOR_NOTIFICATION), {
                            data: n
                        } = await o({
                            token: t,
                            walletAddress: i
                        });
                        return n
                    }
                },
                x = e => (0, O.D)(e => R.subscribe(e), e),
                A = () => {
                    let {
                        t: e
                    } = (0, S.$G)(), t = (0, T.useRouter)(), {
                        selectedAccount: i
                    } = (0, a.Z_)(), [r, n] = (0, o.useState)(), [s, u] = (0, o.useState)(!1), c = (0, l.s)(), f = () => {
                        s && C.F.notificationSuccess({
                            message: e("flooz-web.application.push-notification.toast-notification-successfully-subscribed")
                        }), u(!1), m(E.I.messaging)
                    }, {
                        mutate: d
                    } = x({
                        onSuccess: f
                    }), v = (0, o.useCallback)(e => {
                        var t;
                        (null == e ? void 0 : null === (t = e.err) || void 0 === t ? void 0 : t.code) != "messaging/permission-blocked" && C.F.notificationError({
                            message: e.error
                        })
                    }, []), p = (0, o.useCallback)((e, i) => {
                        (0, P.ps)(e, e => {
                            var r;
                            if (!(null === (r = e.notification) || void 0 === r ? void 0 : r.title)) return;
                            let {
                                title: o,
                                body: n,
                                image: a
                            } = e.notification, s = {
                                body: n,
                                icon: null != a ? a : "/logo.png"
                            };
                            try {
                                let e = new Notification(o, s);
                                e.onclick = e => {
                                    e.preventDefault(), t.push("/profile?selectedTab=ACTIVITIES")
                                }
                            } catch (e) {
                                i.showNotification(o, s)
                            }
                        })
                    }, [t]), m = (0, o.useCallback)(t => {
                        if (!(null == navigator ? void 0 : navigator.serviceWorker)) return;
                        let i = new URLSearchParams({
                            apiKey: "AIzaSyBcV-3qswc5QRFEBK8GBU6AsNp4KdW1UCg",
                            projectId: "flooz-profiles-prod",
                            messagingSenderId: "514527224954",
                            appId: "1:514527224954:web:8907b347d3a16cbec387c3"
                        }).toString();
                        navigator.serviceWorker.register("/firebase-messaging-sw.js?".concat(i)).then(e => p(t, e)).catch(t => v({
                            error: e("flooz-web.application.push-notification.registration-service-worker-failed"),
                            err: t
                        }))
                    }, [v, p, e]), h = (0, o.useCallback)(async t => {
                        let i = await I._.isBrave();
                        i ? v({
                            error: e("flooz-web.application.push-notification.notifications-rejected-brave-browser"),
                            err: t
                        }) : v({
                            error: e("flooz-web.application.push-notification.notifications-rejected"),
                            err: t
                        })
                    }, [v, e]), g = (0, o.useCallback)((e, t) => {
                        (0, P.LP)(e, {
                            vapidKey: "BO-QGf75CJPCn_MUwKfpjRNK1A_va2GHfRtgr-0FRs2eTrqe6O-0FYEGXnDLCZFxS5W_ByWTaVBT_FaHZO5O6Eo"
                        }).then(e => {
                            e && (n(e), d({
                                token: e,
                                walletAddress: t
                            }))
                        }).catch(e => {
                            h(e)
                        })
                    }, [d, h]);
                    (0, o.useEffect)(() => {
                        let e = E.I.messaging && i && null == r && "Notification" in window && !0 !== N.Wl.get(N.mJ.pushNotificationRejected) && !1 === c;
                        e && ("default" === Notification.permission ? Notification.requestPermission(() => {
                            u(!0), g(E.I.messaging, i)
                        }) : "granted" === Notification.permission && g(E.I.messaging, i))
                    }, [i, r, g, c])
                };
            var B = i(85945),
                _ = i(30120),
                M = i(34443),
                j = i(67797),
                W = i(71115),
                z = i(13484),
                D = i(19069),
                L = i(194),
                q = i(49749),
                G = i(58871);
            let U = () => {
                    let {
                        selectedAccount: e,
                        web3Provider: t
                    } = (0, a.Z_)(), {
                        mutateAsync: i
                    } = (0, W.q)({}), {
                        t: r
                    } = (0, S.$G)(), n = (0, B.NL)(), {
                        data: s
                    } = (0, j.D)({
                        key: N.mJ.recentSwapActivities(e)
                    }, {
                        enabled: null != e
                    }), {
                        mutate: l
                    } = (0, M.h)(), u = (0, o.useCallback)(() => {
                        let t = {
                            address: e
                        };
                        n.invalidateQueries(D.a.tokenPortfolio({
                            pathParameters: t,
                            queryParameters: {
                                invalidate: !0
                            }
                        })), n.invalidateQueries(D.a.activities({
                            pathParameters: t,
                            queryParameters: {}
                        }))
                    }, [n, e]), c = (0, o.useCallback)(t => {
                        var i;
                        if (!e) return;
                        let r = null !== (i = null == s ? void 0 : s.findIndex(e => {
                                let {
                                    hash: i
                                } = e;
                                return i === t.hash
                            })) && void 0 !== i ? i : -1,
                            o = null != s ? s : []; - 1 === r ? o = [...null != s ? s : [], t] : o[r] = t, l({
                            key: N.mJ.recentSwapActivities(e),
                            value: o
                        })
                    }, [s, e, l]), f = (0, o.useCallback)(e => {
                        var t, i;
                        let o = { ...e,
                                status: !0,
                                blockTimestamp: _.ou.now().toISO()
                            },
                            n = L.S.getTokenAmountInUSD(e.amountFrom, e.tokenFrom);
                        q.k0.emitSwap({
                            activity: e,
                            usdAmount: n
                        }), c(o), C.F.notificationSuccess({
                            message: r("flooz-web.trade.swap-tokens.toast.success", {
                                from: null === (t = o.tokenFrom) || void 0 === t ? void 0 : t.symbol,
                                to: null === (i = o.tokenTo) || void 0 === i ? void 0 : i.symbol
                            })
                        }), u()
                    }, [c, r, u]), d = (0, o.useCallback)((e, t) => {
                        var i, o;
                        let n = { ...e,
                            blockTimestamp: _.ou.now().toISO(),
                            status: !1
                        };
                        c(n), C.F.notificationError({
                            message: r("flooz-web.trade.swap-tokens.toast.error")
                        }), u(), q.k0.emitSwapError({
                            fromTokenSymbol: null === (i = n.tokenFrom) || void 0 === i ? void 0 : i.symbol,
                            toTokenSymbol: null === (o = n.tokenTo) || void 0 === o ? void 0 : o.symbol,
                            usdAmount: n.usdValue,
                            error: G.CB.getSwapError(t),
                            errorMessage: G.CB.parseErrorMessage(t)
                        })
                    }, [c, u, r]);
                    (0, o.useEffect)(() => {
                        let e = async e => {
                            try {
                                await i({
                                    provider: t,
                                    txHash: e.hash
                                }), f(e), e.processing = !1
                            } catch (t) {
                                d(e, t), e.processing = !1
                            }
                        };
                        null == s || s.forEach(t => {
                            t.type == z.T.SWAP && null == t.status && null !== t.hash && !0 != t.processing && (t.processing = !0, e(t))
                        })
                    }, [d, f, s, i, t])
                },
                Z = e => {
                    let {
                        refId: t
                    } = e;
                    (0, o.useEffect)(() => {
                        t && N.Wl.set(N.mJ.referralId, t, !0)
                    }, [t])
                },
                J = e => {
                    let {
                        refId: t
                    } = e;
                    return b(), u({
                        refId: t
                    }), Z({
                        refId: t
                    }), A(), h(), U(), k(), null
                }
        },
        194: function(e, t, i) {
            "use strict";
            var r, o;
            i.d(t, {
                S: function() {
                    return n
                }
            }), (o = r || (r = {})).ONRAMP = "onramp", o.OFFRAMP = "offramp";
            let n = new class {
                constructor() {
                    this.getTokenAmountInUSD = (e, t) => {
                        var i;
                        return (parseFloat(null != e ? e : "0") * parseFloat(null !== (i = null == t ? void 0 : t.usdValue) && void 0 !== i ? i : "0")).toFixed(2)
                    }, this.filterTokenByName = function(e) {
                        let {
                            name: t,
                            symbol: i
                        } = e, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                        return t.toLowerCase().includes(null == r ? void 0 : r.toLowerCase()) || i.toLowerCase().includes(r.toLowerCase())
                    }, this.filterTokenByNetwork = (e, t) => null == t || t === e, this.filterTokenByStatus = (e, t) => null == t || t === e, this.filterTokenByRampProvider = (e, t) => {
                        var i, o;
                        return null == t || t === r.OFFRAMP && (null === (i = e.rampProviders) || void 0 === i ? void 0 : i.some(e => e.allowsSellingToken)) || t === r.ONRAMP && (null === (o = e.rampProviders) || void 0 === o ? void 0 : o.some(e => e.allowsBuyingToken))
                    }
                }
            }
        },
        71115: function(e, t, i) {
            "use strict";
            i.d(t, {
                q: function() {
                    return n
                }
            });
            var r = i(48228),
                o = i(2948);
            let n = e => (0, r.D)(e => o.x.waitTransaction(e), e)
        },
        92738: function(e, t, i) {
            "use strict";
            i.d(t, {
                G: function() {
                    return a
                }
            });
            var r = i(59403),
                o = i(46223),
                n = i(19069);
            let a = (e, t) => (0, r.N)(n.a.activities(e), t => {
                let {
                    pageParam: i
                } = t;
                return o.W4.getActivities({ ...e,
                    ...i
                })
            }, { ...t,
                getNextPageParam: o.W4.getReactQueryCursorPaginatedParams(e)
            })
        },
        7134: function(e, t, i) {
            "use strict";
            i.d(t, {
                d: function() {
                    return u
                }
            });
            var r = i(91296),
                o = i.n(r),
                n = i(67294);
            let a = new Set,
                s = () => {
                    let {
                        innerWidth: e,
                        innerHeight: t
                    } = window;
                    return {
                        width: e,
                        height: t
                    }
                },
                l = o()(() => {
                    var e;
                    if (!(null === (e = window.ethereum) || void 0 === e ? void 0 : e.isSafePal)) {
                        let e = s();
                        a.forEach(t => t(e))
                    }
                }, 300),
                u = () => {
                    let [e, t] = (0, n.useState)(s());
                    return (0, n.useEffect)(() => (a.add(t), 1 === a.size && window.addEventListener("resize", l), () => {
                        a.delete(t), 0 === a.size && window.removeEventListener("resize", l)
                    }), []), e
                }
        },
        59403: function(e, t, i) {
            "use strict";
            i.d(t, {
                N: function() {
                    return l
                }
            });
            var r = i(32161),
                o = i(52924),
                n = i(9499);
            class a extends o.z {
                constructor(e, t) {
                    super(e, t)
                }
                bindMethods() {
                    super.bindMethods(), this.fetchNextPage = this.fetchNextPage.bind(this), this.fetchPreviousPage = this.fetchPreviousPage.bind(this)
                }
                setOptions(e, t) {
                    super.setOptions({ ...e,
                        behavior: (0, n.Gm)()
                    }, t)
                }
                getOptimisticResult(e) {
                    return e.behavior = (0, n.Gm)(), super.getOptimisticResult(e)
                }
                fetchNextPage({
                    pageParam: e,
                    ...t
                } = {}) {
                    return this.fetch({ ...t,
                        meta: {
                            fetchMore: {
                                direction: "forward",
                                pageParam: e
                            }
                        }
                    })
                }
                fetchPreviousPage({
                    pageParam: e,
                    ...t
                } = {}) {
                    return this.fetch({ ...t,
                        meta: {
                            fetchMore: {
                                direction: "backward",
                                pageParam: e
                            }
                        }
                    })
                }
                createResult(e, t) {
                    var i, r, o, a, s, l;
                    let {
                        state: u
                    } = e, c = super.createResult(e, t), {
                        isFetching: f,
                        isRefetching: d
                    } = c, v = f && (null == (i = u.fetchMeta) ? void 0 : null == (r = i.fetchMore) ? void 0 : r.direction) === "forward", p = f && (null == (o = u.fetchMeta) ? void 0 : null == (a = o.fetchMore) ? void 0 : a.direction) === "backward";
                    return { ...c,
                        fetchNextPage: this.fetchNextPage,
                        fetchPreviousPage: this.fetchPreviousPage,
                        hasNextPage: (0, n.Qy)(t, null == (s = u.data) ? void 0 : s.pages),
                        hasPreviousPage: (0, n.ZF)(t, null == (l = u.data) ? void 0 : l.pages),
                        isFetchingNextPage: v,
                        isFetchingPreviousPage: p,
                        isRefetching: d && !v && !p
                    }
                }
            }
            var s = i(67187);

            function l(e, t, i) {
                let o = (0, r._v)(e, t, i);
                return (0, s.r)(o, a)
            }
        }
    }
]);