"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1933], {
        21933: function(e, t, r) {
            r.r(t), r.d(t, {
                CustomProvider: function() {
                    return X
                },
                ReCaptchaEnterpriseProvider: function() {
                    return W
                },
                ReCaptchaV3Provider: function() {
                    return q
                },
                getToken: function() {
                    return J
                },
                initializeAppCheck: function() {
                    return V
                },
                onTokenChanged: function() {
                    return Q
                },
                setTokenAutoRefreshEnabled: function() {
                    return Y
                }
            });
            var n = r(32238),
                o = r(8463),
                i = r(74444),
                a = r(53333);
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            let s = new Map,
                l = {
                    activated: !1,
                    tokenObservers: []
                },
                c = {
                    initialized: !1,
                    enabled: !1
                };

            function h(e) {
                return s.get(e) || Object.assign({}, l)
            }
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            let u = "https://content-firebaseappcheck.googleapis.com/v1",
                p = {
                    OFFSET_DURATION: 3e5,
                    RETRIAL_MIN_WAIT: 3e4,
                    RETRIAL_MAX_WAIT: 96e4
                };
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            class d {
                constructor(e, t, r, n, o) {
                    if (this.operation = e, this.retryPolicy = t, this.getWaitDuration = r, this.lowerBound = n, this.upperBound = o, this.pending = null, this.nextErrorWaitInterval = n, n > o) throw Error("Proactive refresh lower bound greater than upper bound!")
                }
                start() {
                    this.nextErrorWaitInterval = this.lowerBound, this.process(!0).catch(() => {})
                }
                stop() {
                    this.pending && (this.pending.reject("cancelled"), this.pending = null)
                }
                isRunning() {
                    return !!this.pending
                }
                async process(e) {
                    this.stop();
                    try {
                        var t;
                        this.pending = new i.BH, await (t = this.getNextRun(e), new Promise(e => {
                            setTimeout(e, t)
                        })), this.pending.resolve(), await this.pending.promise, this.pending = new i.BH, await this.operation(), this.pending.resolve(), await this.pending.promise, this.process(!0).catch(() => {})
                    } catch (e) {
                        this.retryPolicy(e) ? this.process(!1).catch(() => {}) : this.stop()
                    }
                }
                getNextRun(e) {
                    if (e) return this.nextErrorWaitInterval = this.lowerBound, this.getWaitDuration(); {
                        let e = this.nextErrorWaitInterval;
                        return this.nextErrorWaitInterval *= 2, this.nextErrorWaitInterval > this.upperBound && (this.nextErrorWaitInterval = this.upperBound), e
                    }
                }
            }
            let f = new i.LL("appCheck", "AppCheck", {
                "already-initialized": "You have already called initializeAppCheck() for FirebaseApp {$appName} with different options. To avoid this error, call initializeAppCheck() with the same options as when it was originally called. This will return the already initialized instance.",
                "use-before-activation": "App Check is being used before initializeAppCheck() is called for FirebaseApp {$appName}. Call initializeAppCheck() before instantiating other Firebase services.",
                "fetch-network-error": "Fetch failed to connect to a network. Check Internet connection. Original error: {$originalErrorMessage}.",
                "fetch-parse-error": "Fetch client could not parse response. Original error: {$originalErrorMessage}.",
                "fetch-status-error": "Fetch server returned an HTTP error status. HTTP status: {$httpStatus}.",
                "storage-open": "Error thrown when opening storage. Original error: {$originalErrorMessage}.",
                "storage-get": "Error thrown when reading from storage. Original error: {$originalErrorMessage}.",
                "storage-set": "Error thrown when writing to storage. Original error: {$originalErrorMessage}.",
                "recaptcha-error": "ReCAPTCHA error.",
                throttled: "Requests throttled due to {$httpStatus} error. Attempts allowed again after {$time}"
            });
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            function g(e = !1) {
                var t;
                return e ? null === (t = self.grecaptcha) || void 0 === t ? void 0 : t.enterprise : self.grecaptcha
            }

            function k(e) {
                if (!h(e).activated) throw f.create("use-before-activation", {
                    appName: e.name
                })
            }

            function w(e) {
                let t = Math.round(e / 1e3),
                    r = Math.floor(t / 86400),
                    n = Math.floor((t - 86400 * r) / 3600),
                    o = Math.floor((t - 86400 * r - 3600 * n) / 60),
                    i = "";
                return r && (i += v(r) + "d:"), n && (i += v(n) + "h:"), i += v(o) + "m:" + v(t - 86400 * r - 3600 * n - 60 * o) + "s"
            }

            function v(e) {
                return 0 === e ? "00" : e >= 10 ? e.toString() : "0" + e
            }
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            async function m({
                url: e,
                body: t
            }, r) {
                let n, o;
                let i = {
                        "Content-Type": "application/json"
                    },
                    a = r.getImmediate({
                        optional: !0
                    });
                if (a) {
                    let e = await a.getHeartbeatsHeader();
                    e && (i["X-Firebase-Client"] = e)
                }
                let s = {
                    method: "POST",
                    body: JSON.stringify(t),
                    headers: i
                };
                try {
                    n = await fetch(e, s)
                } catch (e) {
                    throw f.create("fetch-network-error", {
                        originalErrorMessage: null == e ? void 0 : e.message
                    })
                }
                if (200 !== n.status) throw f.create("fetch-status-error", {
                    httpStatus: n.status
                });
                try {
                    o = await n.json()
                } catch (e) {
                    throw f.create("fetch-parse-error", {
                        originalErrorMessage: null == e ? void 0 : e.message
                    })
                }
                let l = o.ttl.match(/^([\d.]+)(s)$/);
                if (!l || !l[2] || isNaN(Number(l[1]))) throw f.create("fetch-parse-error", {
                    originalErrorMessage: `ttl field (timeToLive) is not in standard Protobuf Duration format: ${o.ttl}`
                });
                let c = 1e3 * Number(l[1]),
                    h = Date.now();
                return {
                    token: o.token,
                    expireTimeMillis: h + c,
                    issuedAtTimeMillis: h
                }
            }
            let E = "firebase-app-check-store",
                b = "debug-token",
                T = null;

            function _() {
                return T || (T = new Promise((e, t) => {
                    try {
                        let r = indexedDB.open("firebase-app-check-database", 1);
                        r.onsuccess = t => {
                            e(t.target.result)
                        }, r.onerror = e => {
                            var r;
                            t(f.create("storage-open", {
                                originalErrorMessage: null === (r = e.target.error) || void 0 === r ? void 0 : r.message
                            }))
                        }, r.onupgradeneeded = e => {
                            let t = e.target.result;
                            0 === e.oldVersion && t.createObjectStore(E, {
                                keyPath: "compositeKey"
                            })
                        }
                    } catch (e) {
                        t(f.create("storage-open", {
                            originalErrorMessage: null == e ? void 0 : e.message
                        }))
                    }
                }))
            }
            async function A(e, t) {
                let r = await _(),
                    n = r.transaction(E, "readwrite"),
                    o = n.objectStore(E),
                    i = o.put({
                        compositeKey: e,
                        value: t
                    });
                return new Promise((e, t) => {
                    i.onsuccess = t => {
                        e()
                    }, n.onerror = e => {
                        var r;
                        t(f.create("storage-set", {
                            originalErrorMessage: null === (r = e.target.error) || void 0 === r ? void 0 : r.message
                        }))
                    }
                })
            }
            async function y(e) {
                let t = await _(),
                    r = t.transaction(E, "readonly"),
                    n = r.objectStore(E),
                    o = n.get(e);
                return new Promise((e, t) => {
                    o.onsuccess = t => {
                        let r = t.target.result;
                        r ? e(r.value) : e(void 0)
                    }, r.onerror = e => {
                        var r;
                        t(f.create("storage-get", {
                            originalErrorMessage: null === (r = e.target.error) || void 0 === r ? void 0 : r.message
                        }))
                    }
                })
            }

            function P(e) {
                return `${e.options.appId}-${e.name}`
            }
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            let C = new a.Yd("@firebase/app-check");
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            async function R(e) {
                if ((0, i.hl)()) {
                    let t;
                    try {
                        t = await y(P(e))
                    } catch (e) {
                        C.warn(`Failed to read token from IndexedDB. Error: ${e}`)
                    }
                    return t
                }
            }

            function I(e, t) {
                return (0, i.hl)() ? A(P(e), t).catch(e => {
                    C.warn(`Failed to write token to IndexedDB. Error: ${e}`)
                }) : Promise.resolve()
            }
            async function D() {
                let e;
                try {
                    e = await y(b)
                } catch (e) {}
                if (e) return e; {
                    let e = (0, i.k$)();
                    return A(b, e).catch(e => C.warn(`Failed to persist debug token to IndexedDB. Error: ${e}`)), e
                }
            }
            async function S() {
                if (c.enabled && c.token) return c.token.promise;
                throw Error(`
            Can't get debug token in production mode.
        `)
            }
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            let x = {
                error: "UNKNOWN_ERROR"
            };
            async function O(e, t = !1) {
                let r, n;
                let o = e.app;
                k(o);
                let i = h(o),
                    a = i.token;
                if (a && !z(a) && (i.token = void 0, a = void 0), !a) {
                    let e = await i.cachedTokenPromise;
                    e && (z(e) ? a = e : await I(o, void 0))
                }
                if (!t && a && z(a)) return {
                    token: a.token
                };
                let s = !1;
                if (c.enabled) {
                    i.exchangeTokenPromise || (i.exchangeTokenPromise = m(function(e, t) {
                        let {
                            projectId: r,
                            appId: n,
                            apiKey: o
                        } = e.options;
                        return {
                            url: `${u}/projects/${r}/apps/${n}:exchangeDebugToken?key=${o}`,
                            body: {
                                debug_token: t
                            }
                        }
                    }(o, await S()), e.heartbeatServiceProvider).finally(() => {
                        i.exchangeTokenPromise = void 0
                    }), s = !0);
                    let t = await i.exchangeTokenPromise;
                    return await I(o, t), i.token = t, {
                        token: t.token
                    }
                }
                try {
                    i.exchangeTokenPromise || (i.exchangeTokenPromise = i.provider.getToken().finally(() => {
                        i.exchangeTokenPromise = void 0
                    }), s = !0), a = await h(o).exchangeTokenPromise
                } catch (e) {
                    "appCheck/throttled" === e.code ? C.warn(e.message) : C.error(e), n = e
                }
                return a ? n ? r = z(a) ? {
                    token: a.token,
                    internalError: n
                } : H(n) : (r = {
                    token: a.token
                }, i.token = a, await I(o, a)) : r = H(n), s && B(o, r), r
            }

            function M(e, t, r, n) {
                let {
                    app: o
                } = e, i = h(o);
                if (i.tokenObservers = [...i.tokenObservers, {
                        next: r,
                        error: n,
                        type: t
                    }], i.token && z(i.token)) {
                    let t = i.token;
                    Promise.resolve().then(() => {
                        r({
                            token: t.token
                        }), $(e)
                    }).catch(() => {})
                }
                i.cachedTokenPromise.then(() => $(e))
            }

            function N(e, t) {
                let r = h(e),
                    n = r.tokenObservers.filter(e => e.next !== t);
                0 === n.length && r.tokenRefresher && r.tokenRefresher.isRunning() && r.tokenRefresher.stop(), r.tokenObservers = n
            }

            function $(e) {
                let {
                    app: t
                } = e, r = h(t), n = r.tokenRefresher;
                n || (n = function(e) {
                    let {
                        app: t
                    } = e;
                    return new d(async () => {
                        let r;
                        let n = h(t);
                        if ((r = n.token ? await O(e, !0) : await O(e)).error) throw r.error;
                        if (r.internalError) throw r.internalError
                    }, () => !0, () => {
                        let e = h(t);
                        if (!e.token) return 0; {
                            let t = e.token.issuedAtTimeMillis + (e.token.expireTimeMillis - e.token.issuedAtTimeMillis) * .5 + 3e5,
                                r = e.token.expireTimeMillis - 3e5;
                            return Math.max(0, (t = Math.min(t, r)) - Date.now())
                        }
                    }, p.RETRIAL_MIN_WAIT, p.RETRIAL_MAX_WAIT)
                }(e), r.tokenRefresher = n), !n.isRunning() && r.isTokenAutoRefreshEnabled && n.start()
            }

            function B(e, t) {
                let r = h(e).tokenObservers;
                for (let e of r) try {
                    "EXTERNAL" === e.type && null != t.error ? e.error(t.error) : e.next(t)
                } catch (e) {}
            }

            function z(e) {
                return e.expireTimeMillis - Date.now() > 0
            }

            function H(e) {
                return {
                    token: i.US.encodeString(JSON.stringify(x), !1),
                    error: e
                }
            }
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            class K {
                constructor(e, t) {
                    this.app = e, this.heartbeatServiceProvider = t
                }
                _delete() {
                    let {
                        tokenObservers: e
                    } = h(this.app);
                    for (let t of e) N(this.app, t.next);
                    return Promise.resolve()
                }
            }

            function j(e, t, r, n, o) {
                r.ready(() => {
                    (function(e, t, r, n) {
                        let o = r.render(n, {
                                sitekey: t,
                                size: "invisible"
                            }),
                            i = h(e);
                        i.reCAPTCHAState = Object.assign(Object.assign({}, i.reCAPTCHAState), {
                            widgetId: o
                        })
                    })(e, t, r, n), o.resolve(r)
                })
            }

            function F(e) {
                let t = `fire_app_check_${e.name}`,
                    r = document.createElement("div");
                return r.id = t, r.style.display = "none", document.body.appendChild(r), t
            }
            async function L(e) {
                k(e);
                let t = h(e).reCAPTCHAState,
                    r = await t.initialized.promise;
                return new Promise((t, n) => {
                    let o = h(e).reCAPTCHAState;
                    r.ready(() => {
                        t(r.execute(o.widgetId, {
                            action: "fire_app_check"
                        }))
                    })
                })
            }
            /**
             * @license
             * Copyright 2021 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            class q {
                constructor(e) {
                    this._siteKey = e, this._throttleData = null
                }
                async getToken() {
                    var e, t;
                    let r;
                    G(this._throttleData);
                    let n = await L(this._app).catch(e => {
                        throw f.create("recaptcha-error")
                    });
                    try {
                        r = await m(function(e, t) {
                            let {
                                projectId: r,
                                appId: n,
                                apiKey: o
                            } = e.options;
                            return {
                                url: `${u}/projects/${r}/apps/${n}:exchangeRecaptchaV3Token?key=${o}`,
                                body: {
                                    recaptcha_v3_token: t
                                }
                            }
                        }(this._app, n), this._heartbeatServiceProvider)
                    } catch (r) {
                        if (null === (e = r.code) || void 0 === e ? void 0 : e.includes("fetch-status-error")) throw this._throttleData = U(Number(null === (t = r.customData) || void 0 === t ? void 0 : t.httpStatus), this._throttleData), f.create("throttled", {
                            time: w(this._throttleData.allowRequestsAfter - Date.now()),
                            httpStatus: this._throttleData.httpStatus
                        });
                        throw r
                    }
                    return this._throttleData = null, r
                }
                initialize(e) {
                    this._app = e, this._heartbeatServiceProvider = (0, n.qX)(e, "heartbeat"), (function(e, t) {
                        let r = new i.BH,
                            n = h(e);
                        n.reCAPTCHAState = {
                            initialized: r
                        };
                        let o = F(e),
                            a = g(!1);
                        return a ? j(e, t, a, o, r) : function(e) {
                            let t = document.createElement("script");
                            t.src = "https://www.google.com/recaptcha/api.js", t.onload = e, document.head.appendChild(t)
                        }(() => {
                            let n = g(!1);
                            if (!n) throw Error("no recaptcha");
                            j(e, t, n, o, r)
                        }), r.promise
                    })(e, this._siteKey).catch(() => {})
                }
                isEqual(e) {
                    return e instanceof q && this._siteKey === e._siteKey
                }
            }
            class W {
                constructor(e) {
                    this._siteKey = e, this._throttleData = null
                }
                async getToken() {
                    var e, t;
                    let r;
                    G(this._throttleData);
                    let n = await L(this._app).catch(e => {
                        throw f.create("recaptcha-error")
                    });
                    try {
                        r = await m(function(e, t) {
                            let {
                                projectId: r,
                                appId: n,
                                apiKey: o
                            } = e.options;
                            return {
                                url: `${u}/projects/${r}/apps/${n}:exchangeRecaptchaEnterpriseToken?key=${o}`,
                                body: {
                                    recaptcha_enterprise_token: t
                                }
                            }
                        }(this._app, n), this._heartbeatServiceProvider)
                    } catch (r) {
                        if (null === (e = r.code) || void 0 === e ? void 0 : e.includes("fetch-status-error")) throw this._throttleData = U(Number(null === (t = r.customData) || void 0 === t ? void 0 : t.httpStatus), this._throttleData), f.create("throttled", {
                            time: w(this._throttleData.allowRequestsAfter - Date.now()),
                            httpStatus: this._throttleData.httpStatus
                        });
                        throw r
                    }
                    return this._throttleData = null, r
                }
                initialize(e) {
                    this._app = e, this._heartbeatServiceProvider = (0, n.qX)(e, "heartbeat"), (function(e, t) {
                        let r = new i.BH,
                            n = h(e);
                        n.reCAPTCHAState = {
                            initialized: r
                        };
                        let o = F(e),
                            a = g(!0);
                        return a ? j(e, t, a, o, r) : function(e) {
                            let t = document.createElement("script");
                            t.src = "https://www.google.com/recaptcha/enterprise.js", t.onload = e, document.head.appendChild(t)
                        }(() => {
                            let n = g(!0);
                            if (!n) throw Error("no recaptcha");
                            j(e, t, n, o, r)
                        }), r.promise
                    })(e, this._siteKey).catch(() => {})
                }
                isEqual(e) {
                    return e instanceof W && this._siteKey === e._siteKey
                }
            }
            class X {
                constructor(e) {
                    this._customProviderOptions = e
                }
                async getToken() {
                    let e = await this._customProviderOptions.getToken(),
                        t = (0, i.DO)(e.token),
                        r = null !== t && t < Date.now() && t > 0 ? 1e3 * t : Date.now();
                    return Object.assign(Object.assign({}, e), {
                        issuedAtTimeMillis: r
                    })
                }
                initialize(e) {
                    this._app = e
                }
                isEqual(e) {
                    return e instanceof X && this._customProviderOptions.getToken.toString() === e._customProviderOptions.getToken.toString()
                }
            }

            function U(e, t) {
                if (404 === e || 403 === e) return {
                    backoffCount: 1,
                    allowRequestsAfter: Date.now() + 864e5,
                    httpStatus: e
                }; {
                    let r = t ? t.backoffCount : 0,
                        n = (0, i.$s)(r, 1e3, 2);
                    return {
                        backoffCount: r + 1,
                        allowRequestsAfter: Date.now() + n,
                        httpStatus: e
                    }
                }
            }

            function G(e) {
                if (e && Date.now() - e.allowRequestsAfter <= 0) throw f.create("throttled", {
                    time: w(e.allowRequestsAfter - Date.now()),
                    httpStatus: e.httpStatus
                })
            }
            /**
             * @license
             * Copyright 2020 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */
            function V(e = (0, n.Mq)(), t) {
                e = (0, i.m9)(e);
                let r = (0, n.qX)(e, "app-check");
                if (c.initialized || function() {
                        let e = (0, i.Rd)(),
                            t = c;
                        if (t.initialized = !0, "string" != typeof e.FIREBASE_APPCHECK_DEBUG_TOKEN && !0 !== e.FIREBASE_APPCHECK_DEBUG_TOKEN) return;
                        t.enabled = !0;
                        let r = new i.BH;
                        t.token = r, "string" == typeof e.FIREBASE_APPCHECK_DEBUG_TOKEN ? r.resolve(e.FIREBASE_APPCHECK_DEBUG_TOKEN) : r.resolve(D())
                    }(), c.enabled && S().then(e => console.log(`App Check debug token: ${e}. You will need to add it to your app's App Check settings in the Firebase console for it to work.`)), r.isInitialized()) {
                    let n = r.getImmediate(),
                        o = r.getOptions();
                    if (o.isTokenAutoRefreshEnabled === t.isTokenAutoRefreshEnabled && o.provider.isEqual(t.provider)) return n;
                    throw f.create("already-initialized", {
                        appName: e.name
                    })
                }
                let o = r.initialize({
                    options: t
                });
                return function(e, t, r) {
                    var n;
                    let o = (n = Object.assign({}, l), s.set(e, n), s.get(e));
                    o.activated = !0, o.provider = t, o.cachedTokenPromise = R(e).then(t => (t && z(t) && (o.token = t, B(e, {
                        token: t.token
                    })), t)), o.isTokenAutoRefreshEnabled = void 0 === r ? e.automaticDataCollectionEnabled : r, o.provider.initialize(e)
                }(e, t.provider, t.isTokenAutoRefreshEnabled), h(e).isTokenAutoRefreshEnabled && M(o, "INTERNAL", () => {}), o
            }

            function Y(e, t) {
                let r = e.app,
                    n = h(r);
                n.tokenRefresher && (!0 === t ? n.tokenRefresher.start() : n.tokenRefresher.stop()), n.isTokenAutoRefreshEnabled = t
            }
            async function J(e, t) {
                let r = await O(e, t);
                if (r.error) throw r.error;
                return {
                    token: r.token
                }
            }

            function Q(e, t, r, n) {
                let o = () => {},
                    i = () => {};
                return o = null != t.next ? t.next.bind(t) : t, null != t.error ? i = t.error.bind(t) : r && (i = r), M(e, "EXTERNAL", o, i), () => N(e.app, o)
            }
            let Z = "app-check-internal";
            (0, n.Xd)(new o.wA("app-check", e => {
                let t = e.getProvider("app").getImmediate(),
                    r = e.getProvider("heartbeat");
                return new K(t, r)
            }, "PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e, t, r) => {
                e.getProvider(Z).initialize()
            })), (0, n.Xd)(new o.wA(Z, e => {
                let t = e.getProvider("app-check").getImmediate();
                return {
                    getToken: e => O(t, e),
                    addTokenListener: e => M(t, "INTERNAL", e),
                    removeTokenListener: e => N(t.app, e)
                }
            }, "PUBLIC").setInstantiationMode("EXPLICIT")), (0, n.KN)("@firebase/app-check", "0.6.4")
        }
    }
]);