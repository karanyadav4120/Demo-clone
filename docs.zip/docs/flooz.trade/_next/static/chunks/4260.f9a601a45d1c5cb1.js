"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4260], {
        44260: function(e, t, o) {
            o.r(t), o.d(t, {
                ModalRoot: function() {
                    return v
                }
            });
            var l = o(85893),
                i = o(94184),
                n = o.n(i),
                s = o(11163),
                a = o(67294),
                r = o(70337),
                u = o(79577),
                d = o(27722);
            let c = (0, a.createContext)({
                    isVisible: !0
                }),
                h = c.Provider,
                v = e => {
                    let {
                        modalRoutes: t
                    } = e, {
                        modalHistory: o,
                        modalRoutesHistory: i,
                        rootClassNames: c,
                        setRootClassNames: v
                    } = (0, d.N)(), g = (0, s.useRouter)(), {
                        isMobile: f
                    } = (0, r.Pf)(), [m, p] = (0, a.useState)(), M = (0, a.useMemo)(() => t.reduce((e, t) => e.set(t.route, t), new Map), [t]);
                    (0, a.useEffect)(() => (g.events.on("routeChangeStart", o.close), () => g.events.off("routeChangeStart", o.close)), [g.events, o]), (0, a.useEffect)(() => {
                        let e = () => {
                            if (v(void 0), o.isEmpty) {
                                p(void 0);
                                return
                            }
                            let e = M.get(o.location.route);
                            p(e)
                        };
                        e();
                        let t = o.listen(e);
                        return () => t()
                    }, [o, t, v, M]);
                    let x = {
                        minHeight: !f && (null == m ? void 0 : m.desktopMinHeight) ? m.desktopMinHeight : void 0,
                        maxHeight: !f && (null == m ? void 0 : m.desktopMaxHeight) ? m.desktopMaxHeight : void 0
                    };
                    return (0, l.jsx)(u.u.Container, {
                        isOpen: null != m,
                        onClose: o.close,
                        isMobileMaxHeight: null == m ? void 0 : m.isMobileMaxHeight,
                        className: c,
                        children: i.map((e, t) => {
                            let o = M.get(e.route),
                                s = t === i.length - 1,
                                a = "".concat(null == o ? void 0 : o.route, "-").concat(t);
                            return o ? (0, l.jsx)("div", {
                                className: n()("modal-root__modal", {
                                    "modal-root__modal--visible": s
                                }),
                                style: x,
                                children: (0, l.jsx)(h, {
                                    value: {
                                        isVisible: s
                                    },
                                    children: (0, l.jsx)(o.modal, {
                                        location: e
                                    })
                                })
                            }, a) : null
                        })
                    })
                }
        }
    }
]);