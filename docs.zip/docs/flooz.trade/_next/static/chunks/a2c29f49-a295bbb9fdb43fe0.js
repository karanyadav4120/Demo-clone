(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1028], {
        98234: function(t, e, i) {
            "undefined" != typeof navigator && (t.exports = function() {
                "use strict";
                var t, s, a, r, n, h, o, l, p, f, d = "",
                    m = !1,
                    c = function(t) {
                        d = t
                    },
                    u = function() {
                        return d
                    };

                function g(t) {
                    return document.createElement(t)
                }

                function y(t, e) {
                    var i, s, a = t.length;
                    for (i = 0; i < a; i += 1)
                        for (var r in s = t[i].prototype) Object.prototype.hasOwnProperty.call(s, r) && (e.prototype[r] = s[r])
                }
                var v = function() {
                        function t(t) {
                            this.audios = [], this.audioFactory = t, this._volume = 1, this._isMuted = !1
                        }
                        return t.prototype = {
                                addAudio: function(t) {
                                    this.audios.push(t)
                                },
                                pause: function() {
                                    var t, e = this.audios.length;
                                    for (t = 0; t < e; t += 1) this.audios[t].pause()
                                },
                                resume: function() {
                                    var t, e = this.audios.length;
                                    for (t = 0; t < e; t += 1) this.audios[t].resume()
                                },
                                setRate: function(t) {
                                    var e, i = this.audios.length;
                                    for (e = 0; e < i; e += 1) this.audios[e].setRate(t)
                                },
                                createAudio: function(t) {
                                    return this.audioFactory ? this.audioFactory(t) : window.Howl ? new window.Howl({
                                        src: [t]
                                    }) : {
                                        isPlaying: !1,
                                        play: function() {
                                            this.isPlaying = !0
                                        },
                                        seek: function() {
                                            this.isPlaying = !1
                                        },
                                        playing: function() {},
                                        rate: function() {},
                                        setVolume: function() {}
                                    }
                                },
                                setAudioFactory: function(t) {
                                    this.audioFactory = t
                                },
                                setVolume: function(t) {
                                    this._volume = t, this._updateVolume()
                                },
                                mute: function() {
                                    this._isMuted = !0, this._updateVolume()
                                },
                                unmute: function() {
                                    this._isMuted = !1, this._updateVolume()
                                },
                                getVolume: function() {
                                    return this._volume
                                },
                                _updateVolume: function() {
                                    var t, e = this.audios.length;
                                    for (t = 0; t < e; t += 1) this.audios[t].volume(this._volume * (this._isMuted ? 0 : 1))
                                }
                            },
                            function() {
                                return new t
                            }
                    }(),
                    b = function() {
                        function t(t, e) {
                            var i, s = 0,
                                a = [];
                            switch (t) {
                                case "int16":
                                case "uint8c":
                                    i = 1;
                                    break;
                                default:
                                    i = 1.1
                            }
                            for (s = 0; s < e; s += 1) a.push(i);
                            return a
                        }
                        return "function" == typeof Uint8ClampedArray && "function" == typeof Float32Array ? function(e, i) {
                            return "float32" === e ? new Float32Array(i) : "int16" === e ? new Int16Array(i) : "uint8c" === e ? new Uint8ClampedArray(i) : t(e, i)
                        } : t
                    }();

                function _(t) {
                    return Array.apply(null, {
                        length: t
                    })
                }

                function k(t) {
                    return (k = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    })(t)
                }
                var A = !0,
                    P = null,
                    S = "",
                    x = /^((?!chrome|android).)*safari/i.test(navigator.userAgent),
                    w = Math.pow,
                    D = Math.sqrt,
                    C = Math.floor,
                    M = Math.min,
                    F = {};
                (function() {
                    var t, e = ["abs", "acos", "acosh", "asin", "asinh", "atan", "atanh", "atan2", "ceil", "cbrt", "expm1", "clz32", "cos", "cosh", "exp", "floor", "fround", "hypot", "imul", "log", "log1p", "log2", "log10", "max", "min", "pow", "random", "round", "sign", "sin", "sinh", "sqrt", "tan", "tanh", "trunc", "E", "LN10", "LN2", "LOG10E", "LOG2E", "PI", "SQRT1_2", "SQRT2"],
                        i = e.length;
                    for (t = 0; t < i; t += 1) F[e[t]] = Math[e[t]]
                })(), F.random = Math.random, F.abs = function(t) {
                    if ("object" === k(t) && t.length) {
                        var e, i = _(t.length),
                            s = t.length;
                        for (e = 0; e < s; e += 1) i[e] = Math.abs(t[e]);
                        return i
                    }
                    return Math.abs(t)
                };
                var T = 150,
                    E = Math.PI / 180;

                function I(t, e, i, s) {
                    this.type = t, this.currentTime = e, this.totalTime = i, this.direction = s < 0 ? -1 : 1
                }

                function L(t, e) {
                    this.type = t, this.direction = e < 0 ? -1 : 1
                }

                function V(t, e, i, s) {
                    this.type = t, this.currentLoop = i, this.totalLoops = e, this.direction = s < 0 ? -1 : 1
                }

                function z(t, e, i) {
                    this.type = t, this.firstFrame = e, this.totalFrames = i
                }

                function R(t, e) {
                    this.type = t, this.target = e
                }

                function N(t, e) {
                    this.type = "renderFrameError", this.nativeError = t, this.currentTime = e
                }

                function O(t) {
                    this.type = "configError", this.nativeError = t
                }
                var B = (t = 0, function() {
                    return S + "__lottie_element_" + (t += 1)
                });

                function q(t, e, i) {
                    var s, a, r, n, h, o, l, p;
                    switch (n = Math.floor(6 * t), h = 6 * t - n, o = i * (1 - e), l = i * (1 - h * e), p = i * (1 - (1 - h) * e), n % 6) {
                        case 0:
                            s = i, a = p, r = o;
                            break;
                        case 1:
                            s = l, a = i, r = o;
                            break;
                        case 2:
                            s = o, a = i, r = p;
                            break;
                        case 3:
                            s = o, a = l, r = i;
                            break;
                        case 4:
                            s = p, a = o, r = i;
                            break;
                        case 5:
                            s = i, a = o, r = l
                    }
                    return [s, a, r]
                }

                function j(t, e, i) {
                    var s, a = Math.max(t, e, i),
                        r = Math.min(t, e, i),
                        n = a - r;
                    switch (a) {
                        case r:
                            s = 0;
                            break;
                        case t:
                            s = (e - i + n * (e < i ? 6 : 0)) / (6 * n);
                            break;
                        case e:
                            s = (i - t + 2 * n) / (6 * n);
                            break;
                        case i:
                            s = (t - e + 4 * n) / (6 * n)
                    }
                    return [s, 0 === a ? 0 : n / a, a / 255]
                }

                function W(t, e) {
                    var i = j(255 * t[0], 255 * t[1], 255 * t[2]);
                    return i[1] += e, i[1] > 1 ? i[1] = 1 : i[1] <= 0 && (i[1] = 0), q(i[0], i[1], i[2])
                }

                function X(t, e) {
                    var i = j(255 * t[0], 255 * t[1], 255 * t[2]);
                    return i[2] += e, i[2] > 1 ? i[2] = 1 : i[2] < 0 && (i[2] = 0), q(i[0], i[1], i[2])
                }

                function H(t, e) {
                    var i = j(255 * t[0], 255 * t[1], 255 * t[2]);
                    return i[0] += e / 360, i[0] > 1 ? i[0] -= 1 : i[0] < 0 && (i[0] += 1), q(i[0], i[1], i[2])
                }! function() {
                    var t, e, i = [];
                    for (t = 0; t < 256; t += 1) e = t.toString(16), i[t] = 1 === e.length ? "0" + e : e
                }();
                var Y = function(t) {
                        A = !!t
                    },
                    G = function(t) {
                        P = t
                    },
                    J = function() {
                        return P
                    },
                    K = function() {
                        return null
                    },
                    U = function(t) {
                        T = t
                    },
                    Z = function() {
                        return T
                    },
                    Q = function(t) {
                        S = t
                    };

                function $(t) {
                    return document.createElementNS("http://www.w3.org/2000/svg", t)
                }

                function tt(t) {
                    return (tt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    })(t)
                }
                var te = function() {
                        var t, e, i = 1,
                            s = [],
                            a = {
                                onmessage: function() {},
                                postMessage: function(e) {
                                    t({
                                        data: e
                                    })
                                }
                            },
                            r = {
                                postMessage: function(t) {
                                    a.onmessage({
                                        data: t
                                    })
                                }
                            };

                        function n() {
                            e || ((e = function(e) {
                                if (window.Worker && window.Blob && m) {
                                    var i = new Blob(["var _workerSelf = self; self.onmessage = ", e.toString()], {
                                            type: "text/javascript"
                                        }),
                                        s = URL.createObjectURL(i);
                                    return new Worker(s)
                                }
                                return t = e, a
                            }(function(t) {
                                if (r.dataManager || (r.dataManager = function() {
                                        function t(a, r) {
                                            var n, h, o, l, p, f, d = a.length;
                                            for (h = 0; h < d; h += 1)
                                                if ("ks" in (n = a[h]) && !n.completed) {
                                                    if (n.completed = !0, n.hasMask) {
                                                        var m = n.masksProperties;
                                                        for (o = 0, l = m.length; o < l; o += 1)
                                                            if (m[o].pt.k.i) s(m[o].pt.k);
                                                            else
                                                                for (p = 0, f = m[o].pt.k.length; p < f; p += 1) m[o].pt.k[p].s && s(m[o].pt.k[p].s[0]), m[o].pt.k[p].e && s(m[o].pt.k[p].e[0])
                                                    }
                                                    0 === n.ty ? (n.layers = e(n.refId, r), t(n.layers, r)) : 4 === n.ty ? i(n.shapes) : 5 === n.ty && 0 === n.t.a.length && n.t.p
                                                }
                                        }

                                        function e(t, e) {
                                            var i = function(t, e) {
                                                for (var i = 0, s = e.length; i < s;) {
                                                    if (e[i].id === t) return e[i];
                                                    i += 1
                                                }
                                                return null
                                            }(t, e);
                                            return i ? i.layers.__used ? JSON.parse(JSON.stringify(i.layers)) : (i.layers.__used = !0, i.layers) : null
                                        }

                                        function i(t) {
                                            var e, a, r;
                                            for (e = t.length - 1; e >= 0; e -= 1)
                                                if ("sh" === t[e].ty) {
                                                    if (t[e].ks.k.i) s(t[e].ks.k);
                                                    else
                                                        for (a = 0, r = t[e].ks.k.length; a < r; a += 1) t[e].ks.k[a].s && s(t[e].ks.k[a].s[0]), t[e].ks.k[a].e && s(t[e].ks.k[a].e[0])
                                                } else "gr" === t[e].ty && i(t[e].it)
                                        }

                                        function s(t) {
                                            var e, i = t.i.length;
                                            for (e = 0; e < i; e += 1) t.i[e][0] += t.v[e][0], t.i[e][1] += t.v[e][1], t.o[e][0] += t.v[e][0], t.o[e][1] += t.v[e][1]
                                        }

                                        function a(t, e) {
                                            var i = e ? e.split(".") : [100, 100, 100];
                                            return t[0] > i[0] || !(i[0] > t[0]) && (t[1] > i[1] || !(i[1] > t[1]) && (t[2] > i[2] || !(i[2] > t[2]) && null))
                                        }
                                        var r, n = function() {
                                                var t = [4, 4, 14];

                                                function e(t) {
                                                    var e, i = t.length;
                                                    for (e = 0; e < i; e += 1) 5 === t[e].ty && function(t) {
                                                        var e = t.t.d;
                                                        t.t.d = {
                                                            k: [{
                                                                s: e,
                                                                t: 0
                                                            }]
                                                        }
                                                    }(t[e])
                                                }
                                                return function(i) {
                                                    if (a(t, i.v) && (e(i.layers), i.assets)) {
                                                        var s, r = i.assets.length;
                                                        for (s = 0; s < r; s += 1) i.assets[s].layers && e(i.assets[s].layers)
                                                    }
                                                }
                                            }(),
                                            h = (r = [4, 7, 99], function(t) {
                                                if (t.chars && !a(r, t.v)) {
                                                    var e, s = t.chars.length;
                                                    for (e = 0; e < s; e += 1) {
                                                        var n = t.chars[e];
                                                        n.data && n.data.shapes && (i(n.data.shapes), n.data.ip = 0, n.data.op = 99999, n.data.st = 0, n.data.sr = 1, n.data.ks = {
                                                            p: {
                                                                k: [0, 0],
                                                                a: 0
                                                            },
                                                            s: {
                                                                k: [100, 100],
                                                                a: 0
                                                            },
                                                            a: {
                                                                k: [0, 0],
                                                                a: 0
                                                            },
                                                            r: {
                                                                k: 0,
                                                                a: 0
                                                            },
                                                            o: {
                                                                k: 100,
                                                                a: 0
                                                            }
                                                        }, t.chars[e].t || (n.data.shapes.push({
                                                            ty: "no"
                                                        }), n.data.shapes[0].it.push({
                                                            p: {
                                                                k: [0, 0],
                                                                a: 0
                                                            },
                                                            s: {
                                                                k: [100, 100],
                                                                a: 0
                                                            },
                                                            a: {
                                                                k: [0, 0],
                                                                a: 0
                                                            },
                                                            r: {
                                                                k: 0,
                                                                a: 0
                                                            },
                                                            o: {
                                                                k: 100,
                                                                a: 0
                                                            },
                                                            sk: {
                                                                k: 0,
                                                                a: 0
                                                            },
                                                            sa: {
                                                                k: 0,
                                                                a: 0
                                                            },
                                                            ty: "tr"
                                                        })))
                                                    }
                                                }
                                            }),
                                            o = function() {
                                                var t = [5, 7, 15];

                                                function e(t) {
                                                    var e, i = t.length;
                                                    for (e = 0; e < i; e += 1) 5 === t[e].ty && function(t) {
                                                        var e = t.t.p;
                                                        "number" == typeof e.a && (e.a = {
                                                            a: 0,
                                                            k: e.a
                                                        }), "number" == typeof e.p && (e.p = {
                                                            a: 0,
                                                            k: e.p
                                                        }), "number" == typeof e.r && (e.r = {
                                                            a: 0,
                                                            k: e.r
                                                        })
                                                    }(t[e])
                                                }
                                                return function(i) {
                                                    if (a(t, i.v) && (e(i.layers), i.assets)) {
                                                        var s, r = i.assets.length;
                                                        for (s = 0; s < r; s += 1) i.assets[s].layers && e(i.assets[s].layers)
                                                    }
                                                }
                                            }(),
                                            l = function() {
                                                var t = [4, 1, 9];

                                                function e(t) {
                                                    var e, i = t.length;
                                                    for (e = 0; e < i; e += 1) 4 === t[e].ty && function t(e) {
                                                        var i, s, a, r = e.length;
                                                        for (i = 0; i < r; i += 1)
                                                            if ("gr" === e[i].ty) t(e[i].it);
                                                            else if ("fl" === e[i].ty || "st" === e[i].ty) {
                                                            if (e[i].c.k && e[i].c.k[0].i)
                                                                for (s = 0, a = e[i].c.k.length; s < a; s += 1) e[i].c.k[s].s && (e[i].c.k[s].s[0] /= 255, e[i].c.k[s].s[1] /= 255, e[i].c.k[s].s[2] /= 255, e[i].c.k[s].s[3] /= 255), e[i].c.k[s].e && (e[i].c.k[s].e[0] /= 255, e[i].c.k[s].e[1] /= 255, e[i].c.k[s].e[2] /= 255, e[i].c.k[s].e[3] /= 255);
                                                            else e[i].c.k[0] /= 255, e[i].c.k[1] /= 255, e[i].c.k[2] /= 255, e[i].c.k[3] /= 255
                                                        }
                                                    }(t[e].shapes)
                                                }
                                                return function(i) {
                                                    if (a(t, i.v) && (e(i.layers), i.assets)) {
                                                        var s, r = i.assets.length;
                                                        for (s = 0; s < r; s += 1) i.assets[s].layers && e(i.assets[s].layers)
                                                    }
                                                }
                                            }(),
                                            p = function() {
                                                var t = [4, 4, 18];

                                                function e(t) {
                                                    var e, i, s, a, r, n, h = t.length;
                                                    for (i = 0; i < h; i += 1) {
                                                        if ((e = t[i]).hasMask) {
                                                            var o = e.masksProperties;
                                                            for (s = 0, a = o.length; s < a; s += 1)
                                                                if (o[s].pt.k.i) o[s].pt.k.c = o[s].cl;
                                                                else
                                                                    for (r = 0, n = o[s].pt.k.length; r < n; r += 1) o[s].pt.k[r].s && (o[s].pt.k[r].s[0].c = o[s].cl), o[s].pt.k[r].e && (o[s].pt.k[r].e[0].c = o[s].cl)
                                                        }
                                                        4 === e.ty && function t(e) {
                                                            var i, s, a;
                                                            for (i = e.length - 1; i >= 0; i -= 1)
                                                                if ("sh" === e[i].ty) {
                                                                    if (e[i].ks.k.i) e[i].ks.k.c = e[i].closed;
                                                                    else
                                                                        for (s = 0, a = e[i].ks.k.length; s < a; s += 1) e[i].ks.k[s].s && (e[i].ks.k[s].s[0].c = e[i].closed), e[i].ks.k[s].e && (e[i].ks.k[s].e[0].c = e[i].closed)
                                                                } else "gr" === e[i].ty && t(e[i].it)
                                                        }(e.shapes)
                                                    }
                                                }
                                                return function(i) {
                                                    if (a(t, i.v) && (e(i.layers), i.assets)) {
                                                        var s, r = i.assets.length;
                                                        for (s = 0; s < r; s += 1) i.assets[s].layers && e(i.assets[s].layers)
                                                    }
                                                }
                                            }(),
                                            f = {};
                                        return f.completeData = function(i) {
                                            i.__complete || (l(i), n(i), h(i), o(i), p(i), t(i.layers, i.assets), function(i, s) {
                                                if (i) {
                                                    var a = 0,
                                                        r = i.length;
                                                    for (a = 0; a < r; a += 1) 1 === i[a].t && (i[a].data.layers = e(i[a].data.refId, s), t(i[a].data.layers, s))
                                                }
                                            }(i.chars, i.assets), i.__complete = !0)
                                        }, f.checkColors = l, f.checkChars = h, f.checkPathProperties = o, f.checkShapes = p, f.completeLayers = t, f
                                    }()), r.assetLoader || (r.assetLoader = function() {
                                        function t(t) {
                                            var e = t.getResponseHeader("content-type");
                                            return e && "json" === t.responseType && -1 !== e.indexOf("json") || t.response && "object" === tt(t.response) ? t.response : t.response && "string" == typeof t.response ? JSON.parse(t.response) : t.responseText ? JSON.parse(t.responseText) : null
                                        }
                                        return {
                                            load: function(e, i, s, a) {
                                                var r, n = new XMLHttpRequest;
                                                try {
                                                    n.responseType = "json"
                                                } catch (t) {}
                                                n.onreadystatechange = function() {
                                                    if (4 === n.readyState) {
                                                        if (200 === n.status) s(r = t(n));
                                                        else try {
                                                            r = t(n), s(r)
                                                        } catch (t) {
                                                            a && a(t)
                                                        }
                                                    }
                                                };
                                                try {
                                                    n.open("GET", e, !0)
                                                } catch (t) {
                                                    n.open("GET", i + "/" + e, !0)
                                                }
                                                n.send()
                                            }
                                        }
                                    }()), "loadAnimation" === t.data.type) r.assetLoader.load(t.data.path, t.data.fullPath, function(e) {
                                    r.dataManager.completeData(e), r.postMessage({
                                        id: t.data.id,
                                        payload: e,
                                        status: "success"
                                    })
                                }, function() {
                                    r.postMessage({
                                        id: t.data.id,
                                        status: "error"
                                    })
                                });
                                else if ("complete" === t.data.type) {
                                    var e = t.data.animation;
                                    r.dataManager.completeData(e), r.postMessage({
                                        id: t.data.id,
                                        payload: e,
                                        status: "success"
                                    })
                                } else "loadData" === t.data.type && r.assetLoader.load(t.data.path, t.data.fullPath, function(e) {
                                    r.postMessage({
                                        id: t.data.id,
                                        payload: e,
                                        status: "success"
                                    })
                                }, function() {
                                    r.postMessage({
                                        id: t.data.id,
                                        status: "error"
                                    })
                                })
                            })).onmessage = function(t) {
                                var e = t.data,
                                    i = e.id,
                                    a = s[i];
                                s[i] = null, "success" === e.status ? a.onComplete(e.payload) : a.onError && a.onError()
                            })
                        }

                        function h(t, e) {
                            var a = "processId_" + (i += 1);
                            return s[a] = {
                                onComplete: t,
                                onError: e
                            }, a
                        }
                        return {
                            loadAnimation: function(t, i, s) {
                                n();
                                var a = h(i, s);
                                e.postMessage({
                                    type: "loadAnimation",
                                    path: t,
                                    fullPath: window.location.origin + window.location.pathname,
                                    id: a
                                })
                            },
                            loadData: function(t, i, s) {
                                n();
                                var a = h(i, s);
                                e.postMessage({
                                    type: "loadData",
                                    path: t,
                                    fullPath: window.location.origin + window.location.pathname,
                                    id: a
                                })
                            },
                            completeAnimation: function(t, i, s) {
                                n();
                                var a = h(i, s);
                                e.postMessage({
                                    type: "complete",
                                    animation: t,
                                    id: a
                                })
                            }
                        }
                    }(),
                    ti = function() {
                        var t, e, i = ((t = g("canvas")).width = 1, t.height = 1, (e = t.getContext("2d")).fillStyle = "rgba(0,0,0,0)", e.fillRect(0, 0, 1, 1), t);

                        function s() {
                            this.loadedAssets += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null)
                        }

                        function a() {
                            this.loadedFootagesCount += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null)
                        }

                        function r(t, e, i) {
                            var s = "";
                            if (t.e) s = t.p;
                            else if (e) {
                                var a = t.p; - 1 !== a.indexOf("images/") && (a = a.split("/")[1]), s = e + a
                            } else s = i + (t.u ? t.u : "") + t.p;
                            return s
                        }

                        function n(t) {
                            var e = 0,
                                i = setInterval((function() {
                                    (t.getBBox().width || e > 500) && (this._imageLoaded(), clearInterval(i)), e += 1
                                }).bind(this), 50)
                        }

                        function h(t) {
                            var e = {
                                    assetData: t
                                },
                                i = r(t, this.assetsPath, this.path);
                            return te.loadData(i, (function(t) {
                                e.img = t, this._footageLoaded()
                            }).bind(this), (function() {
                                e.img = {}, this._footageLoaded()
                            }).bind(this)), e
                        }

                        function o() {
                            this._imageLoaded = s.bind(this), this._footageLoaded = a.bind(this), this.testImageLoaded = n.bind(this), this.createFootageData = h.bind(this), this.assetsPath = "", this.path = "", this.totalImages = 0, this.totalFootages = 0, this.loadedAssets = 0, this.loadedFootagesCount = 0, this.imagesLoadedCb = null, this.images = []
                        }
                        return o.prototype = {
                            loadAssets: function(t, e) {
                                this.imagesLoadedCb = e;
                                var i, s = t.length;
                                for (i = 0; i < s; i += 1) t[i].layers || (t[i].t && "seq" !== t[i].t ? 3 === t[i].t && (this.totalFootages += 1, this.images.push(this.createFootageData(t[i]))) : (this.totalImages += 1, this.images.push(this._createImageData(t[i]))))
                            },
                            setAssetsPath: function(t) {
                                this.assetsPath = t || ""
                            },
                            setPath: function(t) {
                                this.path = t || ""
                            },
                            loadedImages: function() {
                                return this.totalImages === this.loadedAssets
                            },
                            loadedFootages: function() {
                                return this.totalFootages === this.loadedFootagesCount
                            },
                            destroy: function() {
                                this.imagesLoadedCb = null, this.images.length = 0
                            },
                            getAsset: function(t) {
                                for (var e = 0, i = this.images.length; e < i;) {
                                    if (this.images[e].assetData === t) return this.images[e].img;
                                    e += 1
                                }
                                return null
                            },
                            createImgData: function(t) {
                                var e = r(t, this.assetsPath, this.path),
                                    s = g("img");
                                s.crossOrigin = "anonymous", s.addEventListener("load", this._imageLoaded, !1), s.addEventListener("error", (function() {
                                    a.img = i, this._imageLoaded()
                                }).bind(this), !1), s.src = e;
                                var a = {
                                    img: s,
                                    assetData: t
                                };
                                return a
                            },
                            createImageData: function(t) {
                                var e = r(t, this.assetsPath, this.path),
                                    s = $("image");
                                x ? this.testImageLoaded(s) : s.addEventListener("load", this._imageLoaded, !1), s.addEventListener("error", (function() {
                                    a.img = i, this._imageLoaded()
                                }).bind(this), !1), s.setAttributeNS("http://www.w3.org/1999/xlink", "href", e), this._elementHelper.append ? this._elementHelper.append(s) : this._elementHelper.appendChild(s);
                                var a = {
                                    img: s,
                                    assetData: t
                                };
                                return a
                            },
                            imageLoaded: s,
                            footageLoaded: a,
                            setCacheType: function(t, e) {
                                "svg" === t ? (this._elementHelper = e, this._createImageData = this.createImageData.bind(this)) : this._createImageData = this.createImgData.bind(this)
                            }
                        }, o
                    }();

                function ts() {}
                ts.prototype = {
                    triggerEvent: function(t, e) {
                        if (this._cbs[t])
                            for (var i = this._cbs[t], s = 0; s < i.length; s += 1) i[s](e)
                    },
                    addEventListener: function(t, e) {
                        return this._cbs[t] || (this._cbs[t] = []), this._cbs[t].push(e), (function() {
                            this.removeEventListener(t, e)
                        }).bind(this)
                    },
                    removeEventListener: function(t, e) {
                        if (e) {
                            if (this._cbs[t]) {
                                for (var i = 0, s = this._cbs[t].length; i < s;) this._cbs[t][i] === e && (this._cbs[t].splice(i, 1), i -= 1, s -= 1), i += 1;
                                this._cbs[t].length || (this._cbs[t] = null)
                            }
                        } else this._cbs[t] = null
                    }
                };
                var ta = function(t) {
                        for (var e = [], i = 0; i < t.length; i += 1) {
                            var s = t[i],
                                a = {
                                    time: s.tm,
                                    duration: s.dr
                                };
                            try {
                                a.payload = JSON.parse(t[i].cm)
                            } catch (e) {
                                try {
                                    a.payload = function(t) {
                                        for (var e, i = t.split("\r\n"), s = {}, a = 0, r = 0; r < i.length; r += 1) 2 === (e = i[r].split(":")).length && (s[e[0]] = e[1].trim(), a += 1);
                                        if (0 === a) throw Error();
                                        return s
                                    }(t[i].cm)
                                } catch (e) {
                                    a.payload = {
                                        name: t[i].cm
                                    }
                                }
                            }
                            e.push(a)
                        }
                        return e
                    },
                    tr = function() {
                        function t(t) {
                            this.compositions.push(t)
                        }
                        return function() {
                            function e(t) {
                                for (var e = 0, i = this.compositions.length; e < i;) {
                                    if (this.compositions[e].data && this.compositions[e].data.nm === t) return this.compositions[e].prepareFrame && this.compositions[e].data.xt && this.compositions[e].prepareFrame(this.currentFrame), this.compositions[e].compInterface;
                                    e += 1
                                }
                                return null
                            }
                            return e.compositions = [], e.currentFrame = 0, e.registerComposition = t, e
                        }
                    }(),
                    tn = {};

                function th(t) {
                    return (th = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    })(t)
                }
                var to = function() {
                    this._cbs = [], this.name = "", this.path = "", this.isLoaded = !1, this.currentFrame = 0, this.currentRawFrame = 0, this.firstFrame = 0, this.totalFrames = 0, this.frameRate = 0, this.frameMult = 0, this.playSpeed = 1, this.playDirection = 1, this.playCount = 0, this.animationData = {}, this.assets = [], this.isPaused = !0, this.autoplay = !1, this.loop = !0, this.renderer = null, this.animationID = B(), this.assetsPath = "", this.timeCompleted = 0, this.segmentPos = 0, this.isSubframeEnabled = A, this.segments = [], this._idle = !0, this._completedLoop = !1, this.projectInterface = tr(), this.imagePreloader = new ti, this.audioController = v(), this.markers = [], this.configAnimation = this.configAnimation.bind(this), this.onSetupError = this.onSetupError.bind(this), this.onSegmentComplete = this.onSegmentComplete.bind(this), this.drawnFrameEvent = new I("drawnFrame", 0, 0, 0)
                };
                y([ts], to), to.prototype.setParams = function(t) {
                    (t.wrapper || t.container) && (this.wrapper = t.wrapper || t.container);
                    var e = "svg";
                    t.animType ? e = t.animType : t.renderer && (e = t.renderer);
                    var i = tn[e];
                    this.renderer = new i(this, t.rendererSettings), this.imagePreloader.setCacheType(e, this.renderer.globalData.defs), this.renderer.setProjectInterface(this.projectInterface), this.animType = e, "" === t.loop || null === t.loop || void 0 === t.loop || !0 === t.loop ? this.loop = !0 : !1 === t.loop ? this.loop = !1 : this.loop = parseInt(t.loop, 10), this.autoplay = !("autoplay" in t) || t.autoplay, this.name = t.name ? t.name : "", this.autoloadSegments = !Object.prototype.hasOwnProperty.call(t, "autoloadSegments") || t.autoloadSegments, this.assetsPath = t.assetsPath, this.initialSegment = t.initialSegment, t.audioFactory && this.audioController.setAudioFactory(t.audioFactory), t.animationData ? this.setupAnimation(t.animationData) : t.path && (-1 !== t.path.lastIndexOf("\\") ? this.path = t.path.substr(0, t.path.lastIndexOf("\\") + 1) : this.path = t.path.substr(0, t.path.lastIndexOf("/") + 1), this.fileName = t.path.substr(t.path.lastIndexOf("/") + 1), this.fileName = this.fileName.substr(0, this.fileName.lastIndexOf(".json")), te.loadAnimation(t.path, this.configAnimation, this.onSetupError))
                }, to.prototype.onSetupError = function() {
                    this.trigger("data_failed")
                }, to.prototype.setupAnimation = function(t) {
                    te.completeAnimation(t, this.configAnimation)
                }, to.prototype.setData = function(t, e) {
                    e && "object" !== th(e) && (e = JSON.parse(e));
                    var i = {
                            wrapper: t,
                            animationData: e
                        },
                        s = t.attributes;
                    i.path = s.getNamedItem("data-animation-path") ? s.getNamedItem("data-animation-path").value : s.getNamedItem("data-bm-path") ? s.getNamedItem("data-bm-path").value : s.getNamedItem("bm-path") ? s.getNamedItem("bm-path").value : "", i.animType = s.getNamedItem("data-anim-type") ? s.getNamedItem("data-anim-type").value : s.getNamedItem("data-bm-type") ? s.getNamedItem("data-bm-type").value : s.getNamedItem("bm-type") ? s.getNamedItem("bm-type").value : s.getNamedItem("data-bm-renderer") ? s.getNamedItem("data-bm-renderer").value : s.getNamedItem("bm-renderer") ? s.getNamedItem("bm-renderer").value : "canvas";
                    var a = s.getNamedItem("data-anim-loop") ? s.getNamedItem("data-anim-loop").value : s.getNamedItem("data-bm-loop") ? s.getNamedItem("data-bm-loop").value : s.getNamedItem("bm-loop") ? s.getNamedItem("bm-loop").value : "";
                    "false" === a ? i.loop = !1 : "true" === a ? i.loop = !0 : "" !== a && (i.loop = parseInt(a, 10));
                    var r = s.getNamedItem("data-anim-autoplay") ? s.getNamedItem("data-anim-autoplay").value : s.getNamedItem("data-bm-autoplay") ? s.getNamedItem("data-bm-autoplay").value : !s.getNamedItem("bm-autoplay") || s.getNamedItem("bm-autoplay").value;
                    i.autoplay = "false" !== r, i.name = s.getNamedItem("data-name") ? s.getNamedItem("data-name").value : s.getNamedItem("data-bm-name") ? s.getNamedItem("data-bm-name").value : s.getNamedItem("bm-name") ? s.getNamedItem("bm-name").value : "", "false" === (s.getNamedItem("data-anim-prerender") ? s.getNamedItem("data-anim-prerender").value : s.getNamedItem("data-bm-prerender") ? s.getNamedItem("data-bm-prerender").value : s.getNamedItem("bm-prerender") ? s.getNamedItem("bm-prerender").value : "") && (i.prerender = !1), this.setParams(i)
                }, to.prototype.includeLayers = function(t) {
                    t.op > this.animationData.op && (this.animationData.op = t.op, this.totalFrames = Math.floor(t.op - this.animationData.ip));
                    var e, i, s = this.animationData.layers,
                        a = s.length,
                        r = t.layers,
                        n = r.length;
                    for (i = 0; i < n; i += 1)
                        for (e = 0; e < a;) {
                            if (s[e].id === r[i].id) {
                                s[e] = r[i];
                                break
                            }
                            e += 1
                        }
                    if ((t.chars || t.fonts) && (this.renderer.globalData.fontManager.addChars(t.chars), this.renderer.globalData.fontManager.addFonts(t.fonts, this.renderer.globalData.defs)), t.assets)
                        for (e = 0, a = t.assets.length; e < a; e += 1) this.animationData.assets.push(t.assets[e]);
                    this.animationData.__complete = !1, te.completeAnimation(this.animationData, this.onSegmentComplete)
                }, to.prototype.onSegmentComplete = function(t) {
                    this.animationData = t;
                    var e = J();
                    e && e.initExpressions(this), this.loadNextSegment()
                }, to.prototype.loadNextSegment = function() {
                    var t = this.animationData.segments;
                    if (!t || 0 === t.length || !this.autoloadSegments) {
                        this.trigger("data_ready"), this.timeCompleted = this.totalFrames;
                        return
                    }
                    var e = t.shift();
                    this.timeCompleted = e.time * this.frameRate;
                    var i = this.path + this.fileName + "_" + this.segmentPos + ".json";
                    this.segmentPos += 1, te.loadData(i, this.includeLayers.bind(this), (function() {
                        this.trigger("data_failed")
                    }).bind(this))
                }, to.prototype.loadSegments = function() {
                    this.animationData.segments || (this.timeCompleted = this.totalFrames), this.loadNextSegment()
                }, to.prototype.imagesLoaded = function() {
                    this.trigger("loaded_images"), this.checkLoaded()
                }, to.prototype.preloadImages = function() {
                    this.imagePreloader.setAssetsPath(this.assetsPath), this.imagePreloader.setPath(this.path), this.imagePreloader.loadAssets(this.animationData.assets, this.imagesLoaded.bind(this))
                }, to.prototype.configAnimation = function(t) {
                    if (this.renderer) try {
                        this.animationData = t, this.initialSegment ? (this.totalFrames = Math.floor(this.initialSegment[1] - this.initialSegment[0]), this.firstFrame = Math.round(this.initialSegment[0])) : (this.totalFrames = Math.floor(this.animationData.op - this.animationData.ip), this.firstFrame = Math.round(this.animationData.ip)), this.renderer.configAnimation(t), t.assets || (t.assets = []), this.assets = this.animationData.assets, this.frameRate = this.animationData.fr, this.frameMult = this.animationData.fr / 1e3, this.renderer.searchExtraCompositions(t.assets), this.markers = ta(t.markers || []), this.trigger("config_ready"), this.preloadImages(), this.loadSegments(), this.updaFrameModifier(), this.waitForFontsLoaded(), this.isPaused && this.audioController.pause()
                    } catch (t) {
                        this.triggerConfigError(t)
                    }
                }, to.prototype.waitForFontsLoaded = function() {
                    this.renderer && (this.renderer.globalData.fontManager.isLoaded ? this.checkLoaded() : setTimeout(this.waitForFontsLoaded.bind(this), 20))
                }, to.prototype.checkLoaded = function() {
                    if (!this.isLoaded && this.renderer.globalData.fontManager.isLoaded && (this.imagePreloader.loadedImages() || "canvas" !== this.renderer.rendererType) && this.imagePreloader.loadedFootages()) {
                        this.isLoaded = !0;
                        var t = J();
                        t && t.initExpressions(this), this.renderer.initItems(), setTimeout((function() {
                            this.trigger("DOMLoaded")
                        }).bind(this), 0), this.gotoFrame(), this.autoplay && this.play()
                    }
                }, to.prototype.resize = function(t, e) {
                    this.renderer.updateContainerSize("number" == typeof t ? t : void 0, "number" == typeof e ? e : void 0)
                }, to.prototype.setSubframe = function(t) {
                    this.isSubframeEnabled = !!t
                }, to.prototype.gotoFrame = function() {
                    this.currentFrame = this.isSubframeEnabled ? this.currentRawFrame : ~~this.currentRawFrame, this.timeCompleted !== this.totalFrames && this.currentFrame > this.timeCompleted && (this.currentFrame = this.timeCompleted), this.trigger("enterFrame"), this.renderFrame(), this.trigger("drawnFrame")
                }, to.prototype.renderFrame = function() {
                    if (!1 !== this.isLoaded && this.renderer) try {
                        this.renderer.renderFrame(this.currentFrame + this.firstFrame)
                    } catch (t) {
                        this.triggerRenderFrameError(t)
                    }
                }, to.prototype.play = function(t) {
                    (!t || this.name === t) && !0 === this.isPaused && (this.isPaused = !1, this.trigger("_pause"), this.audioController.resume(), this._idle && (this._idle = !1, this.trigger("_active")))
                }, to.prototype.pause = function(t) {
                    t && this.name !== t || !1 !== this.isPaused || (this.isPaused = !0, this.trigger("_play"), this._idle = !0, this.trigger("_idle"), this.audioController.pause())
                }, to.prototype.togglePause = function(t) {
                    t && this.name !== t || (!0 === this.isPaused ? this.play() : this.pause())
                }, to.prototype.stop = function(t) {
                    t && this.name !== t || (this.pause(), this.playCount = 0, this._completedLoop = !1, this.setCurrentRawFrameValue(0))
                }, to.prototype.getMarkerData = function(t) {
                    for (var e, i = 0; i < this.markers.length; i += 1)
                        if ((e = this.markers[i]).payload && e.payload.name === t) return e;
                    return null
                }, to.prototype.goToAndStop = function(t, e, i) {
                    if (!i || this.name === i) {
                        if (isNaN(Number(t))) {
                            var s = this.getMarkerData(t);
                            s && this.goToAndStop(s.time, !0)
                        } else e ? this.setCurrentRawFrameValue(t) : this.setCurrentRawFrameValue(t * this.frameModifier);
                        this.pause()
                    }
                }, to.prototype.goToAndPlay = function(t, e, i) {
                    if (!i || this.name === i) {
                        var s = Number(t);
                        if (isNaN(s)) {
                            var a = this.getMarkerData(t);
                            a && (a.duration ? this.playSegments([a.time, a.time + a.duration], !0) : this.goToAndStop(a.time, !0))
                        } else this.goToAndStop(s, e, i);
                        this.play()
                    }
                }, to.prototype.advanceTime = function(t) {
                    if (!0 !== this.isPaused && !1 !== this.isLoaded) {
                        var e = this.currentRawFrame + t * this.frameModifier,
                            i = !1;
                        e >= this.totalFrames - 1 && this.frameModifier > 0 ? this.loop && this.playCount !== this.loop ? e >= this.totalFrames ? (this.playCount += 1, this.checkSegments(e % this.totalFrames) || (this.setCurrentRawFrameValue(e % this.totalFrames), this._completedLoop = !0, this.trigger("loopComplete"))) : this.setCurrentRawFrameValue(e) : this.checkSegments(e > this.totalFrames ? e % this.totalFrames : 0) || (i = !0, e = this.totalFrames - 1) : e < 0 ? this.checkSegments(e % this.totalFrames) || (this.loop && !(this.playCount-- <= 0 && !0 !== this.loop) ? (this.setCurrentRawFrameValue(this.totalFrames + e % this.totalFrames), this._completedLoop ? this.trigger("loopComplete") : this._completedLoop = !0) : (i = !0, e = 0)) : this.setCurrentRawFrameValue(e), i && (this.setCurrentRawFrameValue(e), this.pause(), this.trigger("complete"))
                    }
                }, to.prototype.adjustSegment = function(t, e) {
                    this.playCount = 0, t[1] < t[0] ? (this.frameModifier > 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(-1)), this.totalFrames = t[0] - t[1], this.timeCompleted = this.totalFrames, this.firstFrame = t[1], this.setCurrentRawFrameValue(this.totalFrames - .001 - e)) : t[1] > t[0] && (this.frameModifier < 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(1)), this.totalFrames = t[1] - t[0], this.timeCompleted = this.totalFrames, this.firstFrame = t[0], this.setCurrentRawFrameValue(.001 + e)), this.trigger("segmentStart")
                }, to.prototype.setSegment = function(t, e) {
                    var i = -1;
                    this.isPaused && (this.currentRawFrame + this.firstFrame < t ? i = t : this.currentRawFrame + this.firstFrame > e && (i = e - t)), this.firstFrame = t, this.totalFrames = e - t, this.timeCompleted = this.totalFrames, -1 !== i && this.goToAndStop(i, !0)
                }, to.prototype.playSegments = function(t, e) {
                    if (e && (this.segments.length = 0), "object" === th(t[0])) {
                        var i, s = t.length;
                        for (i = 0; i < s; i += 1) this.segments.push(t[i])
                    } else this.segments.push(t);
                    this.segments.length && e && this.adjustSegment(this.segments.shift(), 0), this.isPaused && this.play()
                }, to.prototype.resetSegments = function(t) {
                    this.segments.length = 0, this.segments.push([this.animationData.ip, this.animationData.op]), t && this.checkSegments(0)
                }, to.prototype.checkSegments = function(t) {
                    return !!this.segments.length && (this.adjustSegment(this.segments.shift(), t), !0)
                }, to.prototype.destroy = function(t) {
                    (!t || this.name === t) && this.renderer && (this.renderer.destroy(), this.imagePreloader.destroy(), this.trigger("destroy"), this._cbs = null, this.onEnterFrame = null, this.onLoopComplete = null, this.onComplete = null, this.onSegmentStart = null, this.onDestroy = null, this.renderer = null, this.renderer = null, this.imagePreloader = null, this.projectInterface = null)
                }, to.prototype.setCurrentRawFrameValue = function(t) {
                    this.currentRawFrame = t, this.gotoFrame()
                }, to.prototype.setSpeed = function(t) {
                    this.playSpeed = t, this.updaFrameModifier()
                }, to.prototype.setDirection = function(t) {
                    this.playDirection = t < 0 ? -1 : 1, this.updaFrameModifier()
                }, to.prototype.setLoop = function(t) {
                    this.loop = t
                }, to.prototype.setVolume = function(t, e) {
                    e && this.name !== e || this.audioController.setVolume(t)
                }, to.prototype.getVolume = function() {
                    return this.audioController.getVolume()
                }, to.prototype.mute = function(t) {
                    t && this.name !== t || this.audioController.mute()
                }, to.prototype.unmute = function(t) {
                    t && this.name !== t || this.audioController.unmute()
                }, to.prototype.updaFrameModifier = function() {
                    this.frameModifier = this.frameMult * this.playSpeed * this.playDirection, this.audioController.setRate(this.playSpeed * this.playDirection)
                }, to.prototype.getPath = function() {
                    return this.path
                }, to.prototype.getAssetsPath = function(t) {
                    var e = "";
                    if (t.e) e = t.p;
                    else if (this.assetsPath) {
                        var i = t.p; - 1 !== i.indexOf("images/") && (i = i.split("/")[1]), e = this.assetsPath + i
                    } else e = this.path + (t.u ? t.u : "") + t.p;
                    return e
                }, to.prototype.getAssetData = function(t) {
                    for (var e = 0, i = this.assets.length; e < i;) {
                        if (t === this.assets[e].id) return this.assets[e];
                        e += 1
                    }
                    return null
                }, to.prototype.hide = function() {
                    this.renderer.hide()
                }, to.prototype.show = function() {
                    this.renderer.show()
                }, to.prototype.getDuration = function(t) {
                    return t ? this.totalFrames : this.totalFrames / this.frameRate
                }, to.prototype.updateDocumentData = function(t, e, i) {
                    try {
                        this.renderer.getElementByPath(t).updateDocumentData(e, i)
                    } catch (t) {}
                }, to.prototype.trigger = function(t) {
                    if (this._cbs && this._cbs[t]) switch (t) {
                        case "enterFrame":
                            this.triggerEvent(t, new I(t, this.currentFrame, this.totalFrames, this.frameModifier));
                            break;
                        case "drawnFrame":
                            this.drawnFrameEvent.currentTime = this.currentFrame, this.drawnFrameEvent.totalTime = this.totalFrames, this.drawnFrameEvent.direction = this.frameModifier, this.triggerEvent(t, this.drawnFrameEvent);
                            break;
                        case "loopComplete":
                            this.triggerEvent(t, new V(t, this.loop, this.playCount, this.frameMult));
                            break;
                        case "complete":
                            this.triggerEvent(t, new L(t, this.frameMult));
                            break;
                        case "segmentStart":
                            this.triggerEvent(t, new z(t, this.firstFrame, this.totalFrames));
                            break;
                        case "destroy":
                            this.triggerEvent(t, new R(t, this));
                            break;
                        default:
                            this.triggerEvent(t)
                    }
                    "enterFrame" === t && this.onEnterFrame && this.onEnterFrame.call(this, new I(t, this.currentFrame, this.totalFrames, this.frameMult)), "loopComplete" === t && this.onLoopComplete && this.onLoopComplete.call(this, new V(t, this.loop, this.playCount, this.frameMult)), "complete" === t && this.onComplete && this.onComplete.call(this, new L(t, this.frameMult)), "segmentStart" === t && this.onSegmentStart && this.onSegmentStart.call(this, new z(t, this.firstFrame, this.totalFrames)), "destroy" === t && this.onDestroy && this.onDestroy.call(this, new R(t, this))
                }, to.prototype.triggerRenderFrameError = function(t) {
                    var e = new N(t, this.currentFrame);
                    this.triggerEvent("error", e), this.onError && this.onError.call(this, e)
                }, to.prototype.triggerConfigError = function(t) {
                    var e = new O(t, this.currentFrame);
                    this.triggerEvent("error", e), this.onError && this.onError.call(this, e)
                };
                var tl = function() {
                        var t = {},
                            e = [],
                            i = 0,
                            s = 0,
                            a = 0,
                            r = !0,
                            n = !1;

                        function h(t) {
                            for (var i = 0, a = t.target; i < s;) e[i].animation !== a || (e.splice(i, 1), i -= 1, s -= 1, a.isPaused || p()), i += 1
                        }

                        function o(t, i) {
                            if (!t) return null;
                            for (var a = 0; a < s;) {
                                if (e[a].elem === t && null !== e[a].elem) return e[a].animation;
                                a += 1
                            }
                            var r = new to;
                            return f(r, t), r.setData(t, i), r
                        }

                        function l() {
                            a += 1, c()
                        }

                        function p() {
                            a -= 1
                        }

                        function f(t, i) {
                            t.addEventListener("destroy", h), t.addEventListener("_active", l), t.addEventListener("_idle", p), e.push({
                                elem: i,
                                animation: t
                            }), s += 1
                        }

                        function d(t) {
                            var h, o = t - i;
                            for (h = 0; h < s; h += 1) e[h].animation.advanceTime(o);
                            i = t, a && !n ? window.requestAnimationFrame(d) : r = !0
                        }

                        function m(t) {
                            i = t, window.requestAnimationFrame(d)
                        }

                        function c() {
                            !n && a && r && (window.requestAnimationFrame(m), r = !1)
                        }
                        return t.registerAnimation = o, t.loadAnimation = function(t) {
                            var e = new to;
                            return f(e, null), e.setParams(t), e
                        }, t.setSpeed = function(t, i) {
                            var a;
                            for (a = 0; a < s; a += 1) e[a].animation.setSpeed(t, i)
                        }, t.setDirection = function(t, i) {
                            var a;
                            for (a = 0; a < s; a += 1) e[a].animation.setDirection(t, i)
                        }, t.play = function(t) {
                            var i;
                            for (i = 0; i < s; i += 1) e[i].animation.play(t)
                        }, t.pause = function(t) {
                            var i;
                            for (i = 0; i < s; i += 1) e[i].animation.pause(t)
                        }, t.stop = function(t) {
                            var i;
                            for (i = 0; i < s; i += 1) e[i].animation.stop(t)
                        }, t.togglePause = function(t) {
                            var i;
                            for (i = 0; i < s; i += 1) e[i].animation.togglePause(t)
                        }, t.searchAnimations = function(t, e, i) {
                            var s, a = [].concat([].slice.call(document.getElementsByClassName("lottie")), [].slice.call(document.getElementsByClassName("bodymovin"))),
                                r = a.length;
                            for (s = 0; s < r; s += 1) i && a[s].setAttribute("data-bm-type", i), o(a[s], t);
                            if (e && 0 === r) {
                                i || (i = "svg");
                                var n = document.getElementsByTagName("body")[0];
                                n.innerText = "";
                                var h = g("div");
                                h.style.width = "100%", h.style.height = "100%", h.setAttribute("data-bm-type", i), n.appendChild(h), o(h, t)
                            }
                        }, t.resize = function() {
                            var t;
                            for (t = 0; t < s; t += 1) e[t].animation.resize()
                        }, t.goToAndStop = function(t, i, a) {
                            var r;
                            for (r = 0; r < s; r += 1) e[r].animation.goToAndStop(t, i, a)
                        }, t.destroy = function(t) {
                            var i;
                            for (i = s - 1; i >= 0; i -= 1) e[i].animation.destroy(t)
                        }, t.freeze = function() {
                            n = !0
                        }, t.unfreeze = function() {
                            n = !1, c()
                        }, t.setVolume = function(t, i) {
                            var a;
                            for (a = 0; a < s; a += 1) e[a].animation.setVolume(t, i)
                        }, t.mute = function(t) {
                            var i;
                            for (i = 0; i < s; i += 1) e[i].animation.mute(t)
                        }, t.unmute = function(t) {
                            var i;
                            for (i = 0; i < s; i += 1) e[i].animation.unmute(t)
                        }, t.getRegisteredAnimations = function() {
                            var t, i = e.length,
                                s = [];
                            for (t = 0; t < i; t += 1) s.push(e[t].animation);
                            return s
                        }, t
                    }(),
                    tp = function() {
                        var t = {};
                        t.getBezierEasing = function(t, i, s, a, n) {
                            var h = n || ("bez_" + t + "_" + i + "_" + s + "_" + a).replace(/\./g, "p");
                            if (e[h]) return e[h];
                            var o = new r([t, i, s, a]);
                            return e[h] = o, o
                        };
                        var e = {},
                            i = "function" == typeof Float32Array;

                        function s(t, e, i) {
                            return (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t
                        }

                        function a(t, e, i) {
                            return 3 * (1 - 3 * i + 3 * e) * t * t + 2 * (3 * i - 6 * e) * t + 3 * e
                        }

                        function r(t) {
                            this._p = t, this._mSampleValues = i ? new Float32Array(11) : Array(11), this._precomputed = !1, this.get = this.get.bind(this)
                        }
                        return r.prototype = {
                            get: function(t) {
                                var e = this._p[0],
                                    i = this._p[1],
                                    a = this._p[2],
                                    r = this._p[3];
                                return (this._precomputed || this._precompute(), e === i && a === r) ? t : 0 === t ? 0 : 1 === t ? 1 : s(this._getTForX(t), i, r)
                            },
                            _precompute: function() {
                                var t = this._p[0],
                                    e = this._p[1],
                                    i = this._p[2],
                                    s = this._p[3];
                                this._precomputed = !0, (t !== e || i !== s) && this._calcSampleValues()
                            },
                            _calcSampleValues: function() {
                                for (var t = this._p[0], e = this._p[2], i = 0; i < 11; ++i) this._mSampleValues[i] = s(.1 * i, t, e)
                            },
                            _getTForX: function(t) {
                                for (var e = this._p[0], i = this._p[2], r = this._mSampleValues, n = 0, h = 1; 10 !== h && r[h] <= t; ++h) n += .1;
                                var o = n + (t - r[--h]) / (r[h + 1] - r[h]) * .1,
                                    l = a(o, e, i);
                                return l >= .001 ? function(t, e, i, r) {
                                    for (var n = 0; n < 4; ++n) {
                                        var h = a(e, i, r);
                                        if (0 === h) break;
                                        var o = s(e, i, r) - t;
                                        e -= o / h
                                    }
                                    return e
                                }(t, o, e, i) : 0 === l ? o : function(t, e, i, a, r) {
                                    var n, h, o = 0;
                                    do(n = s(h = e + (i - e) / 2, a, r) - t) > 0 ? i = h : e = h; while (Math.abs(n) > 1e-7 && ++o < 10);
                                    return h
                                }(t, n, n + .1, e, i)
                            }
                        }, t
                    }(),
                    tf = {
                        double: function(t) {
                            return t.concat(_(t.length))
                        }
                    },
                    td = function(t, e, i) {
                        var s = 0,
                            a = t,
                            r = _(a);
                        return {
                            newElement: function() {
                                var t;
                                return s ? (s -= 1, t = r[s]) : t = e(), t
                            },
                            release: function(t) {
                                s === a && (r = tf.double(r), a *= 2), i && i(t), r[s] = t, s += 1
                            }
                        }
                    },
                    tm = td(8, function() {
                        return {
                            addedLength: 0,
                            percents: b("float32", Z()),
                            lengths: b("float32", Z())
                        }
                    }),
                    tc = td(8, function() {
                        return {
                            lengths: [],
                            totalLength: 0
                        }
                    }, function(t) {
                        var e, i = t.lengths.length;
                        for (e = 0; e < i; e += 1) tm.release(t.lengths[e]);
                        t.lengths.length = 0
                    }),
                    tu = function() {
                        var t, e = Math;

                        function i(t, e, i, s, a, r) {
                            var n = t * s + e * a + i * r - a * s - r * t - i * e;
                            return n > -.001 && n < .001
                        }
                        var s = function(t, e, i, s) {
                            var a, r, n, h, o, l, p = Z(),
                                f = 0,
                                d = [],
                                m = [],
                                c = tm.newElement();
                            for (a = 0, n = i.length; a < p; a += 1) {
                                for (r = 0, o = a / (p - 1), l = 0; r < n; r += 1) h = w(1 - o, 3) * t[r] + 3 * w(1 - o, 2) * o * i[r] + 3 * (1 - o) * w(o, 2) * s[r] + w(o, 3) * e[r], d[r] = h, null !== m[r] && (l += w(d[r] - m[r], 2)), m[r] = d[r];
                                l && (f += l = D(l)), c.percents[a] = o, c.lengths[a] = f
                            }
                            return c.addedLength = f, c
                        };

                        function a(t) {
                            this.segmentLength = 0, this.points = Array(t)
                        }

                        function r(t, e) {
                            this.partialLength = t, this.point = e
                        }
                        var n = (t = {}, function(e, s, n, h) {
                            var o = (e[0] + "_" + e[1] + "_" + s[0] + "_" + s[1] + "_" + n[0] + "_" + n[1] + "_" + h[0] + "_" + h[1]).replace(/\./g, "p");
                            if (!t[o]) {
                                var l, p, f, d, m, c, u, g = Z(),
                                    y = 0,
                                    v = null;
                                2 === e.length && (e[0] !== s[0] || e[1] !== s[1]) && i(e[0], e[1], s[0], s[1], e[0] + n[0], e[1] + n[1]) && i(e[0], e[1], s[0], s[1], s[0] + h[0], s[1] + h[1]) && (g = 2);
                                var b = new a(g);
                                for (l = 0, f = n.length; l < g; l += 1) {
                                    for (p = 0, u = _(f), m = l / (g - 1), c = 0; p < f; p += 1) d = w(1 - m, 3) * e[p] + 3 * w(1 - m, 2) * m * (e[p] + n[p]) + 3 * (1 - m) * w(m, 2) * (s[p] + h[p]) + w(m, 3) * s[p], u[p] = d, null !== v && (c += w(u[p] - v[p], 2));
                                    y += c = D(c), b.points[l] = new r(c, u), v = u
                                }
                                b.segmentLength = y, t[o] = b
                            }
                            return t[o]
                        });

                        function h(t, e) {
                            var i = e.percents,
                                s = e.lengths,
                                a = i.length,
                                r = C((a - 1) * t),
                                n = t * e.addedLength,
                                h = 0;
                            if (r === a - 1 || 0 === r || n === s[r]) return i[r];
                            for (var o = s[r] > n ? -1 : 1, l = !0; l;)
                                if (s[r] <= n && s[r + 1] > n ? (h = (n - s[r]) / (s[r + 1] - s[r]), l = !1) : r += o, r < 0 || r >= a - 1) {
                                    if (r === a - 1) return i[r];
                                    l = !1
                                }
                            return i[r] + (i[r + 1] - i[r]) * h
                        }
                        var o = b("float32", 8);
                        return {
                            getSegmentsLength: function(t) {
                                var e, i = tc.newElement(),
                                    a = t.c,
                                    r = t.v,
                                    n = t.o,
                                    h = t.i,
                                    o = t._length,
                                    l = i.lengths,
                                    p = 0;
                                for (e = 0; e < o - 1; e += 1) l[e] = s(r[e], r[e + 1], n[e], h[e + 1]), p += l[e].addedLength;
                                return a && o && (l[e] = s(r[e], r[0], n[e], h[0]), p += l[e].addedLength), i.totalLength = p, i
                            },
                            getNewSegment: function(t, i, s, a, r, n, l) {
                                r < 0 ? r = 0 : r > 1 && (r = 1);
                                var p, f = h(r, l),
                                    d = h(n = n > 1 ? 1 : n, l),
                                    m = t.length,
                                    c = 1 - f,
                                    u = 1 - d,
                                    g = c * c * c,
                                    y = f * c * c * 3,
                                    v = f * f * c * 3,
                                    b = f * f * f,
                                    _ = c * c * u,
                                    k = f * c * u + c * f * u + c * c * d,
                                    A = f * f * u + c * f * d + f * c * d,
                                    P = f * f * d,
                                    S = c * u * u,
                                    x = f * u * u + c * d * u + c * u * d,
                                    w = f * d * u + c * d * d + f * u * d,
                                    D = f * d * d,
                                    C = u * u * u,
                                    M = d * u * u + u * d * u + u * u * d,
                                    F = d * d * u + u * d * d + d * u * d,
                                    T = d * d * d;
                                for (p = 0; p < m; p += 1) o[4 * p] = e.round((g * t[p] + y * s[p] + v * a[p] + b * i[p]) * 1e3) / 1e3, o[4 * p + 1] = e.round((_ * t[p] + k * s[p] + A * a[p] + P * i[p]) * 1e3) / 1e3, o[4 * p + 2] = e.round((S * t[p] + x * s[p] + w * a[p] + D * i[p]) * 1e3) / 1e3, o[4 * p + 3] = e.round((C * t[p] + M * s[p] + F * a[p] + T * i[p]) * 1e3) / 1e3;
                                return o
                            },
                            getPointInSegment: function(t, i, s, a, r, n) {
                                var o = h(r, n),
                                    l = 1 - o;
                                return [e.round((l * l * l * t[0] + (o * l * l + l * o * l + l * l * o) * s[0] + (o * o * l + l * o * o + o * l * o) * a[0] + o * o * o * i[0]) * 1e3) / 1e3, e.round((l * l * l * t[1] + (o * l * l + l * o * l + l * l * o) * s[1] + (o * o * l + l * o * o + o * l * o) * a[1] + o * o * o * i[1]) * 1e3) / 1e3]
                            },
                            buildBezierData: n,
                            pointOnLine2D: i,
                            pointOnLine3D: function(t, s, a, r, n, h, o, l, p) {
                                if (0 === a && 0 === h && 0 === p) return i(t, s, r, n, o, l);
                                var f, d = e.sqrt(e.pow(r - t, 2) + e.pow(n - s, 2) + e.pow(h - a, 2)),
                                    m = e.sqrt(e.pow(o - t, 2) + e.pow(l - s, 2) + e.pow(p - a, 2)),
                                    c = e.sqrt(e.pow(o - r, 2) + e.pow(l - n, 2) + e.pow(p - h, 2));
                                return (f = d > m ? d > c ? d - m - c : c - m - d : c > m ? c - m - d : m - d - c) > -.0001 && f < 1e-4
                            }
                        }
                    }(),
                    tg = function() {
                        var t = Math.abs;

                        function e(t, e) {
                            var s = this.offsetTime;
                            "multidimensional" === this.propType && (d = b("float32", this.pv.length));
                            for (var a = e.lastIndex, r = a, n = this.keyframes.length - 1, h = !0; h;) {
                                if (m = this.keyframes[r], c = this.keyframes[r + 1], r === n - 1 && t >= c.t - s) {
                                    m.h && (m = c), a = 0;
                                    break
                                }
                                if (c.t - s > t) {
                                    a = r;
                                    break
                                }
                                r < n - 1 ? r += 1 : (a = 0, h = !1)
                            }
                            u = this.keyframesMetadata[r] || {};
                            var o = c.t - s,
                                l = m.t - s;
                            if (m.to) {
                                u.bezierData || (u.bezierData = tu.buildBezierData(m.s, c.s || m.e, m.to, m.ti));
                                var p = u.bezierData;
                                if (t >= o || t < l) {
                                    var f = t >= o ? p.points.length - 1 : 0;
                                    for (g = 0, y = p.points[f].point.length; g < y; g += 1) d[g] = p.points[f].point[g]
                                } else {
                                    u.__fnct ? A = u.__fnct : (A = tp.getBezierEasing(m.o.x, m.o.y, m.i.x, m.i.y, m.n).get, u.__fnct = A), v = A((t - l) / (o - l));
                                    var d, m, c, u, g, y, v, _, k, A, P, S, x = p.segmentLength * v,
                                        w = e.lastFrame < t && e._lastKeyframeIndex === r ? e._lastAddedLength : 0;
                                    for (k = e.lastFrame < t && e._lastKeyframeIndex === r ? e._lastPoint : 0, h = !0, _ = p.points.length; h;) {
                                        if (w += p.points[k].partialLength, 0 === x || 0 === v || k === p.points.length - 1) {
                                            for (g = 0, y = p.points[k].point.length; g < y; g += 1) d[g] = p.points[k].point[g];
                                            break
                                        }
                                        if (x >= w && x < w + p.points[k + 1].partialLength) {
                                            for (g = 0, S = (x - w) / p.points[k + 1].partialLength, y = p.points[k].point.length; g < y; g += 1) d[g] = p.points[k].point[g] + (p.points[k + 1].point[g] - p.points[k].point[g]) * S;
                                            break
                                        }
                                        k < _ - 1 ? k += 1 : h = !1
                                    }
                                    e._lastPoint = k, e._lastAddedLength = w - p.points[k].partialLength, e._lastKeyframeIndex = r
                                }
                            } else if (n = m.s.length, P = c.s || m.e, this.sh && 1 !== m.h) {
                                if (t >= o) d[0] = P[0], d[1] = P[1], d[2] = P[2];
                                else if (t <= l) d[0] = m.s[0], d[1] = m.s[1], d[2] = m.s[2];
                                else {
                                    var D, C, M, F, T, I, L, V, z, R, N, O, B, q, j, W, X, H, Y, G, J, K, U, Z, Q, $, tt = i(m.s),
                                        te = i(P);
                                    W = d, H = (D = (t - l) / (o - l), L = [], V = tt[0], z = tt[1], R = tt[2], N = tt[3], O = te[0], B = te[1], (M = V * O + z * B + R * (q = te[2]) + N * (j = te[3])) < 0 && (M = -M, O = -O, B = -B, q = -q, j = -j), 1 - M > 1e-6 ? (F = Math.sin(C = Math.acos(M)), T = Math.sin((1 - D) * C) / F, I = Math.sin(D * C) / F) : (T = 1 - D, I = D), L[0] = T * V + I * O, L[1] = T * z + I * B, L[2] = T * R + I * q, L[3] = T * N + I * j, X = L)[0], Y = X[1], G = X[2], J = X[3], W[0] = Math.atan2(2 * Y * J - 2 * H * G, 1 - 2 * Y * Y - 2 * G * G) / E, W[1] = Math.asin(2 * H * Y + 2 * G * J) / E, W[2] = Math.atan2(2 * H * J - 2 * Y * G, 1 - 2 * H * H - 2 * G * G) / E
                                }
                            } else
                                for (r = 0; r < n; r += 1) 1 !== m.h && (t >= o ? v = 1 : t < l ? v = 0 : (m.o.x.constructor === Array ? (u.__fnct || (u.__fnct = []), u.__fnct[r] ? A = u.__fnct[r] : (K = void 0 === m.o.x[r] ? m.o.x[0] : m.o.x[r], U = void 0 === m.o.y[r] ? m.o.y[0] : m.o.y[r], Z = void 0 === m.i.x[r] ? m.i.x[0] : m.i.x[r], Q = void 0 === m.i.y[r] ? m.i.y[0] : m.i.y[r], A = tp.getBezierEasing(K, U, Z, Q).get, u.__fnct[r] = A)) : u.__fnct ? A = u.__fnct : (K = m.o.x, U = m.o.y, Z = m.i.x, Q = m.i.y, A = tp.getBezierEasing(K, U, Z, Q).get, m.keyframeMetadata = A), v = A((t - l) / (o - l)))), P = c.s || m.e, $ = 1 === m.h ? m.s[r] : m.s[r] + (P[r] - m.s[r]) * v, "multidimensional" === this.propType ? d[r] = $ : d = $;
                            return e.lastIndex = a, d
                        }

                        function i(t) {
                            var e = t[0] * E,
                                i = t[1] * E,
                                s = t[2] * E,
                                a = Math.cos(e / 2),
                                r = Math.cos(i / 2),
                                n = Math.cos(s / 2),
                                h = Math.sin(e / 2),
                                o = Math.sin(i / 2),
                                l = Math.sin(s / 2);
                            return [h * o * n + a * r * l, h * r * n + a * o * l, a * o * n - h * r * l, a * r * n - h * o * l]
                        }

                        function s() {
                            var t = this.comp.renderedFrame - this.offsetTime,
                                e = this.keyframes[0].t - this.offsetTime,
                                i = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
                            if (!(t === this._caching.lastFrame || -999999 !== this._caching.lastFrame && (this._caching.lastFrame >= i && t >= i || this._caching.lastFrame < e && t < e))) {
                                this._caching.lastFrame >= t && (this._caching._lastKeyframeIndex = -1, this._caching.lastIndex = 0);
                                var s = this.interpolateValue(t, this._caching);
                                this.pv = s
                            }
                            return this._caching.lastFrame = t, this.pv
                        }

                        function a(e) {
                            var i;
                            if ("unidimensional" === this.propType) i = e * this.mult, t(this.v - i) > 1e-5 && (this.v = i, this._mdf = !0);
                            else
                                for (var s = 0, a = this.v.length; s < a;) i = e[s] * this.mult, t(this.v[s] - i) > 1e-5 && (this.v[s] = i, this._mdf = !0), s += 1
                        }

                        function r() {
                            if (this.elem.globalData.frameId !== this.frameId && this.effectsSequence.length) {
                                if (this.lock) {
                                    this.setVValue(this.pv);
                                    return
                                }
                                this.lock = !0, this._mdf = this._isFirstFrame;
                                var t, e = this.effectsSequence.length,
                                    i = this.kf ? this.pv : this.data.k;
                                for (t = 0; t < e; t += 1) i = this.effectsSequence[t](i);
                                this.setVValue(i), this._isFirstFrame = !1, this.lock = !1, this.frameId = this.elem.globalData.frameId
                            }
                        }

                        function n(t) {
                            this.effectsSequence.push(t), this.container.addDynamicProperty(this)
                        }

                        function h(t, e, i, s) {
                            this.propType = "unidimensional", this.mult = i || 1, this.data = e, this.v = i ? e.k * i : e.k, this.pv = e.k, this._mdf = !1, this.elem = t, this.container = s, this.comp = t.comp, this.k = !1, this.kf = !1, this.vel = 0, this.effectsSequence = [], this._isFirstFrame = !0, this.getValue = r, this.setVValue = a, this.addEffect = n
                        }

                        function o(t, e, i, s) {
                            this.propType = "multidimensional", this.mult = i || 1, this.data = e, this._mdf = !1, this.elem = t, this.container = s, this.comp = t.comp, this.k = !1, this.kf = !1, this.frameId = -1;
                            var h, o = e.k.length;
                            for (h = 0, this.v = b("float32", o), this.pv = b("float32", o), this.vel = b("float32", o); h < o; h += 1) this.v[h] = e.k[h] * this.mult, this.pv[h] = e.k[h];
                            this._isFirstFrame = !0, this.effectsSequence = [], this.getValue = r, this.setVValue = a, this.addEffect = n
                        }

                        function l(t, i, h, o) {
                            this.propType = "unidimensional", this.keyframes = i.k, this.keyframesMetadata = [], this.offsetTime = t.data.st, this.frameId = -1, this._caching = {
                                lastFrame: -999999,
                                lastIndex: 0,
                                value: 0,
                                _lastKeyframeIndex: -1
                            }, this.k = !0, this.kf = !0, this.data = i, this.mult = h || 1, this.elem = t, this.container = o, this.comp = t.comp, this.v = -999999, this.pv = -999999, this._isFirstFrame = !0, this.getValue = r, this.setVValue = a, this.interpolateValue = e, this.effectsSequence = [s.bind(this)], this.addEffect = n
                        }

                        function p(t, i, h, o) {
                            this.propType = "multidimensional";
                            var l, p, f, d, m, c = i.k.length;
                            for (l = 0; l < c - 1; l += 1) i.k[l].to && i.k[l].s && i.k[l + 1] && i.k[l + 1].s && (p = i.k[l].s, f = i.k[l + 1].s, d = i.k[l].to, m = i.k[l].ti, (2 === p.length && !(p[0] === f[0] && p[1] === f[1]) && tu.pointOnLine2D(p[0], p[1], f[0], f[1], p[0] + d[0], p[1] + d[1]) && tu.pointOnLine2D(p[0], p[1], f[0], f[1], f[0] + m[0], f[1] + m[1]) || 3 === p.length && !(p[0] === f[0] && p[1] === f[1] && p[2] === f[2]) && tu.pointOnLine3D(p[0], p[1], p[2], f[0], f[1], f[2], p[0] + d[0], p[1] + d[1], p[2] + d[2]) && tu.pointOnLine3D(p[0], p[1], p[2], f[0], f[1], f[2], f[0] + m[0], f[1] + m[1], f[2] + m[2])) && (i.k[l].to = null, i.k[l].ti = null), p[0] === f[0] && p[1] === f[1] && 0 === d[0] && 0 === d[1] && 0 === m[0] && 0 === m[1] && (2 === p.length || p[2] === f[2] && 0 === d[2] && 0 === m[2]) && (i.k[l].to = null, i.k[l].ti = null));
                            this.effectsSequence = [s.bind(this)], this.data = i, this.keyframes = i.k, this.keyframesMetadata = [], this.offsetTime = t.data.st, this.k = !0, this.kf = !0, this._isFirstFrame = !0, this.mult = h || 1, this.elem = t, this.container = o, this.comp = t.comp, this.getValue = r, this.setVValue = a, this.interpolateValue = e, this.frameId = -1;
                            var u = i.k[0].s.length;
                            for (l = 0, this.v = b("float32", u), this.pv = b("float32", u); l < u; l += 1) this.v[l] = -999999, this.pv[l] = -999999;
                            this._caching = {
                                lastFrame: -999999,
                                lastIndex: 0,
                                value: b("float32", u)
                            }, this.addEffect = n
                        }
                        return {
                            getProp: function(t, e, i, s, a) {
                                var r;
                                if (e.k.length) {
                                    if ("number" == typeof e.k[0]) r = new o(t, e, s, a);
                                    else switch (i) {
                                        case 0:
                                            r = new l(t, e, s, a);
                                            break;
                                        case 1:
                                            r = new p(t, e, s, a)
                                    }
                                } else r = new h(t, e, s, a);
                                return r.effectsSequence.length && a.addDynamicProperty(r), r
                            }
                        }
                    }();

                function ty() {}
                ty.prototype = {
                    addDynamicProperty: function(t) {
                        -1 === this.dynamicProperties.indexOf(t) && (this.dynamicProperties.push(t), this.container.addDynamicProperty(this), this._isAnimated = !0)
                    },
                    iterateDynamicProperties: function() {
                        this._mdf = !1;
                        var t, e = this.dynamicProperties.length;
                        for (t = 0; t < e; t += 1) this.dynamicProperties[t].getValue(), this.dynamicProperties[t]._mdf && (this._mdf = !0)
                    },
                    initDynamicPropertyContainer: function(t) {
                        this.container = t, this.dynamicProperties = [], this._mdf = !1, this._isAnimated = !1
                    }
                };
                var tv = td(8, function() {
                    return b("float32", 2)
                });

                function tb() {
                    this.c = !1, this._length = 0, this._maxLength = 8, this.v = _(this._maxLength), this.o = _(this._maxLength), this.i = _(this._maxLength)
                }
                tb.prototype.setPathData = function(t, e) {
                    this.c = t, this.setLength(e);
                    for (var i = 0; i < e;) this.v[i] = tv.newElement(), this.o[i] = tv.newElement(), this.i[i] = tv.newElement(), i += 1
                }, tb.prototype.setLength = function(t) {
                    for (; this._maxLength < t;) this.doubleArrayLength();
                    this._length = t
                }, tb.prototype.doubleArrayLength = function() {
                    this.v = this.v.concat(_(this._maxLength)), this.i = this.i.concat(_(this._maxLength)), this.o = this.o.concat(_(this._maxLength)), this._maxLength *= 2
                }, tb.prototype.setXYAt = function(t, e, i, s, a) {
                    var r;
                    switch (this._length = Math.max(this._length, s + 1), this._length >= this._maxLength && this.doubleArrayLength(), i) {
                        case "v":
                            r = this.v;
                            break;
                        case "i":
                            r = this.i;
                            break;
                        case "o":
                            r = this.o;
                            break;
                        default:
                            r = []
                    }
                    r[s] && (!r[s] || a) || (r[s] = tv.newElement()), r[s][0] = t, r[s][1] = e
                }, tb.prototype.setTripleAt = function(t, e, i, s, a, r, n, h) {
                    this.setXYAt(t, e, "v", n, h), this.setXYAt(i, s, "o", n, h), this.setXYAt(a, r, "i", n, h)
                }, tb.prototype.reverse = function() {
                    var t, e = new tb;
                    e.setPathData(this.c, this._length);
                    var i = this.v,
                        s = this.o,
                        a = this.i,
                        r = 0;
                    this.c && (e.setTripleAt(i[0][0], i[0][1], a[0][0], a[0][1], s[0][0], s[0][1], 0, !1), r = 1);
                    var n = this._length - 1,
                        h = this._length;
                    for (t = r; t < h; t += 1) e.setTripleAt(i[n][0], i[n][1], a[n][0], a[n][1], s[n][0], s[n][1], t, !1), n -= 1;
                    return e
                }, tb.prototype.length = function() {
                    return this._length
                };
                var t_ = ((s = td(4, function() {
                    return new tb
                }, function(t) {
                    var e, i = t._length;
                    for (e = 0; e < i; e += 1) tv.release(t.v[e]), tv.release(t.i[e]), tv.release(t.o[e]), t.v[e] = null, t.i[e] = null, t.o[e] = null;
                    t._length = 0, t.c = !1
                })).clone = function(t) {
                    var e, i = s.newElement(),
                        a = void 0 === t._length ? t.v.length : t._length;
                    for (i.setLength(a), i.c = t.c, e = 0; e < a; e += 1) i.setTripleAt(t.v[e][0], t.v[e][1], t.o[e][0], t.o[e][1], t.i[e][0], t.i[e][1], e);
                    return i
                }, s);

                function tk() {
                    this._length = 0, this._maxLength = 4, this.shapes = _(this._maxLength)
                }
                tk.prototype.addShape = function(t) {
                    this._length === this._maxLength && (this.shapes = this.shapes.concat(_(this._maxLength)), this._maxLength *= 2), this.shapes[this._length] = t, this._length += 1
                }, tk.prototype.releaseShapes = function() {
                    var t;
                    for (t = 0; t < this._length; t += 1) t_.release(this.shapes[t]);
                    this._length = 0
                };
                var tA = (a = 0, r = 4, n = _(4), {
                        newShapeCollection: function() {
                            var t;
                            return a ? (a -= 1, t = n[a]) : t = new tk, t
                        },
                        release: function(t) {
                            var e, i = t._length;
                            for (e = 0; e < i; e += 1) t_.release(t.shapes[e]);
                            t._length = 0, a === r && (n = tf.double(n), r *= 2), n[a] = t, a += 1
                        }
                    }),
                    tP = function() {
                        function t(t, e, i) {
                            var s = i.lastIndex,
                                a = this.keyframes;
                            if (t < a[0].t - this.offsetTime) r = a[0].s[0], h = !0, s = 0;
                            else if (t >= a[a.length - 1].t - this.offsetTime) r = a[a.length - 1].s ? a[a.length - 1].s[0] : a[a.length - 2].e[0], h = !0;
                            else {
                                for (var r, n, h, o, l, p, f, d, m, c, u, g, y, v = s, b = a.length - 1, _ = !0; _ && (c = a[v], !((u = a[v + 1]).t - this.offsetTime > t));) v < b - 1 ? v += 1 : _ = !1;
                                g = this.keyframesMetadata[v] || {}, h = 1 === c.h, s = v, h || (t >= u.t - this.offsetTime ? d = 1 : t < c.t - this.offsetTime ? d = 0 : (g.__fnct ? y = g.__fnct : (y = tp.getBezierEasing(c.o.x, c.o.y, c.i.x, c.i.y).get, g.__fnct = y), d = y((t - (c.t - this.offsetTime)) / (u.t - this.offsetTime - (c.t - this.offsetTime)))), n = u.s ? u.s[0] : c.e[0]), r = c.s[0]
                            }
                            for (o = 0, p = e._length, f = r.i[0].length, i.lastIndex = s; o < p; o += 1)
                                for (l = 0; l < f; l += 1) m = h ? r.i[o][l] : r.i[o][l] + (n.i[o][l] - r.i[o][l]) * d, e.i[o][l] = m, m = h ? r.o[o][l] : r.o[o][l] + (n.o[o][l] - r.o[o][l]) * d, e.o[o][l] = m, m = h ? r.v[o][l] : r.v[o][l] + (n.v[o][l] - r.v[o][l]) * d, e.v[o][l] = m
                        }

                        function e() {
                            var t = this.comp.renderedFrame - this.offsetTime,
                                e = this.keyframes[0].t - this.offsetTime,
                                i = this.keyframes[this.keyframes.length - 1].t - this.offsetTime,
                                s = this._caching.lastFrame;
                            return -999999 !== s && (s < e && t < e || s > i && t > i) || (this._caching.lastIndex = s < t ? this._caching.lastIndex : 0, this.interpolateShape(t, this.pv, this._caching)), this._caching.lastFrame = t, this.pv
                        }

                        function i() {
                            this.paths = this.localShapeCollection
                        }

                        function s(t) {
                            ! function(t, e) {
                                if (t._length !== e._length || t.c !== e.c) return !1;
                                var i, s = t._length;
                                for (i = 0; i < s; i += 1)
                                    if (t.v[i][0] !== e.v[i][0] || t.v[i][1] !== e.v[i][1] || t.o[i][0] !== e.o[i][0] || t.o[i][1] !== e.o[i][1] || t.i[i][0] !== e.i[i][0] || t.i[i][1] !== e.i[i][1]) return !1;
                                return !0
                            }(this.v, t) && (this.v = t_.clone(t), this.localShapeCollection.releaseShapes(), this.localShapeCollection.addShape(this.v), this._mdf = !0, this.paths = this.localShapeCollection)
                        }

                        function a() {
                            if (this.elem.globalData.frameId !== this.frameId) {
                                if (!this.effectsSequence.length) {
                                    this._mdf = !1;
                                    return
                                }
                                if (this.lock) {
                                    this.setVValue(this.pv);
                                    return
                                }
                                this.lock = !0, this._mdf = !1, t = this.kf ? this.pv : this.data.ks ? this.data.ks.k : this.data.pt.k;
                                var t, e, i = this.effectsSequence.length;
                                for (e = 0; e < i; e += 1) t = this.effectsSequence[e](t);
                                this.setVValue(t), this.lock = !1, this.frameId = this.elem.globalData.frameId
                            }
                        }

                        function r(t, e, s) {
                            this.propType = "shape", this.comp = t.comp, this.container = t, this.elem = t, this.data = e, this.k = !1, this.kf = !1, this._mdf = !1;
                            var a = 3 === s ? e.pt.k : e.ks.k;
                            this.v = t_.clone(a), this.pv = t_.clone(this.v), this.localShapeCollection = tA.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.reset = i, this.effectsSequence = []
                        }

                        function n(t) {
                            this.effectsSequence.push(t), this.container.addDynamicProperty(this)
                        }

                        function h(t, s, a) {
                            this.propType = "shape", this.comp = t.comp, this.elem = t, this.container = t, this.offsetTime = t.data.st, this.keyframes = 3 === a ? s.pt.k : s.ks.k, this.keyframesMetadata = [], this.k = !0, this.kf = !0;
                            var r = this.keyframes[0].s[0].i.length;
                            this.v = t_.newElement(), this.v.setPathData(this.keyframes[0].s[0].c, r), this.pv = t_.clone(this.v), this.localShapeCollection = tA.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.lastFrame = -999999, this.reset = i, this._caching = {
                                lastFrame: -999999,
                                lastIndex: 0
                            }, this.effectsSequence = [e.bind(this)]
                        }
                        r.prototype.interpolateShape = t, r.prototype.getValue = a, r.prototype.setVValue = s, r.prototype.addEffect = n, h.prototype.getValue = a, h.prototype.interpolateShape = t, h.prototype.setVValue = s, h.prototype.addEffect = n;
                        var o = function() {
                                function t(t, e) {
                                    this.v = t_.newElement(), this.v.setPathData(!0, 4), this.localShapeCollection = tA.newShapeCollection(), this.paths = this.localShapeCollection, this.localShapeCollection.addShape(this.v), this.d = e.d, this.elem = t, this.comp = t.comp, this.frameId = -1, this.initDynamicPropertyContainer(t), this.p = tg.getProp(t, e.p, 1, 0, this), this.s = tg.getProp(t, e.s, 1, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertEllToPath())
                                }
                                return t.prototype = {
                                    reset: i,
                                    getValue: function() {
                                        this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertEllToPath())
                                    },
                                    convertEllToPath: function() {
                                        var t = this.p.v[0],
                                            e = this.p.v[1],
                                            i = this.s.v[0] / 2,
                                            s = this.s.v[1] / 2,
                                            a = 3 !== this.d,
                                            r = this.v;
                                        r.v[0][0] = t, r.v[0][1] = e - s, r.v[1][0] = a ? t + i : t - i, r.v[1][1] = e, r.v[2][0] = t, r.v[2][1] = e + s, r.v[3][0] = a ? t - i : t + i, r.v[3][1] = e, r.i[0][0] = a ? t - .5519 * i : t + .5519 * i, r.i[0][1] = e - s, r.i[1][0] = a ? t + i : t - i, r.i[1][1] = e - .5519 * s, r.i[2][0] = a ? t + .5519 * i : t - .5519 * i, r.i[2][1] = e + s, r.i[3][0] = a ? t - i : t + i, r.i[3][1] = e + .5519 * s, r.o[0][0] = a ? t + .5519 * i : t - .5519 * i, r.o[0][1] = e - s, r.o[1][0] = a ? t + i : t - i, r.o[1][1] = e + .5519 * s, r.o[2][0] = a ? t - .5519 * i : t + .5519 * i, r.o[2][1] = e + s, r.o[3][0] = a ? t - i : t + i, r.o[3][1] = e - .5519 * s
                                    }
                                }, y([ty], t), t
                            }(),
                            l = function() {
                                function t(t, e) {
                                    this.v = t_.newElement(), this.v.setPathData(!0, 0), this.elem = t, this.comp = t.comp, this.data = e, this.frameId = -1, this.d = e.d, this.initDynamicPropertyContainer(t), 1 === e.sy ? (this.ir = tg.getProp(t, e.ir, 0, 0, this), this.is = tg.getProp(t, e.is, 0, .01, this), this.convertToPath = this.convertStarToPath) : this.convertToPath = this.convertPolygonToPath, this.pt = tg.getProp(t, e.pt, 0, 0, this), this.p = tg.getProp(t, e.p, 1, 0, this), this.r = tg.getProp(t, e.r, 0, E, this), this.or = tg.getProp(t, e.or, 0, 0, this), this.os = tg.getProp(t, e.os, 0, .01, this), this.localShapeCollection = tA.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertToPath())
                                }
                                return t.prototype = {
                                    reset: i,
                                    getValue: function() {
                                        this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertToPath())
                                    },
                                    convertStarToPath: function() {
                                        var t, e, i, s, a = 2 * Math.floor(this.pt.v),
                                            r = 2 * Math.PI / a,
                                            n = !0,
                                            h = this.or.v,
                                            o = this.ir.v,
                                            l = this.os.v,
                                            p = this.is.v,
                                            f = 2 * Math.PI * h / (2 * a),
                                            d = 2 * Math.PI * o / (2 * a),
                                            m = -Math.PI / 2;
                                        m += this.r.v;
                                        var c = 3 === this.data.d ? -1 : 1;
                                        for (t = 0, this.v._length = 0; t < a; t += 1) {
                                            e = n ? h : o, i = n ? l : p, s = n ? f : d;
                                            var u = e * Math.cos(m),
                                                g = e * Math.sin(m),
                                                y = 0 === u && 0 === g ? 0 : g / Math.sqrt(u * u + g * g),
                                                v = 0 === u && 0 === g ? 0 : -u / Math.sqrt(u * u + g * g);
                                            u += +this.p.v[0], g += +this.p.v[1], this.v.setTripleAt(u, g, u - y * s * i * c, g - v * s * i * c, u + y * s * i * c, g + v * s * i * c, t, !0), n = !n, m += r * c
                                        }
                                    },
                                    convertPolygonToPath: function() {
                                        var t, e = Math.floor(this.pt.v),
                                            i = 2 * Math.PI / e,
                                            s = this.or.v,
                                            a = this.os.v,
                                            r = 2 * Math.PI * s / (4 * e),
                                            n = -(.5 * Math.PI),
                                            h = 3 === this.data.d ? -1 : 1;
                                        for (n += this.r.v, this.v._length = 0, t = 0; t < e; t += 1) {
                                            var o = s * Math.cos(n),
                                                l = s * Math.sin(n),
                                                p = 0 === o && 0 === l ? 0 : l / Math.sqrt(o * o + l * l),
                                                f = 0 === o && 0 === l ? 0 : -o / Math.sqrt(o * o + l * l);
                                            o += +this.p.v[0], l += +this.p.v[1], this.v.setTripleAt(o, l, o - p * r * a * h, l - f * r * a * h, o + p * r * a * h, l + f * r * a * h, t, !0), n += i * h
                                        }
                                        this.paths.length = 0, this.paths[0] = this.v
                                    }
                                }, y([ty], t), t
                            }(),
                            p = function() {
                                function t(t, e) {
                                    this.v = t_.newElement(), this.v.c = !0, this.localShapeCollection = tA.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.elem = t, this.comp = t.comp, this.frameId = -1, this.d = e.d, this.initDynamicPropertyContainer(t), this.p = tg.getProp(t, e.p, 1, 0, this), this.s = tg.getProp(t, e.s, 1, 0, this), this.r = tg.getProp(t, e.r, 0, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertRectToPath())
                                }
                                return t.prototype = {
                                    convertRectToPath: function() {
                                        var t = this.p.v[0],
                                            e = this.p.v[1],
                                            i = this.s.v[0] / 2,
                                            s = this.s.v[1] / 2,
                                            a = M(i, s, this.r.v),
                                            r = .44810000000000005 * a;
                                        this.v._length = 0, 2 === this.d || 1 === this.d ? (this.v.setTripleAt(t + i, e - s + a, t + i, e - s + a, t + i, e - s + r, 0, !0), this.v.setTripleAt(t + i, e + s - a, t + i, e + s - r, t + i, e + s - a, 1, !0), 0 !== a ? (this.v.setTripleAt(t + i - a, e + s, t + i - a, e + s, t + i - r, e + s, 2, !0), this.v.setTripleAt(t - i + a, e + s, t - i + r, e + s, t - i + a, e + s, 3, !0), this.v.setTripleAt(t - i, e + s - a, t - i, e + s - a, t - i, e + s - r, 4, !0), this.v.setTripleAt(t - i, e - s + a, t - i, e - s + r, t - i, e - s + a, 5, !0), this.v.setTripleAt(t - i + a, e - s, t - i + a, e - s, t - i + r, e - s, 6, !0), this.v.setTripleAt(t + i - a, e - s, t + i - r, e - s, t + i - a, e - s, 7, !0)) : (this.v.setTripleAt(t - i, e + s, t - i + r, e + s, t - i, e + s, 2), this.v.setTripleAt(t - i, e - s, t - i, e - s + r, t - i, e - s, 3))) : (this.v.setTripleAt(t + i, e - s + a, t + i, e - s + r, t + i, e - s + a, 0, !0), 0 !== a ? (this.v.setTripleAt(t + i - a, e - s, t + i - a, e - s, t + i - r, e - s, 1, !0), this.v.setTripleAt(t - i + a, e - s, t - i + r, e - s, t - i + a, e - s, 2, !0), this.v.setTripleAt(t - i, e - s + a, t - i, e - s + a, t - i, e - s + r, 3, !0), this.v.setTripleAt(t - i, e + s - a, t - i, e + s - r, t - i, e + s - a, 4, !0), this.v.setTripleAt(t - i + a, e + s, t - i + a, e + s, t - i + r, e + s, 5, !0), this.v.setTripleAt(t + i - a, e + s, t + i - r, e + s, t + i - a, e + s, 6, !0), this.v.setTripleAt(t + i, e + s - a, t + i, e + s - a, t + i, e + s - r, 7, !0)) : (this.v.setTripleAt(t - i, e - s, t - i + r, e - s, t - i, e - s, 1, !0), this.v.setTripleAt(t - i, e + s, t - i, e + s - r, t - i, e + s, 2, !0), this.v.setTripleAt(t + i, e + s, t + i - r, e + s, t + i, e + s, 3, !0)))
                                    },
                                    getValue: function() {
                                        this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertRectToPath())
                                    },
                                    reset: i
                                }, y([ty], t), t
                            }(),
                            f = {};
                        return f.getShapeProp = function(t, e, i) {
                            var s;
                            return 3 === i || 4 === i ? s = (3 === i ? e.pt : e.ks).k.length ? new h(t, e, i) : new r(t, e, i) : 5 === i ? s = new p(t, e) : 6 === i ? s = new o(t, e) : 7 === i && (s = new l(t, e)), s.k && t.addDynamicProperty(s), s
                        }, f.getConstructorFunction = function() {
                            return r
                        }, f.getKeyframedConstructorFunction = function() {
                            return h
                        }, f
                    }(),
                    tS = function() {
                        var t = Math.cos,
                            e = Math.sin,
                            i = Math.tan,
                            s = Math.round;

                        function a() {
                            return this.props[0] = 1, this.props[1] = 0, this.props[2] = 0, this.props[3] = 0, this.props[4] = 0, this.props[5] = 1, this.props[6] = 0, this.props[7] = 0, this.props[8] = 0, this.props[9] = 0, this.props[10] = 1, this.props[11] = 0, this.props[12] = 0, this.props[13] = 0, this.props[14] = 0, this.props[15] = 1, this
                        }

                        function r(i) {
                            if (0 === i) return this;
                            var s = t(i),
                                a = e(i);
                            return this._t(s, -a, 0, 0, a, s, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
                        }

                        function n(i) {
                            if (0 === i) return this;
                            var s = t(i),
                                a = e(i);
                            return this._t(1, 0, 0, 0, 0, s, -a, 0, 0, a, s, 0, 0, 0, 0, 1)
                        }

                        function h(i) {
                            if (0 === i) return this;
                            var s = t(i),
                                a = e(i);
                            return this._t(s, 0, a, 0, 0, 1, 0, 0, -a, 0, s, 0, 0, 0, 0, 1)
                        }

                        function o(i) {
                            if (0 === i) return this;
                            var s = t(i),
                                a = e(i);
                            return this._t(s, -a, 0, 0, a, s, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
                        }

                        function l(t, e) {
                            return this._t(1, e, t, 1, 0, 0)
                        }

                        function p(t, e) {
                            return this.shear(i(t), i(e))
                        }

                        function f(s, a) {
                            var r = t(a),
                                n = e(a);
                            return this._t(r, n, 0, 0, -n, r, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(1, 0, 0, 0, i(s), 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(r, -n, 0, 0, n, r, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
                        }

                        function d(t, e, i) {
                            return (i || 0 === i || (i = 1), 1 === t && 1 === e && 1 === i) ? this : this._t(t, 0, 0, 0, 0, e, 0, 0, 0, 0, i, 0, 0, 0, 0, 1)
                        }

                        function m(t, e, i, s, a, r, n, h, o, l, p, f, d, m, c, u) {
                            return this.props[0] = t, this.props[1] = e, this.props[2] = i, this.props[3] = s, this.props[4] = a, this.props[5] = r, this.props[6] = n, this.props[7] = h, this.props[8] = o, this.props[9] = l, this.props[10] = p, this.props[11] = f, this.props[12] = d, this.props[13] = m, this.props[14] = c, this.props[15] = u, this
                        }

                        function c(t, e, i) {
                            return (i = i || 0, 0 !== t || 0 !== e || 0 !== i) ? this._t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, t, e, i, 1) : this
                        }

                        function u(t, e, i, s, a, r, n, h, o, l, p, f, d, m, c, u) {
                            var g = this.props;
                            if (1 === t && 0 === e && 0 === i && 0 === s && 0 === a && 1 === r && 0 === n && 0 === h && 0 === o && 0 === l && 1 === p && 0 === f) return g[12] = g[12] * t + g[15] * d, g[13] = g[13] * r + g[15] * m, g[14] = g[14] * p + g[15] * c, g[15] *= u, this._identityCalculated = !1, this;
                            var y = g[0],
                                v = g[1],
                                b = g[2],
                                _ = g[3],
                                k = g[4],
                                A = g[5],
                                P = g[6],
                                S = g[7],
                                x = g[8],
                                w = g[9],
                                D = g[10],
                                C = g[11],
                                M = g[12],
                                F = g[13],
                                T = g[14],
                                E = g[15];
                            return g[0] = y * t + v * a + b * o + _ * d, g[1] = y * e + v * r + b * l + _ * m, g[2] = y * i + v * n + b * p + _ * c, g[3] = y * s + v * h + b * f + _ * u, g[4] = k * t + A * a + P * o + S * d, g[5] = k * e + A * r + P * l + S * m, g[6] = k * i + A * n + P * p + S * c, g[7] = k * s + A * h + P * f + S * u, g[8] = x * t + w * a + D * o + C * d, g[9] = x * e + w * r + D * l + C * m, g[10] = x * i + w * n + D * p + C * c, g[11] = x * s + w * h + D * f + C * u, g[12] = M * t + F * a + T * o + E * d, g[13] = M * e + F * r + T * l + E * m, g[14] = M * i + F * n + T * p + E * c, g[15] = M * s + F * h + T * f + E * u, this._identityCalculated = !1, this
                        }

                        function g() {
                            return this._identityCalculated || (this._identity = !(1 !== this.props[0] || 0 !== this.props[1] || 0 !== this.props[2] || 0 !== this.props[3] || 0 !== this.props[4] || 1 !== this.props[5] || 0 !== this.props[6] || 0 !== this.props[7] || 0 !== this.props[8] || 0 !== this.props[9] || 1 !== this.props[10] || 0 !== this.props[11] || 0 !== this.props[12] || 0 !== this.props[13] || 0 !== this.props[14] || 1 !== this.props[15]), this._identityCalculated = !0), this._identity
                        }

                        function y(t) {
                            for (var e = 0; e < 16;) {
                                if (t.props[e] !== this.props[e]) return !1;
                                e += 1
                            }
                            return !0
                        }

                        function v(t) {
                            var e;
                            for (e = 0; e < 16; e += 1) t.props[e] = this.props[e];
                            return t
                        }

                        function _(t) {
                            var e;
                            for (e = 0; e < 16; e += 1) this.props[e] = t[e]
                        }

                        function k(t, e, i) {
                            return {
                                x: t * this.props[0] + e * this.props[4] + i * this.props[8] + this.props[12],
                                y: t * this.props[1] + e * this.props[5] + i * this.props[9] + this.props[13],
                                z: t * this.props[2] + e * this.props[6] + i * this.props[10] + this.props[14]
                            }
                        }

                        function A(t, e, i) {
                            return t * this.props[0] + e * this.props[4] + i * this.props[8] + this.props[12]
                        }

                        function P(t, e, i) {
                            return t * this.props[1] + e * this.props[5] + i * this.props[9] + this.props[13]
                        }

                        function S(t, e, i) {
                            return t * this.props[2] + e * this.props[6] + i * this.props[10] + this.props[14]
                        }

                        function x() {
                            var t = this.props[0] * this.props[5] - this.props[1] * this.props[4],
                                e = this.props[5] / t,
                                i = -this.props[1] / t,
                                s = -this.props[4] / t,
                                a = this.props[0] / t,
                                r = (this.props[4] * this.props[13] - this.props[5] * this.props[12]) / t,
                                n = -(this.props[0] * this.props[13] - this.props[1] * this.props[12]) / t,
                                h = new tS;
                            return h.props[0] = e, h.props[1] = i, h.props[4] = s, h.props[5] = a, h.props[12] = r, h.props[13] = n, h
                        }

                        function w(t) {
                            return this.getInverseMatrix().applyToPointArray(t[0], t[1], t[2] || 0)
                        }

                        function D(t) {
                            var e, i = t.length,
                                s = [];
                            for (e = 0; e < i; e += 1) s[e] = w(t[e]);
                            return s
                        }

                        function C(t, e, i) {
                            var s = b("float32", 6);
                            if (this.isIdentity()) s[0] = t[0], s[1] = t[1], s[2] = e[0], s[3] = e[1], s[4] = i[0], s[5] = i[1];
                            else {
                                var a = this.props[0],
                                    r = this.props[1],
                                    n = this.props[4],
                                    h = this.props[5],
                                    o = this.props[12],
                                    l = this.props[13];
                                s[0] = t[0] * a + t[1] * n + o, s[1] = t[0] * r + t[1] * h + l, s[2] = e[0] * a + e[1] * n + o, s[3] = e[0] * r + e[1] * h + l, s[4] = i[0] * a + i[1] * n + o, s[5] = i[0] * r + i[1] * h + l
                            }
                            return s
                        }

                        function M(t, e, i) {
                            return this.isIdentity() ? [t, e, i] : [t * this.props[0] + e * this.props[4] + i * this.props[8] + this.props[12], t * this.props[1] + e * this.props[5] + i * this.props[9] + this.props[13], t * this.props[2] + e * this.props[6] + i * this.props[10] + this.props[14]]
                        }

                        function F(t, e) {
                            if (this.isIdentity()) return t + "," + e;
                            var i = this.props;
                            return Math.round((t * i[0] + e * i[4] + i[12]) * 100) / 100 + "," + Math.round((t * i[1] + e * i[5] + i[13]) * 100) / 100
                        }

                        function T() {
                            for (var t = 0, e = this.props, i = "matrix3d("; t < 16;) i += s(1e4 * e[t]) / 1e4 + (15 === t ? ")" : ","), t += 1;
                            return i
                        }

                        function E(t) {
                            return t < 1e-6 && t > 0 || t > -.000001 && t < 0 ? s(1e4 * t) / 1e4 : t
                        }

                        function I() {
                            var t = this.props;
                            return "matrix(" + E(t[0]) + "," + E(t[1]) + "," + E(t[4]) + "," + E(t[5]) + "," + E(t[12]) + "," + E(t[13]) + ")"
                        }
                        return function() {
                            this.reset = a, this.rotate = r, this.rotateX = n, this.rotateY = h, this.rotateZ = o, this.skew = p, this.skewFromAxis = f, this.shear = l, this.scale = d, this.setTransform = m, this.translate = c, this.transform = u, this.applyToPoint = k, this.applyToX = A, this.applyToY = P, this.applyToZ = S, this.applyToPointArray = M, this.applyToTriplePoints = C, this.applyToPointStringified = F, this.toCSS = T, this.to2dCSS = I, this.clone = v, this.cloneFromProps = _, this.equals = y, this.inversePoints = D, this.inversePoint = w, this.getInverseMatrix = x, this._t = this.transform, this.isIdentity = g, this._identity = !0, this._identityCalculated = !1, this.props = b("float32", 16), this.reset()
                        }
                    }();

                function tx(t) {
                    return (tx = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    })(t)
                }
                var tw = {},
                    tD = "__[STANDALONE]__",
                    tC = "__[ANIMATIONDATA]__",
                    tM = "";

                function tF() {
                    !0 === tD ? tl.searchAnimations(tC, tD, tM) : tl.searchAnimations()
                }
                tw.play = tl.play, tw.pause = tl.pause, tw.setLocationHref = function(t) {
                    c(t)
                }, tw.togglePause = tl.togglePause, tw.setSpeed = tl.setSpeed, tw.setDirection = tl.setDirection, tw.stop = tl.stop, tw.searchAnimations = tF, tw.registerAnimation = tl.registerAnimation, tw.loadAnimation = function(t) {
                    return !0 === tD && (t.animationData = JSON.parse(tC)), tl.loadAnimation(t)
                }, tw.setSubframeRendering = function(t) {
                    Y(t)
                }, tw.resize = tl.resize, tw.goToAndStop = tl.goToAndStop, tw.destroy = tl.destroy, tw.setQuality = function(t) {
                    if ("string" == typeof t) switch (t) {
                        case "high":
                            U(200);
                            break;
                        default:
                        case "medium":
                            U(50);
                            break;
                        case "low":
                            U(10)
                    } else !isNaN(t) && t > 1 && U(t);
                    Z()
                }, tw.inBrowser = function() {
                    return "undefined" != typeof navigator
                }, tw.installPlugin = function(t, e) {
                    "expressions" === t && G(e)
                }, tw.freeze = tl.freeze, tw.unfreeze = tl.unfreeze, tw.setVolume = tl.setVolume, tw.mute = tl.mute, tw.unmute = tl.unmute, tw.getRegisteredAnimations = tl.getRegisteredAnimations, tw.useWebWorker = function(t) {
                    m = !!t
                }, tw.setIDPrefix = function(t) {
                    Q(t)
                }, tw.__getFactory = function(t) {
                    switch (t) {
                        case "propertyFactory":
                            return tg;
                        case "shapePropertyFactory":
                            return tP;
                        case "matrix":
                            return tS;
                        default:
                            return null
                    }
                }, tw.version = "5.10.2";
                var tT = "";
                if (tD) {
                    var tE = document.getElementsByTagName("script"),
                        tI = tE.length - 1,
                        tL = tE[tI] || {
                            src: ""
                        };
                    tT = tL.src ? tL.src.replace(/^[^\?]+\??/, "") : "", tM = function(t) {
                        for (var e = tT.split("&"), i = 0; i < e.length; i += 1) {
                            var s = e[i].split("=");
                            if (decodeURIComponent(s[0]) == t) return decodeURIComponent(s[1])
                        }
                        return null
                    }("renderer")
                }
                var tV = setInterval(function() {
                    "complete" === document.readyState && (clearInterval(tV), tF())
                }, 100);
                try {
                    "object" !== tx(e) && i.amdO
                } catch (t) {}
                var tz = (o = {}, (h = {}).registerModifier = function(t, e) {
                    o[t] || (o[t] = e)
                }, h.getModifier = function(t, e, i) {
                    return new o[t](e, i)
                }, h);

                function tR() {}

                function tN() {}

                function tO() {}
                tR.prototype.initModifierProperties = function() {}, tR.prototype.addShapeToModifier = function() {}, tR.prototype.addShape = function(t) {
                    if (!this.closed) {
                        t.sh.container.addDynamicProperty(t.sh);
                        var e = {
                            shape: t.sh,
                            data: t,
                            localShapeCollection: tA.newShapeCollection()
                        };
                        this.shapes.push(e), this.addShapeToModifier(e), this._isAnimated && t.setAsAnimated()
                    }
                }, tR.prototype.init = function(t, e) {
                    this.shapes = [], this.elem = t, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e), this.frameId = -999999, this.closed = !1, this.k = !1, this.dynamicProperties.length ? this.k = !0 : this.getValue(!0)
                }, tR.prototype.processKeys = function() {
                    this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties())
                }, y([ty], tR), y([tR], tN), tN.prototype.initModifierProperties = function(t, e) {
                    this.s = tg.getProp(t, e.s, 0, .01, this), this.e = tg.getProp(t, e.e, 0, .01, this), this.o = tg.getProp(t, e.o, 0, 0, this), this.sValue = 0, this.eValue = 0, this.getValue = this.processKeys, this.m = e.m, this._isAnimated = !!this.s.effectsSequence.length || !!this.e.effectsSequence.length || !!this.o.effectsSequence.length
                }, tN.prototype.addShapeToModifier = function(t) {
                    t.pathsData = []
                }, tN.prototype.calculateShapeEdges = function(t, e, i, s, a) {
                    var r, n, h = [];
                    e <= 1 ? h.push({
                        s: t,
                        e: e
                    }) : t >= 1 ? h.push({
                        s: t - 1,
                        e: e - 1
                    }) : (h.push({
                        s: t,
                        e: 1
                    }), h.push({
                        s: 0,
                        e: e - 1
                    }));
                    var o = [],
                        l = h.length;
                    for (r = 0; r < l; r += 1)(n = h[r]).e * a < s || n.s * a > s + i || o.push([n.s * a <= s ? 0 : (n.s * a - s) / i, n.e * a >= s + i ? 1 : (n.e * a - s) / i]);
                    return o.length || o.push([0, 0]), o
                }, tN.prototype.releasePathsData = function(t) {
                    var e, i = t.length;
                    for (e = 0; e < i; e += 1) tc.release(t[e]);
                    return t.length = 0, t
                }, tN.prototype.processShapes = function(t) {
                    if (this._mdf || t) {
                        var e = this.o.v % 360 / 360;
                        if (e < 0 && (e += 1), (r = this.s.v > 1 ? 1 + e : this.s.v < 0 ? 0 + e : this.s.v + e) > (n = this.e.v > 1 ? 1 + e : this.e.v < 0 ? 0 + e : this.e.v + e)) {
                            var i = r;
                            r = n, n = i
                        }
                        r = 1e-4 * Math.round(1e4 * r), n = 1e-4 * Math.round(1e4 * n), this.sValue = r, this.eValue = n
                    } else r = this.sValue, n = this.eValue;
                    var s = this.shapes.length,
                        a = 0;
                    if (n === r)
                        for (o = 0; o < s; o += 1) this.shapes[o].localShapeCollection.releaseShapes(), this.shapes[o].shape._mdf = !0, this.shapes[o].shape.paths = this.shapes[o].localShapeCollection, this._mdf && (this.shapes[o].pathsData.length = 0);
                    else if (1 === n && 0 === r || 0 === n && 1 === r) {
                        if (this._mdf)
                            for (o = 0; o < s; o += 1) this.shapes[o].pathsData.length = 0, this.shapes[o].shape._mdf = !0
                    } else {
                        var r, n, h, o, l, p, f, d, m, c, u, g, y = [];
                        for (o = 0; o < s; o += 1)
                            if ((c = this.shapes[o]).shape._mdf || this._mdf || t || 2 === this.m) {
                                if (p = (h = c.shape.paths)._length, m = 0, !c.shape._mdf && c.pathsData.length) m = c.totalShapeLength;
                                else {
                                    for (l = 0, f = this.releasePathsData(c.pathsData); l < p; l += 1) d = tu.getSegmentsLength(h.shapes[l]), f.push(d), m += d.totalLength;
                                    c.totalShapeLength = m, c.pathsData = f
                                }
                                a += m, c.shape._mdf = !0
                            } else c.shape.paths = c.localShapeCollection;
                        var v = r,
                            b = n,
                            _ = 0;
                        for (o = s - 1; o >= 0; o -= 1)
                            if ((c = this.shapes[o]).shape._mdf) {
                                for ((u = c.localShapeCollection).releaseShapes(), 2 === this.m && s > 1 ? (g = this.calculateShapeEdges(r, n, c.totalShapeLength, _, a), _ += c.totalShapeLength) : g = [
                                        [v, b]
                                    ], p = g.length, l = 0; l < p; l += 1) {
                                    v = g[l][0], b = g[l][1], y.length = 0, b <= 1 ? y.push({
                                        s: c.totalShapeLength * v,
                                        e: c.totalShapeLength * b
                                    }) : v >= 1 ? y.push({
                                        s: c.totalShapeLength * (v - 1),
                                        e: c.totalShapeLength * (b - 1)
                                    }) : (y.push({
                                        s: c.totalShapeLength * v,
                                        e: c.totalShapeLength
                                    }), y.push({
                                        s: 0,
                                        e: c.totalShapeLength * (b - 1)
                                    }));
                                    var k = this.addShapes(c, y[0]);
                                    if (y[0].s !== y[0].e) {
                                        if (y.length > 1) {
                                            if (c.shape.paths.shapes[c.shape.paths._length - 1].c) {
                                                var A = k.pop();
                                                this.addPaths(k, u), k = this.addShapes(c, y[1], A)
                                            } else this.addPaths(k, u), k = this.addShapes(c, y[1])
                                        }
                                        this.addPaths(k, u)
                                    }
                                }
                                c.shape.paths = u
                            }
                    }
                }, tN.prototype.addPaths = function(t, e) {
                    var i, s = t.length;
                    for (i = 0; i < s; i += 1) e.addShape(t[i])
                }, tN.prototype.addSegment = function(t, e, i, s, a, r, n) {
                    a.setXYAt(e[0], e[1], "o", r), a.setXYAt(i[0], i[1], "i", r + 1), n && a.setXYAt(t[0], t[1], "v", r), a.setXYAt(s[0], s[1], "v", r + 1)
                }, tN.prototype.addSegmentFromArray = function(t, e, i, s) {
                    e.setXYAt(t[1], t[5], "o", i), e.setXYAt(t[2], t[6], "i", i + 1), s && e.setXYAt(t[0], t[4], "v", i), e.setXYAt(t[3], t[7], "v", i + 1)
                }, tN.prototype.addShapes = function(t, e, i) {
                    var s, a, r, n, h, o, l, p, f = t.pathsData,
                        d = t.shape.paths.shapes,
                        m = t.shape.paths._length,
                        c = 0,
                        u = [],
                        g = !0;
                    for (i ? (h = i._length, p = i._length) : (i = t_.newElement(), h = 0, p = 0), u.push(i), s = 0; s < m; s += 1) {
                        for (a = 1, o = f[s].lengths, i.c = d[s].c, r = d[s].c ? o.length : o.length + 1; a < r; a += 1)
                            if (c + (n = o[a - 1]).addedLength < e.s) c += n.addedLength, i.c = !1;
                            else if (c > e.e) {
                            i.c = !1;
                            break
                        } else e.s <= c && e.e >= c + n.addedLength ? (this.addSegment(d[s].v[a - 1], d[s].o[a - 1], d[s].i[a], d[s].v[a], i, h, g), g = !1) : (l = tu.getNewSegment(d[s].v[a - 1], d[s].v[a], d[s].o[a - 1], d[s].i[a], (e.s - c) / n.addedLength, (e.e - c) / n.addedLength, o[a - 1]), this.addSegmentFromArray(l, i, h, g), g = !1, i.c = !1), c += n.addedLength, h += 1;
                        if (d[s].c && o.length) {
                            if (n = o[a - 1], c <= e.e) {
                                var y = o[a - 1].addedLength;
                                e.s <= c && e.e >= c + y ? (this.addSegment(d[s].v[a - 1], d[s].o[a - 1], d[s].i[0], d[s].v[0], i, h, g), g = !1) : (l = tu.getNewSegment(d[s].v[a - 1], d[s].v[0], d[s].o[a - 1], d[s].i[0], (e.s - c) / y, (e.e - c) / y, o[a - 1]), this.addSegmentFromArray(l, i, h, g), g = !1, i.c = !1)
                            } else i.c = !1;
                            c += n.addedLength, h += 1
                        }
                        if (i._length && (i.setXYAt(i.v[p][0], i.v[p][1], "i", p), i.setXYAt(i.v[i._length - 1][0], i.v[i._length - 1][1], "o", i._length - 1)), c > e.e) break;
                        s < m - 1 && (i = t_.newElement(), g = !0, u.push(i), h = 0)
                    }
                    return u
                }, y([tR], tO), tO.prototype.initModifierProperties = function(t, e) {
                    this.getValue = this.processKeys, this.amount = tg.getProp(t, e.a, 0, null, this), this._isAnimated = !!this.amount.effectsSequence.length
                }, tO.prototype.processPath = function(t, e) {
                    var i, s, a, r, n, h, o = e / 100,
                        l = [0, 0],
                        p = t._length,
                        f = 0;
                    for (f = 0; f < p; f += 1) l[0] += t.v[f][0], l[1] += t.v[f][1];
                    l[0] /= p, l[1] /= p;
                    var d = t_.newElement();
                    for (f = 0, d.c = t.c; f < p; f += 1) i = t.v[f][0] + (l[0] - t.v[f][0]) * o, s = t.v[f][1] + (l[1] - t.v[f][1]) * o, a = t.o[f][0] + -((l[0] - t.o[f][0]) * o), r = t.o[f][1] + -((l[1] - t.o[f][1]) * o), n = t.i[f][0] + -((l[0] - t.i[f][0]) * o), h = t.i[f][1] + -((l[1] - t.i[f][1]) * o), d.setTripleAt(i, s, a, r, n, h, f);
                    return d
                }, tO.prototype.processShapes = function(t) {
                    var e, i, s, a, r, n, h = this.shapes.length,
                        o = this.amount.v;
                    if (0 !== o)
                        for (i = 0; i < h; i += 1) {
                            if (n = (r = this.shapes[i]).localShapeCollection, !(!r.shape._mdf && !this._mdf && !t))
                                for (n.releaseShapes(), r.shape._mdf = !0, e = r.shape.paths.shapes, a = r.shape.paths._length, s = 0; s < a; s += 1) n.addShape(this.processPath(e[s], o));
                            r.shape.paths = r.localShapeCollection
                        }
                    this.dynamicProperties.length || (this._mdf = !1)
                };
                var tB = function() {
                    var t = [0, 0];

                    function e(t, e, i) {
                        if (this.elem = t, this.frameId = -1, this.propType = "transform", this.data = e, this.v = new tS, this.pre = new tS, this.appliedTransformations = 0, this.initDynamicPropertyContainer(i || t), e.p && e.p.s ? (this.px = tg.getProp(t, e.p.x, 0, 0, this), this.py = tg.getProp(t, e.p.y, 0, 0, this), e.p.z && (this.pz = tg.getProp(t, e.p.z, 0, 0, this))) : this.p = tg.getProp(t, e.p || {
                                k: [0, 0, 0]
                            }, 1, 0, this), e.rx) {
                            if (this.rx = tg.getProp(t, e.rx, 0, E, this), this.ry = tg.getProp(t, e.ry, 0, E, this), this.rz = tg.getProp(t, e.rz, 0, E, this), e.or.k[0].ti) {
                                var s, a = e.or.k.length;
                                for (s = 0; s < a; s += 1) e.or.k[s].to = null, e.or.k[s].ti = null
                            }
                            this.or = tg.getProp(t, e.or, 1, E, this), this.or.sh = !0
                        } else this.r = tg.getProp(t, e.r || {
                            k: 0
                        }, 0, E, this);
                        e.sk && (this.sk = tg.getProp(t, e.sk, 0, E, this), this.sa = tg.getProp(t, e.sa, 0, E, this)), this.a = tg.getProp(t, e.a || {
                            k: [0, 0, 0]
                        }, 1, 0, this), this.s = tg.getProp(t, e.s || {
                            k: [100, 100, 100]
                        }, 1, .01, this), e.o ? this.o = tg.getProp(t, e.o, 0, .01, t) : this.o = {
                            _mdf: !1,
                            v: 1
                        }, this._isDirty = !0, this.dynamicProperties.length || this.getValue(!0)
                    }
                    return e.prototype = {
                        applyToMatrix: function(t) {
                            var e = this._mdf;
                            this.iterateDynamicProperties(), this._mdf = this._mdf || e, this.a && t.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.s && t.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && t.skewFromAxis(-this.sk.v, this.sa.v), this.r ? t.rotate(-this.r.v) : t.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.data.p.s ? this.data.p.z ? t.translate(this.px.v, this.py.v, -this.pz.v) : t.translate(this.px.v, this.py.v, 0) : t.translate(this.p.v[0], this.p.v[1], -this.p.v[2])
                        },
                        getValue: function(e) {
                            if (this.elem.globalData.frameId !== this.frameId) {
                                if (this._isDirty && (this.precalculateMatrix(), this._isDirty = !1), this.iterateDynamicProperties(), this._mdf || e) {
                                    var i;
                                    if (this.v.cloneFromProps(this.pre.props), this.appliedTransformations < 1 && this.v.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations < 2 && this.v.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && this.appliedTransformations < 3 && this.v.skewFromAxis(-this.sk.v, this.sa.v), this.r && this.appliedTransformations < 4 ? this.v.rotate(-this.r.v) : !this.r && this.appliedTransformations < 4 && this.v.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.autoOriented) {
                                        if (i = this.elem.globalData.frameRate, this.p && this.p.keyframes && this.p.getValueAtTime) this.p._caching.lastFrame + this.p.offsetTime <= this.p.keyframes[0].t ? (s = this.p.getValueAtTime((this.p.keyframes[0].t + .01) / i, 0), a = this.p.getValueAtTime(this.p.keyframes[0].t / i, 0)) : this.p._caching.lastFrame + this.p.offsetTime >= this.p.keyframes[this.p.keyframes.length - 1].t ? (s = this.p.getValueAtTime(this.p.keyframes[this.p.keyframes.length - 1].t / i, 0), a = this.p.getValueAtTime((this.p.keyframes[this.p.keyframes.length - 1].t - .05) / i, 0)) : (s = this.p.pv, a = this.p.getValueAtTime((this.p._caching.lastFrame + this.p.offsetTime - .01) / i, this.p.offsetTime));
                                        else if (this.px && this.px.keyframes && this.py.keyframes && this.px.getValueAtTime && this.py.getValueAtTime) {
                                            s = [], a = [];
                                            var s, a, r = this.px,
                                                n = this.py;
                                            r._caching.lastFrame + r.offsetTime <= r.keyframes[0].t ? (s[0] = r.getValueAtTime((r.keyframes[0].t + .01) / i, 0), s[1] = n.getValueAtTime((n.keyframes[0].t + .01) / i, 0), a[0] = r.getValueAtTime(r.keyframes[0].t / i, 0), a[1] = n.getValueAtTime(n.keyframes[0].t / i, 0)) : r._caching.lastFrame + r.offsetTime >= r.keyframes[r.keyframes.length - 1].t ? (s[0] = r.getValueAtTime(r.keyframes[r.keyframes.length - 1].t / i, 0), s[1] = n.getValueAtTime(n.keyframes[n.keyframes.length - 1].t / i, 0), a[0] = r.getValueAtTime((r.keyframes[r.keyframes.length - 1].t - .01) / i, 0), a[1] = n.getValueAtTime((n.keyframes[n.keyframes.length - 1].t - .01) / i, 0)) : (s = [r.pv, n.pv], a[0] = r.getValueAtTime((r._caching.lastFrame + r.offsetTime - .01) / i, r.offsetTime), a[1] = n.getValueAtTime((n._caching.lastFrame + n.offsetTime - .01) / i, n.offsetTime))
                                        } else s = a = t;
                                        this.v.rotate(-Math.atan2(s[1] - a[1], s[0] - a[0]))
                                    }
                                    this.data.p && this.data.p.s ? this.data.p.z ? this.v.translate(this.px.v, this.py.v, -this.pz.v) : this.v.translate(this.px.v, this.py.v, 0) : this.v.translate(this.p.v[0], this.p.v[1], -this.p.v[2])
                                }
                                this.frameId = this.elem.globalData.frameId
                            }
                        },
                        precalculateMatrix: function() {
                            if (!this.a.k && (this.pre.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations = 1, !this.s.effectsSequence.length)) {
                                if (this.pre.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.appliedTransformations = 2, this.sk) {
                                    if (this.sk.effectsSequence.length || this.sa.effectsSequence.length) return;
                                    this.pre.skewFromAxis(-this.sk.v, this.sa.v), this.appliedTransformations = 3
                                }
                                this.r ? this.r.effectsSequence.length || (this.pre.rotate(-this.r.v), this.appliedTransformations = 4) : this.rz.effectsSequence.length || this.ry.effectsSequence.length || this.rx.effectsSequence.length || this.or.effectsSequence.length || (this.pre.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.appliedTransformations = 4)
                            }
                        },
                        autoOrient: function() {}
                    }, y([ty], e), e.prototype.addDynamicProperty = function(t) {
                        this._addDynamicProperty(t), this.elem.addDynamicProperty(t), this._isDirty = !0
                    }, e.prototype._addDynamicProperty = ty.prototype.addDynamicProperty, {
                        getTransformProperty: function(t, i, s) {
                            return new e(t, i, s)
                        }
                    }
                }();

                function tq() {}

                function tj() {}

                function tW(t, e) {
                    return 1e5 * Math.abs(t - e) <= Math.min(Math.abs(t), Math.abs(e))
                }

                function tX(t) {
                    return 1e-5 >= Math.abs(t)
                }

                function tH(t, e, i) {
                    return [t[0] * (1 - i) + e[0] * i, t[1] * (1 - i) + e[1] * i]
                }

                function tY(t, e, i, s) {
                    return [-t + 3 * e - 3 * i + s, 3 * t - 6 * e + 3 * i, -3 * t + 3 * e, t]
                }

                function tG(t) {
                    return new tJ(t, t, t, t, !1)
                }

                function tJ(t, e, i, s, a) {
                    a && t2(t, e) && (e = tH(t, s, 1 / 3)), a && t2(i, s) && (i = tH(t, s, 2 / 3));
                    var r = tY(t[0], e[0], i[0], s[0]),
                        n = tY(t[1], e[1], i[1], s[1]);
                    this.a = [r[0], n[0]], this.b = [r[1], n[1]], this.c = [r[2], n[2]], this.d = [r[3], n[3]], this.points = [t, e, i, s]
                }

                function tK(t, e) {
                    var i = t.points[0][e],
                        s = t.points[t.points.length - 1][e];
                    if (i > s) {
                        var a = s;
                        s = i, i = a
                    }
                    for (var r = function(t, e, i) {
                            if (0 === t) return [];
                            var s = e * e - 4 * t * i;
                            if (s < 0) return [];
                            var a = -e / (2 * t);
                            if (0 === s) return [a];
                            var r = Math.sqrt(s) / (2 * t);
                            return [a - r, a + r]
                        }(3 * t.a[e], 2 * t.b[e], t.c[e]), n = 0; n < r.length; n += 1)
                        if (r[n] > 0 && r[n] < 1) {
                            var h = t.point(r[n])[e];
                            h < i ? i = h : h > s && (s = h)
                        }
                    return {
                        min: i,
                        max: s
                    }
                }

                function tU(t, e, i) {
                    var s = t.boundingBox();
                    return {
                        cx: s.cx,
                        cy: s.cy,
                        width: s.width,
                        height: s.height,
                        bez: t,
                        t: (e + i) / 2,
                        t1: e,
                        t2: i
                    }
                }

                function tZ(t) {
                    var e = t.bez.split(.5);
                    return [tU(e[0], t.t1, t.t), tU(e[1], t.t, t.t2)]
                }

                function tQ(t, e) {
                    return [t[1] * e[2] - t[2] * e[1], t[2] * e[0] - t[0] * e[2], t[0] * e[1] - t[1] * e[0]]
                }

                function t$(t, e, i, s) {
                    var a = [t[0], t[1], 1],
                        r = [e[0], e[1], 1],
                        n = [i[0], i[1], 1],
                        h = [s[0], s[1], 1],
                        o = tQ(tQ(a, r), tQ(n, h));
                    return tX(o[2]) ? null : [o[0] / o[2], o[1] / o[2]]
                }

                function t0(t, e, i) {
                    return [t[0] + Math.cos(e) * i, t[1] - Math.sin(e) * i]
                }

                function t1(t, e) {
                    return Math.hypot(t[0] - e[0], t[1] - e[1])
                }

                function t2(t, e) {
                    return tW(t[0], e[0]) && tW(t[1], e[1])
                }

                function t3() {}

                function t5(t, e, i, s, a, r, n) {
                    var h = i - Math.PI / 2,
                        o = i + Math.PI / 2,
                        l = e[0] + Math.cos(i) * s * a,
                        p = e[1] - Math.sin(i) * s * a;
                    t.setTripleAt(l, p, l + Math.cos(h) * r, p - Math.sin(h) * r, l + Math.cos(o) * n, p - Math.sin(o) * n, t.length())
                }

                function t9(t, e, i, s, a, r, n) {
                    var h, o, l, p, f, d, m, c = (h = 0 === i ? e.length() - 1 : i - 1, o = (i + 1) % e.length(), l = e.v[h], Math.atan2(0, 1) - Math.atan2((f = [(p = e.v[o])[0] - l[0], p[1] - l[1]], m = [Math.cos(d = -(.5 * Math.PI)) * f[0] - Math.sin(d) * f[1], Math.sin(d) * f[0] + Math.cos(d) * f[1]])[1], m[0])),
                        u = e.v[i % e._length],
                        g = e.v[0 === i ? e._length - 1 : i - 1],
                        y = e.v[(i + 1) % e._length],
                        v = 2 === r ? Math.sqrt(Math.pow(u[0] - g[0], 2) + Math.pow(u[1] - g[1], 2)) : 0,
                        b = 2 === r ? Math.sqrt(Math.pow(u[0] - y[0], 2) + Math.pow(u[1] - y[1], 2)) : 0;
                    t5(t, e.v[i % e._length], c, n, s, b / ((a + 1) * 2), v / ((a + 1) * 2), r)
                }

                function t4(t, e, i) {
                    var s = Math.atan2(e[0] - t[0], e[1] - t[1]);
                    return [t0(t, s, i), t0(e, s, i)]
                }

                function t6(t, e) {
                    i = (o = t4(t.points[0], t.points[1], e))[0], s = o[1], a = (o = t4(t.points[1], t.points[2], e))[0], r = o[1], n = (o = t4(t.points[2], t.points[3], e))[0], h = o[1];
                    var i, s, a, r, n, h, o, l = t$(i, s, a, r);
                    null === l && (l = s);
                    var p = t$(n, h, a, r);
                    return null === p && (p = n), new tJ(i, l, p, h)
                }

                function t8(t, e, i, s, a) {
                    var r = e.points[3],
                        n = i.points[0];
                    if (3 === s || t2(r, n)) return r;
                    if (2 === s) {
                        var h = -e.tangentAngle(1),
                            o = -i.tangentAngle(0) + Math.PI,
                            l = t$(r, t0(r, h + Math.PI / 2, 100), n, t0(n, h + Math.PI / 2, 100)),
                            p = l ? t1(l, r) : t1(r, n) / 2,
                            f = t0(r, h, 2 * p * .5519);
                        return t.setXYAt(f[0], f[1], "o", t.length() - 1), f = t0(n, o, 2 * p * .5519), t.setTripleAt(n[0], n[1], n[0], n[1], f[0], f[1], t.length()), n
                    }
                    var d = t2(r, e.points[2]) ? e.points[0] : e.points[2],
                        m = t2(n, i.points[1]) ? i.points[3] : i.points[1],
                        c = t$(d, r, n, m);
                    return c && t1(c, r) < a ? (t.setTripleAt(c[0], c[1], c[0], c[1], c[0], c[1], t.length()), c) : r
                }

                function t7(t, e) {
                    var i = t.intersections(e);
                    return (i.length && tW(i[0][0], 1) && i.shift(), i.length) ? i[0] : null
                }

                function et(t, e) {
                    var i = t.slice(),
                        s = e.slice(),
                        a = t7(t[t.length - 1], e[0]);
                    return (a && (i[t.length - 1] = t[t.length - 1].split(a[0])[0], s[0] = e[0].split(a[1])[1]), t.length > 1 && e.length > 1 && (a = t7(t[0], e[e.length - 1]))) ? [
                        [t[0].split(a[0])[0]],
                        [e[e.length - 1].split(a[1])[1]]
                    ] : [i, s]
                }

                function ee(t, e) {
                    var i, s, a, r, n = t.inflectionPoints();
                    if (0 === n.length) return [t6(t, e)];
                    if (1 === n.length || tW(n[1], 1)) return i = (a = t.split(n[0]))[0], s = a[1], [t6(i, e), t6(s, e)];
                    i = (a = t.split(n[0]))[0];
                    var h = (n[1] - n[0]) / (1 - n[0]);
                    return r = (a = a[1].split(h))[0], s = a[1], [t6(i, e), t6(r, e), t6(s, e)]
                }

                function ei() {}

                function es(t) {
                    for (var e = t.fStyle ? t.fStyle.split(" ") : [], i = "normal", s = "normal", a = e.length, r = 0; r < a; r += 1) switch (e[r].toLowerCase()) {
                        case "italic":
                            s = "italic";
                            break;
                        case "bold":
                            i = "700";
                            break;
                        case "black":
                            i = "900";
                            break;
                        case "medium":
                            i = "500";
                            break;
                        case "regular":
                        case "normal":
                            i = "400";
                            break;
                        case "light":
                        case "thin":
                            i = "200"
                    }
                    return {
                        style: s,
                        weight: t.fWeight || i
                    }
                }
                y([tR], tq), tq.prototype.initModifierProperties = function(t, e) {
                    this.getValue = this.processKeys, this.c = tg.getProp(t, e.c, 0, null, this), this.o = tg.getProp(t, e.o, 0, null, this), this.tr = tB.getTransformProperty(t, e.tr, this), this.so = tg.getProp(t, e.tr.so, 0, .01, this), this.eo = tg.getProp(t, e.tr.eo, 0, .01, this), this.data = e, this.dynamicProperties.length || this.getValue(!0), this._isAnimated = !!this.dynamicProperties.length, this.pMatrix = new tS, this.rMatrix = new tS, this.sMatrix = new tS, this.tMatrix = new tS, this.matrix = new tS
                }, tq.prototype.applyTransforms = function(t, e, i, s, a, r) {
                    var n = r ? -1 : 1,
                        h = s.s.v[0] + (1 - s.s.v[0]) * (1 - a),
                        o = s.s.v[1] + (1 - s.s.v[1]) * (1 - a);
                    t.translate(s.p.v[0] * n * a, s.p.v[1] * n * a, s.p.v[2]), e.translate(-s.a.v[0], -s.a.v[1], s.a.v[2]), e.rotate(-s.r.v * n * a), e.translate(s.a.v[0], s.a.v[1], s.a.v[2]), i.translate(-s.a.v[0], -s.a.v[1], s.a.v[2]), i.scale(r ? 1 / h : h, r ? 1 / o : o), i.translate(s.a.v[0], s.a.v[1], s.a.v[2])
                }, tq.prototype.init = function(t, e, i, s) {
                    for (this.elem = t, this.arr = e, this.pos = i, this.elemsData = s, this._currentCopies = 0, this._elements = [], this._groups = [], this.frameId = -1, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e[i]); i > 0;) i -= 1, this._elements.unshift(e[i]);
                    this.dynamicProperties.length ? this.k = !0 : this.getValue(!0)
                }, tq.prototype.resetElements = function(t) {
                    var e, i = t.length;
                    for (e = 0; e < i; e += 1) t[e]._processed = !1, "gr" === t[e].ty && this.resetElements(t[e].it)
                }, tq.prototype.cloneElements = function(t) {
                    var e = JSON.parse(JSON.stringify(t));
                    return this.resetElements(e), e
                }, tq.prototype.changeGroupRender = function(t, e) {
                    var i, s = t.length;
                    for (i = 0; i < s; i += 1) t[i]._render = e, "gr" === t[i].ty && this.changeGroupRender(t[i].it, e)
                }, tq.prototype.processShapes = function(t) {
                    var e = !1;
                    if (this._mdf || t) {
                        var i, s, a, r, n, h, o, l, p = Math.ceil(this.c.v);
                        if (this._groups.length < p) {
                            for (; this._groups.length < p;) {
                                var f = {
                                    it: this.cloneElements(this._elements),
                                    ty: "gr"
                                };
                                f.it.push({
                                    a: {
                                        a: 0,
                                        ix: 1,
                                        k: [0, 0]
                                    },
                                    nm: "Transform",
                                    o: {
                                        a: 0,
                                        ix: 7,
                                        k: 100
                                    },
                                    p: {
                                        a: 0,
                                        ix: 2,
                                        k: [0, 0]
                                    },
                                    r: {
                                        a: 1,
                                        ix: 6,
                                        k: [{
                                            s: 0,
                                            e: 0,
                                            t: 0
                                        }, {
                                            s: 0,
                                            e: 0,
                                            t: 1
                                        }]
                                    },
                                    s: {
                                        a: 0,
                                        ix: 3,
                                        k: [100, 100]
                                    },
                                    sa: {
                                        a: 0,
                                        ix: 5,
                                        k: 0
                                    },
                                    sk: {
                                        a: 0,
                                        ix: 4,
                                        k: 0
                                    },
                                    ty: "tr"
                                }), this.arr.splice(0, 0, f), this._groups.splice(0, 0, f), this._currentCopies += 1
                            }
                            this.elem.reloadShapes(), e = !0
                        }
                        for (a = 0, n = 0; a <= this._groups.length - 1; a += 1) {
                            if (h = n < p, this._groups[a]._render = h, this.changeGroupRender(this._groups[a].it, h), !h) {
                                var d = this.elemsData[a].it,
                                    m = d[d.length - 1];
                                0 !== m.transform.op.v ? (m.transform.op._mdf = !0, m.transform.op.v = 0) : m.transform.op._mdf = !1
                            }
                            n += 1
                        }
                        this._currentCopies = p;
                        var c = this.o.v,
                            u = c % 1,
                            g = c > 0 ? Math.floor(c) : Math.ceil(c),
                            y = this.pMatrix.props,
                            v = this.rMatrix.props,
                            b = this.sMatrix.props;
                        this.pMatrix.reset(), this.rMatrix.reset(), this.sMatrix.reset(), this.tMatrix.reset(), this.matrix.reset();
                        var _ = 0;
                        if (c > 0) {
                            for (; _ < g;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), _ += 1;
                            u && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, u, !1), _ += u)
                        } else if (c < 0) {
                            for (; _ > g;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !0), _ -= 1;
                            u && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, -u, !0), _ -= u)
                        }
                        for (a = 1 === this.data.m ? 0 : this._currentCopies - 1, r = 1 === this.data.m ? 1 : -1, n = this._currentCopies; n;) {
                            if (l = (s = (i = this.elemsData[a].it)[i.length - 1].transform.mProps.v.props).length, i[i.length - 1].transform.mProps._mdf = !0, i[i.length - 1].transform.op._mdf = !0, i[i.length - 1].transform.op.v = 1 === this._currentCopies ? this.so.v : this.so.v + (this.eo.v - this.so.v) * (a / (this._currentCopies - 1)), 0 !== _) {
                                for ((0 !== a && 1 === r || a !== this._currentCopies - 1 && -1 === r) && this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), this.matrix.transform(v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11], v[12], v[13], v[14], v[15]), this.matrix.transform(b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15]), this.matrix.transform(y[0], y[1], y[2], y[3], y[4], y[5], y[6], y[7], y[8], y[9], y[10], y[11], y[12], y[13], y[14], y[15]), o = 0; o < l; o += 1) s[o] = this.matrix.props[o];
                                this.matrix.reset()
                            } else
                                for (this.matrix.reset(), o = 0; o < l; o += 1) s[o] = this.matrix.props[o];
                            _ += 1, n -= 1, a += r
                        }
                    } else
                        for (n = this._currentCopies, a = 0, r = 1; n;) s = (i = this.elemsData[a].it)[i.length - 1].transform.mProps.v.props, i[i.length - 1].transform.mProps._mdf = !1, i[i.length - 1].transform.op._mdf = !1, n -= 1, a += r;
                    return e
                }, tq.prototype.addShape = function() {}, y([tR], tj), tj.prototype.initModifierProperties = function(t, e) {
                    this.getValue = this.processKeys, this.rd = tg.getProp(t, e.r, 0, null, this), this._isAnimated = !!this.rd.effectsSequence.length
                }, tj.prototype.processPath = function(t, e) {
                    var i, s, a, r, n, h, o, l, p, f, d, m, c, u = t_.newElement();
                    u.c = t.c;
                    var g = t._length,
                        y = 0;
                    for (i = 0; i < g; i += 1) s = t.v[i], r = t.o[i], a = t.i[i], s[0] === r[0] && s[1] === r[1] && s[0] === a[0] && s[1] === a[1] ? 0 !== i && i !== g - 1 || t.c ? (n = 0 === i ? t.v[g - 1] : t.v[i - 1], o = (h = Math.sqrt(Math.pow(s[0] - n[0], 2) + Math.pow(s[1] - n[1], 2))) ? Math.min(h / 2, e) / h : 0, l = m = s[0] + (n[0] - s[0]) * o, p = c = s[1] - (s[1] - n[1]) * o, f = l - (l - s[0]) * .5519, d = p - (p - s[1]) * .5519, u.setTripleAt(l, p, f, d, m, c, y), y += 1, n = i === g - 1 ? t.v[0] : t.v[i + 1], o = (h = Math.sqrt(Math.pow(s[0] - n[0], 2) + Math.pow(s[1] - n[1], 2))) ? Math.min(h / 2, e) / h : 0, l = f = s[0] + (n[0] - s[0]) * o, p = d = s[1] + (n[1] - s[1]) * o, m = l - (l - s[0]) * .5519, c = p - (p - s[1]) * .5519, u.setTripleAt(l, p, f, d, m, c, y), y += 1) : (u.setTripleAt(s[0], s[1], r[0], r[1], a[0], a[1], y), y += 1) : (u.setTripleAt(t.v[i][0], t.v[i][1], t.o[i][0], t.o[i][1], t.i[i][0], t.i[i][1], y), y += 1);
                    return u
                }, tj.prototype.processShapes = function(t) {
                    var e, i, s, a, r, n, h = this.shapes.length,
                        o = this.rd.v;
                    if (0 !== o)
                        for (i = 0; i < h; i += 1) {
                            if (n = (r = this.shapes[i]).localShapeCollection, !(!r.shape._mdf && !this._mdf && !t))
                                for (n.releaseShapes(), r.shape._mdf = !0, e = r.shape.paths.shapes, a = r.shape.paths._length, s = 0; s < a; s += 1) n.addShape(this.processPath(e[s], o));
                            r.shape.paths = r.localShapeCollection
                        }
                    this.dynamicProperties.length || (this._mdf = !1)
                }, tJ.prototype.point = function(t) {
                    return [((this.a[0] * t + this.b[0]) * t + this.c[0]) * t + this.d[0], ((this.a[1] * t + this.b[1]) * t + this.c[1]) * t + this.d[1]]
                }, tJ.prototype.derivative = function(t) {
                    return [(3 * t * this.a[0] + 2 * this.b[0]) * t + this.c[0], (3 * t * this.a[1] + 2 * this.b[1]) * t + this.c[1]]
                }, tJ.prototype.tangentAngle = function(t) {
                    var e = this.derivative(t);
                    return Math.atan2(e[1], e[0])
                }, tJ.prototype.normalAngle = function(t) {
                    var e = this.derivative(t);
                    return Math.atan2(e[0], e[1])
                }, tJ.prototype.inflectionPoints = function() {
                    var t = this.a[1] * this.b[0] - this.a[0] * this.b[1];
                    if (tX(t)) return [];
                    var e = -.5 * (this.a[1] * this.c[0] - this.a[0] * this.c[1]) / t,
                        i = e * e - 1 / 3 * (this.b[1] * this.c[0] - this.b[0] * this.c[1]) / t;
                    if (i < 0) return [];
                    var s = Math.sqrt(i);
                    return tX(s) ? s > 0 && s < 1 ? [e] : [] : [e - s, e + s].filter(function(t) {
                        return t > 0 && t < 1
                    })
                }, tJ.prototype.split = function(t) {
                    if (t <= 0) return [tG(this.points[0]), this];
                    if (t >= 1) return [this, tG(this.points[this.points.length - 1])];
                    var e = tH(this.points[0], this.points[1], t),
                        i = tH(this.points[1], this.points[2], t),
                        s = tH(this.points[2], this.points[3], t),
                        a = tH(e, i, t),
                        r = tH(i, s, t),
                        n = tH(a, r, t);
                    return [new tJ(this.points[0], e, a, n, !0), new tJ(n, r, s, this.points[3], !0)]
                }, tJ.prototype.bounds = function() {
                    return {
                        x: tK(this, 0),
                        y: tK(this, 1)
                    }
                }, tJ.prototype.boundingBox = function() {
                    var t = this.bounds();
                    return {
                        left: t.x.min,
                        right: t.x.max,
                        top: t.y.min,
                        bottom: t.y.max,
                        width: t.x.max - t.x.min,
                        height: t.y.max - t.y.min,
                        cx: (t.x.max + t.x.min) / 2,
                        cy: (t.y.max + t.y.min) / 2
                    }
                }, tJ.prototype.intersections = function(t, e, i) {
                    void 0 === e && (e = 2), void 0 === i && (i = 7);
                    var s = [];
                    return function t(e, i, s, a, r, n) {
                        if (2 * Math.abs(e.cx - i.cx) < e.width + i.width && 2 * Math.abs(e.cy - i.cy) < e.height + i.height) {
                            if (s >= n || e.width <= a && e.height <= a && i.width <= a && i.height <= a) {
                                r.push([e.t, i.t]);
                                return
                            }
                            var h = tZ(e),
                                o = tZ(i);
                            t(h[0], o[0], s + 1, a, r, n), t(h[0], o[1], s + 1, a, r, n), t(h[1], o[0], s + 1, a, r, n), t(h[1], o[1], s + 1, a, r, n)
                        }
                    }(tU(this, 0, 1), tU(t, 0, 1), 0, e, s, i), s
                }, tJ.shapeSegment = function(t, e) {
                    var i = (e + 1) % t.length();
                    return new tJ(t.v[e], t.o[e], t.i[i], t.v[i], !0)
                }, tJ.shapeSegmentInverted = function(t, e) {
                    var i = (e + 1) % t.length();
                    return new tJ(t.v[i], t.i[i], t.o[e], t.v[e], !0)
                }, y([tR], t3), t3.prototype.initModifierProperties = function(t, e) {
                    this.getValue = this.processKeys, this.amplitude = tg.getProp(t, e.s, 0, null, this), this.frequency = tg.getProp(t, e.r, 0, null, this), this.pointsType = tg.getProp(t, e.pt, 0, null, this), this._isAnimated = 0 !== this.amplitude.effectsSequence.length || 0 !== this.frequency.effectsSequence.length || 0 !== this.pointsType.effectsSequence.length
                }, t3.prototype.processPath = function(t, e, i, s) {
                    var a = t._length,
                        r = t_.newElement();
                    if (r.c = t.c, t.c || (a -= 1), 0 === a) return r;
                    var n = -1,
                        h = tJ.shapeSegment(t, 0);
                    t9(r, t, 0, e, i, s, n);
                    for (var o = 0; o < a; o += 1) n = function(t, e, i, s, a, r) {
                        for (var n = 0; n < s; n += 1) {
                            var h = (n + 1) / (s + 1),
                                o = 2 === a ? Math.sqrt(Math.pow(e.points[3][0] - e.points[0][0], 2) + Math.pow(e.points[3][1] - e.points[0][1], 2)) : 0,
                                l = e.normalAngle(h);
                            t5(t, e.point(h), l, r, i, o / ((s + 1) * 2), o / ((s + 1) * 2), a), r = -r
                        }
                        return r
                    }(r, h, e, i, s, -n), h = o !== a - 1 || t.c ? tJ.shapeSegment(t, (o + 1) % a) : null, t9(r, t, o + 1, e, i, s, n);
                    return r
                }, t3.prototype.processShapes = function(t) {
                    var e, i, s, a, r, n, h = this.shapes.length,
                        o = this.amplitude.v,
                        l = Math.max(0, Math.round(this.frequency.v)),
                        p = this.pointsType.v;
                    if (0 !== o)
                        for (i = 0; i < h; i += 1) {
                            if (n = (r = this.shapes[i]).localShapeCollection, !(!r.shape._mdf && !this._mdf && !t))
                                for (n.releaseShapes(), r.shape._mdf = !0, e = r.shape.paths.shapes, a = r.shape.paths._length, s = 0; s < a; s += 1) n.addShape(this.processPath(e[s], o, l, p));
                            r.shape.paths = r.localShapeCollection
                        }
                    this.dynamicProperties.length || (this._mdf = !1)
                }, y([tR], ei), ei.prototype.initModifierProperties = function(t, e) {
                    this.getValue = this.processKeys, this.amount = tg.getProp(t, e.a, 0, null, this), this.miterLimit = tg.getProp(t, e.ml, 0, null, this), this.lineJoin = e.lj, this._isAnimated = 0 !== this.amount.effectsSequence.length
                }, ei.prototype.processPath = function(t, e, i, s) {
                    var a, r, n, h = t_.newElement();
                    h.c = t.c;
                    var o = t.length();
                    t.c || (o -= 1);
                    var l = [];
                    for (a = 0; a < o; a += 1) n = tJ.shapeSegment(t, a), l.push(ee(n, e));
                    if (!t.c)
                        for (a = o - 1; a >= 0; a -= 1) n = tJ.shapeSegmentInverted(t, a), l.push(ee(n, e));
                    l = function(t) {
                        for (var e, i = 1; i < t.length; i += 1) e = et(t[i - 1], t[i]), t[i - 1] = e[0], t[i] = e[1];
                        return t.length > 1 && (e = et(t[t.length - 1], t[0]), t[t.length - 1] = e[0], t[0] = e[1]), t
                    }(l);
                    var p = null,
                        f = null;
                    for (a = 0; a < l.length; a += 1) {
                        var d = l[a];
                        for (f && (p = t8(h, f, d[0], i, s)), f = d[d.length - 1], r = 0; r < d.length; r += 1) n = d[r], p && t2(n.points[0], p) ? h.setXYAt(n.points[1][0], n.points[1][1], "o", h.length() - 1) : h.setTripleAt(n.points[0][0], n.points[0][1], n.points[1][0], n.points[1][1], n.points[0][0], n.points[0][1], h.length()), h.setTripleAt(n.points[3][0], n.points[3][1], n.points[3][0], n.points[3][1], n.points[2][0], n.points[2][1], h.length()), p = n.points[3]
                    }
                    return l.length && t8(h, f, l[0][0], i, s), h
                }, ei.prototype.processShapes = function(t) {
                    var e, i, s, a, r, n, h = this.shapes.length,
                        o = this.amount.v,
                        l = this.miterLimit.v,
                        p = this.lineJoin;
                    if (0 !== o)
                        for (i = 0; i < h; i += 1) {
                            if (n = (r = this.shapes[i]).localShapeCollection, !(!r.shape._mdf && !this._mdf && !t))
                                for (n.releaseShapes(), r.shape._mdf = !0, e = r.shape.paths.shapes, a = r.shape.paths._length, s = 0; s < a; s += 1) n.addShape(this.processPath(e[s], o, p, l));
                            r.shape.paths = r.localShapeCollection
                        }
                    this.dynamicProperties.length || (this._mdf = !1)
                };
                var ea = function() {
                    var t = {
                            w: 0,
                            size: 0,
                            shapes: [],
                            data: {
                                shapes: []
                            }
                        },
                        e = [];
                    e = e.concat([2304, 2305, 2306, 2307, 2362, 2363, 2364, 2364, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2387, 2388, 2389, 2390, 2391, 2402, 2403]);
                    var i = ["d83cdffb", "d83cdffc", "d83cdffd", "d83cdffe", "d83cdfff"];

                    function s(t, e) {
                        var i = g("span");
                        i.setAttribute("aria-hidden", !0), i.style.fontFamily = e;
                        var s = g("span");
                        s.innerText = "giItT1WQy@!-/#", i.style.position = "absolute", i.style.left = "-10000px", i.style.top = "-10000px", i.style.fontSize = "300px", i.style.fontVariant = "normal", i.style.fontStyle = "normal", i.style.fontWeight = "normal", i.style.letterSpacing = "0", i.appendChild(s), document.body.appendChild(i);
                        var a = s.offsetWidth;
                        return s.style.fontFamily = function(t) {
                            var e, i = t.split(","),
                                s = i.length,
                                a = [];
                            for (e = 0; e < s; e += 1) "sans-serif" !== i[e] && "monospace" !== i[e] && a.push(i[e]);
                            return a.join(",")
                        }(t) + ", " + e, {
                            node: s,
                            w: a,
                            parent: i
                        }
                    }

                    function a(t, e) {
                        var i, s = document.body && e ? "svg" : "canvas",
                            a = es(t);
                        if ("svg" === s) {
                            var r = $("text");
                            r.style.fontSize = "100px", r.setAttribute("font-family", t.fFamily), r.setAttribute("font-style", a.style), r.setAttribute("font-weight", a.weight), r.textContent = "1", t.fClass ? (r.style.fontFamily = "inherit", r.setAttribute("class", t.fClass)) : r.style.fontFamily = t.fFamily, e.appendChild(r), i = r
                        } else {
                            var n = new OffscreenCanvas(500, 500).getContext("2d");
                            n.font = a.style + " " + a.weight + " 100px " + t.fFamily, i = n
                        }
                        return {
                            measureText: function(t) {
                                return "svg" === s ? (i.textContent = t, i.getComputedTextLength()) : i.measureText(t).width
                            }
                        }
                    }
                    var r = function() {
                        this.fonts = [], this.chars = null, this.typekitLoaded = 0, this.isLoaded = !1, this._warned = !1, this.initTime = Date.now(), this.setIsLoadedBinded = this.setIsLoaded.bind(this), this.checkLoadedFontsBinded = this.checkLoadedFonts.bind(this)
                    };
                    return r.isModifier = function(t, e) {
                        var s = t.toString(16) + e.toString(16);
                        return -1 !== i.indexOf(s)
                    }, r.isZeroWidthJoiner = function(t, e) {
                        return e ? 65039 === t && 8205 === e : 8205 === t
                    }, r.isCombinedCharacter = function(t) {
                        return -1 !== e.indexOf(t)
                    }, r.prototype = {
                        addChars: function(t) {
                            if (t) {
                                this.chars || (this.chars = []);
                                var e, i, s, a = t.length,
                                    r = this.chars.length;
                                for (e = 0; e < a; e += 1) {
                                    for (i = 0, s = !1; i < r;) this.chars[i].style === t[e].style && this.chars[i].fFamily === t[e].fFamily && this.chars[i].ch === t[e].ch && (s = !0), i += 1;
                                    s || (this.chars.push(t[e]), r += 1)
                                }
                            }
                        },
                        addFonts: function(t, e) {
                            if (!t) {
                                this.isLoaded = !0;
                                return
                            }
                            if (this.chars) {
                                this.isLoaded = !0, this.fonts = t.list;
                                return
                            }
                            if (!document.body) {
                                this.isLoaded = !0, t.list.forEach(function(t) {
                                    t.helper = a(t), t.cache = {}
                                }), this.fonts = t.list;
                                return
                            }
                            var i = t.list,
                                r = i.length,
                                n = r;
                            for (h = 0; h < r; h += 1) {
                                var h, o, l, p = !0;
                                if (i[h].loaded = !1, i[h].monoCase = s(i[h].fFamily, "monospace"), i[h].sansCase = s(i[h].fFamily, "sans-serif"), i[h].fPath) {
                                    if ("p" === i[h].fOrigin || 3 === i[h].origin) {
                                        if ((o = document.querySelectorAll('style[f-forigin="p"][f-family="' + i[h].fFamily + '"], style[f-origin="3"][f-family="' + i[h].fFamily + '"]')).length > 0 && (p = !1), p) {
                                            var f = g("style");
                                            f.setAttribute("f-forigin", i[h].fOrigin), f.setAttribute("f-origin", i[h].origin), f.setAttribute("f-family", i[h].fFamily), f.type = "text/css", f.innerText = "@font-face {font-family: " + i[h].fFamily + "; font-style: normal; src: url('" + i[h].fPath + "');}", e.appendChild(f)
                                        }
                                    } else if ("g" === i[h].fOrigin || 1 === i[h].origin) {
                                        for (l = 0, o = document.querySelectorAll('link[f-forigin="g"], link[f-origin="1"]'); l < o.length; l += 1) - 1 !== o[l].href.indexOf(i[h].fPath) && (p = !1);
                                        if (p) {
                                            var d = g("link");
                                            d.setAttribute("f-forigin", i[h].fOrigin), d.setAttribute("f-origin", i[h].origin), d.type = "text/css", d.rel = "stylesheet", d.href = i[h].fPath, document.body.appendChild(d)
                                        }
                                    } else if ("t" === i[h].fOrigin || 2 === i[h].origin) {
                                        for (l = 0, o = document.querySelectorAll('script[f-forigin="t"], script[f-origin="2"]'); l < o.length; l += 1) i[h].fPath === o[l].src && (p = !1);
                                        if (p) {
                                            var m = g("link");
                                            m.setAttribute("f-forigin", i[h].fOrigin), m.setAttribute("f-origin", i[h].origin), m.setAttribute("rel", "stylesheet"), m.setAttribute("href", i[h].fPath), e.appendChild(m)
                                        }
                                    }
                                } else i[h].loaded = !0, n -= 1;
                                i[h].helper = a(i[h], e), i[h].cache = {}, this.fonts.push(i[h])
                            }
                            0 === n ? this.isLoaded = !0 : setTimeout(this.checkLoadedFonts.bind(this), 100)
                        },
                        getCharData: function(e, i, s) {
                            for (var a = 0, r = this.chars.length; a < r;) {
                                if (this.chars[a].ch === e && this.chars[a].style === i && this.chars[a].fFamily === s) return this.chars[a];
                                a += 1
                            }
                            return ("string" == typeof e && 13 !== e.charCodeAt(0) || !e) && console && console.warn && !this._warned && (this._warned = !0, console.warn("Missing character from exported characters list: ", e, i, s)), t
                        },
                        getFontByName: function(t) {
                            for (var e = 0, i = this.fonts.length; e < i;) {
                                if (this.fonts[e].fName === t) return this.fonts[e];
                                e += 1
                            }
                            return this.fonts[0]
                        },
                        measureText: function(t, e, i) {
                            var s = this.getFontByName(e),
                                a = t.charCodeAt(0);
                            if (!s.cache[a + 1]) {
                                var r = s.helper;
                                if (" " === t) {
                                    var n = r.measureText("|" + t + "|"),
                                        h = r.measureText("||");
                                    s.cache[a + 1] = (n - h) / 100
                                } else s.cache[a + 1] = r.measureText(t) / 100
                            }
                            return s.cache[a + 1] * i
                        },
                        checkLoadedFonts: function() {
                            var t, e, i, s = this.fonts.length,
                                a = s;
                            for (t = 0; t < s; t += 1) this.fonts[t].loaded ? a -= 1 : "n" === this.fonts[t].fOrigin || 0 === this.fonts[t].origin ? this.fonts[t].loaded = !0 : (e = this.fonts[t].monoCase.node, i = this.fonts[t].monoCase.w, e.offsetWidth !== i ? (a -= 1, this.fonts[t].loaded = !0) : (e = this.fonts[t].sansCase.node, i = this.fonts[t].sansCase.w, e.offsetWidth !== i && (a -= 1, this.fonts[t].loaded = !0)), this.fonts[t].loaded && (this.fonts[t].sansCase.parent.parentNode.removeChild(this.fonts[t].sansCase.parent), this.fonts[t].monoCase.parent.parentNode.removeChild(this.fonts[t].monoCase.parent)));
                            0 !== a && Date.now() - this.initTime < 5e3 ? setTimeout(this.checkLoadedFontsBinded, 20) : setTimeout(this.setIsLoadedBinded, 10)
                        },
                        setIsLoaded: function() {
                            this.isLoaded = !0
                        }
                    }, r
                }();

                function er() {}
                er.prototype = {
                    initRenderable: function() {
                        this.isInRange = !1, this.hidden = !1, this.isTransparent = !1, this.renderableComponents = []
                    },
                    addRenderableComponent: function(t) {
                        -1 === this.renderableComponents.indexOf(t) && this.renderableComponents.push(t)
                    },
                    removeRenderableComponent: function(t) {
                        -1 !== this.renderableComponents.indexOf(t) && this.renderableComponents.splice(this.renderableComponents.indexOf(t), 1)
                    },
                    prepareRenderableFrame: function(t) {
                        this.checkLayerLimits(t)
                    },
                    checkTransparency: function() {
                        this.finalTransform.mProp.o.v <= 0 ? !this.isTransparent && this.globalData.renderConfig.hideOnTransparent && (this.isTransparent = !0, this.hide()) : this.isTransparent && (this.isTransparent = !1, this.show())
                    },
                    checkLayerLimits: function(t) {
                        this.data.ip - this.data.st <= t && this.data.op - this.data.st > t ? !0 !== this.isInRange && (this.globalData._mdf = !0, this._mdf = !0, this.isInRange = !0, this.show()) : !1 !== this.isInRange && (this.globalData._mdf = !0, this.isInRange = !1, this.hide())
                    },
                    renderRenderable: function() {
                        var t, e = this.renderableComponents.length;
                        for (t = 0; t < e; t += 1) this.renderableComponents[t].renderFrame(this._isFirstFrame)
                    },
                    sourceRectAtTime: function() {
                        return {
                            top: 0,
                            left: 0,
                            width: 100,
                            height: 100
                        }
                    },
                    getLayerSize: function() {
                        return 5 === this.data.ty ? {
                            w: this.data.textData.width,
                            h: this.data.textData.height
                        } : {
                            w: this.data.width,
                            h: this.data.height
                        }
                    }
                };
                var en = (l = {
                    0: "source-over",
                    1: "multiply",
                    2: "screen",
                    3: "overlay",
                    4: "darken",
                    5: "lighten",
                    6: "color-dodge",
                    7: "color-burn",
                    8: "hard-light",
                    9: "soft-light",
                    10: "difference",
                    11: "exclusion",
                    12: "hue",
                    13: "saturation",
                    14: "color",
                    15: "luminosity"
                }, function(t) {
                    return l[t] || ""
                });

                function eh(t, e, i) {
                    this.p = tg.getProp(e, t.v, 0, 0, i)
                }

                function eo(t, e, i) {
                    this.p = tg.getProp(e, t.v, 0, 0, i)
                }

                function el(t, e, i) {
                    this.p = tg.getProp(e, t.v, 1, 0, i)
                }

                function ep(t, e, i) {
                    this.p = tg.getProp(e, t.v, 1, 0, i)
                }

                function ef(t, e, i) {
                    this.p = tg.getProp(e, t.v, 0, 0, i)
                }

                function ed(t, e, i) {
                    this.p = tg.getProp(e, t.v, 0, 0, i)
                }

                function em(t, e, i) {
                    this.p = tg.getProp(e, t.v, 0, 0, i)
                }

                function ec() {
                    this.p = {}
                }

                function eu(t, e) {
                    var i, s, a = t.ef || [];
                    this.effectElements = [];
                    var r = a.length;
                    for (i = 0; i < r; i += 1) s = new eg(a[i], e), this.effectElements.push(s)
                }

                function eg(t, e) {
                    this.init(t, e)
                }

                function ey() {}

                function ev() {}

                function eb(t, e, i) {
                    this.initFrame(), this.initRenderable(), this.assetData = e.getAssetData(t.refId), this.footageData = e.imageLoader.getAsset(this.assetData), this.initBaseData(t, e, i)
                }

                function e_(t, e, i) {
                    this.initFrame(), this.initRenderable(), this.assetData = e.getAssetData(t.refId), this.initBaseData(t, e, i), this._isPlaying = !1, this._canPlay = !1;
                    var s = this.globalData.getAssetsPath(this.assetData);
                    this.audio = this.globalData.audioController.createAudio(s), this._currentTime = 0, this.globalData.audioController.addAudio(this), this._volumeMultiplier = 1, this._volume = 1, this._previousVolume = null, this.tm = t.tm ? tg.getProp(this, t.tm, 0, e.frameRate, this) : {
                        _placeholder: !0
                    }, this.lv = tg.getProp(this, t.au && t.au.lv ? t.au.lv : {
                        k: [100]
                    }, 1, .01, this)
                }

                function ek() {}

                function eA() {}

                function eP(t, e, i) {
                    this.data = t, this.element = e, this.globalData = i, this.storedData = [], this.masksProperties = this.data.masksProperties || [], this.maskElement = null;
                    var s = this.globalData.defs,
                        a = this.masksProperties ? this.masksProperties.length : 0;
                    this.viewData = _(a), this.solidPath = "";
                    var r = this.masksProperties,
                        n = 0,
                        h = [],
                        o = B(),
                        l = "clipPath",
                        p = "clip-path";
                    for (f = 0; f < a; f += 1)
                        if (("a" !== r[f].mode && "n" !== r[f].mode || r[f].inv || 100 !== r[f].o.k || r[f].o.x) && (l = "mask", p = "mask"), ("s" === r[f].mode || "i" === r[f].mode) && 0 === n ? ((g = $("rect")).setAttribute("fill", "#ffffff"), g.setAttribute("width", this.element.comp.data.w || 0), g.setAttribute("height", this.element.comp.data.h || 0), h.push(g)) : g = null, d = $("path"), "n" === r[f].mode) this.viewData[f] = {
                            op: tg.getProp(this.element, r[f].o, 0, .01, this.element),
                            prop: tP.getShapeProp(this.element, r[f], 3),
                            elem: d,
                            lastPath: ""
                        }, s.appendChild(d);
                        else {
                            if (n += 1, d.setAttribute("fill", "s" === r[f].mode ? "#000000" : "#ffffff"), d.setAttribute("clip-rule", "nonzero"), 0 !== r[f].x.k ? (l = "mask", p = "mask", b = tg.getProp(this.element, r[f].x, 0, null, this.element), k = B(), (y = $("filter")).setAttribute("id", k), (v = $("feMorphology")).setAttribute("operator", "erode"), v.setAttribute("in", "SourceGraphic"), v.setAttribute("radius", "0"), y.appendChild(v), s.appendChild(y), d.setAttribute("stroke", "s" === r[f].mode ? "#000000" : "#ffffff")) : (v = null, b = null), this.storedData[f] = {
                                    elem: d,
                                    x: b,
                                    expan: v,
                                    lastPath: "",
                                    lastOperator: "",
                                    filterId: k,
                                    lastRadius: 0
                                }, "i" === r[f].mode) {
                                c = h.length;
                                var f, d, m, c, g, y, v, b, k, A = $("g");
                                for (m = 0; m < c; m += 1) A.appendChild(h[m]);
                                var P = $("mask");
                                P.setAttribute("mask-type", "alpha"), P.setAttribute("id", o + "_" + n), P.appendChild(d), s.appendChild(P), A.setAttribute("mask", "url(" + u() + "#" + o + "_" + n + ")"), h.length = 0, h.push(A)
                            } else h.push(d);
                            r[f].inv && !this.solidPath && (this.solidPath = this.createLayerSolidPath()), this.viewData[f] = {
                                elem: d,
                                lastPath: "",
                                op: tg.getProp(this.element, r[f].o, 0, .01, this.element),
                                prop: tP.getShapeProp(this.element, r[f], 3),
                                invRect: g
                            }, this.viewData[f].prop.k || this.drawPath(r[f], this.viewData[f].prop.v, this.viewData[f])
                        }
                    for (f = 0, this.maskElement = $(l), a = h.length; f < a; f += 1) this.maskElement.appendChild(h[f]);
                    n > 0 && (this.maskElement.setAttribute("id", o), this.element.maskedElement.setAttribute(p, "url(" + u() + "#" + o + ")"), s.appendChild(this.maskElement)), this.viewData.length && this.element.addRenderableComponent(this)
                }
                y([ty], eg), eg.prototype.getValue = eg.prototype.iterateDynamicProperties, eg.prototype.init = function(t, e) {
                    this.data = t, this.effectElements = [], this.initDynamicPropertyContainer(e);
                    var i, s, a = this.data.ef.length,
                        r = this.data.ef;
                    for (i = 0; i < a; i += 1) {
                        switch (s = null, r[i].ty) {
                            case 0:
                                s = new eh(r[i], e, this);
                                break;
                            case 1:
                                s = new eo(r[i], e, this);
                                break;
                            case 2:
                                s = new el(r[i], e, this);
                                break;
                            case 3:
                                s = new ep(r[i], e, this);
                                break;
                            case 4:
                            case 7:
                                s = new em(r[i], e, this);
                                break;
                            case 10:
                                s = new ef(r[i], e, this);
                                break;
                            case 11:
                                s = new ed(r[i], e, this);
                                break;
                            case 5:
                                s = new eu(r[i], e, this);
                                break;
                            default:
                                s = new ec(r[i], e, this)
                        }
                        s && this.effectElements.push(s)
                    }
                }, ey.prototype = {
                    checkMasks: function() {
                        if (!this.data.hasMask) return !1;
                        for (var t = 0, e = this.data.masksProperties.length; t < e;) {
                            if ("n" !== this.data.masksProperties[t].mode && !1 !== this.data.masksProperties[t].cl) return !0;
                            t += 1
                        }
                        return !1
                    },
                    initExpressions: function() {
                        var t = K();
                        if (t) {
                            var e = t("layer"),
                                i = t("effects"),
                                s = t("shape"),
                                a = t("text"),
                                r = t("comp");
                            this.layerInterface = e(this), this.data.hasMask && this.maskManager && this.layerInterface.registerMaskInterface(this.maskManager);
                            var n = i.createEffectsInterface(this, this.layerInterface);
                            this.layerInterface.registerEffectsInterface(n), 0 === this.data.ty || this.data.xt ? this.compInterface = r(this) : 4 === this.data.ty ? (this.layerInterface.shapeInterface = s(this.shapesData, this.itemsData, this.layerInterface), this.layerInterface.content = this.layerInterface.shapeInterface) : 5 === this.data.ty && (this.layerInterface.textInterface = a(this), this.layerInterface.text = this.layerInterface.textInterface)
                        }
                    },
                    setBlendMode: function() {
                        var t = en(this.data.bm);
                        (this.baseElement || this.layerElement).style["mix-blend-mode"] = t
                    },
                    initBaseData: function(t, e, i) {
                        this.globalData = e, this.comp = i, this.data = t, this.layerId = B(), this.data.sr || (this.data.sr = 1), this.effectsManager = new eu(this.data, this, this.dynamicProperties)
                    },
                    getType: function() {
                        return this.type
                    },
                    sourceRectAtTime: function() {}
                }, ev.prototype = {
                    initFrame: function() {
                        this._isFirstFrame = !1, this.dynamicProperties = [], this._mdf = !1
                    },
                    prepareProperties: function(t, e) {
                        var i, s = this.dynamicProperties.length;
                        for (i = 0; i < s; i += 1)(e || this._isParent && "transform" === this.dynamicProperties[i].propType) && (this.dynamicProperties[i].getValue(), this.dynamicProperties[i]._mdf && (this.globalData._mdf = !0, this._mdf = !0))
                    },
                    addDynamicProperty: function(t) {
                        -1 === this.dynamicProperties.indexOf(t) && this.dynamicProperties.push(t)
                    }
                }, eb.prototype.prepareFrame = function() {}, y([er, ey, ev], eb), eb.prototype.getBaseElement = function() {
                    return null
                }, eb.prototype.renderFrame = function() {}, eb.prototype.destroy = function() {}, eb.prototype.initExpressions = function() {
                    var t = K();
                    if (t) {
                        var e = t("footage");
                        this.layerInterface = e(this)
                    }
                }, eb.prototype.getFootageData = function() {
                    return this.footageData
                }, e_.prototype.prepareFrame = function(t) {
                    if (this.prepareRenderableFrame(t, !0), this.prepareProperties(t, !0), this.tm._placeholder) this._currentTime = t / this.data.sr;
                    else {
                        var e = this.tm.v;
                        this._currentTime = e
                    }
                    this._volume = this.lv.v[0];
                    var i = this._volume * this._volumeMultiplier;
                    this._previousVolume !== i && (this._previousVolume = i, this.audio.volume(i))
                }, y([er, ey, ev], e_), e_.prototype.renderFrame = function() {
                    this.isInRange && this._canPlay && (this._isPlaying ? (!this.audio.playing() || Math.abs(this._currentTime / this.globalData.frameRate - this.audio.seek()) > .1) && this.audio.seek(this._currentTime / this.globalData.frameRate) : (this.audio.play(), this.audio.seek(this._currentTime / this.globalData.frameRate), this._isPlaying = !0))
                }, e_.prototype.show = function() {}, e_.prototype.hide = function() {
                    this.audio.pause(), this._isPlaying = !1
                }, e_.prototype.pause = function() {
                    this.audio.pause(), this._isPlaying = !1, this._canPlay = !1
                }, e_.prototype.resume = function() {
                    this._canPlay = !0
                }, e_.prototype.setRate = function(t) {
                    this.audio.rate(t)
                }, e_.prototype.volume = function(t) {
                    this._volumeMultiplier = t, this._previousVolume = t * this._volume, this.audio.volume(this._previousVolume)
                }, e_.prototype.getBaseElement = function() {
                    return null
                }, e_.prototype.destroy = function() {}, e_.prototype.sourceRectAtTime = function() {}, e_.prototype.initExpressions = function() {}, ek.prototype.checkLayers = function(t) {
                    var e, i, s = this.layers.length;
                    for (this.completeLayers = !0, e = s - 1; e >= 0; e -= 1) !this.elements[e] && (i = this.layers[e]).ip - i.st <= t - this.layers[e].st && i.op - i.st > t - this.layers[e].st && this.buildItem(e), this.completeLayers = !!this.elements[e] && this.completeLayers;
                    this.checkPendingElements()
                }, ek.prototype.createItem = function(t) {
                    switch (t.ty) {
                        case 2:
                            return this.createImage(t);
                        case 0:
                            return this.createComp(t);
                        case 1:
                            return this.createSolid(t);
                        case 3:
                        default:
                            return this.createNull(t);
                        case 4:
                            return this.createShape(t);
                        case 5:
                            return this.createText(t);
                        case 6:
                            return this.createAudio(t);
                        case 13:
                            return this.createCamera(t);
                        case 15:
                            return this.createFootage(t)
                    }
                }, ek.prototype.createCamera = function() {
                    throw Error("You're using a 3d camera. Try the html renderer.")
                }, ek.prototype.createAudio = function(t) {
                    return new e_(t, this.globalData, this)
                }, ek.prototype.createFootage = function(t) {
                    return new eb(t, this.globalData, this)
                }, ek.prototype.buildAllItems = function() {
                    var t, e = this.layers.length;
                    for (t = 0; t < e; t += 1) this.buildItem(t);
                    this.checkPendingElements()
                }, ek.prototype.includeLayers = function(t) {
                    this.completeLayers = !1;
                    var e, i, s = t.length,
                        a = this.layers.length;
                    for (e = 0; e < s; e += 1)
                        for (i = 0; i < a;) {
                            if (this.layers[i].id === t[e].id) {
                                this.layers[i] = t[e];
                                break
                            }
                            i += 1
                        }
                }, ek.prototype.setProjectInterface = function(t) {
                    this.globalData.projectInterface = t
                }, ek.prototype.initItems = function() {
                    this.globalData.progressiveLoad || this.buildAllItems()
                }, ek.prototype.buildElementParenting = function(t, e, i) {
                    for (var s = this.elements, a = this.layers, r = 0, n = a.length; r < n;) a[r].ind == e && (s[r] && !0 !== s[r] ? (i.push(s[r]), s[r].setAsParent(), void 0 !== a[r].parent ? this.buildElementParenting(t, a[r].parent, i) : t.setHierarchy(i)) : (this.buildItem(r), this.addPendingElement(t))), r += 1
                }, ek.prototype.addPendingElement = function(t) {
                    this.pendingElements.push(t)
                }, ek.prototype.searchExtraCompositions = function(t) {
                    var e, i = t.length;
                    for (e = 0; e < i; e += 1)
                        if (t[e].xt) {
                            var s = this.createComp(t[e]);
                            s.initExpressions(), this.globalData.projectInterface.registerComposition(s)
                        }
                }, ek.prototype.getElementById = function(t) {
                    var e, i = this.elements.length;
                    for (e = 0; e < i; e += 1)
                        if (this.elements[e].data.ind === t) return this.elements[e];
                    return null
                }, ek.prototype.getElementByPath = function(t) {
                    var e = t.shift();
                    if ("number" == typeof e) i = this.elements[e];
                    else {
                        var i, s, a = this.elements.length;
                        for (s = 0; s < a; s += 1)
                            if (this.elements[s].data.nm === e) {
                                i = this.elements[s];
                                break
                            }
                    }
                    return 0 === t.length ? i : i.getElementByPath(t)
                }, ek.prototype.setupGlobalData = function(t, e) {
                    this.globalData.fontManager = new ea, this.globalData.fontManager.addChars(t.chars), this.globalData.fontManager.addFonts(t.fonts, e), this.globalData.getAssetData = this.animationItem.getAssetData.bind(this.animationItem), this.globalData.getAssetsPath = this.animationItem.getAssetsPath.bind(this.animationItem), this.globalData.imageLoader = this.animationItem.imagePreloader, this.globalData.audioController = this.animationItem.audioController, this.globalData.frameId = 0, this.globalData.frameRate = t.fr, this.globalData.nm = t.nm, this.globalData.compSize = {
                        w: t.w,
                        h: t.h
                    }
                }, eA.prototype = {
                    initTransform: function() {
                        this.finalTransform = {
                            mProp: this.data.ks ? tB.getTransformProperty(this, this.data.ks, this) : {
                                o: 0
                            },
                            _matMdf: !1,
                            _opMdf: !1,
                            mat: new tS
                        }, this.data.ao && (this.finalTransform.mProp.autoOriented = !0), this.data.ty
                    },
                    renderTransform: function() {
                        if (this.finalTransform._opMdf = this.finalTransform.mProp.o._mdf || this._isFirstFrame, this.finalTransform._matMdf = this.finalTransform.mProp._mdf || this._isFirstFrame, this.hierarchy) {
                            var t, e = this.finalTransform.mat,
                                i = 0,
                                s = this.hierarchy.length;
                            if (!this.finalTransform._matMdf)
                                for (; i < s;) {
                                    if (this.hierarchy[i].finalTransform.mProp._mdf) {
                                        this.finalTransform._matMdf = !0;
                                        break
                                    }
                                    i += 1
                                }
                            if (this.finalTransform._matMdf)
                                for (t = this.finalTransform.mProp.v.props, e.cloneFromProps(t), i = 0; i < s; i += 1) t = this.hierarchy[i].finalTransform.mProp.v.props, e.transform(t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11], t[12], t[13], t[14], t[15])
                        }
                    },
                    globalToLocal: function(t) {
                        var e, i, s = [];
                        s.push(this.finalTransform);
                        for (var a = !0, r = this.comp; a;) r.finalTransform ? (r.data.hasMask && s.splice(0, 0, r.finalTransform), r = r.comp) : a = !1;
                        var n = s.length;
                        for (e = 0; e < n; e += 1) i = s[e].mat.applyToPointArray(0, 0, 0), t = [t[0] - i[0], t[1] - i[1], 0];
                        return t
                    },
                    mHelper: new tS
                }, eP.prototype.getMaskProperty = function(t) {
                    return this.viewData[t].prop
                }, eP.prototype.renderFrame = function(t) {
                    var e, i = this.element.finalTransform.mat,
                        s = this.masksProperties.length;
                    for (e = 0; e < s; e += 1)
                        if ((this.viewData[e].prop._mdf || t) && this.drawPath(this.masksProperties[e], this.viewData[e].prop.v, this.viewData[e]), (this.viewData[e].op._mdf || t) && this.viewData[e].elem.setAttribute("fill-opacity", this.viewData[e].op.v), "n" !== this.masksProperties[e].mode && (this.viewData[e].invRect && (this.element.finalTransform.mProp._mdf || t) && this.viewData[e].invRect.setAttribute("transform", i.getInverseMatrix().to2dCSS()), this.storedData[e].x && (this.storedData[e].x._mdf || t))) {
                            var a = this.storedData[e].expan;
                            this.storedData[e].x.v < 0 ? ("erode" !== this.storedData[e].lastOperator && (this.storedData[e].lastOperator = "erode", this.storedData[e].elem.setAttribute("filter", "url(" + u() + "#" + this.storedData[e].filterId + ")")), a.setAttribute("radius", -this.storedData[e].x.v)) : ("dilate" !== this.storedData[e].lastOperator && (this.storedData[e].lastOperator = "dilate", this.storedData[e].elem.setAttribute("filter", null)), this.storedData[e].elem.setAttribute("stroke-width", 2 * this.storedData[e].x.v))
                        }
                }, eP.prototype.getMaskelement = function() {
                    return this.maskElement
                }, eP.prototype.createLayerSolidPath = function() {
                    return "M0,0 " + (" h" + this.globalData.compSize.w + " v" + this.globalData.compSize.h + " h-" + this.globalData.compSize.w + " v-" + this.globalData.compSize.h) + " "
                }, eP.prototype.drawPath = function(t, e, i) {
                    var s, a, r = " M" + e.v[0][0] + "," + e.v[0][1];
                    for (s = 1, a = e._length; s < a; s += 1) r += " C" + e.o[s - 1][0] + "," + e.o[s - 1][1] + " " + e.i[s][0] + "," + e.i[s][1] + " " + e.v[s][0] + "," + e.v[s][1];
                    if (e.c && a > 1 && (r += " C" + e.o[s - 1][0] + "," + e.o[s - 1][1] + " " + e.i[0][0] + "," + e.i[0][1] + " " + e.v[0][0] + "," + e.v[0][1]), i.lastPath !== r) {
                        var n = "";
                        i.elem && (e.c && (n = t.inv ? this.solidPath + r : r), i.elem.setAttribute("d", n)), i.lastPath = r
                    }
                }, eP.prototype.destroy = function() {
                    this.element = null, this.globalData = null, this.maskElement = null, this.data = null, this.masksProperties = null
                };
                var eS = ((p = {}).createFilter = function(t, e) {
                        var i = $("filter");
                        return i.setAttribute("id", t), !0 !== e && (i.setAttribute("filterUnits", "objectBoundingBox"), i.setAttribute("x", "0%"), i.setAttribute("y", "0%"), i.setAttribute("width", "100%"), i.setAttribute("height", "100%")), i
                    }, p.createAlphaToLuminanceFilter = function() {
                        var t = $("feColorMatrix");
                        return t.setAttribute("type", "matrix"), t.setAttribute("color-interpolation-filters", "sRGB"), t.setAttribute("values", "0 0 0 1 0  0 0 0 1 0  0 0 0 1 0  0 0 0 1 1"), t
                    }, p),
                    ex = (f = {
                        maskType: !0,
                        svgLumaHidden: !0,
                        offscreenCanvas: "undefined" != typeof OffscreenCanvas
                    }, (/MSIE 10/i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge\/\d./i.test(navigator.userAgent)) && (f.maskType = !1), /firefox/i.test(navigator.userAgent) && (f.svgLumaHidden = !1), f),
                    ew = {},
                    eD = "filter_result_";

                function eC(t) {
                    var e, i, s = "SourceGraphic",
                        a = t.data.ef ? t.data.ef.length : 0,
                        r = B(),
                        n = eS.createFilter(r, !0),
                        h = 0;
                    for (e = 0, this.filters = []; e < a; e += 1) {
                        i = null;
                        var o = t.data.ef[e].ty;
                        ew[o] && (i = new ew[o].effect(n, t.effectsManager.effectElements[e], t, eD + h, s), s = eD + h, ew[o].countsAsEffect && (h += 1)), i && this.filters.push(i)
                    }
                    h && (t.globalData.defs.appendChild(n), t.layerElement.setAttribute("filter", "url(" + u() + "#" + r + ")")), this.filters.length && t.addRenderableComponent(this)
                }

                function eM() {}

                function eF() {}

                function eT() {}

                function eE(t, e, i) {
                    this.assetData = e.getAssetData(t.refId), this.initElement(t, e, i), this.sourceRect = {
                        top: 0,
                        left: 0,
                        width: this.assetData.w,
                        height: this.assetData.h
                    }
                }

                function eI(t, e) {
                    this.elem = t, this.pos = e
                }

                function eL() {}
                eC.prototype.renderFrame = function(t) {
                    var e, i = this.filters.length;
                    for (e = 0; e < i; e += 1) this.filters[e].renderFrame(t)
                }, eM.prototype = {
                    initRendererElement: function() {
                        this.layerElement = $("g")
                    },
                    createContainerElements: function() {
                        this.matteElement = $("g"), this.transformedElement = this.layerElement, this.maskedElement = this.layerElement, this._sizeChanged = !1;
                        var t = null;
                        if (this.data.td) {
                            this.matteMasks = {};
                            var e = $("g");
                            e.setAttribute("id", this.layerId), e.appendChild(this.layerElement), t = e, this.globalData.defs.appendChild(e)
                        } else this.data.tt ? (this.matteElement.appendChild(this.layerElement), t = this.matteElement, this.baseElement = this.matteElement) : this.baseElement = this.layerElement;
                        if (this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), 0 === this.data.ty && !this.data.hd) {
                            var i = $("clipPath"),
                                s = $("path");
                            s.setAttribute("d", "M0,0 L" + this.data.w + ",0 L" + this.data.w + "," + this.data.h + " L0," + this.data.h + "z");
                            var a = B();
                            if (i.setAttribute("id", a), i.appendChild(s), this.globalData.defs.appendChild(i), this.checkMasks()) {
                                var r = $("g");
                                r.setAttribute("clip-path", "url(" + u() + "#" + a + ")"), r.appendChild(this.layerElement), this.transformedElement = r, t ? t.appendChild(this.transformedElement) : this.baseElement = this.transformedElement
                            } else this.layerElement.setAttribute("clip-path", "url(" + u() + "#" + a + ")")
                        }
                        0 !== this.data.bm && this.setBlendMode()
                    },
                    renderElement: function() {
                        this.finalTransform._matMdf && this.transformedElement.setAttribute("transform", this.finalTransform.mat.to2dCSS()), this.finalTransform._opMdf && this.transformedElement.setAttribute("opacity", this.finalTransform.mProp.o.v)
                    },
                    destroyBaseElement: function() {
                        this.layerElement = null, this.matteElement = null, this.maskManager.destroy()
                    },
                    getBaseElement: function() {
                        return this.data.hd ? null : this.baseElement
                    },
                    createRenderableComponents: function() {
                        this.maskManager = new eP(this.data, this, this.globalData), this.renderableEffectsManager = new eC(this)
                    },
                    getMatte: function(t) {
                        if (this.matteMasks || (this.matteMasks = {}), !this.matteMasks[t]) {
                            var e, i, s, a, r = this.layerId + "_" + t;
                            if (1 === t || 3 === t) {
                                var n = $("mask");
                                n.setAttribute("id", r), n.setAttribute("mask-type", 3 === t ? "luminance" : "alpha"), (s = $("use")).setAttributeNS("http://www.w3.org/1999/xlink", "href", "#" + this.layerId), n.appendChild(s), this.globalData.defs.appendChild(n), ex.maskType || 1 !== t || (n.setAttribute("mask-type", "luminance"), e = B(), i = eS.createFilter(e), this.globalData.defs.appendChild(i), i.appendChild(eS.createAlphaToLuminanceFilter()), (a = $("g")).appendChild(s), n.appendChild(a), a.setAttribute("filter", "url(" + u() + "#" + e + ")"))
                            } else if (2 === t) {
                                var h = $("mask");
                                h.setAttribute("id", r), h.setAttribute("mask-type", "alpha");
                                var o = $("g");
                                h.appendChild(o), e = B(), i = eS.createFilter(e);
                                var l = $("feComponentTransfer");
                                l.setAttribute("in", "SourceGraphic"), i.appendChild(l);
                                var p = $("feFuncA");
                                p.setAttribute("type", "table"), p.setAttribute("tableValues", "1.0 0.0"), l.appendChild(p), this.globalData.defs.appendChild(i);
                                var f = $("rect");
                                f.setAttribute("width", this.comp.data.w), f.setAttribute("height", this.comp.data.h), f.setAttribute("x", "0"), f.setAttribute("y", "0"), f.setAttribute("fill", "#ffffff"), f.setAttribute("opacity", "0"), o.setAttribute("filter", "url(" + u() + "#" + e + ")"), o.appendChild(f), (s = $("use")).setAttributeNS("http://www.w3.org/1999/xlink", "href", "#" + this.layerId), o.appendChild(s), ex.maskType || (h.setAttribute("mask-type", "luminance"), i.appendChild(eS.createAlphaToLuminanceFilter()), a = $("g"), o.appendChild(f), a.appendChild(this.layerElement), o.appendChild(a)), this.globalData.defs.appendChild(h)
                            }
                            this.matteMasks[t] = r
                        }
                        return this.matteMasks[t]
                    },
                    setMatte: function(t) {
                        this.matteElement && this.matteElement.setAttribute("mask", "url(" + u() + "#" + t + ")")
                    }
                }, eF.prototype = {
                    initHierarchy: function() {
                        this.hierarchy = [], this._isParent = !1, this.checkParenting()
                    },
                    setHierarchy: function(t) {
                        this.hierarchy = t
                    },
                    setAsParent: function() {
                        this._isParent = !0
                    },
                    checkParenting: function() {
                        void 0 !== this.data.parent && this.comp.buildElementParenting(this, this.data.parent, [])
                    }
                }, y([er, function(t) {
                    function e() {}
                    return e.prototype = t, e
                }({
                    initElement: function(t, e, i) {
                        this.initFrame(), this.initBaseData(t, e, i), this.initTransform(t, e, i), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide()
                    },
                    hide: function() {
                        this.hidden || this.isInRange && !this.isTransparent || ((this.baseElement || this.layerElement).style.display = "none", this.hidden = !0)
                    },
                    show: function() {
                        this.isInRange && !this.isTransparent && (this.data.hd || ((this.baseElement || this.layerElement).style.display = "block"), this.hidden = !1, this._isFirstFrame = !0)
                    },
                    renderFrame: function() {
                        this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = !1))
                    },
                    renderInnerContent: function() {},
                    prepareFrame: function(t) {
                        this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), this.checkTransparency()
                    },
                    destroy: function() {
                        this.innerElem = null, this.destroyBaseElement()
                    }
                })], eT), y([ey, eA, eM, eF, ev, eT], eE), eE.prototype.createContent = function() {
                    var t = this.globalData.getAssetsPath(this.assetData);
                    this.innerElem = $("image"), this.innerElem.setAttribute("width", this.assetData.w + "px"), this.innerElem.setAttribute("height", this.assetData.h + "px"), this.innerElem.setAttribute("preserveAspectRatio", this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio), this.innerElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", t), this.layerElement.appendChild(this.innerElem)
                }, eE.prototype.sourceRectAtTime = function() {
                    return this.sourceRect
                }, eL.prototype = {
                    addShapeToModifiers: function(t) {
                        var e, i = this.shapeModifiers.length;
                        for (e = 0; e < i; e += 1) this.shapeModifiers[e].addShape(t)
                    },
                    isShapeInAnimatedModifiers: function(t) {
                        for (var e = this.shapeModifiers.length; 0 < e;)
                            if (this.shapeModifiers[0].isAnimatedWithShape(t)) return !0;
                        return !1
                    },
                    renderModifiers: function() {
                        if (this.shapeModifiers.length) {
                            var t, e = this.shapes.length;
                            for (t = 0; t < e; t += 1) this.shapes[t].sh.reset();
                            for (t = (e = this.shapeModifiers.length) - 1; t >= 0 && !this.shapeModifiers[t].processShapes(this._isFirstFrame); t -= 1);
                        }
                    },
                    searchProcessedElement: function(t) {
                        for (var e = this.processedElements, i = 0, s = e.length; i < s;) {
                            if (e[i].elem === t) return e[i].pos;
                            i += 1
                        }
                        return 0
                    },
                    addProcessedElement: function(t, e) {
                        for (var i = this.processedElements, s = i.length; s;)
                            if (i[s -= 1].elem === t) {
                                i[s].pos = e;
                                return
                            }
                        i.push(new eI(t, e))
                    },
                    prepareFrame: function(t) {
                        this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange)
                    }
                };
                var eV = {
                        1: "butt",
                        2: "round",
                        3: "square"
                    },
                    ez = {
                        1: "miter",
                        2: "round",
                        3: "bevel"
                    };

                function eR(t, e, i) {
                    this.caches = [], this.styles = [], this.transformers = t, this.lStr = "", this.sh = i, this.lvl = e, this._isAnimated = !!i.k;
                    for (var s = 0, a = t.length; s < a;) {
                        if (t[s].mProps.dynamicProperties.length) {
                            this._isAnimated = !0;
                            break
                        }
                        s += 1
                    }
                }

                function eN(t, e) {
                    this.data = t, this.type = t.ty, this.d = "", this.lvl = e, this._mdf = !1, this.closed = !0 === t.hd, this.pElem = $("path"), this.msElem = null
                }

                function eO(t, e, i, s) {
                    this.elem = t, this.frameId = -1, this.dataProps = _(e.length), this.renderer = i, this.k = !1, this.dashStr = "", this.dashArray = b("float32", e.length ? e.length - 1 : 0), this.dashoffset = b("float32", 1), this.initDynamicPropertyContainer(s);
                    var a, r, n = e.length || 0;
                    for (a = 0; a < n; a += 1) r = tg.getProp(t, e[a].v, 0, 0, this), this.k = r.k || this.k, this.dataProps[a] = {
                        n: e[a].n,
                        p: r
                    };
                    this.k || this.getValue(!0), this._isAnimated = this.k
                }

                function eB(t, e, i) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = tg.getProp(t, e.o, 0, .01, this), this.w = tg.getProp(t, e.w, 0, null, this), this.d = new eO(t, e.d || {}, "svg", this), this.c = tg.getProp(t, e.c, 1, 255, this), this.style = i, this._isAnimated = !!this._isAnimated
                }

                function eq(t, e, i) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = tg.getProp(t, e.o, 0, .01, this), this.c = tg.getProp(t, e.c, 1, 255, this), this.style = i
                }

                function ej(t, e, i) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.style = i
                }

                function eW(t, e, i) {
                    this.data = e, this.c = b("uint8c", 4 * e.p);
                    var s = e.k.k[0].s ? e.k.k[0].s.length - 4 * e.p : e.k.k.length - 4 * e.p;
                    this.o = b("float32", s), this._cmdf = !1, this._omdf = !1, this._collapsable = this.checkCollapsable(), this._hasOpacity = s, this.initDynamicPropertyContainer(i), this.prop = tg.getProp(t, e.k, 1, null, this), this.k = this.prop.k, this.getValue(!0)
                }

                function eX(t, e, i) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.initGradientData(t, e, i)
                }

                function eH(t, e, i) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.w = tg.getProp(t, e.w, 0, null, this), this.d = new eO(t, e.d || {}, "svg", this), this.initGradientData(t, e, i), this._isAnimated = !!this._isAnimated
                }

                function eY() {
                    this.it = [], this.prevViewData = [], this.gr = $("g")
                }

                function eG(t, e, i) {
                    this.transform = {
                        mProps: t,
                        op: e,
                        container: i
                    }, this.elements = [], this._isAnimated = this.transform.mProps.dynamicProperties.length || this.transform.op.effectsSequence.length
                }
                eR.prototype.setAsAnimated = function() {
                    this._isAnimated = !0
                }, eN.prototype.reset = function() {
                    this.d = "", this._mdf = !1
                }, eO.prototype.getValue = function(t) {
                    if ((this.elem.globalData.frameId !== this.frameId || t) && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf = this._mdf || t, this._mdf)) {
                        var e = 0,
                            i = this.dataProps.length;
                        for ("svg" === this.renderer && (this.dashStr = ""), e = 0; e < i; e += 1) "o" !== this.dataProps[e].n ? "svg" === this.renderer ? this.dashStr += " " + this.dataProps[e].p.v : this.dashArray[e] = this.dataProps[e].p.v : this.dashoffset[0] = this.dataProps[e].p.v
                    }
                }, y([ty], eO), y([ty], eB), y([ty], eq), y([ty], ej), eW.prototype.comparePoints = function(t, e) {
                    for (var i = 0, s = this.o.length / 2; i < s;) {
                        if (Math.abs(t[4 * i] - t[4 * e + 2 * i]) > .01) return !1;
                        i += 1
                    }
                    return !0
                }, eW.prototype.checkCollapsable = function() {
                    if (this.o.length / 2 != this.c.length / 4) return !1;
                    if (this.data.k.k[0].s)
                        for (var t = 0, e = this.data.k.k.length; t < e;) {
                            if (!this.comparePoints(this.data.k.k[t].s, this.data.p)) return !1;
                            t += 1
                        } else if (!this.comparePoints(this.data.k.k, this.data.p)) return !1;
                    return !0
                }, eW.prototype.getValue = function(t) {
                    if (this.prop.getValue(), this._mdf = !1, this._cmdf = !1, this._omdf = !1, this.prop._mdf || t) {
                        var e, i, s, a = 4 * this.data.p;
                        for (e = 0; e < a; e += 1) i = e % 4 == 0 ? 100 : 255, s = Math.round(this.prop.v[e] * i), this.c[e] !== s && (this.c[e] = s, this._cmdf = !t);
                        if (this.o.length)
                            for (a = this.prop.v.length, e = 4 * this.data.p; e < a; e += 1) i = e % 2 == 0 ? 100 : 1, s = e % 2 == 0 ? Math.round(100 * this.prop.v[e]) : this.prop.v[e], this.o[e - 4 * this.data.p] !== s && (this.o[e - 4 * this.data.p] = s, this._omdf = !t);
                        this._mdf = !t
                    }
                }, y([ty], eW), eX.prototype.initGradientData = function(t, e, i) {
                    this.o = tg.getProp(t, e.o, 0, .01, this), this.s = tg.getProp(t, e.s, 1, null, this), this.e = tg.getProp(t, e.e, 1, null, this), this.h = tg.getProp(t, e.h || {
                        k: 0
                    }, 0, .01, this), this.a = tg.getProp(t, e.a || {
                        k: 0
                    }, 0, E, this), this.g = new eW(t, e.g, this), this.style = i, this.stops = [], this.setGradientData(i.pElem, e), this.setGradientOpacity(e, i), this._isAnimated = !!this._isAnimated
                }, eX.prototype.setGradientData = function(t, e) {
                    var i, s, a, r = B(),
                        n = $(1 === e.t ? "linearGradient" : "radialGradient");
                    n.setAttribute("id", r), n.setAttribute("spreadMethod", "pad"), n.setAttribute("gradientUnits", "userSpaceOnUse");
                    var h = [];
                    for (s = 0, a = 4 * e.g.p; s < a; s += 4) i = $("stop"), n.appendChild(i), h.push(i);
                    t.setAttribute("gf" === e.ty ? "fill" : "stroke", "url(" + u() + "#" + r + ")"), this.gf = n, this.cst = h
                }, eX.prototype.setGradientOpacity = function(t, e) {
                    if (this.g._hasOpacity && !this.g._collapsable) {
                        var i, s, a, r = $("mask"),
                            n = $("path");
                        r.appendChild(n);
                        var h = B(),
                            o = B();
                        r.setAttribute("id", o);
                        var l = $(1 === t.t ? "linearGradient" : "radialGradient");
                        l.setAttribute("id", h), l.setAttribute("spreadMethod", "pad"), l.setAttribute("gradientUnits", "userSpaceOnUse"), a = t.g.k.k[0].s ? t.g.k.k[0].s.length : t.g.k.k.length;
                        var p = this.stops;
                        for (s = 4 * t.g.p; s < a; s += 2)(i = $("stop")).setAttribute("stop-color", "rgb(255,255,255)"), l.appendChild(i), p.push(i);
                        n.setAttribute("gf" === t.ty ? "fill" : "stroke", "url(" + u() + "#" + h + ")"), "gs" === t.ty && (n.setAttribute("stroke-linecap", eV[t.lc || 2]), n.setAttribute("stroke-linejoin", ez[t.lj || 2]), 1 === t.lj && n.setAttribute("stroke-miterlimit", t.ml)), this.of = l, this.ms = r, this.ost = p, this.maskId = o, e.msElem = n
                    }
                }, y([ty], eX), y([eX, ty], eH);
                var eJ = function(t, e, i, s) {
                        if (0 === e) return "";
                        var a, r = t.o,
                            n = t.i,
                            h = t.v,
                            o = " M" + s.applyToPointStringified(h[0][0], h[0][1]);
                        for (a = 1; a < e; a += 1) o += " C" + s.applyToPointStringified(r[a - 1][0], r[a - 1][1]) + " " + s.applyToPointStringified(n[a][0], n[a][1]) + " " + s.applyToPointStringified(h[a][0], h[a][1]);
                        return i && e && (o += " C" + s.applyToPointStringified(r[a - 1][0], r[a - 1][1]) + " " + s.applyToPointStringified(n[0][0], n[0][1]) + " " + s.applyToPointStringified(h[0][0], h[0][1]) + "z"), o
                    },
                    eK = function() {
                        var t = new tS,
                            e = new tS;

                        function i(t, e, i) {
                            (i || e.transform.op._mdf) && e.transform.container.setAttribute("opacity", e.transform.op.v), (i || e.transform.mProps._mdf) && e.transform.container.setAttribute("transform", e.transform.mProps.v.to2dCSS())
                        }

                        function s() {}

                        function a(i, s, a) {
                            var r, n, h, o, l, p, f, d, m, c, u, g = s.styles.length,
                                y = s.lvl;
                            for (p = 0; p < g; p += 1) {
                                if (o = s.sh._mdf || a, s.styles[p].lvl < y) {
                                    for (d = e.reset(), c = y - s.styles[p].lvl, u = s.transformers.length - 1; !o && c > 0;) o = s.transformers[u].mProps._mdf || o, c -= 1, u -= 1;
                                    if (o)
                                        for (c = y - s.styles[p].lvl, u = s.transformers.length - 1; c > 0;) m = s.transformers[u].mProps.v.props, d.transform(m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]), c -= 1, u -= 1
                                } else d = t;
                                if (n = (f = s.sh.paths)._length, o) {
                                    for (r = 0, h = ""; r < n; r += 1)(l = f.shapes[r]) && l._length && (h += eJ(l, l._length, l.c, d));
                                    s.caches[p] = h
                                } else h = s.caches[p];
                                s.styles[p].d += !0 === i.hd ? "" : h, s.styles[p]._mdf = o || s.styles[p]._mdf
                            }
                        }

                        function r(t, e, i) {
                            var s = e.style;
                            (e.c._mdf || i) && s.pElem.setAttribute("fill", "rgb(" + C(e.c.v[0]) + "," + C(e.c.v[1]) + "," + C(e.c.v[2]) + ")"), (e.o._mdf || i) && s.pElem.setAttribute("fill-opacity", e.o.v)
                        }

                        function n(t, e, i) {
                            h(t, e, i), o(t, e, i)
                        }

                        function h(t, e, i) {
                            var s, a, r, n, h, o = e.gf,
                                l = e.g._hasOpacity,
                                p = e.s.v,
                                f = e.e.v;
                            if (e.o._mdf || i) {
                                var d = "gf" === t.ty ? "fill-opacity" : "stroke-opacity";
                                e.style.pElem.setAttribute(d, e.o.v)
                            }
                            if (e.s._mdf || i) {
                                var m = 1 === t.t ? "x1" : "cx",
                                    c = "x1" === m ? "y1" : "cy";
                                o.setAttribute(m, p[0]), o.setAttribute(c, p[1]), l && !e.g._collapsable && (e.of.setAttribute(m, p[0]), e.of.setAttribute(c, p[1]))
                            }
                            if (e.g._cmdf || i) {
                                s = e.cst;
                                var u = e.g.c;
                                for (a = 0, r = s.length; a < r; a += 1)(n = s[a]).setAttribute("offset", u[4 * a] + "%"), n.setAttribute("stop-color", "rgb(" + u[4 * a + 1] + "," + u[4 * a + 2] + "," + u[4 * a + 3] + ")")
                            }
                            if (l && (e.g._omdf || i)) {
                                var g = e.g.o;
                                for (a = 0, r = (s = e.g._collapsable ? e.cst : e.ost).length; a < r; a += 1) n = s[a], e.g._collapsable || n.setAttribute("offset", g[2 * a] + "%"), n.setAttribute("stop-opacity", g[2 * a + 1])
                            }
                            if (1 === t.t)(e.e._mdf || i) && (o.setAttribute("x2", f[0]), o.setAttribute("y2", f[1]), l && !e.g._collapsable && (e.of.setAttribute("x2", f[0]), e.of.setAttribute("y2", f[1])));
                            else if ((e.s._mdf || e.e._mdf || i) && (h = Math.sqrt(Math.pow(p[0] - f[0], 2) + Math.pow(p[1] - f[1], 2)), o.setAttribute("r", h), l && !e.g._collapsable && e.of.setAttribute("r", h)), e.e._mdf || e.h._mdf || e.a._mdf || i) {
                                h || (h = Math.sqrt(Math.pow(p[0] - f[0], 2) + Math.pow(p[1] - f[1], 2)));
                                var y = Math.atan2(f[1] - p[1], f[0] - p[0]),
                                    v = e.h.v;
                                v >= 1 ? v = .99 : v <= -1 && (v = -.99);
                                var b = h * v,
                                    _ = Math.cos(y + e.a.v) * b + p[0],
                                    k = Math.sin(y + e.a.v) * b + p[1];
                                o.setAttribute("fx", _), o.setAttribute("fy", k), l && !e.g._collapsable && (e.of.setAttribute("fx", _), e.of.setAttribute("fy", k))
                            }
                        }

                        function o(t, e, i) {
                            var s = e.style,
                                a = e.d;
                            a && (a._mdf || i) && a.dashStr && (s.pElem.setAttribute("stroke-dasharray", a.dashStr), s.pElem.setAttribute("stroke-dashoffset", a.dashoffset[0])), e.c && (e.c._mdf || i) && s.pElem.setAttribute("stroke", "rgb(" + C(e.c.v[0]) + "," + C(e.c.v[1]) + "," + C(e.c.v[2]) + ")"), (e.o._mdf || i) && s.pElem.setAttribute("stroke-opacity", e.o.v), (e.w._mdf || i) && (s.pElem.setAttribute("stroke-width", e.w.v), s.msElem && s.msElem.setAttribute("stroke-width", e.w.v))
                        }
                        return {
                            createRenderFunction: function(t) {
                                switch (t.ty) {
                                    case "fl":
                                        return r;
                                    case "gf":
                                        return h;
                                    case "gs":
                                        return n;
                                    case "st":
                                        return o;
                                    case "sh":
                                    case "el":
                                    case "rc":
                                    case "sr":
                                        return a;
                                    case "tr":
                                        return i;
                                    case "no":
                                        return s;
                                    default:
                                        return null
                                }
                            }
                        }
                    }();

                function eU(t, e, i) {
                    this.shapes = [], this.shapesData = t.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.initElement(t, e, i), this.prevViewData = []
                }

                function eZ(t, e, i, s, a, r) {
                    this.o = t, this.sw = e, this.sc = i, this.fc = s, this.m = a, this.p = r, this._mdf = {
                        o: !0,
                        sw: !!e,
                        sc: !!i,
                        fc: !!s,
                        m: !0,
                        p: !0
                    }
                }

                function eQ(t, e) {
                    this._frameId = -999999, this.pv = "", this.v = "", this.kf = !1, this._isFirstFrame = !0, this._mdf = !1, this.data = e, this.elem = t, this.comp = this.elem.comp, this.keysIndex = 0, this.canResize = !1, this.minimumFontSize = 1, this.effectsSequence = [], this.currentData = {
                        ascent: 0,
                        boxWidth: this.defaultBoxWidth,
                        f: "",
                        fStyle: "",
                        fWeight: "",
                        fc: "",
                        j: "",
                        justifyOffset: "",
                        l: [],
                        lh: 0,
                        lineWidths: [],
                        ls: "",
                        of: "",
                        s: "",
                        sc: "",
                        sw: 0,
                        t: 0,
                        tr: 0,
                        sz: 0,
                        ps: null,
                        fillColorAnim: !1,
                        strokeColorAnim: !1,
                        strokeWidthAnim: !1,
                        yOffset: 0,
                        finalSize: 0,
                        finalText: [],
                        finalLineHeight: 0,
                        __complete: !1
                    }, this.copyData(this.currentData, this.data.d.k[0].s), this.searchProperty() || this.completeTextData(this.currentData)
                }
                y([ey, eA, eM, eL, eF, ev, eT], eU), eU.prototype.initSecondaryElement = function() {}, eU.prototype.identityMatrix = new tS, eU.prototype.buildExpressionInterface = function() {}, eU.prototype.createContent = function() {
                    this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes()
                }, eU.prototype.filterUniqueShapes = function() {
                    var t, e, i, s, a = this.shapes.length,
                        r = this.stylesList.length,
                        n = [],
                        h = !1;
                    for (i = 0; i < r; i += 1) {
                        for (t = 0, s = this.stylesList[i], h = !1, n.length = 0; t < a; t += 1) - 1 !== (e = this.shapes[t]).styles.indexOf(s) && (n.push(e), h = e._isAnimated || h);
                        n.length > 1 && h && this.setShapesAsAnimated(n)
                    }
                }, eU.prototype.setShapesAsAnimated = function(t) {
                    var e, i = t.length;
                    for (e = 0; e < i; e += 1) t[e].setAsAnimated()
                }, eU.prototype.createStyleElement = function(t, e) {
                    var i, s = new eN(t, e),
                        a = s.pElem;
                    return "st" === t.ty ? i = new eB(this, t, s) : "fl" === t.ty ? i = new eq(this, t, s) : "gf" === t.ty || "gs" === t.ty ? (i = new("gf" === t.ty ? eX : eH)(this, t, s), this.globalData.defs.appendChild(i.gf), i.maskId && (this.globalData.defs.appendChild(i.ms), this.globalData.defs.appendChild(i.of), a.setAttribute("mask", "url(" + u() + "#" + i.maskId + ")"))) : "no" === t.ty && (i = new ej(this, t, s)), ("st" === t.ty || "gs" === t.ty) && (a.setAttribute("stroke-linecap", eV[t.lc || 2]), a.setAttribute("stroke-linejoin", ez[t.lj || 2]), a.setAttribute("fill-opacity", "0"), 1 === t.lj && a.setAttribute("stroke-miterlimit", t.ml)), 2 === t.r && a.setAttribute("fill-rule", "evenodd"), t.ln && a.setAttribute("id", t.ln), t.cl && a.setAttribute("class", t.cl), t.bm && (a.style["mix-blend-mode"] = en(t.bm)), this.stylesList.push(s), this.addToAnimatedContents(t, i), i
                }, eU.prototype.createGroupElement = function(t) {
                    var e = new eY;
                    return t.ln && e.gr.setAttribute("id", t.ln), t.cl && e.gr.setAttribute("class", t.cl), t.bm && (e.gr.style["mix-blend-mode"] = en(t.bm)), e
                }, eU.prototype.createTransformElement = function(t, e) {
                    var i = tB.getTransformProperty(this, t, this),
                        s = new eG(i, i.o, e);
                    return this.addToAnimatedContents(t, s), s
                }, eU.prototype.createShapeElement = function(t, e, i) {
                    var s = 4;
                    "rc" === t.ty ? s = 5 : "el" === t.ty ? s = 6 : "sr" === t.ty && (s = 7);
                    var a = tP.getShapeProp(this, t, s, this),
                        r = new eR(e, i, a);
                    return this.shapes.push(r), this.addShapeToModifiers(r), this.addToAnimatedContents(t, r), r
                }, eU.prototype.addToAnimatedContents = function(t, e) {
                    for (var i = 0, s = this.animatedContents.length; i < s;) {
                        if (this.animatedContents[i].element === e) return;
                        i += 1
                    }
                    this.animatedContents.push({
                        fn: eK.createRenderFunction(t),
                        element: e,
                        data: t
                    })
                }, eU.prototype.setElementStyles = function(t) {
                    var e, i = t.styles,
                        s = this.stylesList.length;
                    for (e = 0; e < s; e += 1) this.stylesList[e].closed || i.push(this.stylesList[e])
                }, eU.prototype.reloadShapes = function() {
                    this._isFirstFrame = !0;
                    var t, e = this.itemsData.length;
                    for (t = 0; t < e; t += 1) this.prevViewData[t] = this.itemsData[t];
                    for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes(), e = this.dynamicProperties.length, t = 0; t < e; t += 1) this.dynamicProperties[t].getValue();
                    this.renderModifiers()
                }, eU.prototype.searchShapes = function(t, e, i, s, a, r, n) {
                    var h, o, l, p, f, d, m = [].concat(r),
                        c = t.length - 1,
                        u = [],
                        g = [];
                    for (h = c; h >= 0; h -= 1) {
                        if ((d = this.searchProcessedElement(t[h])) ? e[h] = i[d - 1] : t[h]._render = n, "fl" === t[h].ty || "st" === t[h].ty || "gf" === t[h].ty || "gs" === t[h].ty || "no" === t[h].ty) d ? e[h].style.closed = !1 : e[h] = this.createStyleElement(t[h], a), t[h]._render && e[h].style.pElem.parentNode !== s && s.appendChild(e[h].style.pElem), u.push(e[h].style);
                        else if ("gr" === t[h].ty) {
                            if (d)
                                for (o = 0, l = e[h].it.length; o < l; o += 1) e[h].prevViewData[o] = e[h].it[o];
                            else e[h] = this.createGroupElement(t[h]);
                            this.searchShapes(t[h].it, e[h].it, e[h].prevViewData, e[h].gr, a + 1, m, n), t[h]._render && e[h].gr.parentNode !== s && s.appendChild(e[h].gr)
                        } else "tr" === t[h].ty ? (d || (e[h] = this.createTransformElement(t[h], s)), p = e[h].transform, m.push(p)) : "sh" === t[h].ty || "rc" === t[h].ty || "el" === t[h].ty || "sr" === t[h].ty ? (d || (e[h] = this.createShapeElement(t[h], m, a)), this.setElementStyles(e[h])) : "tm" === t[h].ty || "rd" === t[h].ty || "ms" === t[h].ty || "pb" === t[h].ty || "zz" === t[h].ty || "op" === t[h].ty ? (d ? (f = e[h]).closed = !1 : ((f = tz.getModifier(t[h].ty)).init(this, t[h]), e[h] = f, this.shapeModifiers.push(f)), g.push(f)) : "rp" === t[h].ty && (d ? (f = e[h]).closed = !0 : (f = tz.getModifier(t[h].ty), e[h] = f, f.init(this, t, h, e), this.shapeModifiers.push(f), n = !1), g.push(f));
                        this.addProcessedElement(t[h], h + 1)
                    }
                    for (h = 0, c = u.length; h < c; h += 1) u[h].closed = !0;
                    for (h = 0, c = g.length; h < c; h += 1) g[h].closed = !0
                }, eU.prototype.renderInnerContent = function() {
                    this.renderModifiers();
                    var t, e = this.stylesList.length;
                    for (t = 0; t < e; t += 1) this.stylesList[t].reset();
                    for (this.renderShape(), t = 0; t < e; t += 1)(this.stylesList[t]._mdf || this._isFirstFrame) && (this.stylesList[t].msElem && (this.stylesList[t].msElem.setAttribute("d", this.stylesList[t].d), this.stylesList[t].d = "M0 0" + this.stylesList[t].d), this.stylesList[t].pElem.setAttribute("d", this.stylesList[t].d || "M0 0"))
                }, eU.prototype.renderShape = function() {
                    var t, e, i = this.animatedContents.length;
                    for (t = 0; t < i; t += 1) e = this.animatedContents[t], (this._isFirstFrame || e.element._isAnimated) && !0 !== e.data && e.fn(e.data, e.element, this._isFirstFrame)
                }, eU.prototype.destroy = function() {
                    this.destroyBaseElement(), this.shapesData = null, this.itemsData = null
                }, eZ.prototype.update = function(t, e, i, s, a, r) {
                    this._mdf.o = !1, this._mdf.sw = !1, this._mdf.sc = !1, this._mdf.fc = !1, this._mdf.m = !1, this._mdf.p = !1;
                    var n = !1;
                    return this.o !== t && (this.o = t, this._mdf.o = !0, n = !0), this.sw !== e && (this.sw = e, this._mdf.sw = !0, n = !0), this.sc !== i && (this.sc = i, this._mdf.sc = !0, n = !0), this.fc !== s && (this.fc = s, this._mdf.fc = !0, n = !0), this.m !== a && (this.m = a, this._mdf.m = !0, n = !0), r.length && (this.p[0] !== r[0] || this.p[1] !== r[1] || this.p[4] !== r[4] || this.p[5] !== r[5] || this.p[12] !== r[12] || this.p[13] !== r[13]) && (this.p = r, this._mdf.p = !0, n = !0), n
                }, eQ.prototype.defaultBoxWidth = [0, 0], eQ.prototype.copyData = function(t, e) {
                    for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
                    return t
                }, eQ.prototype.setCurrentData = function(t) {
                    t.__complete || this.completeTextData(t), this.currentData = t, this.currentData.boxWidth = this.currentData.boxWidth || this.defaultBoxWidth, this._mdf = !0
                }, eQ.prototype.searchProperty = function() {
                    return this.searchKeyframes()
                }, eQ.prototype.searchKeyframes = function() {
                    return this.kf = this.data.d.k.length > 1, this.kf && this.addEffect(this.getKeyframeValue.bind(this)), this.kf
                }, eQ.prototype.addEffect = function(t) {
                    this.effectsSequence.push(t), this.elem.addDynamicProperty(this)
                }, eQ.prototype.getValue = function(t) {
                    if (this.elem.globalData.frameId !== this.frameId && this.effectsSequence.length || t) {
                        this.currentData.t = this.data.d.k[this.keysIndex].s.t;
                        var e, i = this.currentData,
                            s = this.keysIndex;
                        if (this.lock) {
                            this.setCurrentData(this.currentData);
                            return
                        }
                        this.lock = !0, this._mdf = !1;
                        var a = this.effectsSequence.length,
                            r = t || this.data.d.k[this.keysIndex].s;
                        for (e = 0; e < a; e += 1) r = s !== this.keysIndex ? this.effectsSequence[e](r, r.t) : this.effectsSequence[e](this.currentData, r.t);
                        i !== r && this.setCurrentData(r), this.v = this.currentData, this.pv = this.v, this.lock = !1, this.frameId = this.elem.globalData.frameId
                    }
                }, eQ.prototype.getKeyframeValue = function() {
                    for (var t = this.data.d.k, e = this.elem.comp.renderedFrame, i = 0, s = t.length; i <= s - 1 && i !== s - 1 && !(t[i + 1].t > e);) i += 1;
                    return this.keysIndex !== i && (this.keysIndex = i), this.data.d.k[this.keysIndex].s
                }, eQ.prototype.buildFinalText = function(t) {
                    for (var e, i, s = [], a = 0, r = t.length, n = !1; a < r;) e = t.charCodeAt(a), ea.isCombinedCharacter(e) ? s[s.length - 1] += t.charAt(a) : e >= 55296 && e <= 56319 ? (i = t.charCodeAt(a + 1)) >= 56320 && i <= 57343 ? (n || ea.isModifier(e, i) ? (s[s.length - 1] += t.substr(a, 2), n = !1) : s.push(t.substr(a, 2)), a += 1) : s.push(t.charAt(a)) : e > 56319 ? (i = t.charCodeAt(a + 1), ea.isZeroWidthJoiner(e, i) ? (n = !0, s[s.length - 1] += t.substr(a, 2), a += 1) : s.push(t.charAt(a))) : ea.isZeroWidthJoiner(e) ? (s[s.length - 1] += t.charAt(a), n = !0) : s.push(t.charAt(a)), a += 1;
                    return s
                }, eQ.prototype.completeTextData = function(t) {
                    t.__complete = !0;
                    var e = this.elem.globalData.fontManager,
                        i = this.data,
                        s = [],
                        a = 0,
                        r = i.m.g,
                        n = 0,
                        h = 0,
                        o = 0,
                        l = [],
                        p = 0,
                        f = 0,
                        d = e.getFontByName(t.f),
                        m = 0,
                        c = es(d);
                    t.fWeight = c.weight, t.fStyle = c.style, t.finalSize = t.s, t.finalText = this.buildFinalText(t.t), y = t.finalText.length, t.finalLineHeight = t.lh;
                    var u = t.tr / 1e3 * t.finalSize;
                    if (t.sz)
                        for (var g, y, v, b, _, k, A, P, S, x, w = !0, D = t.sz[0], C = t.sz[1]; w;) {
                            x = this.buildFinalText(t.t), S = 0, p = 0, y = x.length, u = t.tr / 1e3 * t.finalSize;
                            var M = -1;
                            for (g = 0; g < y; g += 1) P = x[g].charCodeAt(0), v = !1, " " === x[g] ? M = g : (13 === P || 3 === P) && (p = 0, v = !0, S += t.finalLineHeight || 1.2 * t.finalSize), e.chars ? (A = e.getCharData(x[g], d.fStyle, d.fFamily), m = v ? 0 : A.w * t.finalSize / 100) : m = e.measureText(x[g], t.f, t.finalSize), p + m > D && " " !== x[g] ? (-1 === M ? y += 1 : g = M, S += t.finalLineHeight || 1.2 * t.finalSize, x.splice(g, M === g ? 1 : 0, "\r"), M = -1, p = 0) : p += m + u;
                            S += d.ascent * t.finalSize / 100, this.canResize && t.finalSize > this.minimumFontSize && C < S ? (t.finalSize -= 1, t.finalLineHeight = t.finalSize * t.lh / t.s) : (t.finalText = x, y = t.finalText.length, w = !1)
                        }
                    p = -u, m = 0;
                    var F = 0;
                    for (g = 0; g < y; g += 1)
                        if (v = !1, 13 === (P = (I = t.finalText[g]).charCodeAt(0)) || 3 === P ? (F = 0, l.push(p), f = p > f ? p : f, p = -2 * u, b = "", v = !0, o += 1) : b = I, e.chars ? (A = e.getCharData(I, d.fStyle, e.getFontByName(t.f).fFamily), m = v ? 0 : A.w * t.finalSize / 100) : m = e.measureText(b, t.f, t.finalSize), " " === I ? F += m + u : (p += m + u + F, F = 0), s.push({
                                l: m,
                                an: m,
                                add: n,
                                n: v,
                                anIndexes: [],
                                val: b,
                                line: o,
                                animatorJustifyOffset: 0
                            }), 2 == r) {
                            if (n += m, "" === b || " " === b || g === y - 1) {
                                for (("" === b || " " === b) && (n -= m); h <= g;) s[h].an = n, s[h].ind = a, s[h].extra = m, h += 1;
                                a += 1, n = 0
                            }
                        } else if (3 == r) {
                        if (n += m, "" === b || g === y - 1) {
                            for ("" === b && (n -= m); h <= g;) s[h].an = n, s[h].ind = a, s[h].extra = m, h += 1;
                            n = 0, a += 1
                        }
                    } else s[a].ind = a, s[a].extra = 0, a += 1;
                    if (t.l = s, f = p > f ? p : f, l.push(p), t.sz) t.boxWidth = t.sz[0], t.justifyOffset = 0;
                    else switch (t.boxWidth = f, t.j) {
                        case 1:
                            t.justifyOffset = -t.boxWidth;
                            break;
                        case 2:
                            t.justifyOffset = -t.boxWidth / 2;
                            break;
                        default:
                            t.justifyOffset = 0
                    }
                    t.lineWidths = l;
                    var T = i.a;
                    k = T.length;
                    var E = [];
                    for (_ = 0; _ < k; _ += 1) {
                        for ((L = T[_]).a.sc && (t.strokeColorAnim = !0), L.a.sw && (t.strokeWidthAnim = !0), (L.a.fc || L.a.fh || L.a.fs || L.a.fb) && (t.fillColorAnim = !0), R = 0, z = L.s.b, g = 0; g < y; g += 1)(V = s[g]).anIndexes[_] = R, (1 == z && "" !== V.val || 2 == z && "" !== V.val && " " !== V.val || 3 == z && (V.n || " " == V.val || g == y - 1) || 4 == z && (V.n || g == y - 1)) && (1 === L.s.rn && E.push(R), R += 1);
                        i.a[_].s.totalChars = R;
                        var I, L, V, z, R, N, O = -1;
                        if (1 === L.s.rn)
                            for (g = 0; g < y; g += 1) O != (V = s[g]).anIndexes[_] && (O = V.anIndexes[_], N = E.splice(Math.floor(Math.random() * E.length), 1)[0]), V.anIndexes[_] = N
                    }
                    t.yOffset = t.finalLineHeight || 1.2 * t.finalSize, t.ls = t.ls || 0, t.ascent = d.ascent * t.finalSize / 100
                }, eQ.prototype.updateDocumentData = function(t, e) {
                    e = void 0 === e ? this.keysIndex : e;
                    var i = this.copyData({}, this.data.d.k[e].s);
                    i = this.copyData(i, t), this.data.d.k[e].s = i, this.recalculate(e), this.elem.addDynamicProperty(this)
                }, eQ.prototype.recalculate = function(t) {
                    var e = this.data.d.k[t].s;
                    e.__complete = !1, this.keysIndex = 0, this._isFirstFrame = !0, this.getValue(e)
                }, eQ.prototype.canResizeFont = function(t) {
                    this.canResize = t, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this)
                }, eQ.prototype.setMinimumFontSize = function(t) {
                    this.minimumFontSize = Math.floor(t) || 1, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this)
                };
                var e$ = function() {
                    var t = Math.max,
                        e = Math.min,
                        i = Math.floor;

                    function s(t, e) {
                        this._currentTextLength = -1, this.k = !1, this.data = e, this.elem = t, this.comp = t.comp, this.finalS = 0, this.finalE = 0, this.initDynamicPropertyContainer(t), this.s = tg.getProp(t, e.s || {
                            k: 0
                        }, 0, 0, this), "e" in e ? this.e = tg.getProp(t, e.e, 0, 0, this) : this.e = {
                            v: 100
                        }, this.o = tg.getProp(t, e.o || {
                            k: 0
                        }, 0, 0, this), this.xe = tg.getProp(t, e.xe || {
                            k: 0
                        }, 0, 0, this), this.ne = tg.getProp(t, e.ne || {
                            k: 0
                        }, 0, 0, this), this.sm = tg.getProp(t, e.sm || {
                            k: 100
                        }, 0, 0, this), this.a = tg.getProp(t, e.a, 0, .01, this), this.dynamicProperties.length || this.getValue()
                    }
                    return s.prototype = {
                        getMult: function(s) {
                            this._currentTextLength !== this.elem.textProperty.currentData.l.length && this.getValue();
                            var a = 0,
                                r = 0,
                                n = 1,
                                h = 1;
                            this.ne.v > 0 ? a = this.ne.v / 100 : r = -this.ne.v / 100, this.xe.v > 0 ? n = 1 - this.xe.v / 100 : h = 1 + this.xe.v / 100;
                            var o = tp.getBezierEasing(a, r, n, h).get,
                                l = 0,
                                p = this.finalS,
                                f = this.finalE,
                                d = this.data.sh;
                            if (2 === d) l = o(l = f === p ? s >= f ? 1 : 0 : t(0, e(.5 / (f - p) + (s - p) / (f - p), 1)));
                            else if (3 === d) l = o(l = f === p ? s >= f ? 0 : 1 : 1 - t(0, e(.5 / (f - p) + (s - p) / (f - p), 1)));
                            else if (4 === d) f === p ? l = 0 : (l = t(0, e(.5 / (f - p) + (s - p) / (f - p), 1))) < .5 ? l *= 2 : l = 1 - 2 * (l - .5), l = o(l);
                            else if (5 === d) {
                                if (f === p) l = 0;
                                else {
                                    var m = f - p,
                                        c = -m / 2 + (s = e(t(0, s + .5 - p), f - p)),
                                        u = m / 2;
                                    l = Math.sqrt(1 - c * c / (u * u))
                                }
                                l = o(l)
                            } else 6 === d ? l = o(l = f === p ? 0 : (1 + Math.cos(Math.PI + 2 * Math.PI * (s = e(t(0, s + .5 - p), f - p)) / (f - p))) / 2) : (s >= i(p) && (l = s - p < 0 ? t(0, e(e(f, 1) - (p - s), 1)) : t(0, e(f - s, 1))), l = o(l));
                            if (100 !== this.sm.v) {
                                var g = .01 * this.sm.v;
                                0 === g && (g = 1e-8);
                                var y = .5 - .5 * g;
                                l < y ? l = 0 : (l = (l - y) / g) > 1 && (l = 1)
                            }
                            return l * this.a.v
                        },
                        getValue: function(t) {
                            this.iterateDynamicProperties(), this._mdf = t || this._mdf, this._currentTextLength = this.elem.textProperty.currentData.l.length || 0, t && 2 === this.data.r && (this.e.v = this._currentTextLength);
                            var e = 2 === this.data.r ? 1 : 100 / this.data.totalChars,
                                i = this.o.v / e,
                                s = this.s.v / e + i,
                                a = this.e.v / e + i;
                            if (s > a) {
                                var r = s;
                                s = a, a = r
                            }
                            this.finalS = s, this.finalE = a
                        }
                    }, y([ty], s), {
                        getTextSelectorProp: function(t, e, i) {
                            return new s(t, e, i)
                        }
                    }
                }();

                function e0(t, e, i) {
                    var s = {
                            propType: !1
                        },
                        a = tg.getProp,
                        r = e.a;
                    this.a = {
                        r: r.r ? a(t, r.r, 0, E, i) : s,
                        rx: r.rx ? a(t, r.rx, 0, E, i) : s,
                        ry: r.ry ? a(t, r.ry, 0, E, i) : s,
                        sk: r.sk ? a(t, r.sk, 0, E, i) : s,
                        sa: r.sa ? a(t, r.sa, 0, E, i) : s,
                        s: r.s ? a(t, r.s, 1, .01, i) : s,
                        a: r.a ? a(t, r.a, 1, 0, i) : s,
                        o: r.o ? a(t, r.o, 0, .01, i) : s,
                        p: r.p ? a(t, r.p, 1, 0, i) : s,
                        sw: r.sw ? a(t, r.sw, 0, 0, i) : s,
                        sc: r.sc ? a(t, r.sc, 1, 0, i) : s,
                        fc: r.fc ? a(t, r.fc, 1, 0, i) : s,
                        fh: r.fh ? a(t, r.fh, 0, 0, i) : s,
                        fs: r.fs ? a(t, r.fs, 0, .01, i) : s,
                        fb: r.fb ? a(t, r.fb, 0, .01, i) : s,
                        t: r.t ? a(t, r.t, 0, 0, i) : s
                    }, this.s = e$.getTextSelectorProp(t, e.s, i), this.s.t = e.s.t
                }

                function e1(t, e, i) {
                    this._isFirstFrame = !0, this._hasMaskedPath = !1, this._frameId = -1, this._textData = t, this._renderType = e, this._elem = i, this._animatorsData = _(this._textData.a.length), this._pathData = {}, this._moreOptions = {
                        alignment: {}
                    }, this.renderedLetters = [], this.lettersChangedFlag = !1, this.initDynamicPropertyContainer(i)
                }

                function e2() {}
                e1.prototype.searchProperties = function() {
                    var t, e, i = this._textData.a.length,
                        s = tg.getProp;
                    for (t = 0; t < i; t += 1) e = this._textData.a[t], this._animatorsData[t] = new e0(this._elem, e, this);
                    this._textData.p && "m" in this._textData.p ? (this._pathData = {
                        a: s(this._elem, this._textData.p.a, 0, 0, this),
                        f: s(this._elem, this._textData.p.f, 0, 0, this),
                        l: s(this._elem, this._textData.p.l, 0, 0, this),
                        r: s(this._elem, this._textData.p.r, 0, 0, this),
                        p: s(this._elem, this._textData.p.p, 0, 0, this),
                        m: this._elem.maskManager.getMaskProperty(this._textData.p.m)
                    }, this._hasMaskedPath = !0) : this._hasMaskedPath = !1, this._moreOptions.alignment = s(this._elem, this._textData.m.a, 1, 0, this)
                }, e1.prototype.getMeasures = function(t, e) {
                    if (this.lettersChangedFlag = e, this._mdf || this._isFirstFrame || e || this._hasMaskedPath && this._pathData.m._mdf) {
                        this._isFirstFrame = !1;
                        var i, s, a, r, n, h, o, l, p, f, d, m, c, u, g, y, v, b = this._moreOptions.alignment.v,
                            _ = this._animatorsData,
                            k = this._textData,
                            A = this.mHelper,
                            P = this._renderType,
                            S = this.renderedLetters.length,
                            x = t.l;
                        if (this._hasMaskedPath) {
                            if (Y = this._pathData.m, !this._pathData.n || this._pathData._mdf) {
                                var w, D, C, M, F, T, E, I, L, V, z, R, N, O, B, q, j, Y, G, J = Y.v;
                                for (this._pathData.r.v && (J = J.reverse()), F = {
                                        tLength: 0,
                                        segments: []
                                    }, M = J._length - 1, q = 0, C = 0; C < M; C += 1) G = tu.buildBezierData(J.v[C], J.v[C + 1], [J.o[C][0] - J.v[C][0], J.o[C][1] - J.v[C][1]], [J.i[C + 1][0] - J.v[C + 1][0], J.i[C + 1][1] - J.v[C + 1][1]]), F.tLength += G.segmentLength, F.segments.push(G), q += G.segmentLength;
                                C = M, Y.v.c && (G = tu.buildBezierData(J.v[C], J.v[0], [J.o[C][0] - J.v[C][0], J.o[C][1] - J.v[C][1]], [J.i[0][0] - J.v[0][0], J.i[0][1] - J.v[0][1]]), F.tLength += G.segmentLength, F.segments.push(G), q += G.segmentLength), this._pathData.pi = F
                            }
                            if (F = this._pathData.pi, T = this._pathData.f.v, z = 0, V = 1, I = 0, L = !0, O = F.segments, T < 0 && Y.v.c)
                                for (F.tLength < Math.abs(T) && (T = -Math.abs(T) % F.tLength), z = O.length - 1, V = (N = O[z].points).length - 1; T < 0;) T += N[V].partialLength, (V -= 1) < 0 && (z -= 1, V = (N = O[z].points).length - 1);
                            R = (N = O[z].points)[V - 1], B = (E = N[V]).partialLength
                        }
                        M = x.length, w = 0, D = 0;
                        var K = 1.2 * t.finalSize * .714,
                            U = !0;
                        a = _.length;
                        var Z = -1,
                            Q = T,
                            $ = z,
                            tt = V,
                            te = -1,
                            ti = "",
                            ts = this.defaultPropsArray;
                        if (2 === t.j || 1 === t.j) {
                            var ta = 0,
                                tr = 0,
                                tn = 2 === t.j ? -.5 : -1,
                                th = 0,
                                to = !0;
                            for (C = 0; C < M; C += 1)
                                if (x[C].n) {
                                    for (ta && (ta += tr); th < C;) x[th].animatorJustifyOffset = ta, th += 1;
                                    ta = 0, to = !0
                                } else {
                                    for (s = 0; s < a; s += 1)(i = _[s].a).t.propType && (to && 2 === t.j && (tr += i.t.v * tn), (n = (0, _[s].s).getMult(x[C].anIndexes[s], k.a[s].s.totalChars)).length ? ta += i.t.v * n[0] * tn : ta += i.t.v * n * tn);
                                    to = !1
                                }
                            for (ta && (ta += tr); th < C;) x[th].animatorJustifyOffset = ta, th += 1
                        }
                        for (C = 0; C < M; C += 1) {
                            if (A.reset(), p = 1, x[C].n) w = 0, D += t.yOffset + (U ? 1 : 0), T = Q, U = !1, this._hasMaskedPath && (z = $, V = tt, R = (N = O[z].points)[V - 1], B = (E = N[V]).partialLength, I = 0), ti = "", y = "", u = "", v = "", ts = this.defaultPropsArray;
                            else {
                                if (this._hasMaskedPath) {
                                    if (te !== x[C].line) {
                                        switch (t.j) {
                                            case 1:
                                                T += q - t.lineWidths[x[C].line];
                                                break;
                                            case 2:
                                                T += (q - t.lineWidths[x[C].line]) / 2
                                        }
                                        te = x[C].line
                                    }
                                    Z !== x[C].ind && (x[Z] && (T += x[Z].extra), T += x[C].an / 2, Z = x[C].ind), T += b[0] * x[C].an * .005;
                                    var tl = 0;
                                    for (s = 0; s < a; s += 1)(i = _[s].a).p.propType && ((n = (0, _[s].s).getMult(x[C].anIndexes[s], k.a[s].s.totalChars)).length ? tl += i.p.v[0] * n[0] : tl += i.p.v[0] * n), i.a.propType && ((n = (0, _[s].s).getMult(x[C].anIndexes[s], k.a[s].s.totalChars)).length ? tl += i.a.v[0] * n[0] : tl += i.a.v[0] * n);
                                    for (L = !0, this._pathData.a.v && (T = .5 * x[0].an + (q - this._pathData.f.v - .5 * x[0].an - .5 * x[x.length - 1].an) * Z / (M - 1) + this._pathData.f.v); L;) I + B >= T + tl || !N ? (j = (T + tl - I) / E.partialLength, o = R.point[0] + (E.point[0] - R.point[0]) * j, l = R.point[1] + (E.point[1] - R.point[1]) * j, A.translate(-b[0] * x[C].an * .005, -(.01 * (b[1] * K))), L = !1) : N && (I += E.partialLength, (V += 1) >= N.length && (V = 0, O[z += 1] ? N = O[z].points : Y.v.c ? (V = 0, N = O[z = 0].points) : (I -= E.partialLength, N = null)), N && (R = E, B = (E = N[V]).partialLength));
                                    h = x[C].an / 2 - x[C].add, A.translate(-h, 0, 0)
                                } else h = x[C].an / 2 - x[C].add, A.translate(-h, 0, 0), A.translate(-b[0] * x[C].an * .005, -b[1] * K * .01, 0);
                                for (s = 0; s < a; s += 1)(i = _[s].a).t.propType && (n = (0, _[s].s).getMult(x[C].anIndexes[s], k.a[s].s.totalChars), (0 !== w || 0 !== t.j) && (this._hasMaskedPath ? n.length ? T += i.t.v * n[0] : T += i.t.v * n : n.length ? w += i.t.v * n[0] : w += i.t.v * n));
                                for (t.strokeWidthAnim && (d = t.sw || 0), t.strokeColorAnim && (f = t.sc ? [t.sc[0], t.sc[1], t.sc[2]] : [0, 0, 0]), t.fillColorAnim && t.fc && (m = [t.fc[0], t.fc[1], t.fc[2]]), s = 0; s < a; s += 1)(i = _[s].a).a.propType && ((n = (0, _[s].s).getMult(x[C].anIndexes[s], k.a[s].s.totalChars)).length ? A.translate(-i.a.v[0] * n[0], -i.a.v[1] * n[1], i.a.v[2] * n[2]) : A.translate(-i.a.v[0] * n, -i.a.v[1] * n, i.a.v[2] * n));
                                for (s = 0; s < a; s += 1)(i = _[s].a).s.propType && ((n = (0, _[s].s).getMult(x[C].anIndexes[s], k.a[s].s.totalChars)).length ? A.scale(1 + (i.s.v[0] - 1) * n[0], 1 + (i.s.v[1] - 1) * n[1], 1) : A.scale(1 + (i.s.v[0] - 1) * n, 1 + (i.s.v[1] - 1) * n, 1));
                                for (s = 0; s < a; s += 1) {
                                    if (i = _[s].a, n = (0, _[s].s).getMult(x[C].anIndexes[s], k.a[s].s.totalChars), i.sk.propType && (n.length ? A.skewFromAxis(-i.sk.v * n[0], i.sa.v * n[1]) : A.skewFromAxis(-i.sk.v * n, i.sa.v * n)), i.r.propType && (n.length ? A.rotateZ(-i.r.v * n[2]) : A.rotateZ(-i.r.v * n)), i.ry.propType && (n.length ? A.rotateY(i.ry.v * n[1]) : A.rotateY(i.ry.v * n)), i.rx.propType && (n.length ? A.rotateX(i.rx.v * n[0]) : A.rotateX(i.rx.v * n)), i.o.propType && (n.length ? p += (i.o.v * n[0] - p) * n[0] : p += (i.o.v * n - p) * n), t.strokeWidthAnim && i.sw.propType && (n.length ? d += i.sw.v * n[0] : d += i.sw.v * n), t.strokeColorAnim && i.sc.propType)
                                        for (c = 0; c < 3; c += 1) n.length ? f[c] += (i.sc.v[c] - f[c]) * n[0] : f[c] += (i.sc.v[c] - f[c]) * n;
                                    if (t.fillColorAnim && t.fc) {
                                        if (i.fc.propType)
                                            for (c = 0; c < 3; c += 1) n.length ? m[c] += (i.fc.v[c] - m[c]) * n[0] : m[c] += (i.fc.v[c] - m[c]) * n;
                                        i.fh.propType && (m = n.length ? H(m, i.fh.v * n[0]) : H(m, i.fh.v * n)), i.fs.propType && (m = n.length ? W(m, i.fs.v * n[0]) : W(m, i.fs.v * n)), i.fb.propType && (m = n.length ? X(m, i.fb.v * n[0]) : X(m, i.fb.v * n))
                                    }
                                }
                                for (s = 0; s < a; s += 1)(i = _[s].a).p.propType && (n = (0, _[s].s).getMult(x[C].anIndexes[s], k.a[s].s.totalChars), this._hasMaskedPath ? n.length ? A.translate(0, i.p.v[1] * n[0], -i.p.v[2] * n[1]) : A.translate(0, i.p.v[1] * n, -i.p.v[2] * n) : n.length ? A.translate(i.p.v[0] * n[0], i.p.v[1] * n[1], -i.p.v[2] * n[2]) : A.translate(i.p.v[0] * n, i.p.v[1] * n, -i.p.v[2] * n));
                                if (t.strokeWidthAnim && (u = d < 0 ? 0 : d), t.strokeColorAnim && (g = "rgb(" + Math.round(255 * f[0]) + "," + Math.round(255 * f[1]) + "," + Math.round(255 * f[2]) + ")"), t.fillColorAnim && t.fc && (y = "rgb(" + Math.round(255 * m[0]) + "," + Math.round(255 * m[1]) + "," + Math.round(255 * m[2]) + ")"), this._hasMaskedPath) {
                                    if (A.translate(0, -t.ls), A.translate(0, b[1] * K * .01 + D, 0), this._pathData.p.v) {
                                        var tp = 180 * Math.atan((E.point[1] - R.point[1]) / (E.point[0] - R.point[0])) / Math.PI;
                                        E.point[0] < R.point[0] && (tp += 180), A.rotate(-tp * Math.PI / 180)
                                    }
                                    A.translate(o, l, 0), T -= b[0] * x[C].an * .005, x[C + 1] && Z !== x[C + 1].ind && (T += x[C].an / 2 + .001 * t.tr * t.finalSize)
                                } else {
                                    switch (A.translate(w, D, 0), t.ps && A.translate(t.ps[0], t.ps[1] + t.ascent, 0), t.j) {
                                        case 1:
                                            A.translate(x[C].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[x[C].line]), 0, 0);
                                            break;
                                        case 2:
                                            A.translate(x[C].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[x[C].line]) / 2, 0, 0)
                                    }
                                    A.translate(0, -t.ls), A.translate(h, 0, 0), A.translate(b[0] * x[C].an * .005, b[1] * K * .01, 0), w += x[C].l + .001 * t.tr * t.finalSize
                                }
                                "html" === P ? ti = A.toCSS() : "svg" === P ? ti = A.to2dCSS() : ts = [A.props[0], A.props[1], A.props[2], A.props[3], A.props[4], A.props[5], A.props[6], A.props[7], A.props[8], A.props[9], A.props[10], A.props[11], A.props[12], A.props[13], A.props[14], A.props[15]], v = p
                            }
                            S <= C ? (r = new eZ(v, u, g, y, ti, ts), this.renderedLetters.push(r), S += 1, this.lettersChangedFlag = !0) : (r = this.renderedLetters[C], this.lettersChangedFlag = r.update(v, u, g, y, ti, ts) || this.lettersChangedFlag)
                        }
                    }
                }, e1.prototype.getValue = function() {
                    this._elem.globalData.frameId !== this._frameId && (this._frameId = this._elem.globalData.frameId, this.iterateDynamicProperties())
                }, e1.prototype.mHelper = new tS, e1.prototype.defaultPropsArray = [], y([ty], e1), e2.prototype.initElement = function(t, e, i) {
                    this.lettersChangedFlag = !0, this.initFrame(), this.initBaseData(t, e, i), this.textProperty = new eQ(this, t.t, this.dynamicProperties), this.textAnimator = new e1(t.t, this.renderType, this), this.initTransform(t, e, i), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide(), this.textAnimator.searchProperties(this.dynamicProperties)
                }, e2.prototype.prepareFrame = function(t) {
                    this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), (this.textProperty._mdf || this.textProperty._isFirstFrame) && (this.buildNewText(), this.textProperty._isFirstFrame = !1, this.textProperty._mdf = !1)
                }, e2.prototype.createPathShape = function(t, e) {
                    var i, s, a = e.length,
                        r = "";
                    for (i = 0; i < a; i += 1) "sh" === e[i].ty && (r += eJ(s = e[i].ks.k, s.i.length, !0, t));
                    return r
                }, e2.prototype.updateDocumentData = function(t, e) {
                    this.textProperty.updateDocumentData(t, e)
                }, e2.prototype.canResizeFont = function(t) {
                    this.textProperty.canResizeFont(t)
                }, e2.prototype.setMinimumFontSize = function(t) {
                    this.textProperty.setMinimumFontSize(t)
                }, e2.prototype.applyTextPropertiesToMatrix = function(t, e, i, s, a) {
                    switch (t.ps && e.translate(t.ps[0], t.ps[1] + t.ascent, 0), e.translate(0, -t.ls, 0), t.j) {
                        case 1:
                            e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[i]), 0, 0);
                            break;
                        case 2:
                            e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[i]) / 2, 0, 0)
                    }
                    e.translate(s, a, 0)
                }, e2.prototype.buildColor = function(t) {
                    return "rgb(" + Math.round(255 * t[0]) + "," + Math.round(255 * t[1]) + "," + Math.round(255 * t[2]) + ")"
                }, e2.prototype.emptyProp = new eZ, e2.prototype.destroy = function() {};
                var e3 = {
                    shapes: []
                };

                function e5(t, e, i) {
                    this.textSpans = [], this.renderType = "svg", this.initElement(t, e, i)
                }

                function e9(t, e, i) {
                    this.initElement(t, e, i)
                }

                function e4(t, e, i) {
                    this.initFrame(), this.initBaseData(t, e, i), this.initFrame(), this.initTransform(t, e, i), this.initHierarchy()
                }

                function e6() {}

                function e8() {}

                function e7(t, e, i) {
                    this.layers = t.layers, this.supports3d = !0, this.completeLayers = !1, this.pendingElements = [], this.elements = this.layers ? _(this.layers.length) : [], this.initElement(t, e, i), this.tm = t.tm ? tg.getProp(this, t.tm, 0, e.frameRate, this) : {
                        _placeholder: !0
                    }
                }

                function it(t, e) {
                    this.animationItem = t, this.layers = null, this.renderedFrame = -1, this.svgElement = $("svg");
                    var i = "";
                    if (e && e.title) {
                        var s = $("title"),
                            a = B();
                        s.setAttribute("id", a), s.textContent = e.title, this.svgElement.appendChild(s), i += a
                    }
                    if (e && e.description) {
                        var r = $("desc"),
                            n = B();
                        r.setAttribute("id", n), r.textContent = e.description, this.svgElement.appendChild(r), i += " " + n
                    }
                    i && this.svgElement.setAttribute("aria-labelledby", i);
                    var h = $("defs");
                    this.svgElement.appendChild(h);
                    var o = $("g");
                    this.svgElement.appendChild(o), this.layerElement = o, this.renderConfig = {
                        preserveAspectRatio: e && e.preserveAspectRatio || "xMidYMid meet",
                        imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
                        contentVisibility: e && e.contentVisibility || "visible",
                        progressiveLoad: e && e.progressiveLoad || !1,
                        hideOnTransparent: !(e && !1 === e.hideOnTransparent),
                        viewBoxOnly: e && e.viewBoxOnly || !1,
                        viewBoxSize: e && e.viewBoxSize || !1,
                        className: e && e.className || "",
                        id: e && e.id || "",
                        focusable: e && e.focusable,
                        filterSize: {
                            width: e && e.filterSize && e.filterSize.width || "100%",
                            height: e && e.filterSize && e.filterSize.height || "100%",
                            x: e && e.filterSize && e.filterSize.x || "0%",
                            y: e && e.filterSize && e.filterSize.y || "0%"
                        },
                        width: e && e.width,
                        height: e && e.height,
                        runExpressions: !e || void 0 === e.runExpressions || e.runExpressions
                    }, this.globalData = {
                        _mdf: !1,
                        frameNum: -1,
                        defs: h,
                        renderConfig: this.renderConfig
                    }, this.elements = [], this.pendingElements = [], this.destroyed = !1, this.rendererType = "svg"
                }
                return y([ey, eA, eM, eF, ev, eT, e2], e5), e5.prototype.createContent = function() {
                    this.data.singleShape && !this.globalData.fontManager.chars && (this.textContainer = $("text"))
                }, e5.prototype.buildTextContents = function(t) {
                    for (var e = 0, i = t.length, s = [], a = ""; e < i;) "\r" === t[e] || "\x03" === t[e] ? (s.push(a), a = "") : a += t[e], e += 1;
                    return s.push(a), s
                }, e5.prototype.buildShapeData = function(t, e) {
                    if (t.shapes && t.shapes.length) {
                        var i = t.shapes[0];
                        if (i.it) {
                            var s = i.it[i.it.length - 1];
                            s.s && (s.s.k[0] = e, s.s.k[1] = e)
                        }
                    }
                    return t
                }, e5.prototype.buildNewText = function() {
                    this.addDynamicProperty(this);
                    var t = this.textProperty.currentData;
                    this.renderedLetters = _(t ? t.l.length : 0), t.fc ? this.layerElement.setAttribute("fill", this.buildColor(t.fc)) : this.layerElement.setAttribute("fill", "rgba(0,0,0,0)"), t.sc && (this.layerElement.setAttribute("stroke", this.buildColor(t.sc)), this.layerElement.setAttribute("stroke-width", t.sw)), this.layerElement.setAttribute("font-size", t.finalSize);
                    var e = this.globalData.fontManager.getFontByName(t.f);
                    if (e.fClass) this.layerElement.setAttribute("class", e.fClass);
                    else {
                        this.layerElement.setAttribute("font-family", e.fFamily);
                        var i = t.fWeight,
                            s = t.fStyle;
                        this.layerElement.setAttribute("font-style", s), this.layerElement.setAttribute("font-weight", i)
                    }
                    this.layerElement.setAttribute("aria-label", t.t);
                    var a = t.l || [],
                        r = !!this.globalData.fontManager.chars;
                    u = a.length;
                    var n = this.mHelper,
                        h = this.data.singleShape,
                        o = 0,
                        l = 0,
                        p = !0,
                        f = .001 * t.tr * t.finalSize;
                    if (!h || r || t.sz) {
                        var d = this.textSpans.length;
                        for (c = 0; c < u; c += 1) {
                            if (this.textSpans[c] || (this.textSpans[c] = {
                                    span: null,
                                    childSpan: null,
                                    glyph: null
                                }), !r || !h || 0 === c) {
                                if (g = d > c ? this.textSpans[c].span : $(r ? "g" : "text"), d <= c) {
                                    if (g.setAttribute("stroke-linecap", "butt"), g.setAttribute("stroke-linejoin", "round"), g.setAttribute("stroke-miterlimit", "4"), this.textSpans[c].span = g, r) {
                                        var m = $("g");
                                        g.appendChild(m), this.textSpans[c].childSpan = m
                                    }
                                    this.textSpans[c].span = g, this.layerElement.appendChild(g)
                                }
                                g.style.display = "inherit"
                            }
                            if (n.reset(), h && (a[c].n && (o = -f, l += t.yOffset + (p ? 1 : 0), p = !1), this.applyTextPropertiesToMatrix(t, n, a[c].line, o, l), o += (a[c].l || 0) + f), r) {
                                if (1 === (y = this.globalData.fontManager.getCharData(t.finalText[c], e.fStyle, this.globalData.fontManager.getFontByName(t.f).fFamily)).t) v = new e7(y.data, this.globalData, this);
                                else {
                                    var c, u, g, y, v, b = e3;
                                    y.data && y.data.shapes && (b = this.buildShapeData(y.data, t.finalSize)), v = new eU(b, this.globalData, this)
                                }
                                if (this.textSpans[c].glyph) {
                                    var k = this.textSpans[c].glyph;
                                    this.textSpans[c].childSpan.removeChild(k.layerElement), k.destroy()
                                }
                                this.textSpans[c].glyph = v, v._debug = !0, v.prepareFrame(0), v.renderFrame(), this.textSpans[c].childSpan.appendChild(v.layerElement), 1 === y.t && this.textSpans[c].childSpan.setAttribute("transform", "scale(" + t.finalSize / 100 + "," + t.finalSize / 100 + ")")
                            } else h && g.setAttribute("transform", "translate(" + n.props[12] + "," + n.props[13] + ")"), g.textContent = a[c].val, g.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve")
                        }
                        h && g && g.setAttribute("d", "")
                    } else {
                        var A = this.textContainer,
                            P = "start";
                        switch (t.j) {
                            case 1:
                                P = "end";
                                break;
                            case 2:
                                P = "middle";
                                break;
                            default:
                                P = "start"
                        }
                        A.setAttribute("text-anchor", P), A.setAttribute("letter-spacing", f);
                        var S = this.buildTextContents(t.finalText);
                        for (c = 0, u = S.length, l = t.ps ? t.ps[1] + t.ascent : 0; c < u; c += 1)(g = this.textSpans[c].span || $("tspan")).textContent = S[c], g.setAttribute("x", 0), g.setAttribute("y", l), g.style.display = "inherit", A.appendChild(g), this.textSpans[c] || (this.textSpans[c] = {
                            span: null,
                            glyph: null
                        }), this.textSpans[c].span = g, l += t.finalLineHeight;
                        this.layerElement.appendChild(A)
                    }
                    for (; c < this.textSpans.length;) this.textSpans[c].span.style.display = "none", c += 1;
                    this._sizeChanged = !0
                }, e5.prototype.sourceRectAtTime = function() {
                    if (this.prepareFrame(this.comp.renderedFrame - this.data.st), this.renderInnerContent(), this._sizeChanged) {
                        this._sizeChanged = !1;
                        var t = this.layerElement.getBBox();
                        this.bbox = {
                            top: t.y,
                            left: t.x,
                            width: t.width,
                            height: t.height
                        }
                    }
                    return this.bbox
                }, e5.prototype.getValue = function() {
                    var t, e, i = this.textSpans.length;
                    for (t = 0, this.renderedFrame = this.comp.renderedFrame; t < i; t += 1)(e = this.textSpans[t].glyph) && (e.prepareFrame(this.comp.renderedFrame - this.data.st), e._mdf && (this._mdf = !0))
                }, e5.prototype.renderInnerContent = function() {
                    if ((!this.data.singleShape || this._mdf) && (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag)) {
                        this._sizeChanged = !0;
                        var t, e, i, s, a, r = this.textAnimator.renderedLetters,
                            n = this.textProperty.currentData.l;
                        for (t = 0, e = n.length; t < e; t += 1) !n[t].n && (i = r[t], s = this.textSpans[t].span, (a = this.textSpans[t].glyph) && a.renderFrame(), i._mdf.m && s.setAttribute("transform", i.m), i._mdf.o && s.setAttribute("opacity", i.o), i._mdf.sw && s.setAttribute("stroke-width", i.sw), i._mdf.sc && s.setAttribute("stroke", i.sc), i._mdf.fc && s.setAttribute("fill", i.fc))
                    }
                }, y([eE], e9), e9.prototype.createContent = function() {
                    var t = $("rect");
                    t.setAttribute("width", this.data.sw), t.setAttribute("height", this.data.sh), t.setAttribute("fill", this.data.sc), this.layerElement.appendChild(t)
                }, e4.prototype.prepareFrame = function(t) {
                    this.prepareProperties(t, !0)
                }, e4.prototype.renderFrame = function() {}, e4.prototype.getBaseElement = function() {
                    return null
                }, e4.prototype.destroy = function() {}, e4.prototype.sourceRectAtTime = function() {}, e4.prototype.hide = function() {}, y([ey, eA, eF, ev], e4), y([ek], e6), e6.prototype.createNull = function(t) {
                    return new e4(t, this.globalData, this)
                }, e6.prototype.createShape = function(t) {
                    return new eU(t, this.globalData, this)
                }, e6.prototype.createText = function(t) {
                    return new e5(t, this.globalData, this)
                }, e6.prototype.createImage = function(t) {
                    return new eE(t, this.globalData, this)
                }, e6.prototype.createSolid = function(t) {
                    return new e9(t, this.globalData, this)
                }, e6.prototype.configAnimation = function(t) {
                    this.svgElement.setAttribute("xmlns", "http://www.w3.org/2000/svg"), this.svgElement.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink"), this.renderConfig.viewBoxSize ? this.svgElement.setAttribute("viewBox", this.renderConfig.viewBoxSize) : this.svgElement.setAttribute("viewBox", "0 0 " + t.w + " " + t.h), this.renderConfig.viewBoxOnly || (this.svgElement.setAttribute("width", t.w), this.svgElement.setAttribute("height", t.h), this.svgElement.style.width = "100%", this.svgElement.style.height = "100%", this.svgElement.style.transform = "translate3d(0,0,0)", this.svgElement.style.contentVisibility = this.renderConfig.contentVisibility), this.renderConfig.width && this.svgElement.setAttribute("width", this.renderConfig.width), this.renderConfig.height && this.svgElement.setAttribute("height", this.renderConfig.height), this.renderConfig.className && this.svgElement.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.svgElement.setAttribute("id", this.renderConfig.id), void 0 !== this.renderConfig.focusable && this.svgElement.setAttribute("focusable", this.renderConfig.focusable), this.svgElement.setAttribute("preserveAspectRatio", this.renderConfig.preserveAspectRatio), this.animationItem.wrapper.appendChild(this.svgElement);
                    var e = this.globalData.defs;
                    this.setupGlobalData(t, e), this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.data = t;
                    var i = $("clipPath"),
                        s = $("rect");
                    s.setAttribute("width", t.w), s.setAttribute("height", t.h), s.setAttribute("x", 0), s.setAttribute("y", 0);
                    var a = B();
                    i.setAttribute("id", a), i.appendChild(s), this.layerElement.setAttribute("clip-path", "url(" + u() + "#" + a + ")"), e.appendChild(i), this.layers = t.layers, this.elements = _(t.layers.length)
                }, e6.prototype.destroy = function() {
                    this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.layerElement = null, this.globalData.defs = null;
                    var t, e = this.layers ? this.layers.length : 0;
                    for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy();
                    this.elements.length = 0, this.destroyed = !0, this.animationItem = null
                }, e6.prototype.updateContainerSize = function() {}, e6.prototype.findIndexByInd = function(t) {
                    var e = 0,
                        i = this.layers.length;
                    for (e = 0; e < i; e += 1)
                        if (this.layers[e].ind === t) return e;
                    return -1
                }, e6.prototype.buildItem = function(t) {
                    var e = this.elements;
                    if (!e[t] && 99 !== this.layers[t].ty) {
                        e[t] = !0;
                        var i = this.createItem(this.layers[t]);
                        if (e[t] = i, J() && (0 === this.layers[t].ty && this.globalData.projectInterface.registerComposition(i), i.initExpressions()), this.appendElementInPos(i, t), this.layers[t].tt) {
                            var s = "tp" in this.layers[t] ? this.findIndexByInd(this.layers[t].tp) : t - 1;
                            if (-1 === s) return;
                            if (this.elements[s] && !0 !== this.elements[s]) {
                                var a = e[s].getMatte(this.layers[t].tt);
                                i.setMatte(a)
                            } else this.buildItem(s), this.addPendingElement(i)
                        }
                    }
                }, e6.prototype.checkPendingElements = function() {
                    for (; this.pendingElements.length;) {
                        var t = this.pendingElements.pop();
                        if (t.checkParenting(), t.data.tt)
                            for (var e = 0, i = this.elements.length; e < i;) {
                                if (this.elements[e] === t) {
                                    var s = "tp" in t.data ? this.findIndexByInd(t.data.tp) : e - 1,
                                        a = this.elements[s].getMatte(this.layers[e].tt);
                                    t.setMatte(a);
                                    break
                                }
                                e += 1
                            }
                    }
                }, e6.prototype.renderFrame = function(t) {
                    if (this.renderedFrame !== t && !this.destroyed) {
                        null === t ? t = this.renderedFrame : this.renderedFrame = t, this.globalData.frameNum = t, this.globalData.frameId += 1, this.globalData.projectInterface.currentFrame = t, this.globalData._mdf = !1;
                        var e, i = this.layers.length;
                        for (this.completeLayers || this.checkLayers(t), e = i - 1; e >= 0; e -= 1)(this.completeLayers || this.elements[e]) && this.elements[e].prepareFrame(t - this.layers[e].st);
                        if (this.globalData._mdf)
                            for (e = 0; e < i; e += 1)(this.completeLayers || this.elements[e]) && this.elements[e].renderFrame()
                    }
                }, e6.prototype.appendElementInPos = function(t, e) {
                    var i, s = t.getBaseElement();
                    if (s) {
                        for (var a = 0; a < e;) this.elements[a] && !0 !== this.elements[a] && this.elements[a].getBaseElement() && (i = this.elements[a].getBaseElement()), a += 1;
                        i ? this.layerElement.insertBefore(s, i) : this.layerElement.appendChild(s)
                    }
                }, e6.prototype.hide = function() {
                    this.layerElement.style.display = "none"
                }, e6.prototype.show = function() {
                    this.layerElement.style.display = "block"
                }, y([ey, eA, eF, ev, eT], e8), e8.prototype.initElement = function(t, e, i) {
                    this.initFrame(), this.initBaseData(t, e, i), this.initTransform(t, e, i), this.initRenderable(), this.initHierarchy(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), (this.data.xt || !e.progressiveLoad) && this.buildAllItems(), this.hide()
                }, e8.prototype.prepareFrame = function(t) {
                    if (this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), this.isInRange || this.data.xt) {
                        if (this.tm._placeholder) this.renderedFrame = t / this.data.sr;
                        else {
                            var e, i = this.tm.v;
                            i === this.data.op && (i = this.data.op - 1), this.renderedFrame = i
                        }
                        var s = this.elements.length;
                        for (this.completeLayers || this.checkLayers(this.renderedFrame), e = s - 1; e >= 0; e -= 1)(this.completeLayers || this.elements[e]) && (this.elements[e].prepareFrame(this.renderedFrame - this.layers[e].st), this.elements[e]._mdf && (this._mdf = !0))
                    }
                }, e8.prototype.renderInnerContent = function() {
                    var t, e = this.layers.length;
                    for (t = 0; t < e; t += 1)(this.completeLayers || this.elements[t]) && this.elements[t].renderFrame()
                }, e8.prototype.setElements = function(t) {
                    this.elements = t
                }, e8.prototype.getElements = function() {
                    return this.elements
                }, e8.prototype.destroyElements = function() {
                    var t, e = this.layers.length;
                    for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy()
                }, e8.prototype.destroy = function() {
                    this.destroyElements(), this.destroyBaseElement()
                }, y([e6, e8, eM], e7), e7.prototype.createComp = function(t) {
                    return new e7(t, this.globalData, this)
                }, y([e6], it), it.prototype.createComp = function(t) {
                    return new e7(t, this.globalData, this)
                }, tn.svg = it, tz.registerModifier("tm", tN), tz.registerModifier("pb", tO), tz.registerModifier("rp", tq), tz.registerModifier("rd", tj), tz.registerModifier("zz", t3), tz.registerModifier("op", ei), tw
            }())
        }
    }
]);