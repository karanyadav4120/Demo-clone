"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5142], {
        45142: function(e, t, l) {
            l.r(t), l.d(t, {
                MIN_QUERY_LENGTH: function() {
                    return D
                },
                ModalSelectToken: function() {
                    return I
                },
                ModalSelectTokenQueryParams: function() {
                    return r
                },
                ModalSelectTokenTab: function() {
                    return o
                }
            });
            var n, a, r, o, s = l(85893),
                i = l(9264),
                d = l(67294),
                c = l(66314),
                u = l(69484),
                m = l(47540),
                h = l(87930),
                k = l(79577),
                x = l(27722),
                p = l(47043),
                g = l(3188),
                b = l(48791),
                v = l(99740),
                f = l(38826),
                w = l(31821),
                j = l(28285),
                N = l(49981),
                T = l(99640);
            (a || (a = {})).TOKEN_SEARCH = "token_search";
            let S = new class {
                constructor() {
                    this.emitTokenSearch = e => {
                        let {
                            searchTerm: t
                        } = e;
                        T.I.emitEvent(a.TOKEN_SEARCH, {
                            search_term: t
                        })
                    }
                }
            };
            var E = l(194),
                C = l(94184),
                _ = l.n(C),
                P = l(36521),
                y = l(18067),
                A = l(36789),
                L = l(47885),
                M = l(13915),
                F = l(85494),
                O = l(32483);
            let z = [{
                    id: "name",
                    title: "flooz-web.trade.modal-select-token.table.column.name",
                    titleAlignment: "left"
                }, {
                    id: "price",
                    title: "flooz-web.trade.modal-select-token.table.column.price"
                }, {
                    id: "delta",
                    title: "flooz-web.trade.modal-select-token.table.column.delta"
                }],
                R = e => {
                    let {
                        selectedNetwork: t,
                        onNetworkChange: l,
                        onTokenSelected: n,
                        onEmptyFeedbackActionClick: a,
                        tokens: r,
                        className: o,
                        isLoading: i,
                        isError: d,
                        isEmpty: c,
                        ...u
                    } = e, {
                        EMPTY: m,
                        ERROR: h,
                        NO_RESULT: k
                    } = A.l, x = {
                        namespace: "flooz-web.trade.modal-select-token.table.feedback",
                        context: d ? h : c ? m : k,
                        actionHref: F.hA,
                        actionLinkTarget: "_blank"
                    }, p = d || !i && null != r && 0 === r.length;
                    return (0, s.jsxs)(L.P, {
                        className: _()("modal-select-token-table", o),
                        gap: "100",
                        children: [null != l && !d && !c && (0, s.jsx)(L.P, {
                            gap: "50",
                            direction: "row",
                            grow: "1",
                            children: v.si.map(e => (0, s.jsx)(P.A, {
                                onClick: () => l(t === e ? void 0 : e),
                                variant: e === t ? "selected" : "secondary",
                                icon: v.Eu[e].logo,
                                className: "modal-select-token-table__network"
                            }, e))
                        }), (0, s.jsx)(y.w.Table, { ...u,
                            className: "modal-select-token-table__table",
                            columns: z,
                            feedback: x,
                            displayFeedback: p,
                            isLoading: i,
                            children: null == r ? void 0 : r.map(e => {
                                let {
                                    priceDelta: t,
                                    usdValue: l
                                } = e, a = t ? "".concat(M.z.formatNumber(t, {
                                    fixedFractionDigits: 2
                                }), "%") : void 0, r = l ? "$".concat(M.z.formatNumber(l, {
                                    fixedFractionDigits: 2,
                                    useSuperscriptFormat: !0,
                                    useRangeFormat: !0
                                })) : void 0;
                                return (0, s.jsxs)(y.w.Row, {
                                    onClick: () => null == n ? void 0 : n(e),
                                    children: [(0, s.jsx)(y.w.Cell, {
                                        children: (0, s.jsx)(O.W, {
                                            token: e
                                        })
                                    }), (0, s.jsx)(y.w.Cell, {
                                        ellipsis: !0,
                                        children: null != r ? r : "-"
                                    }), (0, s.jsx)(y.w.Cell, {
                                        ellipsis: !0,
                                        contextualValue: t,
                                        children: null != a ? a : "-"
                                    })]
                                }, e.address)
                            })
                        })]
                    })
                };
            (r || (r = {})).NETWORK = "network", (n = o || (o = {})).ALL_TOKENS = "ALL_TOKENS", n.MY_TOKENS = "MY_TOKENS";
            let K = [{
                    id: o.ALL_TOKENS,
                    label: "flooz-web.trade.modal-select-token.tab.".concat(o.ALL_TOKENS),
                    priority: 100
                }, {
                    id: o.MY_TOKENS,
                    label: "flooz-web.trade.modal-select-token.tab.".concat(o.MY_TOKENS),
                    priority: 200
                }],
                D = 3,
                I = e => {
                    var t, l;
                    let {
                        location: n
                    } = e, {
                        modalHistory: a
                    } = (0, x.N)(), {
                        t: T
                    } = (0, i.$G)(), {
                        selectedAccount: C
                    } = (0, b.Z_)(), _ = new URLSearchParams(n.search), P = null !== (t = _.get(r.NETWORK)) && void 0 !== t ? t : void 0, [y, A] = (0, d.useState)(P), {
                        onTokenSelected: L
                    } = null !== (l = a.location.state) && void 0 !== l ? l : {}, [M, F] = (0, d.useState)(o.ALL_TOKENS), [O, z] = (0, d.useState)(""), I = (0, w.N)(O, 500), W = N.a.isAddress(I), B = I.trim().length >= D, {
                        list: q,
                        status: Y
                    } = (0, j.h)(), H = (0, d.useMemo)(() => q.filter(e => E.S.filterTokenByNetwork(e.network, y)), [q, y]), Q = B && !W, U = {
                        query: I.trim(),
                        network: y
                    }, {
                        data: G,
                        isFetching: V,
                        isError: $
                    } = (0, m.P)({
                        queryParameters: U
                    }, {
                        enabled: Q
                    }), J = B && W, {
                        data: Z,
                        isFetching: X,
                        isError: ee
                    } = (0, u.d)({
                        pathParameters: {
                            tokenAddress: I
                        },
                        queryParameters: {
                            network: y
                        }
                    }, {
                        enabled: J
                    }), et = {
                        status: c.Y.VERIFIED,
                        network: y,
                        limit: 20
                    }, {
                        data: el,
                        status: en,
                        isFetchingNextPage: ea,
                        hasNextPage: er,
                        fetchNextPage: eo
                    } = (0, m.K)({
                        queryParameters: et
                    }), es = (0, d.useMemo)(() => null == el ? void 0 : el.pages.flatMap(e => {
                        let {
                            result: t
                        } = e;
                        return t
                    }), [null == el ? void 0 : el.pages]), ei = (0, d.useCallback)(e => {
                        a.back(), null == L || L(e)
                    }, [a, L]), ed = e => F(e), ec = () => a.push(f._.connect), eu = null != P ? void 0 : A;
                    return (0, d.useEffect)(() => {
                        I.length > 0 && S.emitTokenSearch({
                            searchTerm: I
                        })
                    }, [I]), (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(k.u.Header, {
                            title: T("flooz-web.trade.modal-select-token.title"),
                            subtitle: P ? v.Eu[P].label : void 0
                        }), (0, s.jsx)(k.u.Content, {
                            className: "modal-select-token",
                            children: (0, s.jsxs)(g.m.Container, {
                                className: "modal-select-token__tabs",
                                selectedTabId: M,
                                onTabSelected: ed,
                                variant: "sheet",
                                alignTabs: "center",
                                tabEntries: K,
                                children: [(0, s.jsx)(g.m.Tab, {
                                    id: o.ALL_TOKENS,
                                    children: (0, s.jsxs)(h.P, {
                                        direction: "column",
                                        gap: "100",
                                        grow: "1",
                                        children: [(0, s.jsx)(p.E.Container, {
                                            value: O,
                                            onChange: e => z(null != e ? e : ""),
                                            placeholder: T("flooz-web.trade.modal-select-token.input-placeholder")
                                        }), Q || J ? (0, s.jsx)(R, {
                                            tokens: J && Z ? [Z] : null == G ? void 0 : G.result,
                                            onTokenSelected: ei,
                                            selectedNetwork: y,
                                            onNetworkChange: eu,
                                            isLoading: V || X,
                                            isError: $ || ee
                                        }) : (0, s.jsx)(R, {
                                            tokens: es,
                                            onTokenSelected: ei,
                                            selectedNetwork: y,
                                            onNetworkChange: eu,
                                            onLoadMore: eo,
                                            hasNextPage: er,
                                            isLoading: "loading" === en || ea,
                                            isError: "error" === en
                                        })]
                                    })
                                }), (0, s.jsx)(g.m.Tab, {
                                    id: o.MY_TOKENS,
                                    children: (0, s.jsx)(R, {
                                        tokens: H,
                                        selectedNetwork: y,
                                        onTokenSelected: ei,
                                        onNetworkChange: eu,
                                        isEmpty: null == C,
                                        onEmptyFeedbackActionClick: ec,
                                        isError: "error" === Y
                                    })
                                })]
                            })
                        })]
                    })
                }
        },
        194: function(e, t, l) {
            var n, a;
            l.d(t, {
                S: function() {
                    return r
                }
            }), (a = n || (n = {})).ONRAMP = "onramp", a.OFFRAMP = "offramp";
            let r = new class {
                constructor() {
                    this.getTokenAmountInUSD = (e, t) => {
                        var l;
                        return (parseFloat(null != e ? e : "0") * parseFloat(null !== (l = null == t ? void 0 : t.usdValue) && void 0 !== l ? l : "0")).toFixed(2)
                    }, this.filterTokenByName = function(e) {
                        let {
                            name: t,
                            symbol: l
                        } = e, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                        return t.toLowerCase().includes(null == n ? void 0 : n.toLowerCase()) || l.toLowerCase().includes(n.toLowerCase())
                    }, this.filterTokenByNetwork = (e, t) => null == t || t === e, this.filterTokenByStatus = (e, t) => null == t || t === e, this.filterTokenByRampProvider = (e, t) => {
                        var l, a;
                        return null == t || t === n.OFFRAMP && (null === (l = e.rampProviders) || void 0 === l ? void 0 : l.some(e => e.allowsSellingToken)) || t === n.ONRAMP && (null === (a = e.rampProviders) || void 0 === a ? void 0 : a.some(e => e.allowsBuyingToken))
                    }
                }
            }
        },
        77356: function(e, t, l) {
            var n, a;
            l.d(t, {
                S: function() {
                    return n
                }
            }), (a = n || (n = {})).ASC = "asc", a.DESC = "desc"
        },
        47540: function(e, t, l) {
            l.d(t, {
                K: function() {
                    return d
                },
                P: function() {
                    return i
                }
            });
            var n = l(85945),
                a = l(36492),
                r = l(59403),
                o = l(46223),
                s = l(19069);
            let i = (e, t) => {
                    let l = (0, n.NL)();
                    return (0, a.a)(s.a.tokenList(e), () => o.W4.getTokenList(e), { ...t,
                        onSuccess: e => {
                            var n;
                            e.result.forEach(e => {
                                let t = {
                                        tokenAddress: e.address
                                    },
                                    n = {
                                        network: e.network
                                    },
                                    a = s.a.token({
                                        queryParameters: n,
                                        pathParameters: t
                                    });
                                l.setQueryData(a, e)
                            }), null == t || null === (n = t.onSuccess) || void 0 === n || n.call(t, e)
                        }
                    })
                },
                d = (e, t) => {
                    let l = (0, n.NL)();
                    return (0, r.N)(s.a.tokenList(e), t => {
                        let {
                            pageParam: l
                        } = t;
                        return o.W4.getTokenList({ ...e,
                            ...l
                        })
                    }, { ...t,
                        getNextPageParam: t => o.W4.getReactQueryPaginatedParams(t, e),
                        onSuccess: e => {
                            var n;
                            let a = [...e.pages].pop();
                            null == a || a.result.forEach(e => {
                                let t = {
                                        tokenAddress: e.address
                                    },
                                    n = {
                                        network: e.network
                                    },
                                    a = s.a.token({
                                        queryParameters: n,
                                        pathParameters: t
                                    });
                                l.setQueryData(a, e)
                            }), null == t || null === (n = t.onSuccess) || void 0 === n || n.call(t, e)
                        }
                    })
                }
        },
        36521: function(e, t, l) {
            l.d(t, {
                A: function() {
                    return n.A
                }
            });
            var n = l(39430)
        },
        18067: function(e, t, l) {
            l.d(t, {
                w: function() {
                    return A
                }
            });
            var n = l(85893),
                a = l(94184),
                r = l.n(a),
                o = l(9264),
                s = l(67294),
                i = l(77902),
                d = l(49105),
                c = l(47885);
            let u = (0, s.createContext)(void 0),
                m = u.Provider,
                h = () => {
                    let e = (0, s.useContext)(u);
                    if (null == e) throw Error("dataTableContext: the hook must be used inside a DataTableContextProvider to work properly");
                    return e
                },
                k = {
                    id: "actions"
                },
                x = {
                    id: "rowIndex",
                    titleAlignment: "left"
                };
            var p = l(77356),
                g = l(33715),
                b = l(10673),
                v = l(1527);
            let f = (e, t) => t && t.columnId === e ? "asc" === t.direction ? g.T.SORT_ASC : g.T.SORT_DESC : g.T.SORT_DEFAULT,
                w = (e, t) => {
                    let l = null == t ? p.S.DESC : t.direction === p.S.DESC ? p.S.ASC : void 0;
                    return l ? {
                        columnId: e,
                        direction: l
                    } : void 0
                },
                j = e => {
                    let {
                        column: t,
                        className: l,
                        ...a
                    } = e, {
                        currentSort: s,
                        updateSorting: i
                    } = h(), {
                        t: d
                    } = (0, o.$G)(), {
                        id: u,
                        title: m,
                        titleAlignment: k = "right",
                        minBreakpoint: x,
                        isHidden: p,
                        infoTooltip: j,
                        isSortable: N
                    } = t, T = f(u, s), S = () => i(w(u, s));
                    return (0, n.jsx)("th", {
                        className: r()("data-table-head", {
                            "data-table-head--hidden": p
                        }, {
                            ["data-table-head--hidden-".concat(x)]: null != x
                        }, l),
                        "data-column": u,
                        ...a,
                        children: (0, n.jsx)(c.P, {
                            direction: "row",
                            gap: "0",
                            grow: "1",
                            justifyContent: "right" === k ? "end" : "start",
                            children: (0, n.jsxs)(c.P, {
                                direction: "row",
                                gap: "25",
                                alignItems: "center",
                                shrink: "1",
                                onClick: N ? S : void 0,
                                role: N ? "button" : void 0,
                                className: r()("data-table-head__layout", {
                                    "data-table-head__layout--sortable": N
                                }),
                                children: [(0, n.jsx)(v.x, {
                                    size: "m",
                                    color: "muted",
                                    ellipsis: !0,
                                    children: m ? d(m) : ""
                                }), j && (0, n.jsx)(b.b, { ...j
                                }), N && (0, n.jsx)(g.J, {
                                    icon: T
                                })]
                            })
                        })
                    })
                };
            var N = l(55642),
                T = l(90544),
                S = l(10070);
            let E = e => {
                let {
                    column: t,
                    link: l,
                    target: a,
                    className: o,
                    children: s,
                    ellipsis: i,
                    contextualValue: d,
                    ...c
                } = e;
                (0, T.k)(null != t, "DataTableCell: component must be used inside a DataTableRow component");
                let {
                    id: u,
                    minBreakpoint: m,
                    isHidden: h,
                    titleAlignment: k = "right"
                } = t, x = "number" == typeof d ? d : null != d ? parseFloat(d) : void 0, p = (0, n.jsx)(v.x, {
                    className: "data-table-cell__text",
                    textAlign: k,
                    component: "span",
                    fontWeight: "regular",
                    ellipsis: i,
                    color: null != x ? x > 0 ? "success" : "muted" : "inherit",
                    children: s
                });
                return (0, n.jsxs)("td", {
                    className: r()("data-table-cell", {
                        "data-table-cell--hidden": h
                    }, {
                        ["data-table-cell--hidden-".concat(m)]: null != m
                    }, o),
                    "data-column": u,
                    ...c,
                    children: [null != l && (0, n.jsx)(S.r, {
                        href: l,
                        target: a,
                        children: p
                    }), null == l && p]
                })
            };
            var C = l(79516);
            let _ = e => {
                    let {
                        rowIndex: t,
                        className: l,
                        children: a,
                        actions: o,
                        onClick: d,
                        ...c
                    } = e, {
                        numbered: u,
                        columns: m,
                        setHasActions: p
                    } = h(), g = s.Children.toArray(a), b = Boolean(u) && null != t, f = null != o && o.length > 0, w = f ? o[0] : void 0;
                    return (0, s.useEffect)(() => {
                        f && p(!0)
                    }, [f, p]), (0, n.jsxs)("tr", {
                        className: r()("data-table-row", {
                            "data-table-row--clickable": null != d
                        }, l),
                        onClick: d,
                        ...c,
                        children: [b && (0, n.jsx)(E, {
                            column: x,
                            children: (0, n.jsx)(v.x, {
                                size: "l",
                                color: "muted",
                                children: t + 1
                            })
                        }), null == g ? void 0 : g.map((e, t) => (0, n.jsx)(s.Fragment, {
                            children: s.cloneElement(e, {
                                column: m[t],
                                ...e.props
                            })
                        }, t)), f && o.length > 1 && (0, n.jsx)(E, {
                            column: k,
                            children: (0, n.jsx)(C.P.Container, {
                                title: "",
                                useMobileDialog: !1,
                                placement: "bottom-end",
                                children: o.map(e => (0, n.jsx)(C.P.Item, { ...e
                                }, e.label))
                            })
                        }), f && 1 === o.length && (0, n.jsx)(E, {
                            column: k,
                            children: (0, n.jsx)(i.z, {
                                variant: "text",
                                size: "m",
                                icon: null == w ? void 0 : w.icon,
                                onClick: null == w ? void 0 : w.onClick
                            })
                        })]
                    })
                },
                P = e => {
                    let {
                        loadingElements: t = 3
                    } = e, {
                        numbered: l,
                        columns: a,
                        hasActions: r
                    } = h(), o = [...Array(t).keys()], i = (0, s.useMemo)(() => {
                        let e = l ? [x, ...a] : [...a];
                        return r ? e.concat(k) : e
                    }, [a, l, r]);
                    return (0, n.jsx)(n.Fragment, {
                        children: o.map(e => (0, n.jsx)(_, {
                            children: i.map(e => (0, n.jsx)(E, {
                                column: e,
                                children: (0, n.jsx)(N.g, {
                                    width: "100%",
                                    height: 32
                                })
                            }, e.id))
                        }, e))
                    })
                },
                y = e => {
                    var t;
                    let {
                        numbered: l = !1,
                        columns: a,
                        hasNextPage: u,
                        className: h,
                        maxRows: p = 25,
                        onLoadMore: g,
                        currentSort: b,
                        onSort: v,
                        isLoading: f,
                        feedback: w,
                        displayFeedback: N,
                        children: T,
                        ...S
                    } = e, {
                        t: E
                    } = (0, o.$G)(), C = s.Children.toArray(T), [_, y] = (0, s.useState)(0), [A, L] = (0, s.useState)(!1), M = (0, s.useMemo)(() => null !== (t = null == C ? void 0 : C.slice(0, p * (_ + 1))) && void 0 !== t ? t : [], [C, p, _]), F = null != T && C.length > M.length, O = (0, s.useCallback)(e => null == v ? void 0 : v(e), [v]), z = () => {
                        F || null == g || g(), y(e => e + 1)
                    }, R = (0, s.useMemo)(() => ({
                        numbered: l,
                        columns: a,
                        currentSort: b,
                        updateSorting: O,
                        setHasActions: L,
                        hasActions: A
                    }), [l, a, b, O, L, A]);
                    return (0, n.jsx)(m, {
                        value: R,
                        children: (0, n.jsxs)(c.P, {
                            gap: "200",
                            className: r()("data-table", h),
                            children: [N && w && (0, n.jsx)(d.x, { ...w
                            }), !N && (0, n.jsxs)("table", {
                                className: "data-table__table",
                                ...S,
                                children: [(0, n.jsx)("thead", {
                                    children: (0, n.jsxs)("tr", {
                                        children: [l && (0, n.jsx)(j, {
                                            column: x
                                        }), a.map(e => (0, n.jsx)(j, {
                                            column: e
                                        }, e.id)), A && (0, n.jsx)(j, {
                                            column: k
                                        })]
                                    })
                                }), (0, n.jsxs)("tbody", {
                                    children: [M.map((e, t) => (0, n.jsx)(s.Fragment, {
                                        children: s.cloneElement(e, {
                                            rowIndex: t,
                                            ...e.props
                                        })
                                    }, t)), f && (0, n.jsx)(P, {})]
                                })]
                            }), (F || u) && !N && (0, n.jsx)(i.z, {
                                disabled: f,
                                variant: "text",
                                size: "l",
                                onClick: z,
                                children: E("flooz-web.shared.data-table.load-more")
                            })]
                        })
                    })
                },
                A = {
                    Table: y,
                    Row: _,
                    Cell: E
                }
        },
        10673: function(e, t, l) {
            l.d(t, {
                b: function() {
                    return m
                }
            });
            var n = l(85893),
                a = l(94184),
                r = l.n(a);
            l(67294);
            var o = l(33715),
                s = l(47885),
                i = l(1527),
                d = l(11217),
                c = l(10070);
            let u = e => {
                    let {
                        primaryInfo: t,
                        secondaryInfo: l,
                        link: a,
                        linkTarget: o,
                        className: d
                    } = e;
                    return (0, n.jsxs)(s.P, {
                        className: r()("info-tooltip-content", d),
                        gap: "75",
                        direction: "column",
                        children: [(0, n.jsx)(i.x, {
                            size: "m",
                            color: "white",
                            children: a ? (0, n.jsx)(c.r, {
                                href: a,
                                target: o,
                                children: t
                            }) : t
                        }), l && (0, n.jsx)("div", {
                            className: "info-tooltip-content__secondary-info",
                            children: (0, n.jsx)(i.x, {
                                size: "m",
                                fontWeight: "regular",
                                children: l
                            })
                        })]
                    })
                },
                m = e => {
                    let {
                        label: t,
                        className: l,
                        ...a
                    } = e;
                    return (0, n.jsxs)(s.P, {
                        gap: "50",
                        direction: "row",
                        alignItems: "center",
                        children: [t && (0, n.jsx)(i.x, {
                            size: "l",
                            fontWeight: "regular",
                            children: t
                        }), (0, n.jsx)(d.u, {
                            className: r()("info-tooltip", l),
                            contentClassName: "info-tooltip__content-wrapper",
                            tooltipContent: (0, n.jsx)(u, { ...a
                            }),
                            children: (0, n.jsx)(s.P, {
                                gap: "0",
                                children: (0, n.jsx)(o.J, {
                                    icon: o.T.INFO
                                })
                            })
                        })]
                    })
                }
        },
        28285: function(e, t, l) {
            l.d(t, {
                h: function() {
                    return m
                }
            });
            var n = l(67294),
                a = l(36492),
                r = l(46223),
                o = l(19069);
            let s = (e, t) => (0, a.a)(o.a.tokenPortfolio(e), () => r.W4.getTokenPortfolio(e), t);
            var i = l(94176),
                d = l(48791),
                c = l(99740);
            let u = new Map,
                m = e => {
                    var t;
                    let {
                        selectedAccount: l
                    } = (0, d.Z_)(), {
                        impersonatedUser: a
                    } = (0, i.UV)(), r = null !== (t = null != e ? e : a) && void 0 !== t ? t : l, {
                        data: o,
                        status: m,
                        isInitialLoading: h,
                        dataUpdatedAt: k
                    } = s({
                        queryParameters: {
                            invalidate: r === l
                        },
                        pathParameters: {
                            address: r
                        }
                    }, {
                        enabled: null != r
                    }), {
                        map: x,
                        list: p,
                        hiddenList: g
                    } = (0, n.useMemo)(() => {
                        var e, t, l;
                        if (!r || !o) return {
                            map: new Map,
                            list: [],
                            hiddenList: []
                        };
                        let n = null === (e = u.get(r)) || void 0 === e ? void 0 : e.get(k);
                        if (n) return n;
                        let a = o.tokens.filter(e => !0 !== e.hidden).sort((e, n) => parseFloat(null !== (t = n.usdBalance) && void 0 !== t ? t : "0") - parseFloat(null !== (l = e.usdBalance) && void 0 !== l ? l : "0")),
                            s = o.tokens.filter(e => !0 === e.hidden),
                            i = new Map(c.si.map(e => [e, new Map]));
                        a.forEach(e => {
                            var t;
                            return null === (t = i.get(e.network)) || void 0 === t ? void 0 : t.set(e.address, e)
                        });
                        let d = {
                            map: i,
                            list: a,
                            hiddenList: s
                        };
                        return u.set(r, new Map([
                            [k, d]
                        ])), d
                    }, [r, o, k]);
                    return {
                        list: p,
                        hiddenList: g,
                        map: x,
                        status: h ? "loading" : "error" === m ? "error" : "success" === m ? "success" : "idle"
                    }
                }
        }
    }
]);