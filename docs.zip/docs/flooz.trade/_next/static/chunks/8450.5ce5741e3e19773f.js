"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8450], {
        60590: function(e, t, i) {
            i.d(t, {
                p: function() {
                    return r
                }
            });
            var s = i(67294),
                n = i(34443),
                l = i(67797),
                c = i(87988),
                o = i(60759);
            let r = () => {
                var e;
                let {
                    data: t
                } = (0, l.D)({
                    key: o.mJ.acceptedTermsOfServiceVersion
                }), {
                    mutate: i
                } = (0, n.h)(), {
                    data: r
                } = (0, c.m)(), a = parseFloat(null !== (e = null == r ? void 0 : r.termsOfServiceVersion) && void 0 !== e ? e : "") || 1, u = parseFloat(null != t ? t : "") || 0, d = (0, s.useCallback)(() => {
                    i({
                        key: o.mJ.acceptedTermsOfServiceVersion,
                        value: a.toString()
                    })
                }, [a, i]);
                return {
                    userNeedsToAcceptCurrentToS: u < a,
                    handleUserAcceptedCurrentToS: d
                }
            }
        },
        48450: function(e, t, i) {
            i.r(t), i.d(t, {
                CookiesDisclaimer: function() {
                    return E
                }
            });
            var s = i(85893),
                n = i(9264),
                l = i(11163),
                c = i(67294),
                o = i(99640),
                r = i(77902),
                a = i(81031),
                u = i(47885),
                d = i(27722),
                p = i(1527),
                m = i(99185),
                f = i(60759),
                k = i(39376),
                h = i(3703),
                v = i(60590),
                b = i(85494);
            let E = e => {
                let {
                    onAcceptCookiesChange: t
                } = e, {
                    t: i
                } = (0, n.$G)(), {
                    isGdprCountry: E
                } = (0, a.Y)(), x = (0, l.useRouter)(), g = (0, k.s)(), {
                    userNeedsToAcceptCurrentToS: w
                } = (0, v.p)(), {
                    modalHistory: C
                } = (0, d.N)(), [_, z] = (0, c.useState)();
                (0, c.useEffect)(() => {
                    z(!0 === f.Wl.get(f.mJ.cookiesAccepted))
                }, []);
                let S = !0 === _ || g || !1 === E;
                (0, c.useEffect)(() => {
                    o.I.setEnabled(S), m.M.setEnabled(S), null == t || t(S)
                }, [t, S]), (0, c.useEffect)(() => {
                    _ && w && C.push(h.D.tosUpdated)
                }, [_, C, w]), (0, c.useEffect)(() => {
                    S && o.I.initAttributionService(x.pathname)
                }, [S, x]);
                let D = () => {
                    z(!0), f.Wl.set(f.mJ.cookiesAccepted, !0)
                };
                return S || void 0 === _ ? null : (0, s.jsxs)(u.P, {
                    className: "cookies-disclaimer",
                    direction: "row",
                    alignItems: "center",
                    gap: "150",
                    children: [(0, s.jsxs)("div", {
                        children: [(0, s.jsxs)(p.x, {
                            size: "l",
                            color: "muted",
                            component: "span",
                            children: [i("flooz-web.application.cookies-disclaimer.message"), " "]
                        }), (0, s.jsx)(r.Z, {
                            variant: "text",
                            size: "m",
                            isInline: !0,
                            href: b.mW,
                            target: "_blank",
                            children: i("flooz-web.application.cookies-disclaimer.privacy-link")
                        })]
                    }), (0, s.jsxs)(r.z, {
                        variant: "primary",
                        size: "m",
                        onClick: D,
                        className: "cookies-disclaimer__accept-button",
                        children: ["\uD83E\uDD24 ", i("flooz-web.application.cookies-disclaimer.accept-link")]
                    })]
                })
            }
        },
        99185: function(e, t, i) {
            i.d(t, {
                I: function() {
                    return o
                },
                M: function() {
                    return c
                }
            });
            var s = i(18472),
                n = i(67294),
                l = i(48791);
            let c = new class {
                    constructor() {
                        this.setEnabled = e => {
                            this.enabled = e
                        }, this.logException = (e, t) => {
                            this.enabled && s.Tb(e, t)
                        }, this.flush = e => s.yl(e), this.enabled = !1
                    }
                },
                o = () => {
                    let {
                        selectedAccount: e,
                        providerNetwork: t,
                        activeConnector: i
                    } = (0, l.Z_)(), s = (0, n.useCallback)(s => {
                        let {
                            exception: n,
                            context: l,
                            severity: o = "error"
                        } = s, r = {
                            id: null == e ? void 0 : e.toLowerCase()
                        };
                        c.logException(n, {
                            user: r,
                            tags: {
                                connector: i,
                                providerNetwork: t
                            },
                            contexts: l ? {
                                context: l
                            } : void 0,
                            level: o
                        })
                    }, [e, t, i]);
                    return {
                        logException: s
                    }
                }
        }
    }
]);