"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6744, 9846, 7038], {
        55613: function(e, t, n) {
            n.d(t, {
                C: function() {
                    return d
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i);
            n(67294);
            var r = n(10453),
                l = n(33715);
            let s = e => {
                    let {
                        tokenId: t
                    } = null != e ? e : {};
                    return t ? "".concat(t, " image") : "NFT image"
                },
                d = e => {
                    var t;
                    let {
                        nft: n,
                        logo: i,
                        className: d,
                        ...c
                    } = e;
                    return (0, o.jsx)(r.F, {
                        className: a()("nft-logo", d),
                        placeholder: l.T.LOGO_NFT_DEFAULT,
                        logo: null !== (t = null == n ? void 0 : n.tokenImageUri) && void 0 !== t ? t : i,
                        alt: s(n),
                        ...c
                    })
                }
        },
        28497: function(e, t, n) {
            n.d(t, {
                X: function() {
                    return s
                }
            });
            var o = n(36492),
                i = n(60759);
            let a = (e, t) => ({
                placeholderData: i.Wl.get(i.mJ.floozOfflineQuery(e)),
                onSuccess: n => {
                    var o;
                    i.Wl.set(i.mJ.floozOfflineQuery(e), n), null == t || null === (o = t.onSuccess) || void 0 === o || o.call(t, n)
                }
            });
            var r = n(87291),
                l = n(45356);
            let s = (e, t) => (0, o.a)(l.a.follows(e), () => r.Mp.getFollows(e), { ...t,
                ...a(l.a.follows(e), t)
            })
        },
        76729: function(e, t, n) {
            n.r(t), n.d(t, {
                ModalReferral: function() {
                    return u
                },
                ModalReferralQueryParams: function() {
                    return i
                }
            });
            var o, i, a = n(85893),
                r = n(9264);
            n(67294);
            var l = n(69484),
                s = n(47885),
                d = n(79577),
                c = n(28179);
            (o = i || (i = {})).TOKEN = "token", o.NETWORK = "network";
            let u = e => {
                var t;
                let {
                    location: n
                } = e, {
                    t: o
                } = (0, r.$G)(), u = new URLSearchParams(n.search), m = u.get(i.TOKEN), p = null !== (t = u.get(i.NETWORK)) && void 0 !== t ? t : void 0, {
                    data: f
                } = (0, l.d)({
                    pathParameters: {
                        tokenAddress: m
                    },
                    queryParameters: {
                        network: p
                    }
                }, {
                    enabled: null != m
                }), v = o("flooz-web.profile.modal-referral.title", {
                    token: null == f ? void 0 : f.symbol,
                    context: f ? "token" : "generic"
                });
                return (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(d.u.Header, {
                        title: v
                    }), (0, a.jsx)(d.u.Content, {
                        children: (0, a.jsxs)(s.P, {
                            gap: "200",
                            direction: "column",
                            grow: "1",
                            children: [(0, a.jsx)("p", {
                                className: "center-text",
                                children: o("flooz-web.profile.modal-referral.description")
                            }), (0, a.jsx)(c.J, {
                                token: f
                            })]
                        })
                    })]
                })
            }
        },
        44105: function(e, t, n) {
            n.d(t, {
                f: function() {
                    return b
                }
            });
            var o = n(85893),
                i = n(9264),
                a = n(68091),
                r = n(69355),
                l = n(27722),
                s = n(1527),
                d = n(90271),
                c = n(67294),
                u = n(51249),
                m = n(77902),
                p = n(33715),
                f = n(47885),
                v = n(85795),
                k = n(96942),
                h = n(20706),
                T = n(34123),
                x = n(21546);
            let g = e => {
                var t, n, a, g, y;
                let {
                    activity: w
                } = e, {
                    t: N
                } = (0, i.$G)(), {
                    modalHistory: b
                } = (0, l.N)(), _ = (0, o.jsxs)("div", {
                    className: "profile-activity__icon-wrapper",
                    children: [(0, o.jsx)(h.S, {
                        token: w.indirectToken,
                        className: "profile-activity__large-icon"
                    }), (0, o.jsx)(p.J, {
                        icon: p.T.PROFILE_ACTIVITY_PENDING_BUY_ANY_INDICATOR,
                        className: "profile-activity__indicator"
                    })]
                }), j = () => {
                    b.push(d.e.pendingActivityDetails, void 0, {
                        activity: w
                    })
                }, E = () => {
                    b.push(d.e.startBuyAnySwapActivity, void 0, {
                        activity: w
                    }), T.KY.emitBuyAnySwapNow(w)
                }, C = () => {
                    b.push(d.e.cancelBuyAnySwapActivity, void 0, {
                        activity: w
                    }), T.KY.emitBuyAnyCancel(w)
                };
                return (0, o.jsx)(r.s.Item, {
                    className: "profile-activity-pending-buy-any",
                    children: (0, o.jsxs)(f.P, {
                        className: "profile-activity-pending-buy-any__layout",
                        gap: "100",
                        direction: "row",
                        grow: "1",
                        shrink: "1",
                        children: [(0, o.jsx)(f.P, {
                            className: "profile-activity-pending-buy-any__icon-wrapper",
                            alignItems: "center",
                            justifyContent: "center",
                            gap: "100",
                            children: c.cloneElement(_, _.props)
                        }), (0, o.jsxs)(f.P, {
                            className: "profile-activity-pending-buy-any__first-column",
                            gap: "25",
                            grow: "1",
                            shrink: "1",
                            children: [(0, o.jsxs)(f.P, {
                                direction: "row",
                                gap: "25",
                                justifyContent: "space-between",
                                shrink: "1",
                                children: [(0, o.jsx)(s.x, {
                                    ellipsis: !0,
                                    children: N("flooz-web.profile.activities.activity-title", {
                                        context: "".concat(null === (t = w.type) || void 0 === t ? void 0 : t.toLowerCase(), "-buying"),
                                        token: null === (n = w.indirectToken) || void 0 === n ? void 0 : n.name
                                    })
                                }), (0, o.jsx)(s.x, {
                                    ellipsis: !0,
                                    color: "muted",
                                    fontWeight: "regular",
                                    children: x.H.getFiatAmountText(w)
                                })]
                            }), (0, o.jsxs)(f.P, {
                                direction: "row",
                                gap: "25",
                                justifyContent: "space-between",
                                alignItems: "end",
                                children: [(0, o.jsxs)(v.v.Container, {
                                    className: "profile-activity-pending-buy-any__stepper",
                                    children: [(0, o.jsx)(v.v.Step, {
                                        status: w.transactionStatus == u.kl.COMPLETED ? k.x.COMPLETED : w.transactionStatus == u.kl.PENDING ? k.x.PENDING : k.x.ACTIVE,
                                        onClick: j,
                                        children: (0, o.jsx)(s.x, {
                                            color: "muted",
                                            fontWeight: "regular",
                                            isUnderlined: !0,
                                            ellipsis: !0,
                                            children: N("flooz-web.profile.activities.activity-title", {
                                                context: "".concat(null === (a = w.type) || void 0 === a ? void 0 : a.toLowerCase(), "-").concat(w.transactionStatus != u.kl.COMPLETED ? "buying" : "bought"),
                                                token: w.token.name
                                            })
                                        })
                                    }), (0, o.jsx)(v.v.Step, {
                                        status: w.indirectStatus == u._H.COMPLETED ? k.x.COMPLETED : w.transactionStatus == u.kl.PENDING ? k.x.IDLE : k.x.ACTIVE,
                                        children: (0, o.jsx)(s.x, {
                                            color: "muted",
                                            fontWeight: "regular",
                                            ellipsis: !0,
                                            children: N("flooz-web.profile.activities.activity-title", {
                                                context: "".concat(null === (g = w.type) || void 0 === g ? void 0 : g.toLowerCase(), "-swap-to"),
                                                token: null === (y = w.indirectToken) || void 0 === y ? void 0 : y.name
                                            })
                                        })
                                    })]
                                }), (0, o.jsxs)(f.P, {
                                    gap: "50",
                                    direction: "row",
                                    className: "profile-activity-pending-buy-any__buttons",
                                    children: [(0, o.jsx)(m.z, {
                                        variant: "primary",
                                        size: "s",
                                        onClick: E,
                                        disabled: w.transactionStatus != u.kl.COMPLETED,
                                        children: N("flooz-web.profile.activities.swap-now")
                                    }), (0, o.jsx)(m.z, {
                                        variant: "secondary",
                                        size: "s",
                                        onClick: C,
                                        children: N("flooz-web.profile.activities.cancel")
                                    })]
                                })]
                            })]
                        })]
                    })
                })
            };
            var y = n(99740);
            let w = e => {
                    var t, n;
                    let {
                        activity: a,
                        onClick: l
                    } = e, {
                        t: s
                    } = (0, i.$G)();
                    return (0, o.jsx)(r.s.Item, {
                        onClick: l,
                        structuredChildren: {
                            icon: (0, o.jsxs)("div", {
                                className: "profile-activity__icon-wrapper",
                                children: [(0, o.jsx)(h.S, {
                                    token: a.token,
                                    className: "profile-activity__large-icon"
                                }), (0, o.jsx)(p.J, {
                                    icon: p.T.PROFILE_ACTIVITY_PENDING_BUY_TOKEN_INDICATOR,
                                    className: "profile-activity__indicator"
                                })]
                            }),
                            firstColumnTitle: "".concat(s("flooz-web.profile.activities.activity-title", {
                                context: "on-ramp-pending",
                                toToken: null === (t = a.token) || void 0 === t ? void 0 : t.name
                            })),
                            firstColumnSubtitle: "".concat(y.Eu[a.network].label),
                            secondColumnTitle: (0, o.jsxs)("span", {
                                children: ["+", " ", x.H.getTokenText(x.H.getFormattedTokenAmount(a.rate, a.fiatAmount), null == a ? void 0 : null === (n = a.token) || void 0 === n ? void 0 : n.symbol)]
                            }),
                            secondColumnSubtitle: x.H.getFiatAmountText(a)
                        }
                    })
                },
                N = e => {
                    var t, n, a, l, s, d;
                    let {
                        activity: c,
                        onClick: u
                    } = e, {
                        t: m
                    } = (0, i.$G)();
                    return (0, o.jsx)(r.s.Item, {
                        onClick: u,
                        structuredChildren: {
                            icon: (0, o.jsxs)("div", {
                                className: "profile-activity__icon-wrapper profile-activity__icon-wrapper--swap",
                                children: [(0, o.jsx)(h.S, {
                                    token: c.tokenFrom,
                                    className: "profile-activity__swap-logo profile-activity__swap-logo--to"
                                }), (0, o.jsx)(h.S, {
                                    token: c.tokenTo,
                                    className: "profile-activity__swap-logo profile-activity__swap-logo--from"
                                }), (0, o.jsx)(p.J, {
                                    icon: p.T.PROFILE_ACTIVITY_PENDING_SWAP_INDICATOR,
                                    className: "profile-activity__indicator"
                                })]
                            }),
                            firstColumnTitle: (0, o.jsxs)(o.Fragment, {
                                children: [m("flooz-web.profile.activities.activity-title", {
                                    context: "".concat(null === (t = c.type) || void 0 === t ? void 0 : t.toLowerCase(), "-from-pending"),
                                    fromToken: null === (n = c.tokenFrom) || void 0 === n ? void 0 : n.name
                                }), (0, o.jsx)("br", {}), m("flooz-web.profile.activities.activity-title", {
                                    context: "".concat(null === (a = c.type) || void 0 === a ? void 0 : a.toLowerCase(), "-to-pending"),
                                    toToken: null === (l = c.tokenTo) || void 0 === l ? void 0 : l.name
                                })]
                            }),
                            firstColumnSubtitle: "".concat(m("flooz-web.profile.activities.usd-value")),
                            secondColumnTitle: (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsxs)("span", {
                                    title: c.amountFrom,
                                    className: "profile-activity-list-item__price--from",
                                    children: ["-", x.H.getTokenText(c.amountFrom, null === (s = c.tokenFrom) || void 0 === s ? void 0 : s.symbol)]
                                }), (0, o.jsx)("br", {}), (0, o.jsxs)("span", {
                                    title: c.amountTo,
                                    children: ["+", x.H.getTokenText(c.amountTo, null === (d = c.tokenTo) || void 0 === d ? void 0 : d.symbol)]
                                })]
                            }),
                            secondColumnSubtitle: x.H.getUsdValueText(c)
                        }
                    })
                },
                b = e => {
                    let {
                        activities: t
                    } = e, {
                        t: n
                    } = (0, i.$G)(), {
                        modalHistory: c
                    } = (0, l.N)(), u = e => {
                        c.push(d.e.pendingActivityDetails, new URLSearchParams([]), {
                            activity: e
                        })
                    };
                    return (0, o.jsxs)("div", {
                        className: "profile-activities-pending",
                        children: [(0, o.jsx)(s.x, {
                            color: "muted",
                            children: n("flooz-web.profile.activities.details.status.pending")
                        }), (0, o.jsx)(r.s.Container, {
                            children: null == t ? void 0 : t.map((e, t) => e.type === a.L.DIRECT ? (0, o.jsx)(w, {
                                activity: e,
                                onClick: () => u(e)
                            }, t) : e.type === a.L.INDIRECT ? (0, o.jsx)(g, {
                                activity: e
                            }, t) : (0, o.jsx)(N, {
                                activity: e,
                                onClick: () => u(e)
                            }, t))
                        })]
                    })
                }
        },
        70888: function(e, t, n) {
            n.d(t, {
                Q: function() {
                    return S
                }
            });
            var o = n(85893),
                i = n(30120),
                a = n(9264),
                r = n(67294),
                l = n(69355),
                s = n(13915),
                d = n(21546),
                c = n(13484),
                u = n(70038),
                m = n(90271),
                p = n(17139),
                f = n(33715),
                v = n(66567);
            let k = e => {
                var t, n;
                let {
                    activity: i,
                    onClick: r
                } = e, {
                    t: s
                } = (0, a.$G)(), d = s("flooz-web.profile.activities.activity-title", {
                    context: null === (t = i.type) || void 0 === t ? void 0 : t.toLowerCase()
                });
                return (0, o.jsx)(l.s.Item, {
                    onClick: r,
                    structuredChildren: {
                        icon: (0, o.jsx)(f.J, {
                            className: "profile-activity__large-icon",
                            icon: f.T.PROFILE_ACTIVITY_APPROVAL
                        }),
                        firstColumnTitle: d,
                        firstColumnSubtitle: (0, o.jsx)(p.S, {
                            copyValue: null !== (n = i.spender) && void 0 !== n ? n : "",
                            children: v.i.shortenAddress(i.spender)
                        }),
                        secondColumnTitle: i.symbol
                    }
                })
            };
            var h = n(38313),
                T = n(65864);
            let x = e => {
                var t, n;
                let {
                    activity: i,
                    onClick: r
                } = e, {
                    t: s
                } = (0, a.$G)();
                return (0, o.jsx)(l.s.Item, {
                    onClick: r,
                    structuredChildren: {
                        icon: (0, o.jsx)(h.J, {
                            className: "profile-activity__large-icon",
                            icon: T.T.PROFILE_ACTIVITY_CONTRACT_EXECUTION
                        }),
                        firstColumnTitle: s("flooz-web.profile.activities.activity-title", {
                            context: null === (t = i.type) || void 0 === t ? void 0 : t.toLowerCase()
                        }),
                        firstColumnSubtitle: (0, o.jsx)(p.S, {
                            copyValue: null !== (n = i.contractAddress) && void 0 !== n ? n : "",
                            children: v.i.shortenAddress(i.contractAddress)
                        }),
                        secondColumnTitle: d.H.getTokenText(i.amount, i.symbol),
                        secondColumnSubtitle: d.H.getUsdValueText(i)
                    }
                })
            };
            var g = n(55613);
            let y = e => {
                var t, n;
                let {
                    activity: i,
                    onClick: r
                } = e, {
                    t: s
                } = (0, a.$G)();
                return (0, o.jsx)(l.s.Item, {
                    onClick: r,
                    structuredChildren: {
                        icon: (0, o.jsxs)("div", {
                            className: "profile-activity__icon-wrapper",
                            children: [(0, o.jsx)(g.C, {
                                nft: i.nft,
                                className: "profile-activity__large-icon"
                            }), (0, o.jsx)(f.J, {
                                icon: d.H.getIcon(i),
                                className: "profile-activity__indicator"
                            })]
                        }),
                        firstColumnTitle: s("flooz-web.profile.activities.activity-title", {
                            context: null === (t = i.type) || void 0 === t ? void 0 : t.toLowerCase()
                        }),
                        firstColumnSubtitle: "".concat(i.collectionName, " #").concat(null === (n = i.nft) || void 0 === n ? void 0 : n.tokenId)
                    }
                })
            };
            var w = n(20706);
            let N = e => {
                    var t, n, i, r, s, c;
                    let {
                        activity: u,
                        onClick: m
                    } = e, {
                        t: p
                    } = (0, a.$G)(), v = void 0 === u.status ? "-pending" : "";
                    return (0, o.jsx)(l.s.Item, {
                        onClick: m,
                        structuredChildren: {
                            icon: (0, o.jsxs)("div", {
                                className: "profile-activity__icon-wrapper profile-activity__icon-wrapper--swap",
                                children: [(0, o.jsx)(w.S, {
                                    token: u.tokenFrom,
                                    className: "profile-activity__swap-logo profile-activity__swap-logo--to"
                                }), (0, o.jsx)(w.S, {
                                    token: u.tokenTo,
                                    className: "profile-activity__swap-logo profile-activity__swap-logo--from"
                                }), (0, o.jsx)(f.J, {
                                    icon: f.T.PROFILE_ACTIVITY_SWAP_INDICATOR,
                                    className: "profile-activity__indicator"
                                })]
                            }),
                            firstColumnTitle: (0, o.jsxs)(o.Fragment, {
                                children: [p("flooz-web.profile.activities.activity-title", {
                                    context: "".concat(null === (t = u.type) || void 0 === t ? void 0 : t.toLowerCase(), "-from").concat(v),
                                    fromToken: null === (n = u.tokenFrom) || void 0 === n ? void 0 : n.name
                                }), (0, o.jsx)("br", {}), p("flooz-web.profile.activities.activity-title", {
                                    context: "".concat(null === (i = u.type) || void 0 === i ? void 0 : i.toLowerCase(), "-to").concat(v),
                                    toToken: null === (r = u.tokenTo) || void 0 === r ? void 0 : r.name
                                })]
                            }),
                            firstColumnSubtitle: "".concat(p("flooz-web.profile.activities.usd-value")),
                            secondColumnTitle: (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsxs)("span", {
                                    title: u.amountFrom,
                                    className: "profile-activity-list-item__price--from",
                                    children: ["-", d.H.getTokenText(u.amountFrom, null === (s = u.tokenFrom) || void 0 === s ? void 0 : s.symbol)]
                                }), (0, o.jsx)("br", {}), (0, o.jsxs)("span", {
                                    title: u.amountTo,
                                    children: ["+", d.H.getTokenText(u.amountTo, null === (c = u.tokenTo) || void 0 === c ? void 0 : c.symbol)]
                                })]
                            }),
                            secondColumnSubtitle: d.H.getUsdValueText(u)
                        }
                    })
                },
                b = e => {
                    var t, n;
                    let {
                        activity: i,
                        onClick: r
                    } = e, {
                        t: s
                    } = (0, a.$G)();
                    return (0, o.jsx)(l.s.Item, {
                        onClick: r,
                        structuredChildren: {
                            icon: (0, o.jsxs)("div", {
                                className: "profile-activity__icon-wrapper",
                                children: [(0, o.jsx)(w.S, {
                                    token: i.token,
                                    className: "profile-activity__large-icon"
                                }), (0, o.jsx)(f.J, {
                                    icon: d.H.getIcon(i),
                                    className: "profile-activity__indicator"
                                })]
                            }),
                            firstColumnTitle: "".concat(s("flooz-web.profile.activities.activity-title", {
                                context: null === (t = i.type) || void 0 === t ? void 0 : t.toLowerCase()
                            })),
                            firstColumnSubtitle: "".concat(null === (n = i.token) || void 0 === n ? void 0 : n.name),
                            secondColumnTitle: (0, o.jsxs)("span", {
                                children: [d.H.isActivityIn(i.type) ? "+" : "-", d.H.getTokenText(i.amount, i.symbol)]
                            }),
                            secondColumnSubtitle: d.H.getUsdValueText(i)
                        }
                    })
                };
            var _ = n(41471);
            let j = e => {
                    var t;
                    let {
                        activity: n,
                        onClick: i
                    } = e, {
                        t: r
                    } = (0, a.$G)();
                    return (0, o.jsx)(l.s.Item, {
                        onClick: i,
                        structuredChildren: {
                            icon: (0, o.jsx)(_.F, {
                                className: "profile-activity__large-icon"
                            }),
                            firstColumnTitle: "".concat(r("flooz-web.profile.activities.activity-title__transaction_failed")),
                            firstColumnSubtitle: (0, o.jsx)(p.S, {
                                copyValue: n.hash,
                                children: v.i.shortenAddress(null !== (t = n.hash) && void 0 !== t ? t : "", 8)
                            }),
                            secondColumnTitle: d.H.getTokenText(n.amount, n.symbol),
                            secondColumnSubtitle: d.H.getUsdValueText(n)
                        }
                    })
                },
                E = e => {
                    let {
                        activity: t,
                        onClick: n
                    } = e, {
                        t: i
                    } = (0, a.$G)();
                    return (0, o.jsx)(l.s.Item, {
                        onClick: n,
                        structuredChildren: {
                            icon: (0, o.jsx)(_.F, {
                                className: "profile-activity__large-icon"
                            }),
                            firstColumnTitle: "".concat(i("flooz-web.profile.activities.activity-title__unknown_activity")),
                            firstColumnSubtitle: (0, o.jsx)(p.S, {
                                copyValue: t.hash,
                                children: v.i.shortenAddress(t.hash, 8)
                            }),
                            secondColumnTitle: d.H.getTokenText(t.amount, t.symbol),
                            secondColumnSubtitle: d.H.getUsdValueText(t)
                        }
                    })
                },
                C = e => {
                    let {
                        activity: t
                    } = e, {
                        modalHistory: n
                    } = (0, u.N)(), i = () => {
                        n.push(m.e.activityDetails, new URLSearchParams([]), {
                            activity: t
                        })
                    };
                    return !1 === t.status ? (0, o.jsx)(j, {
                        activity: t,
                        onClick: i
                    }) : d.H.isTokenActivity(t) ? (0, o.jsx)(b, {
                        activity: t,
                        onClick: i
                    }) : d.H.isNftActivity(t) ? (0, o.jsx)(y, {
                        activity: t,
                        onClick: i
                    }) : t.type === c.T.SWAP ? (0, o.jsx)(N, {
                        activity: t,
                        onClick: i
                    }) : t.type === c.T.APPROVAL ? (0, o.jsx)(k, {
                        activity: t,
                        onClick: i
                    }) : t.type === c.T.CONTRACT_EXECUTION ? (0, o.jsx)(x, {
                        activity: t,
                        onClick: i
                    }) : (0, o.jsx)(E, {
                        activity: t,
                        onClick: i
                    })
                },
                S = e => {
                    var t;
                    let {
                        activities: n,
                        hasMoreOnChainActivities: c,
                        fetchOnChainActivities: u,
                        isLoading: m,
                        ...p
                    } = e, {
                        t: f
                    } = (0, a.$G)(), [v, k] = (0, r.useState)(0), h = (0, r.useMemo)(() => (null != n ? n : []).filter(e => !d.H.isNftActivity(e)), [n, !1]), T = (0, r.useMemo)(() => h.slice(0, (v + 1) * 25), [v, h]), x = (0, r.useMemo)(() => {
                        var e;
                        let t = T.reduce((e, t) => {
                            var n;
                            let o = t.blockTimestamp ? s.z.formatDate(t.blockTimestamp, {
                                    format: i.ou.DATE_MED
                                }) : f("flooz-web.profile.activities.pending"),
                                a = [...null !== (n = e.get(o)) && void 0 !== n ? n : [], t];
                            return e.set(o, a), e
                        }, new Map);
                        return [...t.keys()].map(n => {
                            var o;
                            return {
                                id: n,
                                label: n,
                                itemsCount: null !== (e = null === (o = t.get(n)) || void 0 === o ? void 0 : o.length) && void 0 !== e ? e : 0
                            }
                        })
                    }, [T, f]);
                    (0, r.useEffect)(() => {
                        !m && null != n && c && n.length < (v + 1) * 25 && u()
                    }, [u, m, n, v, c]);
                    let g = (v + 1) * 25 < (null !== (t = null == h ? void 0 : h.length) && void 0 !== t ? t : 0),
                        y = Boolean(c) || g,
                        w = () => k(e => e + 1);
                    return (0, o.jsx)(o.Fragment, {
                        children: (0, o.jsx)(l.s.Container, {
                            groupedList: x,
                            isLoading: m,
                            onLoadMore: w,
                            hasNextPage: y,
                            ...p,
                            children: T.map((e, t) => (0, o.jsx)(C, {
                                activity: e
                            }, t))
                        })
                    })
                }
        },
        28179: function(e, t, n) {
            n.d(t, {
                J: function() {
                    return y
                }
            });
            var o = n(85893),
                i = n(67294),
                a = n(45837),
                r = n(98851),
                l = n(12204),
                s = n(65864),
                d = n(29485),
                c = n(62351),
                u = n(87930),
                m = n(27722),
                p = n(85795),
                f = n(1527),
                v = n(51275),
                k = n(48791),
                h = n(38826),
                T = n(76409),
                x = n(34123),
                g = n(56318);
            let y = e => {
                let {
                    token: t
                } = e, {
                    modalHistory: n
                } = (0, m.N)(), {
                    selectedAccount: y
                } = (0, k.Z_)(), {
                    data: w,
                    isError: N
                } = (0, a.t)({
                    body: {
                        address: y
                    }
                }, {
                    enabled: null != y
                }), b = (0, i.useCallback)(() => n.push(h._.connect), [n]), _ = (0, i.useCallback)(() => {
                    let e = g.J.generateReferralLink({
                        referralId: w.refId,
                        token: t
                    });
                    T.C.copyValue({
                        value: e,
                        onValueCopied: v.F.notificationCopy
                    }), x.KY.emitGenerateReferral({
                        token: t
                    })
                }, [w, t]), j = w ? g.J.generateReferralLink({
                    referralId: w.refId,
                    token: t
                }) : "Loading..";
                return (0, o.jsxs)(u.P, {
                    className: "refer-token",
                    gap: "200",
                    children: [(0, o.jsxs)(p.v.Container, {
                        children: [(0, o.jsx)(p.v.Step, {
                            children: (0, o.jsx)(f.x, {
                                size: "m",
                                children: "Generate your referral link"
                            })
                        }), (0, o.jsx)(p.v.Step, {
                            children: (0, o.jsx)(f.x, {
                                size: "m",
                                children: "Invite your friends to trade"
                            })
                        }), (0, o.jsx)(p.v.Step, {
                            children: (0, o.jsx)(f.x, {
                                size: "m",
                                children: "Get 0.1% of any trade for life!"
                            })
                        })]
                    }), N && (0, o.jsx)(r.j, {
                        message: "Referral link can currently not be displayed. Don't worry, we are working on a fix."
                    }), y && (0, o.jsxs)(u.P, {
                        className: "refer-token__share",
                        gap: "100",
                        children: [(0, o.jsx)(u.P, {
                            direction: "row",
                            justifyContent: "space-between",
                            gap: "100",
                            children: (0, o.jsx)("p", {
                                children: t ? "Share ".concat(t.symbol, " referral link") : "Share referral link"
                            })
                        }), (0, o.jsx)(u.P, {
                            gap: "50",
                            children: (0, o.jsxs)(c.B, {
                                readOnly: !0,
                                children: [(0, o.jsx)(d.UP, {
                                    readOnly: !0,
                                    value: j
                                }), (0, o.jsx)(l.z, {
                                    variant: "primary",
                                    size: "m",
                                    onClick: _,
                                    icon: s.T.COPY,
                                    disabled: null == w
                                })]
                            })
                        })]
                    }), !y && (0, o.jsx)(l.z, {
                        variant: "primary",
                        size: "xl",
                        onClick: b,
                        children: "Connect your wallet"
                    })]
                })
            }
        },
        72406: function(e, t, n) {
            n.d(t, {
                w: function() {
                    return m
                }
            });
            var o = n(67294),
                i = n(34443),
                a = n(67797),
                r = n(92738),
                l = n(30405),
                s = n(94176),
                d = n(48791),
                c = n(60759),
                u = n(21546);
            let m = (e, t) => {
                var n, m;
                let {
                    selectedAccount: p
                } = (0, d.Z_)(), {
                    data: f
                } = (0, a.D)({
                    key: c.mJ.recentSwapActivities(p)
                }, {
                    enabled: null != p
                }), {
                    mutate: v
                } = (0, i.h)(), {
                    impersonatedUser: k
                } = (0, s.UV)(), h = (0, o.useMemo)(() => null != k ? [] : null != f ? f : [], [k, f]), T = h.filter(e => null != e.status), x = h.filter(e => null == e.status), g = {
                    address: e.pathParameters.address
                }, {
                    data: y,
                    isInitialLoading: w,
                    isError: N
                } = (0, l.f)({
                    pathParameters: g,
                    queryParameters: {
                        limit: 100,
                        skip: 0
                    }
                }, {
                    enabled: null == k && (null == t ? void 0 : t.enabled) !== !1
                }), b = (0, o.useMemo)(() => (null !== (n = null == y ? void 0 : y.result) && void 0 !== n ? n : []).filter(e => u.H.isOnRampActivityPending(e)), [y]), {
                    data: _,
                    isInitialLoading: j,
                    isFetchingNextPage: E,
                    isError: C,
                    fetchNextPage: S,
                    hasNextPage: A
                } = (0, r.G)(e, t), I = (0, o.useMemo)(() => null !== (m = null == _ ? void 0 : _.pages.flatMap(e => {
                    let {
                        result: t
                    } = e;
                    return t
                })) && void 0 !== m ? m : [], [_]), O = [...I, ...T], R = O.sort((e, t) => {
                    let n = new Date(e.blockTimestamp).getTime(),
                        o = new Date(t.blockTimestamp).getTime();
                    return o - n
                });
                (0, o.useEffect)(() => {
                    let e = I.map(e => {
                            let {
                                hash: t
                            } = e;
                            return t
                        }),
                        t = null == h ? void 0 : h.filter(t => {
                            let {
                                hash: n
                            } = t;
                            return !e.includes(n)
                        });
                    p && t.length !== h.length && v({
                        key: c.mJ.recentSwapActivities(p),
                        value: t
                    })
                }, [I, p, h, v]);
                let P = (0, o.useMemo)(() => [...x, ...b], [b, x]);
                return {
                    onChainActivities: R,
                    pendingActivities: P,
                    fetchOnChainActivities: S,
                    hasMoreOnChainActivities: A,
                    isLoading: j || E || w,
                    isError: C || N
                }
            }
        },
        14560: function(e, t, n) {
            n.d(t, {
                c: function() {
                    return N
                }
            });
            var o = n(9264),
                i = n(94176),
                a = n(33715),
                r = n(27722),
                l = n(51275),
                s = n(48791),
                d = n(38826),
                c = n(34030),
                u = n(3703),
                m = n(34123),
                p = n(59971),
                f = n(85945),
                v = n(48228),
                k = n(87291),
                h = n(45356);
            let T = e => {
                let {
                    selectedAccount: t
                } = (0, s.Z_)(), n = (0, f.NL)();
                return (0, v.D)(e => k.Mp.removeFollow(e), { ...e,
                    onMutate: o => {
                        var i;
                        let a = {
                                address: t,
                                followListIds: [o.pathParameters.followListId]
                            },
                            r = h.a.follows({
                                queryParameters: a
                            }),
                            l = n.getQueryData(r),
                            s = { ...l,
                                result: null == l ? void 0 : l.result.filter(e => e.id !== o.pathParameters.id)
                            };
                        n.setQueriesData(r, s), null == e || null === (i = e.onMutate) || void 0 === i || i.call(e, o)
                    },
                    onSuccess: (o, i, a) => {
                        var r;
                        let l = {
                            address: t,
                            followListIds: [i.pathParameters.followListId]
                        };
                        n.invalidateQueries(h.a.follows({
                            queryParameters: l
                        })), null == e || null === (r = e.onSuccess) || void 0 === r || r.call(e, o, i, a)
                    }
                })
            };
            var x = n(28497),
                g = n(33871),
                y = n(76538),
                w = n(85436);
            let N = e => {
                var t;
                let {
                    follow: n
                } = e, {
                    selectedAccount: f
                } = (0, s.Z_)(), {
                    isAuthenticated: v
                } = (0, i.UV)(), {
                    modalHistory: k
                } = (0, r.N)(), {
                    t: h
                } = (0, o.$G)(), N = () => {
                    l.F.notificationSuccess({
                        message: h("flooz-web.profile.follow-button.add-follow-success", {
                            name: z
                        })
                    })
                }, b = () => {
                    l.F.notificationSuccess({
                        message: h("flooz-web.profile.follow-button.remove-follow-success", {
                            name: z
                        }),
                        emoji: "\uD83D\uDC4B\uD83C\uDFFB"
                    })
                }, {
                    mutate: _
                } = (0, p.T)({
                    onSuccess: N
                }), {
                    mutate: j
                } = T({
                    onSuccess: b
                }), {
                    data: E
                } = (0, g.U)({
                    pathParameters: {
                        id: f
                    }
                }, {
                    enabled: null != f
                }), C = {
                    address: f,
                    followListIds: [null == n ? void 0 : n.followListId]
                }, {
                    data: S
                } = (0, x.X)({
                    queryParameters: C
                }, {
                    enabled: null != f && null != n
                }), A = () => {
                    if (L) {
                        let e = {
                            id: L.id,
                            followListId: R
                        };
                        j({
                            pathParameters: e
                        }), m.KY.emitRemoveFollow({
                            followType: O,
                            followListId: R,
                            identifier: P,
                            name: z
                        })
                    } else M || (_({
                        body: [{
                            type: O,
                            followListId: R,
                            identifier: P,
                            network: D,
                            name: z,
                            logoUrl: F
                        }]
                    }), m.KY.emitAddFollow({
                        followType: O,
                        followListId: R,
                        identifier: P,
                        name: z
                    }))
                }, {
                    mutate: I
                } = (0, w.H)({
                    onSuccess: A
                });
                if (null == n) return {
                    isFollowingItem: !1,
                    icon: a.T.STAR_OUTLINE
                };
                let {
                    type: O,
                    followListId: R,
                    identifier: P,
                    name: z = "",
                    logoUrl: F,
                    network: D
                } = n, L = null == S ? void 0 : null === (t = S.result) || void 0 === t ? void 0 : t.find(e => e.identifier.toLowerCase() === (null == P ? void 0 : P.toLowerCase())), M = null != E ? null != L : null != f && y.K.some(e => e.identifier.toLowerCase() === (null == P ? void 0 : P.toLowerCase())), U = M ? a.T.STAR_FILLED : a.T.STAR_OUTLINE, H = () => {
                    null == E ? I({
                        excludeFollowItems: M ? [P] : void 0
                    }) : A()
                }, K = () => {
                    let e = M ? "unfollow" : "follow",
                        t = h("flooz-web.profile.follow-button.authentication.notification.title", {
                            context: e
                        }),
                        n = h("flooz-web.profile.follow-button.authentication.notification.content", {
                            context: e
                        });
                    l.F.notificationError({
                        message: t,
                        description: n
                    })
                }, G = () => {
                    if (v) H();
                    else {
                        let e = "flooz-web.profile.follow-button.authentication",
                            t = M ? "unfollow" : "follow",
                            n = new URLSearchParams([
                                [c.r.EMOJI_TRANSLATION_KEY, "".concat(e, ".emoji__").concat(t)],
                                [c.r.TITLE_TRANSLATION_KEY, "".concat(e, ".title__").concat(t)],
                                [c.r.CONTENT_TRANSLATION_KEY, "".concat(e, ".content")],
                                [c.r.BUTTON_TRANSLATION_KEY, "".concat(e, ".button")]
                            ]);
                        k.push(u.D.authentication, n, {
                            onSuccess: H,
                            onError: K
                        })
                    }
                }, W = () => {
                    f ? G() : k.push(d._.connect)
                };
                return {
                    isFollowingItem: M,
                    icon: U,
                    toggleFollow: W
                }
            }
        },
        21546: function(e, t, n) {
            n.d(t, {
                H: function() {
                    return c
                }
            });
            var o = n(30120),
                i = n(13484),
                a = n(51249),
                r = n(68091),
                l = n(65864),
                s = n(49981),
                d = n(13915);
            let c = new class {
                constructor() {
                    this.isTokenActivity = e => [i.T.BOUGHT_TOKEN, i.T.SOLD_TOKEN, i.T.RECEIVED_TOKEN, i.T.SENT_TOKEN].includes(null == e ? void 0 : e.type), this.isNftActivity = e => [i.T.MINTED_NFT, i.T.BOUGHT_NFT, i.T.SOLD_NFT, i.T.RECEIVED_NFT, i.T.SENT_NFT, i.T.AIRDROP_NFT].includes(null == e ? void 0 : e.type), this.isActivityIn = e => [i.T.BOUGHT_TOKEN, i.T.RECEIVED_TOKEN, i.T.SOLD_NFT, i.T.RECEIVED_NFT, i.T.AIRDROP_NFT].includes(e), this.isOnRampActivityPending = e => e.type === r.L.DIRECT ? e.transactionStatus === a.kl.PENDING : e.indirectStatus === a._H.PENDING && e.transactionStatus === a.kl.COMPLETED || e.transactionStatus === a.kl.PENDING, this.getIcon = e => this.isActivityIn(e.type) ? l.T.PROFILE_ACTIVITY_RECEIVED_INDICATOR : l.T.PROFILE_ACTIVITY_SENT_INDICATOR, this.getTokenText = function(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                            n = d.z.formatNumber(e, {
                                fixedFractionDigits: 2,
                                useSuperscriptFormat: !0,
                                useRangeFormat: !0,
                                fallback: "0.00"
                            });
                        return "".concat(n, " ").concat(t)
                    }, this.getUsdValueText = e => {
                        let t = d.z.formatNumber(null == e ? void 0 : e.usdValue, {
                            fixedFractionDigits: 2,
                            useSuperscriptFormat: !0,
                            useRangeFormat: !0,
                            fallback: "0.00"
                        });
                        return "$ ".concat(t)
                    }, this.getFiatAmountText = e => {
                        let t = d.z.formatNumber(null == e ? void 0 : e.fiatAmount, {
                            fixedFractionDigits: 2,
                            useSuperscriptFormat: !0,
                            useRangeFormat: !0,
                            fallback: "0"
                        });
                        return "".concat(null == e ? void 0 : e.fiatSymbol, " ").concat(t)
                    }, this.getFormattedDate = e => {
                        let t = d.z.formatDate(e, {
                            format: o.ou.DATETIME_MED
                        });
                        return null === t ? "" : t
                    }, this.getFormattedAmount = e => {
                        let t = d.z.formatNumber(e, {
                            fixedFractionDigits: 2,
                            useSuperscriptFormat: !0,
                            useRangeFormat: !0,
                            fallback: "0"
                        });
                        return t
                    }, this.getFormattedTokenAmount = (e, t) => {
                        var n;
                        let o = (null != t ? t : 0) * (1 / parseFloat(e)),
                            i = d.z.formatNumber(o, {
                                fixedFractionDigits: 2,
                                useSuperscriptFormat: !0,
                                useRangeFormat: !0
                            });
                        return i
                    }, this.getFormattedFeeAmount = e => {
                        let t = d.z.formatNumber(e, {
                            maxFractionDigits: 6,
                            useSuperscriptFormat: !1,
                            useRangeFormat: !0,
                            fallback: "0"
                        });
                        return "".concat(t)
                    }, this.getFormattedAmountAndSymbol = (e, t) => {
                        let n = d.z.formatNumber(e, {
                            fixedFractionDigits: 2,
                            useSuperscriptFormat: !0,
                            useRangeFormat: !0
                        });
                        return "".concat(n, " ").concat(t)
                    }, this.getNftName = e => {
                        var t;
                        return "".concat(null == e ? void 0 : e.collectionName, " #").concat(null == e ? void 0 : null === (t = e.nft) || void 0 === t ? void 0 : t.tokenId)
                    }, this.filterActivitiesByToken = function(e) {
                        let {
                            address: t
                        } = e, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                        return n.filter(e => c.isTokenActivity(e) || e.type === i.T.APPROVAL ? s.a.areSameAddress(e.token.address, t) : e.type === i.T.SWAP && (s.a.areSameAddress(e.tokenFrom.address, t) || s.a.areSameAddress(e.tokenTo.address, t)))
                    }, this.filterPendingActivityByToken = function(e) {
                        let {
                            address: t
                        } = e, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                        return n.filter(e => e.type === i.T.SWAP ? s.a.areSameAddress(e.tokenFrom.address, t) || s.a.areSameAddress(e.tokenTo.address, t) : e.type === r.L.DIRECT ? s.a.areSameAddress(e.token.address, t) : s.a.areSameAddress(e.indirectToken.address, t))
                    }
                }
            }
        },
        56318: function(e, t, n) {
            n.d(t, {
                J: function() {
                    return s
                }
            });
            var o = n(12599),
                i = n(51515),
                a = n(16209),
                r = n(72099),
                l = n(66744);
            let s = new class {
                constructor() {
                    this.generateReferralLink = e => {
                        let {
                            referralId: t,
                            token: n
                        } = e, s = "https://flooz.trade", d = new URLSearchParams({
                            [a.C.REF_ID]: t
                        });
                        if (null == n) return "".concat(s, "?").concat(d.toString());
                        d.set(i.H.NETWORK, n.network), d.set(a.C.WIDGET_TAB, l.J.ON_RAMP);
                        let c = (0, o.Gn)(r.U.tokenDetails, {
                            tokenAddress: n.address
                        });
                        return "".concat(s).concat(c, "?").concat(d.toString())
                    }
                }
            }
        },
        16209: function(e, t, n) {
            n.d(t, {
                l: function() {
                    return eH
                },
                C: function() {
                    return l
                }
            });
            var o, i, a, r, l, s = n(85893),
                d = n(94184),
                c = n.n(d),
                u = n(9264),
                m = n(11163),
                p = n(67294),
                f = n(66314),
                v = n(69402),
                k = n(69484),
                h = n(51401),
                T = n(62047),
                x = n(94176),
                g = n(77902),
                y = n(47885),
                w = n(27722),
                N = n(37397),
                b = n(3188),
                _ = n(1527),
                j = n(67832),
                E = n(41141),
                C = n(14560),
                S = n(1657),
                A = n(66744),
                I = n(50417),
                O = n(20706),
                R = n(36789),
                P = n(48791),
                z = n(94162),
                F = n(70888),
                D = n(44105),
                L = n(72406),
                M = n(21546);
            let U = e => {
                let {
                    token: t
                } = e, {
                    selectedAccount: n
                } = (0, P.Z_)(), {
                    t: o
                } = (0, u.$G)(), {
                    onChainActivities: i,
                    pendingActivities: a,
                    fetchOnChainActivities: r,
                    hasMoreOnChainActivities: l,
                    isLoading: d,
                    isError: c
                } = (0, L.w)({
                    pathParameters: {
                        address: n
                    },
                    queryParameters: {}
                }, {
                    enabled: null != n
                }), m = (0, p.useMemo)(() => M.H.filterActivitiesByToken(t, i), [t, i]), f = (0, p.useMemo)(() => M.H.filterPendingActivityByToken(t, a), [t, a]), v = !m.length && !f.length && !c && !d, k = c ? R.l.ERROR : R.l.EMPTY, h = f.length > 0 && !c && !d;
                return (0, s.jsxs)(z.$.Container, {
                    className: "widget-token-activities",
                    children: [(0, s.jsx)(z.$.Header, {
                        title: o("flooz-web.token.widget-token-activities.title")
                    }), h && (0, s.jsx)(D.f, {
                        activities: f
                    }), (0, s.jsx)(F.Q, {
                        activities: m,
                        fetchOnChainActivities: r,
                        hasMoreOnChainActivities: l,
                        isLoading: d,
                        feedback: {
                            namespace: "flooz-web.token.widget-token-activities.feedback",
                            context: k
                        },
                        displayFeedback: !d && (c || v)
                    })]
                })
            };
            var H = n(49105),
                K = n(85494);
            let G = e => {
                let {
                    className: t
                } = e;
                return (0, s.jsx)(z.$.Container, {
                    className: c()("widget-token-blacklisted", t),
                    children: (0, s.jsx)(H.x, {
                        context: R.l.ERROR,
                        namespace: "flooz-web.token.widget-token-blacklisted.feedback",
                        actionHref: K.hA,
                        actionLinkTarget: "_blank"
                    })
                })
            };
            var W = n(30120),
                B = n(43829),
                V = n(36521),
                $ = n(41262);
            let Y = e => {
                let {
                    socialLinks: t
                } = e, n = $.R.filter(e => {
                    let {
                        key: n
                    } = e;
                    return B.s.isValidLink(null == t ? void 0 : t[n])
                });
                return (0, s.jsx)(s.Fragment, {
                    children: n.map(e => {
                        let {
                            key: n,
                            icon: o
                        } = e;
                        return (0, s.jsx)(V.A, {
                            size: "small",
                            href: t[n],
                            icon: o,
                            target: "_blank"
                        }, n)
                    })
                })
            };
            var Q = n(33985),
                J = n(68730),
                q = n(35613),
                Z = n(33715),
                X = n(56161),
                ee = n(58565),
                et = n(99740),
                en = n(66567),
                eo = n(79201),
                ei = n(13915),
                ea = n(36492),
                er = n(46223),
                el = n(19069);
            let es = (e, t) => (0, ea.a)(el.a.tokenTweets(e), () => er.W4.getTokenTweets(e), t);
            var ed = n(84668),
                ec = n(55642);
            let eu = new class {
                    constructor() {
                        this.parseTweet = e => {
                            if (null == e) return;
                            let {
                                text: t,
                                entities: n
                            } = e, {
                                hashtags: o,
                                cashtags: i,
                                mentions: a,
                                urls: r
                            } = null != n ? n : {}, l = t;
                            return null == o || o.forEach(e => {
                                let {
                                    tag: t
                                } = e;
                                l = l.replace(RegExp("#".concat(t, "\\b")), '<a href="https://twitter.com/hashtag/'.concat(t, '">#').concat(t, "</a>"))
                            }), null == i || i.forEach(e => {
                                let {
                                    tag: t
                                } = e;
                                l = l.replace(RegExp("\\$".concat(t, "\\b")), '<a href="https://twitter.com/search?q=%24'.concat(t, '">$').concat(t, "</a>"))
                            }), null == a || a.forEach(e => {
                                let {
                                    username: t
                                } = e;
                                l = l.replace(RegExp("@".concat(t, "\\b")), '<a href="https://twitter.com/'.concat(t, '">@').concat(t, "</a>"))
                            }), null == r || r.forEach(e => {
                                let {
                                    url: t,
                                    expandedUrl: n
                                } = e;
                                l = l.replace(t, "[".concat(B.s.truncateString(n, 30), "](").concat(n, ")"))
                            }), l
                        }
                    }
                },
                em = e => {
                    let {
                        tokenTweet: t,
                        twitterHandle: n,
                        token: o,
                        isLoading: i,
                        className: a
                    } = e, {
                        t: r
                    } = (0, u.$G)(), {
                        publicMetrics: l,
                        createdAt: d,
                        isPinnedTweet: m
                    } = null != t ? t : {}, {
                        replyCount: p,
                        likeCount: f,
                        retweetCount: v
                    } = null != l ? l : {}, k = eu.parseTweet(t), h = ei.z.formatDate(d, {
                        format: W.ou.DATE_MED
                    });
                    return (0, s.jsxs)(y.P, {
                        gap: "125",
                        className: c()("token-tweets-item", a),
                        role: "listitem",
                        children: [(0, s.jsxs)(y.P, {
                            gap: "50",
                            direction: "row",
                            alignItems: "center",
                            justifyContent: "space-between",
                            wrap: "wrap",
                            children: [(0, s.jsxs)(y.P, {
                                gap: "75",
                                direction: "row",
                                alignItems: "center",
                                children: [(0, s.jsx)(O.S, {
                                    token: o,
                                    isLoading: i
                                }), (0, s.jsx)(ed.X, {
                                    size: "h5",
                                    children: i ? (0, s.jsx)(ec.g, {}) : "@".concat(n)
                                })]
                            }), (0, s.jsx)(_.x, {
                                size: "m",
                                color: "muted",
                                children: h
                            })]
                        }), (0, s.jsx)(_.x, {
                            size: "l",
                            fontWeight: "regular",
                            color: "muted",
                            className: "token-tweets-item__text",
                            component: "span",
                            children: i ? (0, s.jsx)(ec.g, {
                                lines: 2
                            }) : (0, s.jsx)(ee.$, {
                                value: k
                            })
                        }), (0, s.jsxs)(y.P, {
                            gap: "50",
                            direction: "row",
                            justifyContent: "space-between",
                            className: "token-tweets-item__metrics",
                            children: [(0, s.jsxs)(y.P, {
                                direction: "row",
                                gap: "200",
                                children: [(0, s.jsxs)(y.P, {
                                    direction: "row",
                                    gap: "50",
                                    children: [(0, s.jsx)(Z.J, {
                                        icon: Z.T.COMMENT
                                    }), (0, s.jsx)(_.x, {
                                        size: "s",
                                        color: "muted",
                                        children: i ? (0, s.jsx)(ec.g, {}) : ei.z.formatNumber(p)
                                    })]
                                }), (0, s.jsxs)(y.P, {
                                    direction: "row",
                                    gap: "50",
                                    children: [(0, s.jsx)(Z.J, {
                                        icon: Z.T.LIKE
                                    }), (0, s.jsx)(_.x, {
                                        size: "s",
                                        color: "muted",
                                        children: i ? (0, s.jsx)(ec.g, {}) : ei.z.formatNumber(f)
                                    })]
                                }), (0, s.jsxs)(y.P, {
                                    direction: "row",
                                    gap: "50",
                                    children: [(0, s.jsx)(Z.J, {
                                        icon: Z.T.ARROW_CIRCULAR
                                    }), (0, s.jsx)(_.x, {
                                        size: "s",
                                        color: "muted",
                                        children: i ? (0, s.jsx)(ec.g, {}) : ei.z.formatNumber(v)
                                    })]
                                })]
                            }), m && (0, s.jsxs)(y.P, {
                                direction: "row",
                                gap: "50",
                                children: [(0, s.jsx)(Z.J, {
                                    icon: Z.T.PIN
                                }), (0, s.jsx)(_.x, {
                                    size: "s",
                                    color: "muted",
                                    children: r("flooz-web.token.token-tweets.pinned-tweet")
                                })]
                            })]
                        })]
                    })
                },
                ep = e => null !== (a = e.split("/").pop()) && void 0 !== a ? a : "",
                ef = e => {
                    let {
                        token: t,
                        className: n
                    } = e, {
                        t: o
                    } = (0, u.$G)(), {
                        address: i,
                        network: a,
                        links: r
                    } = t, {
                        twitter: l
                    } = null != r ? r : {}, [d, m] = (0, p.useState)(!1), f = () => m(e => !e), {
                        data: v,
                        isLoading: k
                    } = es({
                        pathParameters: {
                            tokenAddress: i
                        },
                        queryParameters: {
                            network: a
                        }
                    });
                    if (null == l || !k && (!v || 0 === v.result.length)) return null;
                    let h = null == v ? void 0 : v.result.sort(e => e.isPinnedTweet ? -1 : 1).reduce((e, t) => e.some(e => {
                            let {
                                id: n
                            } = e;
                            return n === t.id
                        }) ? e : e.concat(t), []).slice(0, d ? 10 : 3),
                        T = ep(l);
                    return (0, s.jsxs)(y.P, {
                        className: c()("token-tweets", n),
                        gap: "150",
                        direction: "column",
                        children: [(0, s.jsxs)(y.P, {
                            gap: "100",
                            direction: "row",
                            justifyContent: "space-between",
                            children: [(0, s.jsxs)(y.P, {
                                gap: "75",
                                direction: "row",
                                alignItems: "center",
                                children: [(0, s.jsx)(Z.J, {
                                    className: "token-tweets__title-icon",
                                    icon: Z.T.SOCIAL_TWITTER_FILLED
                                }), (0, s.jsx)(ed.X, {
                                    size: "h5",
                                    children: "Twitter"
                                })]
                            }), (0, s.jsx)(V.A, {
                                icon: Z.T.LINK,
                                href: l,
                                target: "_blank",
                                size: "small",
                                className: "token-tweets__handle",
                                children: (0, s.jsx)("span", {
                                    className: "ellipsis",
                                    children: T
                                })
                            })]
                        }), (0, s.jsxs)(y.P, {
                            gap: "200",
                            direction: "column",
                            children: [(0, s.jsx)(y.P, {
                                gap: "100",
                                direction: "column",
                                role: "list",
                                children: k ? (0, s.jsx)(em, {
                                    twitterHandle: T,
                                    isLoading: !0
                                }) : null == h ? void 0 : h.map(e => (0, s.jsx)(em, {
                                    tokenTweet: e,
                                    twitterHandle: T,
                                    token: t
                                }, e.id))
                            }), (0, s.jsx)(g.z, {
                                variant: "text",
                                size: "xl",
                                onClick: f,
                                children: o("flooz-web.token.token-tweets.show-".concat(d ? "less" : "more"))
                            })]
                        })]
                    })
                },
                ev = (e, t) => {
                    let {
                        name: n,
                        symbol: o,
                        usdValue: i,
                        volumeUsdStats: a,
                        priceDelta: r
                    } = e, l = "flooz-web.token.widget-token-info", s = ei.z.formatNumber(i, {
                        fixedFractionDigits: 2,
                        useSuperscriptFormat: !0,
                        useRangeFormat: !0,
                        fallback: "0"
                    }), d = ei.z.formatNumber(null == a ? void 0 : a.daily, {
                        fixedFractionDigits: 2
                    }), c = r ? "".concat(ei.z.formatNumber(r, {
                        withSign: !0,
                        fixedFractionDigits: 2
                    }), "%") : void 0, u = t("".concat(l, ".default-description-1"), {
                        name: n,
                        symbol: o,
                        tokenPrice: s,
                        tradingVolume: d,
                        context: d ? void 0 : "no-volume"
                    }), m = c ? t("".concat(l, ".default-description-2"), {
                        name: n,
                        symbol: o,
                        delta: c,
                        context: (null != r ? r : 0) > 0 ? "up" : "down"
                    }) : void 0;
                    return [u, m].join(" ").trim()
                },
                ek = e => {
                    var t;
                    let {
                        token: n,
                        className: o
                    } = e, {
                        t: i
                    } = (0, u.$G)(), {
                        description: a,
                        links: r,
                        name: l
                    } = n, {
                        website: d
                    } = null != r ? r : {}, {
                        blockExplorer: m
                    } = et.Eu[n.network], f = m.getUrl(n.address, eo.C.ADDRESS), k = null != a && a.length > 0 ? a.replace("\\", "") : ev(n, i), [h, T] = (0, p.useState)(!1), x = (0, p.useCallback)(() => T(e => !e), []);
                    return (0, s.jsxs)(z.$.Container, {
                        className: c()("widget-token-info", o),
                        children: [(0, s.jsx)(z.$.Header, {
                            title: i("flooz-web.token.widget-token-info.title", {
                                name: l
                            }),
                            titleLogo: (0, s.jsx)(O.S, {
                                token: n
                            })
                        }), (0, s.jsxs)(y.P, {
                            direction: "row",
                            gap: "75",
                            wrap: "wrap",
                            children: [d && (0, s.jsx)(V.A, {
                                size: "small",
                                href: d,
                                target: "_blank",
                                icon: Z.T.LINK,
                                children: B.s.truncateUrl(d)
                            }), n.type !== v.i.NATIVE && (0, s.jsx)(V.A, {
                                size: "small",
                                href: f,
                                target: "_blank",
                                icon: Z.T.LINK,
                                children: m.label
                            }), (0, s.jsx)(Y, {
                                socialLinks: null == n ? void 0 : n.links
                            }), (null != n.deploymentDate || n.type !== v.i.NATIVE) && (0, s.jsx)(X.J, {
                                isOpen: h,
                                title: "",
                                placement: "bottom",
                                onOpenChange: T,
                                useMobileDialog: !1,
                                className: "widget-token-info__more-info",
                                popoverContent: (0, s.jsxs)(q.w.Container, {
                                    children: [(0, s.jsx)(q.w.Item, {
                                        label: i("flooz-web.token.widget-token-info.deployment-date"),
                                        value: null !== (t = ei.z.formatDate(n.deploymentDate, {
                                            format: W.ou.DATE_MED
                                        })) && void 0 !== t ? t : "-"
                                    }), n.type != v.i.NATIVE && (0, s.jsx)(q.w.Item, {
                                        label: i("flooz-web.token.widget-token-info.contract"),
                                        value: (0, s.jsx)(J.S, {
                                            copyValue: n.address,
                                            children: en.i.shortenAddress(n.address, 8)
                                        })
                                    })]
                                }),
                                children: (0, s.jsx)(V.A, {
                                    size: "small",
                                    onClick: x,
                                    icon: Z.T.MORE_HORIZONTAL
                                })
                            })]
                        }), (0, s.jsx)(Q.R, {
                            className: "widget-token-info__description",
                            children: (0, s.jsxs)(y.P, {
                                gap: "200",
                                direction: "column",
                                children: [(0, s.jsx)(_.x, {
                                    size: "l",
                                    color: "muted",
                                    fontWeight: "regular",
                                    component: "span",
                                    children: (0, s.jsx)(ee.$, {
                                        value: k
                                    })
                                }), (0, s.jsx)(_.x, {
                                    color: "muted",
                                    textAlign: "center",
                                    size: "s",
                                    children: i("flooz-web.token.widget-token-info.powered-by-coingecko")
                                })]
                            })
                        }), (0, s.jsx)(ef, {
                            token: n
                        })]
                    })
                };
            var eh = n(89154),
                eT = n(25337),
                ex = n(5152),
                eg = n.n(ex),
                ey = n(88169),
                ew = n(46888),
                eN = n(75358),
                eb = n(3023),
                e_ = n(86108),
                ej = n(14888),
                eE = n(26383),
                eC = n(44868);
            let eS = (e, t) => (0, ea.a)(el.a.tokenPrice(e), () => er.W4.getTokenPrice(e), t);
            var eA = n(41513);
            let eI = eg()(() => n.e(8111).then(n.bind(n, 98111)).then(e => e.ResponsiveContainer), {
                    loadableGenerated: {
                        webpack: () => [98111]
                    },
                    ssr: !1
                }),
                eO = (e, t) => [eC.H.ONE_DAY].includes(t) ? "".concat(ei.z.formatDate(W.ou.fromSeconds(e), {
                    format: W.ou.TIME_SIMPLE
                })) : [eC.H.ONE_WEEK, eC.H.ONE_MONTH].includes(t) ? "".concat(ei.z.formatDate(W.ou.fromSeconds(e), {
                    format: {
                        month: "short"
                    }
                }), " ").concat(ei.z.formatDate(W.ou.fromSeconds(e), {
                    format: {
                        day: "numeric"
                    }
                })) : [eC.H.ONE_YEAR, eC.H.ALL].includes(t) ? "".concat(ei.z.formatDate(W.ou.fromSeconds(e), {
                    format: {
                        day: "numeric"
                    }
                }), " ").concat(ei.z.formatDate(W.ou.fromSeconds(e), {
                    format: {
                        month: "short"
                    }
                }), " ").concat(ei.z.formatDate(W.ou.fromSeconds(e), {
                    format: {
                        year: "2-digit"
                    }
                })) : "".concat(e),
                eR = e => {
                    var t, n, o, i, a;
                    let {
                        token: r,
                        dateRangeFilter: l
                    } = e, {
                        t: d
                    } = (0, u.$G)(), [m, f] = (0, p.useState)(!0), [v, k] = (0, p.useState)(!0), [h, T] = (0, p.useState)(null), x = (0, p.useRef)(null), g = (0, p.useId)(), {
                        data: w,
                        isInitialLoading: N,
                        isError: b,
                        error: j
                    } = eS({
                        pathParameters: {
                            address: r.address
                        },
                        queryParameters: {
                            network: r.network,
                            dateRange: null !== (o = null == l ? void 0 : l.key) && void 0 !== o ? o : eC.H.ALL,
                            till: null !== (i = null == l ? void 0 : l.to.toUTC().toISO()) && void 0 !== i ? i : "",
                            since: null !== (a = null == l ? void 0 : l.from.toUTC().toISO()) && void 0 !== a ? a : ""
                        }
                    }, {
                        enabled: null != l
                    }), E = (null == j ? void 0 : null === (t = j.response) || void 0 === t ? void 0 : t.status) == 404, C = null == l || null != w && (null === (n = w.result) || void 0 === n ? void 0 : n.length) === 0 || E, S = C ? R.l.NO_RESULT : R.l.ERROR, A = C || b, I = (0, p.useMemo)(() => {
                        var e;
                        return null == w ? void 0 : null === (e = w.result) || void 0 === e ? void 0 : e.map(e => ({
                            time: Date.parse(e.timeInterval.minute) / 1e3,
                            value: parseFloat(e.close)
                        }))
                    }, [w]), {
                        highest: O,
                        lowest: P
                    } = (0, p.useMemo)(() => {
                        let e, t;
                        return null == I || I.forEach(n => {
                            (null == t || n.value > t.value) && (t = n), (null == e || n.value < e.value) && (e = n)
                        }), {
                            highest: t,
                            lowest: e
                        }
                    }, [I]), z = (0, p.useMemo)(() => {
                        if (O && P) return (null == O ? void 0 : O.value) - (null == P ? void 0 : P.value) < 1 ? 4 : 2
                    }, [O, P]), F = e => {
                        var t;
                        let {
                            payload: {
                                value: n
                            }
                        } = e, o = eO(n, null !== (t = null == l ? void 0 : l.key) && void 0 !== t ? t : eC.H.ALL);
                        return (0, s.jsx)(ey.x, { ...e,
                            className: "widget-token-performance-chart__tick-label",
                            children: o.toUpperCase()
                        })
                    }, D = (e, t, n) => {
                        let o = ei.z.formatNumber(e, {
                                fixedFractionDigits: z,
                                useSuperscriptFormat: !0
                            }),
                            i = {
                                width: 75,
                                height: 26
                            };
                        return h && t > (null == h ? void 0 : h.clientWidth) - i.width && (t = (null == h ? void 0 : h.clientWidth) - i.width), (0, s.jsx)("g", {
                            children: (0, s.jsx)("foreignObject", {
                                x: t,
                                y: n,
                                width: i.width,
                                height: i.height,
                                children: (0, s.jsxs)(_.x, {
                                    size: "s",
                                    className: "widget-token-performance-chart__tag",
                                    children: ["$", o]
                                })
                            })
                        })
                    }, L = e => {
                        var t, n, o, i, a;
                        let {
                            active: r,
                            payload: d,
                            label: u,
                            coordinate: p,
                            viewBox: f
                        } = e;
                        if (!m || !r || !d || d.length < 1 || (null == d ? void 0 : null === (t = d[0]) || void 0 === t ? void 0 : t.value) == null) return;
                        let v = new Date(1e3 * u),
                            k = "".concat(v.toLocaleDateString(void 0, {
                                dateStyle: [eC.H.ONE_DAY, eC.H.ONE_WEEK, eC.H.ONE_MONTH].includes(null !== (i = null == l ? void 0 : l.key) && void 0 !== i ? i : eC.H.ALL) ? "medium" : "long"
                            }), " ").concat([eC.H.ONE_DAY, eC.H.ONE_WEEK, eC.H.ONE_MONTH].includes(null !== (a = null == l ? void 0 : l.key) && void 0 !== a ? a : eC.H.ALL) ? "- ".concat(v.toLocaleTimeString(void 0, {
                                timeStyle: "short"
                            }).toLowerCase()) : ""),
                            h = null == d ? void 0 : null === (n = d[0]) || void 0 === n ? void 0 : n.value,
                            T = ei.z.formatNumber(h, {
                                fixedFractionDigits: z,
                                useSuperscriptFormat: !0
                            });
                        return (0, s.jsx)(y.P, {
                            gap: "0",
                            ref: x,
                            className: c()("widget-token-performance-chart__tooltip", {
                                "widget-token-performance-chart__tooltip--left-edge": (null == p ? void 0 : p.x) && p.x < 50,
                                "widget-token-performance-chart__tooltip--right-edge": (null == p ? void 0 : p.x) && (null == f ? void 0 : f.width) && (null == x ? void 0 : null === (o = x.current) || void 0 === o ? void 0 : o.clientWidth) && p.x > f.width - x.current.clientWidth
                            }),
                            children: (0, s.jsxs)(y.P, {
                                gap: "0",
                                ref: x,
                                className: "widget-token-performance-chart__tooltip__wrapper",
                                children: [(0, s.jsxs)(_.x, {
                                    size: "m",
                                    children: ["$", T]
                                }), (0, s.jsx)(_.x, {
                                    size: "s",
                                    color: "muted",
                                    children: k
                                })]
                            })
                        })
                    }, M = e => {
                        e.touches.length > 1 || (k(!1), f(!0))
                    }, U = () => {
                        k(!0), f(!1)
                    }, K = () => {
                        k(!1), f(!0)
                    }, G = () => {
                        k(!0), f(!1)
                    };
                    return (0, s.jsxs)(y.P, {
                        gap: "0",
                        className: "widget-token-performance-chart",
                        children: [N && (0, s.jsxs)(y.P, {
                            className: "widget-token-performance-chart__loading",
                            direction: "column",
                            gap: "0",
                            alignItems: "center",
                            justifyContent: "center",
                            children: [(0, s.jsx)(eA.Fm, {
                                animationParams: {
                                    animation: eA.ru.SPINNER,
                                    loop: !0,
                                    autoplay: !0
                                },
                                role: "progressbar"
                            }), (0, s.jsx)(_.x, {
                                children: d("flooz-web.token.widget-token-performance-chart.loading")
                            })]
                        }), !N && A && (0, s.jsx)(H.x, {
                            namespace: "flooz-web.token.widget-token-performance-chart.feedback",
                            context: S
                        }), !N && !A && (0, s.jsx)(y.P, {
                            gap: "0",
                            className: "widget-token-performance-chart__container",
                            role: "presentation",
                            ref: T,
                            onTouchStart: M,
                            onTouchEnd: U,
                            onMouseEnter: K,
                            onMouseLeave: G,
                            children: (0, s.jsx)(eI, {
                                width: "100%",
                                height: "100%",
                                debounce: 50,
                                children: (0, s.jsxs)(ew.T, {
                                    id: g,
                                    data: I,
                                    margin: {
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        left: 0
                                    },
                                    children: [(0, s.jsx)("defs", {
                                        children: (0, s.jsxs)("linearGradient", {
                                            id: "colorUv",
                                            x1: "0",
                                            y1: "0",
                                            x2: "0",
                                            y2: "1",
                                            children: [(0, s.jsx)("stop", {
                                                offset: "5%",
                                                stopColor: "rgb(94,56,244)",
                                                stopOpacity: .1
                                            }), (0, s.jsx)("stop", {
                                                offset: "95%",
                                                stopColor: "rgb(94,56,244)",
                                                stopOpacity: 0
                                            })]
                                        })
                                    }), (0, s.jsx)(eN.B, {
                                        hide: !0,
                                        dataKey: "value",
                                        domain: ["auto", "auto"],
                                        padding: {
                                            top: 55,
                                            bottom: 30
                                        }
                                    }), (0, s.jsx)(eb.K, {
                                        dataKey: "time",
                                        interval: "preserveStart",
                                        dy: 4,
                                        tickLine: !1,
                                        axisLine: !1,
                                        tick: F
                                    }), (0, s.jsx)(e_.u, {
                                        isAnimationActive: !1,
                                        dataKey: "value",
                                        stroke: "var(--sya-color-white)",
                                        strokeWidth: 1,
                                        fillOpacity: 1,
                                        fill: "url(#colorUv)"
                                    }), (0, s.jsx)(ej.u, {
                                        active: m,
                                        isAnimationActive: !1,
                                        content: L,
                                        position: {
                                            y: 0
                                        },
                                        cursor: m && {
                                            stroke: "var(--sya-color-neutral-600)",
                                            strokeWidth: 1,
                                            strokeDasharray: "2 2"
                                        }
                                    }), v && O && (0, s.jsx)(eE.q, {
                                        x: null == O ? void 0 : O.time,
                                        y: null == O ? void 0 : O.value,
                                        label: e => {
                                            let {
                                                viewBox: t
                                            } = e;
                                            return D(null == O ? void 0 : O.value, t.x + 10, t.y - 15)
                                        }
                                    }), v && P && P.value != (null == O ? void 0 : O.value) && (0, s.jsx)(eE.q, {
                                        x: null == P ? void 0 : P.time,
                                        y: null == P ? void 0 : P.value,
                                        label: e => {
                                            let {
                                                viewBox: t
                                            } = e;
                                            return D(null == P ? void 0 : P.value, t.x + 10, t.y + 15)
                                        }
                                    })]
                                })
                            })
                        })]
                    })
                };
            var eP = n(10673);
            let ez = e => {
                    var t;
                    let {
                        token: n
                    } = e, {
                        t: o
                    } = (0, u.$G)(), i = ei.z.formatNumber(null == n ? void 0 : n.holders, {
                        maxFractionDigits: 2,
                        useRangeFormat: !0
                    }), a = ei.z.formatNumber(null == n ? void 0 : null === (t = n.volumeUsdStats) || void 0 === t ? void 0 : t.daily, {
                        maxFractionDigits: 2
                    }), r = ei.z.formatNumber(null == n ? void 0 : n.marketCap, {
                        maxFractionDigits: 2,
                        useRangeFormat: !0
                    });
                    return (0, s.jsx)(y.P, {
                        gap: "50",
                        direction: "row",
                        justifyContent: "center",
                        className: "widget-token-performance-market-data",
                        children: (0, s.jsxs)(q.w.Container, {
                            direction: "column",
                            sRow: !0,
                            className: "widget-token-performance-market-data__grid-container",
                            children: [(0, s.jsx)(q.w.Item, {
                                className: "widget-token-performance-market-data__grid-item",
                                label: (0, s.jsx)(eP.b, {
                                    label: o("flooz-web.token.token-details-page.market-cap.label"),
                                    primaryInfo: o("flooz-web.token.token-details-page.market-cap.primary-info"),
                                    secondaryInfo: o("flooz-web.token.token-details-page.market-cap.secondary-info")
                                }),
                                value: r ? "$".concat(r) : "-"
                            }), (0, s.jsx)("hr", {
                                className: "widget-token-performance-market-data__grid-item-divider"
                            }), (0, s.jsx)(q.w.Item, {
                                className: "widget-token-performance-market-data__grid-item",
                                label: (0, s.jsx)(eP.b, {
                                    label: o("flooz-web.token.token-details-page.24h-volume.label"),
                                    primaryInfo: o("flooz-web.token.token-details-page.24h-volume.primary-info"),
                                    secondaryInfo: o("flooz-web.token.token-details-page.24h-volume.secondary-info")
                                }),
                                value: a ? "$".concat(a) : "-"
                            }), (0, s.jsx)("hr", {
                                className: "widget-token-performance-market-data__grid-item-divider"
                            }), (null == n ? void 0 : n.type) !== v.i.NATIVE && (0, s.jsxs)(s.Fragment, {
                                children: [(0, s.jsx)(q.w.Item, {
                                    className: "widget-token-performance-market-data__grid-item",
                                    label: (0, s.jsx)(eP.b, {
                                        label: o("flooz-web.token.token-details-page.holders.label"),
                                        primaryInfo: o("flooz-web.token.token-details-page.holders.primary-info"),
                                        secondaryInfo: o("flooz-web.token.token-details-page.holders.secondary-info")
                                    }),
                                    value: i
                                }), (0, s.jsx)("hr", {
                                    className: "widget-token-performance-market-data__grid-item-divider"
                                })]
                            }), (0, s.jsx)(q.w.Item, {
                                className: "widget-token-performance-market-data__grid-item",
                                label: o("flooz-web.token.token-details-page.chain"),
                                value: null == n ? void 0 : n.network.toLocaleUpperCase()
                            })]
                        })
                    })
                },
                eF = e => {
                    if (e.includes(eT.s.key)) return eT.s;
                    if (e[0]) {
                        let t = e[0];
                        return eT.v[t]
                    }
                },
                eD = e => {
                    let {
                        token: t,
                        supportedDateRanges: n
                    } = e, {
                        t: o
                    } = (0, u.$G)(), [i, a] = (0, p.useState)(eF(n));
                    return (0, s.jsx)(z.$.Container, {
                        className: "widget-token-performance",
                        children: (0, s.jsxs)(y.P, {
                            gap: "100",
                            direction: "column",
                            children: [(0, s.jsxs)(y.P, {
                                wrap: "wrap",
                                direction: "row",
                                gap: "0",
                                alignItems: "center",
                                justifyContent: "space-between",
                                className: "widget-token-performance__layout",
                                children: [(0, s.jsx)(z.$.Header, {
                                    className: "widget-token-performance__head__header",
                                    title: o("flooz-web.token.widget-token-performance.title")
                                }), null != i && (0, s.jsx)(eh.F, {
                                    supportedDateRanges: n,
                                    currentDateRange: i,
                                    onDateRangeChange: a
                                })]
                            }), (0, s.jsx)(eR, {
                                token: t,
                                dateRangeFilter: i
                            }), (0, s.jsx)(ez, {
                                token: t
                            })]
                        })
                    })
                };
            var eL = n(72099),
                eM = n(67203);
            (o = r || (r = {})).ACTIVITIES = "ACTIVITIES", o.INFO = "INFO", (i = l || (l = {})).REF_ID = "refId", i.WIDGET_TAB = "widgetTab";
            let eU = [{
                    id: r.ACTIVITIES,
                    label: "flooz-web.token.token-details-page.tab.".concat(r.ACTIVITIES),
                    priority: 100
                }, {
                    id: r.INFO,
                    label: "flooz-web.token.token-details-page.tab.".concat(r.INFO),
                    priority: 200
                }],
                eH = () => {
                    var e, t, n;
                    let o = (0, m.useRouter)(),
                        {
                            t: i
                        } = (0, u.$G)(),
                        {
                            networkParam: a
                        } = (0, x.UV)(),
                        {
                            modalHistory: d
                        } = (0, w.N)(),
                        [R, P] = (0, p.useState)(),
                        z = new URLSearchParams(o.query),
                        F = o.query.tokenAddress,
                        D = null !== (e = z.get(l.REF_ID)) && void 0 !== e ? e : void 0,
                        L = null !== (t = z.get(l.WIDGET_TAB)) && void 0 !== t ? t : A.J.SWAP,
                        {
                            data: M,
                            isLoading: H
                        } = (0, k.d)({
                            pathParameters: {
                                tokenAddress: F
                            },
                            queryParameters: {
                                network: a,
                                filteroutBlacklisted: !1
                            }
                        }, {
                            enabled: null != F
                        }),
                        {
                            data: K
                        } = (0, h.I)({
                            pathParameters: {
                                address: F
                            },
                            queryParameters: {
                                network: a
                            }
                        }, {
                            enabled: null != F && null != a
                        }),
                        {
                            data: W
                        } = (0, T.R)({
                            pathParameters: {
                                address: F,
                                network: a
                            }
                        }, {
                            enabled: (null == M ? void 0 : M.type) !== v.i.NATIVE && null != F && null != a
                        }),
                        B = eM.U.isTokenSafe(null == M ? void 0 : M.type, null == W ? void 0 : W.risk),
                        V = () => {
                            d.push(eL.a.tokenSecurity, void 0, {
                                tokens: [M]
                            })
                        },
                        $ = null !== (n = null == K ? void 0 : K.supportedRanges) && void 0 !== n ? n : [],
                        Y = (0, p.useMemo)(() => {
                            if (M) return {
                                type: E.V.TOKEN,
                                followListId: j.f.TOKEN,
                                identifier: M.address,
                                network: M.network,
                                name: M.name,
                                logoUrl: M.logo
                            }
                        }, [M]),
                        Q = () => {
                            if (!M) return;
                            let e = new URLSearchParams([
                                [S.u.NETWORK, M.network],
                                [S.u.SELECTED_TAB, L]
                            ]);
                            M.type !== v.i.NATIVE && e.append(S.u.TO_TOKEN_ADDRESS, M.address), d.push(I.F.tradeTokens, e)
                        },
                        {
                            icon: J,
                            toggleFollow: q
                        } = (0, C.c)({
                            follow: Y
                        }),
                        {
                            name: Z,
                            symbol: X,
                            usdValue: ee,
                            priceDelta: et,
                            blacklisted: en
                        } = null != M ? M : {},
                        eo = Boolean(en),
                        ei = Boolean(en) ? void 0 : {
                            label: i("flooz-web.token.token-details-page.token-price"),
                            value: ee,
                            delta: et
                        };
                    return (0, s.jsxs)(N.C.Container, {
                        className: "token-details-page",
                        hasWidget: !eo,
                        hasTabs: !eo,
                        isLoading: H,
                        metaTitle: i("flooz-web.token.token-details-page.meta.title", {
                            name: Z,
                            symbol: X
                        }),
                        metaDescription: i("flooz-web.token.token-details-page.meta.description", {
                            name: Z,
                            symbol: X
                        }),
                        metaImage: null == M ? void 0 : M.logo,
                        metaImageAlt: "".concat(X, " logo"),
                        children: [(0, s.jsx)(N.C.Overview, {
                            className: c()({
                                "token-details-page__overview--blacklisted": eo
                            }),
                            parentPage: I.O.trade,
                            displayLogo: !0,
                            logo: (0, s.jsx)(O.S, {
                                token: M
                            }),
                            isVerified: (null == M ? void 0 : M.status) === f.Y.VERIFIED,
                            title: null == M ? void 0 : M.name,
                            subtitle: "$".concat(X),
                            isSafe: B,
                            onSafeBadgeClick: V,
                            displayActions: !eo,
                            actions: [{
                                icon: J,
                                onClick: q,
                                id: "follow"
                            }],
                            mainColumn: ei
                        }), (0, s.jsxs)(N.C.Content, {
                            children: [eo ? (0, s.jsx)(G, {}) : (0, s.jsxs)(N.C.Tabs, {
                                selectedTab: R,
                                defaultTab: r.ACTIVITIES,
                                onTabChange: P,
                                tabEntries: eU,
                                children: [(0, s.jsx)(b.m.Tab, {
                                    id: r.ACTIVITIES,
                                    children: M && (0, s.jsxs)(y.P, {
                                        gap: "150",
                                        direction: "column",
                                        children: [(0, s.jsx)(eD, {
                                            token: M,
                                            supportedDateRanges: $
                                        }), (0, s.jsx)(U, {
                                            token: M
                                        }), (0, s.jsxs)(y.P, {
                                            gap: "25",
                                            direction: "row",
                                            justifyContent: "center",
                                            children: [(0, s.jsx)(_.x, {
                                                color: "muted",
                                                size: "s",
                                                children: i("flooz-web.token.token-details-page.data-provided-by")
                                            }), (0, s.jsx)(g.Z, {
                                                size: "s",
                                                variant: "text",
                                                target: "_blank",
                                                href: "https://www.coinmarketcap.com",
                                                children: "CoinMarketCap.com"
                                            })]
                                        })]
                                    })
                                }), (0, s.jsx)(b.m.Tab, {
                                    id: r.INFO,
                                    children: M && (0, s.jsx)(ek, {
                                        token: M
                                    })
                                })]
                            }), !eo && (0, s.jsx)(N.C.Widget, {
                                toggleLabel: i("flooz-web.token.token-details-page.trade-button"),
                                onMobileClick: Q,
                                children: (0, s.jsx)(A.U, {
                                    swapTokensParams: {
                                        refId: D,
                                        toTokenAddress: F,
                                        lockToToken: !0,
                                        network: a,
                                        swapTokensContext: {
                                            hideChartLink: !0
                                        }
                                    },
                                    buyCryptoParams: {
                                        network: a,
                                        tokenAddress: F,
                                        buyCryptoContext: {
                                            hideChartLink: !0
                                        }
                                    },
                                    initialSelectedTab: L
                                })
                            })]
                        })]
                    })
                }
        },
        67203: function(e, t, n) {
            n.d(t, {
                U: function() {
                    return d
                }
            });
            var o, i, a, r, l = n(69402);
            (o = a || (a = {})).LOW = "low", o.MEDIUM = "medium", o.HIGH = "high", (i = r || (r = {})).FALSE = "0", i.TRUE = "1";
            let s = [{
                    name: "isHoneypot",
                    valueConsideredSafe: r.FALSE
                }, {
                    name: "ownerChangeBalance",
                    valueConsideredSafe: r.FALSE
                }, {
                    name: "isOpenSource",
                    valueConsideredSafe: r.TRUE
                }, {
                    name: "isAirdropScam",
                    valueConsideredSafe: r.FALSE
                }, {
                    name: "isTrueToken",
                    valueConsideredSafe: r.TRUE
                }, {
                    name: "personalSlippageModifiable",
                    valueConsideredSafe: r.FALSE
                }],
                d = new class {
                    constructor() {
                        this.isTokenSafe = (e, t) => e === l.i.NATIVE || t === a.LOW || t !== a.MEDIUM && t !== a.HIGH && void 0, this.isTokenRiskAttributeSafe = (e, t) => {
                            if (t[e.name]) return t[e.name] === e.valueConsideredSafe
                        }, this.getProcessedTokenSecurityInfo = e => {
                            let t = [];
                            s.forEach(n => {
                                let o = {
                                    name: n.name,
                                    isSafe: this.isTokenRiskAttributeSafe(n, e)
                                };
                                t.push(o)
                            });
                            let n = {
                                tokenSymbol: e.tokenSymbol,
                                tokenRisk: e.risk,
                                securityAttributes: t
                            };
                            return n
                        }
                    }
                }
        },
        4930: function(e, t, n) {
            n.d(t, {
                E: function() {
                    return u
                }
            });
            var o, i = n(94597),
                a = n(68091),
                r = n(99740),
                l = n(98848),
                s = n(49981),
                d = n(38138),
                c = n(17367);
            (o || (o = {})).FIAT_FIELD_REQUIRED = "FIAT_FIELD_REQUIRED";
            let u = new class {
                constructor() {
                    this.validateFiatAmount = e => {
                        let {
                            amount: t
                        } = e, n = parseInt(null != t ? t : "0");
                        return isNaN(n) || 0 === n ? o.FIAT_FIELD_REQUIRED : void 0
                    }, this.formValuesToSwapQuoteParams = e => {
                        var t;
                        let {
                            token: n,
                            selectedAccount: o,
                            tokenAmount: i
                        } = e;
                        if (null == n || null == i || "0" === i) return;
                        let {
                            nativeCurrency: a
                        } = r.Eu[n.network], l = s.a.toBaseUnit(i, a.decimals).toString(), u = null !== (t = null == n ? void 0 : n.buyFees) && void 0 !== t ? t : 0, m = c.f.MEDIUM, p = {
                            buyCurrency: n.address,
                            sellCurrency: a.address,
                            network: n.network,
                            sellAmount: l,
                            userAddress: o,
                            gasPriceLevel: m,
                            contractType: d.R.FLOOZ_MULTICHAIN_ROUTER,
                            slippage: u
                        };
                        return {
                            body: p
                        }
                    }, this.formValuesToRampTransactionData = e => {
                        let {
                            buyQuote: t,
                            fiatAmount: n,
                            fiatId: o,
                            userAddress: r,
                            token: s,
                            email: d,
                            finalToken: c,
                            refId: u
                        } = e;
                        if ((null == t ? void 0 : t.id) == null || null == s || null == r) return;
                        let m = c ? a.L.INDIRECT : a.L.DIRECT,
                            p = l._.isSafari() ? i.B.SAFARI_WEB_BROWSER : i.B.GENERIC_WEB_BROWSER;
                        return {
                            quoteId: t.id,
                            tokenAddress: s.address,
                            tokenSymbol: s.symbol,
                            network: s.network,
                            fiatAmount: Number(n),
                            fiatSymbol: o,
                            userAddress: r,
                            paymentType: t.paymentType,
                            provider: t.provider,
                            rate: t.cryptoAssetUnitPrice.toString(),
                            client: p,
                            type: m,
                            email: d,
                            indirectTokenAddress: null == c ? void 0 : c.address,
                            referralId: u
                        }
                    }
                }
            }
        },
        71605: function(e, t, n) {
            n.d(t, {
                W: function() {
                    return c
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i),
                r = n(38313),
                l = n(87930),
                s = n(1527),
                d = n(18819);
            let c = e => {
                let {
                    fiatCurrency: t,
                    className: n
                } = e, {
                    id: i,
                    icon: c,
                    symbol: u
                } = d.w[t];
                return (0, o.jsxs)(l.P, {
                    className: a()("fiat-currency", n),
                    direction: "row",
                    gap: "50",
                    alignItems: "center",
                    children: [(0, o.jsx)(r.J, {
                        icon: c
                    }), (0, o.jsxs)(s.x, {
                        size: "m",
                        fontWeight: "bold",
                        ellipsis: !0,
                        children: [u, " ", i]
                    })]
                })
            }
        },
        19846: function(e, t, n) {
            n.r(t), n.d(t, {
                ModalHowToBuyAny: function() {
                    return x
                },
                ModalHowToBuyAnyQueryParams: function() {
                    return i
                }
            });
            var o, i, a = n(85893),
                r = n(9264);
            n(67294);
            var l = n(69484),
                s = n(77902),
                d = n(88112),
                c = n(84668),
                u = n(47885),
                m = n(79577),
                p = n(27722),
                f = n(85795),
                v = n(1527),
                k = n(99740),
                h = n(13915),
                T = n(20706);
            (o = i || (i = {})).TOKEN_ADDRESS = "TOKEN_ADDRESS", o.TOKEN_NETWORK = "TOKEN_NETWORK", o.FROM_TOKEN_AMOUNT = "FROM_TOKEN_AMOUNT", o.TO_TOKEN_AMOUNT = "TO_TOKEN_AMOUNT";
            let x = e => {
                var t, n, o, x;
                let {
                    location: g
                } = e, {
                    modalHistory: y
                } = (0, p.N)(), {
                    t: w
                } = (0, r.$G)(), N = new URLSearchParams(g.search), b = null !== (t = N.get(i.TOKEN_ADDRESS)) && void 0 !== t ? t : void 0, _ = N.get(i.TOKEN_NETWORK), j = null !== (n = N.get(i.FROM_TOKEN_AMOUNT)) && void 0 !== n ? n : "", E = null !== (o = N.get(i.TO_TOKEN_AMOUNT)) && void 0 !== o ? o : "", {
                    data: C,
                    isInitialLoading: S
                } = (0, l.d)({
                    pathParameters: {
                        tokenAddress: b
                    },
                    queryParameters: {
                        network: _
                    }
                }, {
                    enabled: null != b && null != _
                }), A = h.z.formatNumber(j, {
                    useRangeFormat: !0
                }), I = h.z.formatNumber(E, {
                    useRangeFormat: !0
                }), {
                    nativeCurrency: O
                } = k.Eu[null !== (x = null == C ? void 0 : C.network) && void 0 !== x ? x : k.cU.BINANCE_MAINNET], {
                    symbol: R
                } = O, P = null == C ? void 0 : C.symbol;
                return (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(m.u.Header, {}), (0, a.jsx)(m.u.Content, {
                        className: "modal-how-to-buy-any__content",
                        children: (0, a.jsxs)(u.P, {
                            gap: "150",
                            direction: "column",
                            alignItems: "center",
                            children: [(0, a.jsx)(d.d, {
                                size: "l",
                                children: (0, a.jsx)(T.S, {
                                    token: C,
                                    isLoading: S
                                })
                            }), (0, a.jsxs)(u.P, {
                                gap: "100",
                                direction: "column",
                                alignItems: "center",
                                children: [(0, a.jsx)(c.X, {
                                    size: "h4",
                                    children: w("flooz-web.trade.modal-how-to-buy-any.title", {
                                        amount: I,
                                        token: P
                                    })
                                }), (0, a.jsxs)(f.v.Container, {
                                    children: [(0, a.jsx)(f.v.Step, {
                                        children: (0, a.jsxs)(u.P, {
                                            gap: "0",
                                            direction: "column",
                                            children: [(0, a.jsx)(v.x, {
                                                size: "l",
                                                fontWeight: "bold",
                                                children: w("flooz-web.trade.modal-how-to-buy-any.step-1.title", {
                                                    amount: A,
                                                    token: R
                                                })
                                            }), (0, a.jsx)(v.x, {
                                                size: "m",
                                                fontWeight: "regular",
                                                color: "muted",
                                                children: w("flooz-web.trade.modal-how-to-buy-any.step-1.description")
                                            })]
                                        })
                                    }), (0, a.jsx)(f.v.Step, {
                                        children: (0, a.jsxs)(u.P, {
                                            gap: "0",
                                            direction: "column",
                                            children: [(0, a.jsx)(v.x, {
                                                size: "l",
                                                fontWeight: "bold",
                                                children: w("flooz-web.trade.modal-how-to-buy-any.step-2.title")
                                            }), (0, a.jsx)(v.x, {
                                                size: "m",
                                                fontWeight: "regular",
                                                color: "muted",
                                                children: w("flooz-web.trade.modal-how-to-buy-any.step-2.description", {
                                                    token: R
                                                })
                                            })]
                                        })
                                    }), (0, a.jsx)(f.v.Step, {
                                        children: (0, a.jsxs)(u.P, {
                                            gap: "0",
                                            direction: "column",
                                            children: [(0, a.jsx)(v.x, {
                                                size: "l",
                                                fontWeight: "bold",
                                                children: w("flooz-web.trade.modal-how-to-buy-any.step-3.title", {
                                                    fromToken: R,
                                                    toToken: P
                                                })
                                            }), (0, a.jsx)(v.x, {
                                                size: "m",
                                                fontWeight: "regular",
                                                color: "muted",
                                                children: w("flooz-web.trade.modal-how-to-buy-any.step-3.description")
                                            })]
                                        })
                                    })]
                                })]
                            })]
                        })
                    }), (0, a.jsx)(m.u.Footer, {
                        children: (0, a.jsx)(s.z, {
                            className: "modal-how-to-buy-any__button",
                            size: "xl",
                            variant: "primary",
                            onClick: () => y.back(),
                            children: w("flooz-web.trade.modal-how-to-buy-any.continue")
                        })
                    })]
                })
            }
        },
        17038: function(e, t, n) {
            n.r(t), n.d(t, {
                ModalSelectFiat: function() {
                    return p
                },
                ModalSelectFiatQueryParams: function() {
                    return o
                }
            });
            var o, i = n(85893),
                a = n(9264),
                r = n(67294),
                l = n(95263),
                s = n(81031),
                d = n(69355),
                c = n(79577),
                u = n(27722),
                m = n(71605);
            (o || (o = {})).SELECTED_FIAT_ID = "selectedFiatId";
            let p = e => {
                var t;
                let {
                    location: n
                } = e, {
                    t: p
                } = (0, a.$G)(), {
                    modalHistory: f
                } = (0, u.N)(), {
                    countryCode: v
                } = (0, s.Y)(), k = new URLSearchParams(n.search), h = k.get(o.SELECTED_FIAT_ID), {
                    onFiatSelected: T
                } = null !== (t = n.state) && void 0 !== t ? t : {}, x = (0, r.useCallback)(e => {
                    f.back(), null == T || T(e)
                }, [f, T]), g = Object.values(l.Y).filter(e => e !== l.Y.NGN || "NG" === v);
                return (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsx)(c.u.Header, {
                        title: p("flooz-web.trade.modal-select-fiat.title")
                    }), (0, i.jsx)(c.u.Content, {
                        className: "modal-select-fiat__content",
                        children: (0, i.jsx)(d.s.Container, {
                            children: g.map(e => (0, i.jsx)(d.s.Item, {
                                className: "modal-select-fiat__item",
                                isSelected: h === e,
                                onClick: () => x(e),
                                children: (0, i.jsx)(m.W, {
                                    fiatCurrency: e
                                })
                            }, e))
                        })
                    })]
                })
            }
        },
        11116: function(e, t, n) {
            n.d(t, {
                R: function() {
                    return I
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i),
                r = n(82580),
                l = n(9264),
                s = n(67294),
                d = n(77902),
                c = n(34346),
                u = n(87930),
                m = n(55642),
                p = n(1527),
                f = n(28285),
                v = n(13915),
                k = n(58871),
                h = n(29485),
                T = n(99740),
                x = n(5093),
                g = n(84085);
            let y = e => {
                var t;
                let {
                    name: n,
                    token: i,
                    isReadonly: a,
                    isLoading: l
                } = e, {
                    validateField: d
                } = (0, r.u6)(), {
                    setGetFromAmount: c
                } = (0, x.gI)(), m = (0, f.h)(), p = (0, s.useMemo)(() => {
                    var e, t, n;
                    return i ? null === (e = null === (t = null === (n = m.map) || void 0 === n ? void 0 : n.get(i.network)) || void 0 === t ? void 0 : t.get(i.address)) || void 0 === e ? void 0 : e.balance : void 0
                }, [m, i]), v = null != i && g.u5.isFromField(n) ? g.u5.getMaxAmount({
                    token: i,
                    amount: p
                }) : void 0, y = {
                    isFromField: g.u5.isFromField(n),
                    maxBalance: v
                }, w = e => g.u5.validateTokenAmount({ ...y,
                    amount: e,
                    decimals: null == i ? void 0 : i.decimals
                }), [{
                    onChange: N,
                    ...b
                }, , _] = (0, r.U$)({
                    name: n,
                    validate: w
                });
                (0, s.useEffect)(() => {
                    n === k.$M.FROM_TOKEN_AMOUNT && d(n)
                }, [n, d, p, v]);
                let j = e => {
                    _.setValue(e, !1), d(n)
                };
                return (0, o.jsx)(u.P, {
                    className: "token-amount-field",
                    gap: "0",
                    alignItems: "start",
                    grow: "1",
                    children: (0, o.jsx)(u.P, {
                        direction: "row",
                        gap: "0",
                        alignItems: "baseline",
                        children: (0, o.jsx)(h.MK, { ...b,
                            radix: ".",
                            mapToRadix: a ? [] : [","],
                            thousandsSeparator: ",",
                            scale: null !== (t = null == i ? void 0 : i.decimals) && void 0 !== t ? t : T.zo,
                            mask: Number,
                            unmask: !0,
                            min: 0,
                            placeholder: "0.00",
                            onAccept: j,
                            onFocus: () => null == c ? void 0 : c(n === k.$M.TO_TOKEN_AMOUNT),
                            inputMode: "decimal",
                            autoComplete: "off",
                            variant: "quiet",
                            readOnly: a,
                            isLoading: l,
                            disabled: !i
                        })
                    })
                })
            };
            var w = n(12204),
                N = n(27722),
                b = n(49981),
                _ = n(45142),
                j = n(32483),
                E = n(72099),
                C = n(49749),
                S = n(34562);
            let A = e => {
                    let {
                        name: t,
                        isTokenReadonly: n,
                        onSwitchTokens: i
                    } = e, {
                        t: a
                    } = (0, l.$G)(), {
                        values: d,
                        setFieldValue: c
                    } = (0, r.u6)(), {
                        isLoading: u,
                        lockToken: m
                    } = (0, S.E8)(), {
                        modalHistory: p
                    } = (0, N.N)(), [f, , v] = (0, r.U$)({
                        name: t,
                        validate: g.u5.validateToken,
                        readOnly: n
                    }), h = (0, s.useRef)(v.setValue), T = g.u5.isFromField(t), x = T ? d.toToken : d.fromToken, y = T ? k.$M.FROM_TOKEN_AMOUNT : k.$M.TO_TOKEN_AMOUNT, A = (0, s.useCallback)(e => {
                        C.k0.emitTokenSelected({
                            token: e
                        });
                        let t = g.u5.getSwapSlippage({
                            fromToken: T ? e : x,
                            toToken: T ? x : e
                        });
                        b.a.areSameAddress(e.address, null == x ? void 0 : x.address) ? null == i || i() : (c(y, void 0), h.current(e), c(k.$M.NETWORK, e.network)), c(k.$M.SLIPPAGE, t)
                    }, [T, x, c, i, y]), I = x && b.a.areSameAddress(m, x.address) ? d.network : !T && x ? null == x ? void 0 : x.network : void 0, O = (0, s.useCallback)(() => {
                        if (!n) {
                            let e = new URLSearchParams;
                            I && e.append(_.ModalSelectTokenQueryParams.NETWORK, I), p.push(E.a.selectToken, e, {
                                onTokenSelected: A
                            })
                        }
                    }, [n, p, I, A]);
                    return (0, s.useEffect)(() => {
                        var e;
                        f.value && d.network !== (null === (e = f.value) || void 0 === e ? void 0 : e.network) && h.current(void 0)
                    }, [d.network, f.value]), (0, o.jsxs)(o.Fragment, {
                        children: [f.value && (0, o.jsx)(w.z, {
                            className: "token-field",
                            variant: "secondary",
                            size: "m",
                            onClick: O,
                            iconPosition: "right",
                            disabled: null != n ? n : b.a.areSameAddress(m, f.value.address),
                            contentClassName: "ellipsis",
                            children: (0, o.jsx)(j.W, {
                                className: "ellipsis",
                                logoSize: "s",
                                symbolSize: "l",
                                gap: "25",
                                token: f.value,
                                displayChain: !1
                            })
                        }), !f.value && (0, o.jsx)(w.z, {
                            className: "token-field",
                            variant: "primary",
                            disabled: u,
                            size: "m",
                            onClick: O,
                            children: a(u ? "flooz-web.trade.swap-tokens.fields.token-field.loading" : "flooz-web.trade.swap-tokens.fields.token-field.select-token")
                        })]
                    })
                },
                I = e => {
                    var t;
                    let {
                        name: n,
                        isTokenReadonly: i,
                        isLoading: h,
                        isAmountReadonly: T,
                        onSwitchTokens: w,
                        className: N
                    } = e, {
                        t: b
                    } = (0, l.$G)(), {
                        values: _,
                        setFieldValue: j
                    } = (0, r.u6)(), {
                        setGetFromAmount: E
                    } = (0, x.gI)(), C = (0, f.h)(), S = g.u5.isFromField(n), I = S ? k.$M.FROM_TOKEN_AMOUNT : k.$M.TO_TOKEN_AMOUNT, O = _[n], R = _[I], P = (0, s.useMemo)(() => {
                        var e, t, n;
                        return O ? null === (e = null === (t = null === (n = C.map) || void 0 === n ? void 0 : n.get(O.network)) || void 0 === t ? void 0 : t.get(O.address)) || void 0 === e ? void 0 : e.balance : void 0
                    }, [C, O]), z = parseFloat(null != P ? P : "0"), F = v.z.formatNumber(z, {
                        fixedFractionDigits: 2,
                        useSuperscriptFormat: !0,
                        useRangeFormat: !0
                    }), D = null != O && S ? g.u5.getMaxAmount({
                        token: O,
                        amount: P
                    }) : void 0, L = (0, s.useCallback)(() => {
                        null == E || E(!S), j(I, D)
                    }, [j, S, I, E, D]), M = (null == R ? void 0 : R.length) ? parseFloat(R) : 0, U = M * parseFloat(null !== (t = null == O ? void 0 : O.usdValue) && void 0 !== t ? t : "0"), H = v.z.formatNumber(U, {
                        fixedFractionDigits: 2,
                        useRangeFormat: !0
                    }), K = b(S ? "flooz-web.trade.swap-tokens.form.token.from-token" : "flooz-web.trade.swap-tokens.form.token.to-token"), G = null != O && "loading" === C.status, W = g.u5.isFromField(n) && null != P && null != D && !T && R !== D;
                    return (0, o.jsxs)(u.P, {
                        gap: "50",
                        className: a()("swap-tokens-form-token", N),
                        children: [(0, o.jsx)(p.x, {
                            size: "m",
                            fontWeight: "bold",
                            color: "white",
                            children: K
                        }), (0, o.jsx)(u.P, {
                            gap: "25",
                            direction: "row",
                            children: (0, o.jsxs)(c.B, {
                                readOnly: Boolean(T) || null == O,
                                children: [(0, o.jsx)(y, {
                                    token: O,
                                    name: I,
                                    isReadonly: T,
                                    isLoading: h
                                }), (0, o.jsx)(A, {
                                    name: n,
                                    isTokenReadonly: i,
                                    onSwitchTokens: w
                                })]
                            })
                        }), (0, o.jsxs)(u.P, {
                            gap: "25",
                            direction: "row",
                            justifyContent: "space-between",
                            children: [(0, o.jsx)(p.x, {
                                size: "s",
                                fontWeight: "bold",
                                color: "muted",
                                children: b("flooz-web.trade.swap-tokens.form.token.price", {
                                    price: H
                                })
                            }), (0, o.jsxs)(u.P, {
                                gap: "25",
                                direction: "row",
                                children: [G && (0, o.jsx)(m.g, {
                                    width: 30,
                                    height: 16
                                }), !G && z > 0 && (0, o.jsx)(p.x, {
                                    size: "s",
                                    fontWeight: "bold",
                                    component: "span",
                                    color: "muted",
                                    children: F
                                }), W && (0, o.jsx)(d.z, {
                                    variant: "text",
                                    size: "s",
                                    onClick: L,
                                    children: b("flooz-web.trade.swap-tokens.form.token.max")
                                })]
                            })]
                        })]
                    })
                }
        },
        66744: function(e, t, n) {
            n.d(t, {
                U: function() {
                    return e7
                },
                J: function() {
                    return r
                }
            });
            var o, i, a, r, l = n(85893),
                s = n(94184),
                d = n.n(s),
                c = n(9264),
                u = n(67294),
                m = n(84668),
                p = n(47885),
                f = n(3188),
                v = n(95263),
                k = n(69484),
                h = n(81031),
                T = n(48791),
                x = n(27766),
                g = n(31382);
            let y = e => {
                let {
                    network: t,
                    refId: n,
                    tokenAddress: o,
                    currencyId: i,
                    defaultAmount: a,
                    buyCryptoContext: r
                } = null != e ? e : {}, {
                    providerNetwork: l
                } = (0, T.Z_)(), {
                    currency: s
                } = (0, h.Y)(), {
                    address: d
                } = (0, x.e)(n), {
                    data: c
                } = (0, k.d)({
                    pathParameters: {
                        tokenAddress: o
                    },
                    queryParameters: {
                        network: t
                    }
                }, {
                    enabled: null != o && null != t
                }), m = g.p.getTokenToBuy({
                    token: c,
                    providerNetwork: l,
                    networkParam: t
                }), {
                    data: p
                } = (0, k.d)({
                    queryParameters: {
                        network: m.network
                    },
                    pathParameters: {
                        tokenAddress: m.address
                    }
                }), f = (0, u.useMemo)(() => {
                    let e = null != i ? i : s,
                        t = !isNaN(parseFloat(null != a ? a : "")),
                        n = Object.keys(v.Y).some(t => t === e);
                    return {
                        defaultAmount: t ? a : void 0,
                        currencyId: n ? e : void 0,
                        referrer: d,
                        ...r
                    }
                }, [i, s, a, d, r]);
                return {
                    tokenToBuy: p,
                    buyCryptoContext: f
                }
            };
            var w = n(50950);
            (o = a || (a = {})).MINIMUM_AMOUNT_NOT_MET = "MINIMUM_AMOUNT_NOT_MET", o.MAXIMUM_AMOUNT_EXCEEDED = "MAXIMUM_AMOUNT_EXCEEDED", o.BANK_TRANSFERS_NOT_SUPPORTED_FOR_USD = "BANK_TRANSFERS_NOT_SUPPORTED_FOR_USD", o.OTHER = "OTHER";
            var N = n(1527),
                b = n(99740),
                _ = n(31821),
                j = n(49749),
                E = n(68385),
                C = n(77902),
                S = n(33715),
                A = n(27722),
                I = n(50417),
                O = n(2125),
                R = n(45837),
                P = n(51401),
                z = n(12204),
                F = n(99769),
                D = n(65864),
                L = n(87930),
                M = n(70038),
                U = n(51515),
                H = n(76729),
                K = n(90271),
                G = n(72099),
                W = n(46953);
            let B = e => {
                    let {
                        displayChartLink: t = !1,
                        displayReferLink: n = !0,
                        displayOffRampLink: o = !0,
                        tokenAddress: i = b.lJ.address,
                        tokenNetwork: a = b.cU.BINANCE_MAINNET,
                        referrer: r,
                        className: s,
                        children: m
                    } = e, {
                        modalHistory: p
                    } = (0, M.N)(), {
                        t: f
                    } = (0, c.$G)(), {
                        data: v
                    } = (0, R.t)({
                        body: {
                            address: r
                        }
                    }, {
                        enabled: null != r
                    }), {
                        data: k
                    } = (0, P.I)({
                        pathParameters: {
                            address: i
                        },
                        queryParameters: {
                            network: a
                        }
                    }), h = (null == k ? void 0 : k.supported) === !1, T = null == v ? void 0 : v.refId, x = W.S.getChartUrl({
                        tokenDetailsRoute: G.U.tokenDetails,
                        networkParamName: U.H.NETWORK,
                        refIdParamName: U.H.REF_ID,
                        useExternalWebsite: h,
                        tokenAddress: i,
                        refId: T,
                        network: a
                    }), g = (0, u.useCallback)(() => {
                        let e = new URLSearchParams([
                            [H.ModalReferralQueryParams.TOKEN, i],
                            [H.ModalReferralQueryParams.NETWORK, a]
                        ]);
                        p.push(K.e.referral, e)
                    }, [p, i, a]);
                    return (0, l.jsxs)(L.P, {
                        className: d()("trade-actions", s),
                        gap: "50",
                        children: [m, t && (0, l.jsx)(F.Z, {
                            variant: "text",
                            size: "m",
                            href: x,
                            target: "_blank",
                            icon: D.T.CARET_RIGHT,
                            iconPosition: "right",
                            children: f("flooz-web.trade.trade-actions.chart")
                        }), o && (0, l.jsx)(F.Z, {
                            variant: "text",
                            size: "m",
                            href: "https://sell.moonpay.com?apiKey=pk_live_cVdATUCipk0LEMGljSiLPilH4wPKWar",
                            target: "_blank",
                            icon: D.T.CARET_RIGHT,
                            iconPosition: "right",
                            children: f("flooz-web.trade.trade-actions.off-ramp")
                        }), n && (0, l.jsx)(z.z, {
                            variant: "text",
                            size: "m",
                            onClick: g,
                            icon: D.T.CARET_RIGHT,
                            iconPosition: "right",
                            children: f("flooz-web.trade.trade-actions.share-earn")
                        })]
                    })
                },
                V = (0, u.createContext)(null),
                $ = V.Provider,
                Y = () => {
                    let e = (0, u.useContext)(V);
                    if (null == e) throw Error("useBuyCryptoFormContext: the hook must be placed inside a BuyCryptoFormContextProvider to work properly");
                    return e
                },
                Q = e => {
                    var t, n;
                    let {
                        token: o,
                        indirectToken: i,
                        fiatCurrency: a,
                        fiatAmount: r,
                        selectedQuoteId: s,
                        onQuoteSelected: d
                    } = e, {
                        t: u
                    } = (0, c.$G)(), {
                        modalHistory: m
                    } = (0, A.N)(), {
                        hideChartLink: p,
                        hideOffRampLink: f,
                        hideReferLink: v,
                        referrer: k
                    } = Y(), {
                        selectedAccount: h
                    } = (0, T.Z_)(), x = () => {
                        if (!o) return;
                        let e = new URLSearchParams([
                            [O.C.FIAT_ID, a],
                            [O.C.FIAT_AMOUNT, r],
                            [O.C.TOKEN_ADDRESS, o.address],
                            [O.C.TOKEN_NETWORK, o.network]
                        ]);
                        s && e.append(O.C.SELECTED_QUOTE_ID, s), m.push(I.F.selectRampQuote, e, {
                            onQuoteSelected: d
                        })
                    }, g = null !== (t = null == i ? void 0 : i.address) && void 0 !== t ? t : null == o ? void 0 : o.address, y = null !== (n = null == i ? void 0 : i.network) && void 0 !== n ? n : null == o ? void 0 : o.network;
                    return (0, l.jsx)(B, {
                        displayChartLink: !p,
                        displayOffRampLink: !f,
                        displayReferLink: !v,
                        tokenAddress: g,
                        tokenNetwork: y,
                        referrer: k,
                        children: h && (0, l.jsx)(C.z, {
                            variant: "text",
                            size: "m",
                            onClick: x,
                            icon: S.T.CARET_RIGHT,
                            iconPosition: "right",
                            disabled: null == o,
                            children: u("flooz-web.trade.buy-crypto-form.actions.see-other-options")
                        })
                    })
                },
                J = [a.MINIMUM_AMOUNT_NOT_MET, a.MAXIMUM_AMOUNT_EXCEEDED, a.BANK_TRANSFERS_NOT_SUPPORTED_FOR_USD, a.OTHER],
                q = {
                    [v.Y.EUR]: "200",
                    [v.Y.GBP]: "200",
                    [v.Y.NGN]: "45000",
                    [v.Y.USD]: "200"
                };
            var Z = n(88956),
                X = n(38313),
                ee = n(12668),
                et = n(38826),
                en = n(75877),
                eo = n(57969),
                ei = n(56352),
                ea = n(4964),
                er = n(4930);
            let el = e => {
                var t, n;
                let {
                    buyQuote: o,
                    fiatId: i,
                    fiatAmount: a,
                    token: r,
                    ...s
                } = e, {
                    t: d
                } = (0, c.$G)(), {
                    modalHistory: u
                } = (0, A.N)(), {
                    selectedAccount: m
                } = (0, ee.Z_)(), {
                    mutate: p
                } = (0, Z.p)(), f = (null !== (n = null == r ? void 0 : null === (t = r.rampProviders) || void 0 === t ? void 0 : t.length) && void 0 !== n ? n : 0) > 0, v = er.E.formValuesToSwapQuoteParams({
                    token: r,
                    selectedAccount: m,
                    tokenAmount: null == o ? void 0 : o.amountInCryptoAsset
                }), {
                    data: k,
                    isInitialLoading: h
                } = (0, en.F)(v, {
                    enabled: null != v && !f
                }), T = () => ({
                    token: r,
                    fiatId: i,
                    fiatAmount: a,
                    buyQuote: o
                }), x = () => j.k0.emitOnRampWalletConnected(T()), g = () => {
                    j.k0.emitOnRampConnectWallet(T()), u.push(et._.connect, void 0, {
                        onSuccess: x
                    })
                }, y = () => {
                    var e;
                    let t = er.E.formValuesToRampTransactionData({
                        buyQuote: o,
                        token: r,
                        userAddress: m,
                        fiatAmount: a,
                        fiatId: i
                    });
                    if (!r || !o || !t) return;
                    if (j.k0.emitOnRampClickBuyButton(T()), !f) {
                        u.push(I.F.buyAnyCrypto, void 0, {
                            token: r,
                            fiatAmount: a,
                            fiatId: i,
                            buyQuote: o,
                            swapQuote: k
                        });
                        return
                    }
                    p({
                        body: t
                    });
                    let n = new URLSearchParams({
                            [ea.S.BUY_URL]: null !== (e = o.buyUrl) && void 0 !== e ? e : "",
                            [ea.S.PROVIDER_ID]: o.provider
                        }),
                        {
                            modalRoute: l
                        } = ei.Q[o.provider];
                    u.push(l, n)
                }, w = o ? eo.m[o.paymentType] : null, {
                    payButtonLocalizationKey: N,
                    payButtonLogo: b
                } = null != w ? w : {}, _ = {
                    token: null == r ? void 0 : r.symbol,
                    context: r ? "token" : void 0
                }, E = d(null != N ? N : "flooz-web.trade.buy-crypto-form.submit.buy", _), C = (null == o ? void 0 : o.id) == null || null == r || !f && h;
                return (0, l.jsx)(z.z, {
                    variant: "primary",
                    size: "xl",
                    onClick: m ? y : g,
                    className: "buy-crypto-form-submit",
                    disabled: C,
                    ...s,
                    children: m ? (0, l.jsxs)(L.P, {
                        direction: "row",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: "0",
                        children: [(0, l.jsx)("p", {
                            children: E
                        }), b && (0, l.jsx)(X.J, {
                            icon: b,
                            className: "buy-crypto-form-submit__icon"
                        })]
                    }) : d("flooz-web.trade.buy-crypto-form.submit.connect")
                })
            };
            var es = n(40146),
                ed = n(34346),
                ec = n(18819),
                eu = n(71605),
                em = n(17038);
            let ep = e => {
                let {
                    fiatAmount: t,
                    setFiatAmount: n,
                    fiatCurrency: o,
                    setFiat: i,
                    className: a
                } = e, {
                    modalHistory: r
                } = (0, A.N)(), {
                    t: s
                } = (0, c.$G)(), m = (0, u.useCallback)(() => {
                    let e = new URLSearchParams([
                        [em.ModalSelectFiatQueryParams.SELECTED_FIAT_ID, o]
                    ]);
                    r.push(I.F.selectFiat, e, {
                        onFiatSelected: i
                    })
                }, [o, r, i]), f = "".concat(ec.w[o].symbol, "{0000000.00}");
                return (0, l.jsxs)(p.P, {
                    gap: "50",
                    direction: "column",
                    children: [(0, l.jsx)(N.x, {
                        size: "m",
                        children: s("flooz-web.trade.buy-crypto-form.currency-field.label")
                    }), (0, l.jsxs)(ed.B, {
                        className: d()("buy-crypto-form-currency-field", a),
                        children: [(0, l.jsx)(es.M, {
                            value: t,
                            radix: ".",
                            mapToRadix: [","],
                            thousandsSeparator: ",",
                            scale: 5,
                            mask: f,
                            unmask: !0,
                            min: 0,
                            placeholder: "$0.00",
                            onAccept: n,
                            variant: "quiet",
                            inputMode: "decimal",
                            autoComplete: "off"
                        }), (0, l.jsx)(C.z, {
                            variant: "secondary",
                            size: "m",
                            onClick: m,
                            children: (0, l.jsx)(eu.W, {
                                className: "ellipsis",
                                fiatCurrency: o
                            })
                        })]
                    })]
                })
            };
            var ef = n(32483);
            let ev = e => {
                let {
                    token: t,
                    setToken: n,
                    tokenAmount: o,
                    isLoading: i,
                    className: a
                } = e, {
                    modalHistory: r
                } = (0, A.N)(), {
                    t: s
                } = (0, c.$G)(), m = (0, u.useCallback)(() => {
                    r.push(G.a.selectToken, void 0, {
                        onTokenSelected: n
                    })
                }, [r, n]);
                return (0, l.jsxs)(p.P, {
                    className: d()("buy-crypto-form-token-field", a),
                    gap: "50",
                    direction: "column",
                    children: [(0, l.jsx)(N.x, {
                        size: "m",
                        children: s("flooz-web.trade.buy-crypto-form.token-field.label")
                    }), (0, l.jsxs)(ed.B, {
                        readOnly: !0,
                        children: [(0, l.jsx)(es.M, {
                            value: null != o ? o : "0",
                            mask: Number,
                            isLoading: i,
                            radix: ".",
                            mapToRadix: [","],
                            thousandsSeparator: ",",
                            scale: 5,
                            unmask: !0,
                            min: 0,
                            inputMode: "decimal",
                            variant: "quiet",
                            readOnly: !0
                        }), (0, l.jsx)(C.z, {
                            variant: "secondary",
                            size: "m",
                            onClick: m,
                            disabled: !t,
                            children: t ? (0, l.jsx)(ef.W, {
                                logoSize: "s",
                                symbolSize: "m",
                                gap: "25",
                                className: "ellipsis",
                                token: t,
                                displayChain: !1
                            }) : s("flooz-web.trade.buy-crypto-form.token-field.loading")
                        })]
                    })]
                })
            };
            var ek = n(55642),
                eh = n(85795),
                eT = n(49981),
                ex = n(13915),
                eg = n(19846);
            let ey = e => {
                    var t;
                    let {
                        token: n,
                        setToken: o,
                        buyQuote: i,
                        fiatAmount: a,
                        fiatId: r,
                        isLoading: s,
                        className: m
                    } = e, {
                        modalHistory: f
                    } = (0, A.N)(), {
                        selectedAccount: v
                    } = (0, T.Z_)(), {
                        t: k
                    } = (0, c.$G)(), {
                        nativeCurrency: h
                    } = b.Eu[n.network], x = null !== (t = null == i ? void 0 : i.amountInCryptoAsset) && void 0 !== t ? t : "0", g = ex.z.formatNumber(x, {
                        useRangeFormat: !0
                    }), y = (0, u.useCallback)(() => {
                        f.push(G.a.selectToken, void 0, {
                            onTokenSelected: o
                        })
                    }, [f, o]), w = er.E.formValuesToSwapQuoteParams({
                        token: n,
                        selectedAccount: v,
                        tokenAmount: x
                    }), {
                        data: _,
                        isInitialLoading: E
                    } = (0, en.F)(w, {
                        enabled: null != w
                    }), O = eT.a.fromBaseUnit(null == _ ? void 0 : _.amount, null == n ? void 0 : n.decimals), R = ex.z.formatNumber(O, {
                        useRangeFormat: !0
                    }), P = () => {
                        let e = new URLSearchParams([
                            [eg.ModalHowToBuyAnyQueryParams.TOKEN_ADDRESS, n.address],
                            [eg.ModalHowToBuyAnyQueryParams.TOKEN_NETWORK, n.network],
                            [eg.ModalHowToBuyAnyQueryParams.FROM_TOKEN_AMOUNT, x],
                            [eg.ModalHowToBuyAnyQueryParams.TO_TOKEN_AMOUNT, O]
                        ]);
                        j.k0.emitOnRampHowToBuyInfo({
                            token: n,
                            buyQuote: i,
                            fiatAmount: a,
                            fiatId: r
                        }), f.push(I.F.howToBuyAny, e)
                    };
                    return (0, l.jsxs)(p.P, {
                        className: d()("buy-crypto-form-token-field-unsupported", m),
                        gap: "50",
                        direction: "column",
                        children: [(0, l.jsxs)(p.P, {
                            gap: "50",
                            direction: "row",
                            alignItems: "center",
                            children: [(0, l.jsx)(N.x, {
                                size: "m",
                                children: k("flooz-web.trade.buy-crypto-form.token-field-unsupported.label", {
                                    token: n.symbol
                                })
                            }), (0, l.jsx)(C.z, {
                                size: "s",
                                variant: "text",
                                icon: S.T.INFO,
                                onClick: P
                            })]
                        }), (0, l.jsxs)(ed.B, {
                            readOnly: !0,
                            children: [(0, l.jsxs)(eh.v.Container, {
                                activeStepIndex: 0,
                                children: [(0, l.jsx)(eh.v.Step, {
                                    children: (0, l.jsx)(N.x, {
                                        size: "m",
                                        color: "white",
                                        children: k("flooz-web.trade.buy-crypto-form.token-field-unsupported.step.email")
                                    })
                                }), (0, l.jsx)(eh.v.Step, {
                                    children: (0, l.jsxs)(p.P, {
                                        gap: "25",
                                        direction: "column",
                                        children: [(0, l.jsx)(N.x, {
                                            size: "m",
                                            color: "muted",
                                            children: k("flooz-web.trade.buy-crypto-form.token-field-unsupported.step.buy")
                                        }), (0, l.jsx)(p.P, {
                                            gap: "50",
                                            direction: "row",
                                            children: (0, l.jsx)(N.x, {
                                                size: "l",
                                                color: "white",
                                                component: "span",
                                                children: (0, l.jsxs)(p.P, {
                                                    gap: "25",
                                                    direction: "row",
                                                    children: [s ? (0, l.jsx)(ek.g, {
                                                        width: 45
                                                    }) : "~".concat(g, " "), "$", h.symbol]
                                                })
                                            })
                                        })]
                                    })
                                }), (0, l.jsx)(eh.v.Step, {
                                    children: (0, l.jsx)(p.P, {
                                        direction: "column",
                                        gap: "50",
                                        justifyContent: "space-between",
                                        children: (0, l.jsxs)(p.P, {
                                            gap: "25",
                                            direction: "column",
                                            children: [(0, l.jsx)(N.x, {
                                                size: "m",
                                                color: "muted",
                                                children: k("flooz-web.trade.buy-crypto-form.token-field-unsupported.step.swap")
                                            }), (0, l.jsx)(N.x, {
                                                size: "l",
                                                color: "white",
                                                children: s || E ? (0, l.jsx)(ek.g, {
                                                    width: 45
                                                }) : "~".concat(R, " ")
                                            })]
                                        })
                                    })
                                })]
                            }), (0, l.jsx)(C.z, {
                                variant: "secondary",
                                size: "m",
                                onClick: y,
                                disabled: !n,
                                children: (0, l.jsx)(ef.W, {
                                    logoSize: "s",
                                    symbolSize: "m",
                                    gap: "25",
                                    className: "ellipsis",
                                    token: n,
                                    displayChain: !1
                                })
                            })]
                        })]
                    })
                },
                ew = e => {
                    var t, n, o, i;
                    let {
                        initialToken: r,
                        className: s
                    } = e, {
                        t: m
                    } = (0, c.$G)(), {
                        providerNetwork: f
                    } = (0, T.Z_)(), {
                        currencyId: h,
                        defaultAmount: x
                    } = Y(), [g, y] = (0, u.useState)(), w = null != h ? h : v.Y.USD, [C, S] = (0, u.useState)(w), A = null != x ? x : q[w], [I, O] = (0, u.useState)(A), R = (0, _.N)(I, 500), [P, z] = (0, u.useState)(), F = null != f ? f : b.cU.ETHEREUM_MAINNET, {
                        nativeCurrency: D
                    } = b.Eu[F], {
                        data: L
                    } = (0, k.d)({
                        pathParameters: {
                            tokenAddress: D.address
                        },
                        queryParameters: {
                            network: F
                        }
                    }), M = null !== (n = null != g ? g : r) && void 0 !== n ? n : L, U = b.Eu[null !== (o = null == M ? void 0 : M.network) && void 0 !== o ? o : b.cU.BINANCE_MAINNET].nativeCurrency, H = (null !== (i = null == M ? void 0 : null === (t = M.rampProviders) || void 0 === t ? void 0 : t.length) && void 0 !== i ? i : 0) > 0, K = H ? M : U, G = (0, u.useMemo)(() => er.E.validateFiatAmount({
                        amount: R
                    }), [R]), {
                        data: W = [],
                        isInitialLoading: B
                    } = (0, E.Y)({
                        token: K,
                        fiatAmount: I,
                        fiatCurrency: C,
                        enabled: null == G
                    }), V = (0, u.useMemo)(() => {
                        let e = W.some(e => e.isValid),
                            t = J.find(e => W.find(t => {
                                let {
                                    quoteError: n
                                } = t;
                                return (null == n ? void 0 : n.errorType) === e
                            })),
                            n = null != t ? t : a.OTHER;
                        return B || !(K && null == G) || e ? void 0 : "flooz-web.trade.buy-crypto-form.error.quote.".concat(n)
                    }, [B, K, W, G]);
                    return (0, u.useEffect)(() => {
                        O(q[C])
                    }, [C]), (0, u.useEffect)(() => {
                        j.k0.emitOnRampView({
                            token: M,
                            fiatAmount: I,
                            fiatId: C
                        })
                    }, []), (0, u.useEffect)(() => z(null == W ? void 0 : W.find(e => {
                        let {
                            isBestChoice: t
                        } = e;
                        return t
                    })), [W]), (0, l.jsxs)(p.P, {
                        className: d()("buy-crypto-form", s),
                        direction: "column",
                        gap: "100",
                        grow: "1",
                        justifyContent: "space-between",
                        children: [(0, l.jsxs)(p.P, {
                            className: "buy-crypto-form__fields",
                            direction: "column",
                            gap: "200",
                            children: [(0, l.jsx)(ep, {
                                fiatAmount: I,
                                setFiatAmount: O,
                                fiatCurrency: C,
                                setFiat: S
                            }), !M || H ? (0, l.jsx)(ev, {
                                token: M,
                                setToken: y,
                                tokenAmount: null == P ? void 0 : P.amountInCryptoAsset,
                                isLoading: B
                            }) : (0, l.jsx)(ey, {
                                token: M,
                                setToken: y,
                                buyQuote: P,
                                isLoading: B
                            })]
                        }), (0, l.jsxs)(p.P, {
                            gap: "100",
                            direction: "column",
                            className: "buy-crypto-form__footer",
                            children: [(0, l.jsx)(N.x, {
                                size: "m",
                                color: "error",
                                textAlign: "center",
                                className: "buy-crypto-form__footer__error",
                                children: V && m(V)
                            }), (0, l.jsxs)(p.P, {
                                gap: "150",
                                direction: "column",
                                children: [(0, l.jsx)(el, {
                                    buyQuote: P,
                                    fiatId: C,
                                    fiatAmount: I,
                                    token: M
                                }), (0, l.jsx)(Q, {
                                    token: K,
                                    indirectToken: H ? void 0 : M,
                                    fiatCurrency: C,
                                    fiatAmount: I,
                                    selectedQuoteId: null == P ? void 0 : P.id,
                                    onQuoteSelected: z
                                })]
                            })]
                        })]
                    })
                };
            var eN = n(11163),
                eb = n(79516),
                e_ = n(63367),
                ej = n(98671);
            let eE = e => {
                let {
                    multiChainContracts: t,
                    className: n
                } = e, {
                    t: o
                } = (0, c.$G)(), {
                    modalHistory: i
                } = (0, A.N)(), a = (0, eN.useRouter)(), r = e => {
                    let t = (0, ej.G)(I.O.embedTrade),
                        n = new URLSearchParams(a.query);
                    n.set(U.H.NETWORK, e), a.push("".concat(t, "?").concat(n.toString())), i.close()
                };
                return (0, l.jsxs)(e_.I, {
                    className: n,
                    children: [(0, l.jsx)(eb.P.Item, {
                        icon: S.T.EXTERNAL_LINK,
                        label: o("flooz-web.trade.flooz-connect-trade.action.trade"),
                        href: "https://flooz.trade",
                        target: "_blank"
                    }), b.si.filter(e => (null == t ? void 0 : t[e]) != null).map(e => (0, l.jsx)(eb.P.Item, {
                        onClick: () => r(e),
                        icon: b.Eu[e].logo,
                        label: o("flooz-web.trade.flooz-connect-trade.action.switch-chain", {
                            chain: b.Eu[e].label
                        })
                    }, e))]
                })
            };
            var eC = n(82580),
                eS = n(5093),
                eA = n(69402),
                eI = n(62047),
                eO = n(9331),
                eR = n(28813),
                eP = n(41513),
                ez = n(83797),
                eF = n(24453);
            let eD = e => {
                let {
                    isSafe: t,
                    label: n,
                    onClick: o
                } = e;
                return (0, l.jsx)(C.z, {
                    className: d()("risk-label", {
                        "risk-label--safe": t,
                        "risk-label--risky": !t
                    }),
                    onClick: o,
                    iconPosition: "right",
                    icon: S.T.INFO,
                    variant: "text",
                    size: "m",
                    children: (0, l.jsxs)(p.P, {
                        gap: "25",
                        direction: "row",
                        alignItems: "center",
                        children: [(0, l.jsx)(eF.g, {
                            isSafe: t,
                            size: "small",
                            showBackground: !1
                        }), (0, l.jsx)(N.x, {
                            fontWeight: "bold",
                            size: "m",
                            children: n
                        })]
                    })
                })
            };
            var eL = n(67203),
                eM = n(194),
                eU = n(58871),
                eH = n(87440),
                eK = n(85945),
                eG = n(51736),
                eW = n(71115),
                eB = n(49261),
                eV = n(99185),
                e$ = n(78010),
                eY = n(24952);
            let eQ = e => {
                var t;
                let {
                    onError: n,
                    onTransactionSigned: o,
                    onTransactionSuccess: i,
                    onTransactionRequest: a
                } = e, r = (0, eK.NL)(), {
                    providerNetwork: l,
                    web3Provider: s,
                    selectedAccount: d
                } = (0, T.Z_)(), {
                    logException: c
                } = (0, eV.I)(), {
                    values: m
                } = (0, eC.u6)(), {
                    address: p
                } = null !== (t = m.fromToken) && void 0 !== t ? t : {}, f = (0, u.useCallback)((e, t) => {
                    let o = eU.CB.getSwapError(t, l),
                        i = eU.CB.parseErrorMessage(t);
                    if (null == n || n(o), o.log) {
                        let n = eU.CB.buildSwapException({
                            functionName: e,
                            error: t
                        });
                        c(n)
                    }
                    let a = {
                        tokenAddress: p,
                        isBuyAnyCrypto: !1,
                        error: o,
                        errorMessage: i
                    };
                    o.id === eB.i.TRANSACTION_REJECTED ? j.k0.emitApproveSignReject(a) : e === eU.IT.APPROVAL_SEND ? j.k0.emitApproveSignError(a) : j.k0.emitApproveError(a)
                }, [n, c, p, l]), {
                    mutate: v
                } = (0, eW.q)({
                    onSuccess: e => {
                        let t = eY.i.formValuesToAllowanceApprovalParams({
                            selectedAccount: d,
                            values: m
                        });
                        t && r.invalidateQueries(e$.a.allowanceApproval(t)), j.k0.emitApproveSuccess({
                            tokenAddress: p,
                            isBuyAnyCrypto: !1
                        }), null == i || i(e.transactionHash)
                    },
                    onError: e => f(eU.IT.APPROVAL_WAIT, e)
                }), {
                    mutate: k
                } = (0, eG.p)({
                    onSuccess: e => {
                        null == o || o(e), j.k0.emitApproveSignSuccess({
                            tokenAddress: p,
                            isBuyAnyCrypto: !1
                        }), v({
                            provider: s,
                            txHash: e,
                            confirmations: 3
                        })
                    },
                    onError: e => f(eU.IT.APPROVAL_SEND, e)
                }), h = (0, u.useCallback)(e => {
                    if (!s || !e) throw Error("sendApproveTransaction: provider or allowance transaction are not defined");
                    null == a || a(), j.k0.emitApproveSignRequest({
                        tokenAddress: p,
                        isBuyAnyCrypto: !1
                    }), k({
                        provider: s,
                        transaction: e
                    })
                }, [s, p, k, a]);
                return {
                    sendApproveTransaction: h
                }
            };
            var eJ = n(21497),
                eq = n(34562),
                eZ = n(3402),
                eX = n(28285),
                e0 = n(25657),
                e1 = n(84085);
            let e5 = e => {
                var t, n, o, i;
                let {
                    isDisabled: a,
                    isRisky: r = !1
                } = e, {
                    t: s
                } = (0, c.$G)(), {
                    values: m,
                    isValid: p,
                    errors: f
                } = (0, eC.u6)(), {
                    selectedAccount: v,
                    providerNetwork: k
                } = (0, T.Z_)(), {
                    isBuyCryptoDisabled: h
                } = (0, eq.E8)(), {
                    modalHistory: x
                } = (0, M.N)(), g = (0, eX.h)(), {
                    allowanceTransaction: y
                } = (0, eH.y)({
                    logError: !1
                }), w = e1.u5.getSwapActionType({
                    fromToken: m.fromToken,
                    toToken: m.toToken
                }), N = (0, u.useMemo)(() => f.fromTokenAmount === e1._W.TOKEN_AMOUNT_INSUFFICIENT_BALANCE ? s("flooz-web.trade.swap-tokens.form.submit.insufficient-balance-error") : p && null != y ? s("flooz-web.trade.swap-tokens.form.submit.approve") : r ? s("flooz-web.trade.swap-tokens.form.submit.swap-risky", {
                    context: w
                }) : s("flooz-web.trade.swap-tokens.form.submit.swap", {
                    context: w
                }), [f, y, p, w, s, r]), _ = (0, u.useCallback)(() => x.push(et._.connect), [x]), j = (0, u.useCallback)(() => {
                    let e = new URLSearchParams([
                        [eZ.ModalSwitchNetworkQueryParams.REQUIRED_CHAIN, m.network]
                    ]);
                    x.push(et._.switchNetwork, e)
                }, [x, m.network]), E = (0, u.useCallback)(() => {
                    let {
                        address: e,
                        network: t
                    } = m.fromToken, n = new URLSearchParams([
                        [e0.u.TO_TOKEN_ADDRESS, e],
                        [e0.u.NETWORK, t],
                        [e0.u.SELECTED_TAB, e0.Bn.ON_RAMP]
                    ]);
                    x.push(I.F.tradeTokens, n)
                }, [x, m.fromToken]), C = v && m.fromTokenAmount && "0" !== m.fromTokenAmount && m.fromToken && !h && (f.fromTokenAmount === e1._W.TOKEN_AMOUNT_INSUFFICIENT_BALANCE || !(null === (t = null === (n = g.map) || void 0 === n ? void 0 : n.get(null !== (i = null === (o = m.fromToken) || void 0 === o ? void 0 : o.network) && void 0 !== i ? i : "")) || void 0 === t ? void 0 : t.has(m.fromToken.address))), S = null != v && (null != m.fromToken || null != m.toToken) && m.network !== k, A = Boolean(a) || !p || !v;
                return (0, l.jsx)(L.P, {
                    gap: "50",
                    className: "swap-tokens-form-submit",
                    children: v ? C ? (0, l.jsx)(z.z, {
                        variant: "primary",
                        size: "xl",
                        onClick: E,
                        children: s("flooz-web.trade.swap-tokens.form.submit.add-cash")
                    }) : S ? (0, l.jsx)(z.z, {
                        variant: "primary",
                        size: "xl",
                        onClick: j,
                        children: s("flooz-web.trade.swap-tokens.form.submit.switch-network", {
                            network: b.Eu[m.network].label
                        })
                    }) : (0, l.jsx)(z.z, {
                        className: d()(r && !A ? "swap-tokens-button--risky" : void 0),
                        variant: "primary",
                        size: "xl",
                        disabled: A,
                        type: "submit",
                        children: N
                    }) : (0, l.jsx)(z.z, {
                        variant: "primary",
                        size: "xl",
                        onClick: _,
                        children: s("flooz-web.trade.swap-tokens.form.submit.connect-wallet")
                    })
                })
            };
            var e4 = n(11116);
            let e2 = e => {
                    var t, n, o, i, a, r, s, m, p, f, v, k, h;
                    let {
                        values: T,
                        setValues: x,
                        className: g
                    } = e, {
                        t: y
                    } = (0, c.$G)(), {
                        modalHistory: w
                    } = (0, A.N)(), {
                        getFromAmount: N
                    } = (0, eS.gI)(), {
                        hideChartLink: b,
                        hideReferLink: _,
                        hideOffRampLink: E,
                        lockToken: C,
                        referrer: S
                    } = (0, eq.E8)(), {
                        swapState: O
                    } = (0, eO.l4)(), R = (0, eO.uF)(), P = (0, u.useCallback)(() => R({
                        type: "reset"
                    }), [R]), z = {
                        disabled: O !== eR.Wh.IDLE,
                        updateFormData: !0,
                        useRefetch: !0
                    }, {
                        isFetchingSwapQuote: F
                    } = (0, eJ.F)(z), {
                        allowanceTransaction: D,
                        isCheckingAllowance: M
                    } = (0, eH.y)({
                        logError: !0
                    }), U = () => {
                        V(), P()
                    }, H = e => {
                        R({
                            type: "transactionError",
                            payload: {
                                error: e
                            }
                        })
                    }, {
                        sendApproveTransaction: K
                    } = eQ({
                        onError: H,
                        onTransactionSuccess: U
                    }), W = (0, u.useCallback)(() => {
                        let e = { ...T,
                            [eU.$M.FROM_TOKEN]: T.toToken,
                            [eU.$M.TO_TOKEN]: T.fromToken,
                            [eU.$M.FROM_TOKEN_AMOUNT]: T.toTokenAmount,
                            [eU.$M.TO_TOKEN_AMOUNT]: T.fromTokenAmount
                        };
                        x(e, !1)
                    }, [T, x]), V = (0, u.useCallback)(() => {
                        w.push(I.F.confirmSwap, void 0, {
                            referrer: S,
                            values: T
                        })
                    }, [w, S, T]), $ = (0, u.useCallback)(e => {
                        if (e.preventDefault(), null != D ? (R({
                                type: "approveToken"
                            }), K(D)) : V(), T.fromToken && T.toToken) {
                            let {
                                fromToken: e,
                                toToken: t
                            } = T, n = eM.S.getTokenAmountInUSD(T.fromTokenAmount, T.fromToken);
                            j.k0.emitQuote({
                                fromToken: e,
                                toToken: t,
                                usdAmount: n
                            })
                        }
                    }, [D, T, R, K, V]), Y = e => null != C && null != e && eT.a.areSameAddress(C, e), Q = (null === (t = T.fromToken) || void 0 === t ? void 0 : t.type) === eA.i.NATIVE, J = {
                        pathParameters: {
                            address: null === (n = T.fromToken) || void 0 === n ? void 0 : n.address,
                            network: null === (o = T.fromToken) || void 0 === o ? void 0 : o.network
                        }
                    }, {
                        data: q
                    } = (0, eI.R)(J, {
                        enabled: !Q && null != T.fromToken
                    }), Z = eL.U.isTokenSafe(null === (i = T.fromToken) || void 0 === i ? void 0 : i.type, null == q ? void 0 : q.risk), X = (null === (a = T.toToken) || void 0 === a ? void 0 : a.type) === eA.i.NATIVE, ee = {
                        pathParameters: {
                            address: null === (r = T.toToken) || void 0 === r ? void 0 : r.address,
                            network: null === (s = T.toToken) || void 0 === s ? void 0 : s.network
                        }
                    }, {
                        data: et
                    } = (0, eI.R)(ee, {
                        enabled: !X && null != T.toToken
                    }), en = eL.U.isTokenSafe(null === (m = T.toToken) || void 0 === m ? void 0 : m.type, null == et ? void 0 : et.risk), eo = !1 === Z || !1 === en, ei = () => {
                        let e = [];
                        return Q || e.push(T.fromToken), X || e.push(T.toToken), e
                    }, ea = () => {
                        w.push(G.a.tokenSecurity, void 0, {
                            tokens: ei()
                        })
                    };
                    return (0, l.jsx)(eC.l0, {
                        onSubmit: $,
                        className: d()("swap-tokens-form", g),
                        children: (0, l.jsxs)(L.P, {
                            gap: "150",
                            justifyContent: "space-between",
                            grow: "1",
                            children: [(0, l.jsx)(L.P, {
                                gap: "200",
                                className: "swap-tokens-form__layout",
                                children: (0, l.jsxs)(L.P, {
                                    gap: "0",
                                    className: "swap-tokens-form__token-pair",
                                    children: [!0 == (!0 === Z && !0 === en) && (0, l.jsx)(eD, {
                                        isSafe: !0,
                                        label: y("flooz-web.trade.swap-tokens.form.tokens-are-safe"),
                                        onClick: ea
                                    }), !0 === eo && (0, l.jsx)(eD, {
                                        isSafe: !1,
                                        label: y("flooz-web.trade.swap-tokens.form.tokens-are-risky"),
                                        onClick: ea
                                    }), (0, l.jsx)(e4.R, {
                                        name: eU.$M.FROM_TOKEN,
                                        onSwitchTokens: W,
                                        isTokenReadonly: Y(null === (p = T.fromToken) || void 0 === p ? void 0 : p.address),
                                        isLoading: (F || M) && N
                                    }), (0, l.jsx)("div", {
                                        className: "swap-tokens-form__switch",
                                        children: (0, l.jsx)(eP.Fm, {
                                            onClick: W,
                                            animationParams: {
                                                animation: ez.r.SWITCH,
                                                speed: 2,
                                                playOnClick: !0
                                            }
                                        })
                                    }), (0, l.jsx)(e4.R, {
                                        name: eU.$M.TO_TOKEN,
                                        onSwitchTokens: W,
                                        isTokenReadonly: Y(null === (f = T.toToken) || void 0 === f ? void 0 : f.address),
                                        isLoading: (F || M) && !N
                                    })]
                                })
                            }), (0, l.jsxs)(L.P, {
                                direction: "column",
                                gap: "150",
                                children: [(0, l.jsx)(e5, {
                                    isDisabled: F || M,
                                    isRisky: eo
                                }), (0, l.jsx)(B, {
                                    displayChartLink: !b,
                                    displayReferLink: !_,
                                    displayOffRampLink: !E,
                                    tokenAddress: null !== (h = null != C ? C : null === (v = T.toToken) || void 0 === v ? void 0 : v.address) && void 0 !== h ? h : null === (k = T.fromToken) || void 0 === k ? void 0 : k.address,
                                    tokenNetwork: T.network,
                                    referrer: S
                                })]
                            })]
                        })
                    })
                },
                e9 = e => {
                    let {
                        initialValues: t,
                        className: n
                    } = e, [o, i] = (0, u.useState)((null == t ? void 0 : t.fromTokenAmount) == null), [a, r] = (0, u.useState)(e1.u5.getSwapTokensInitialValues(t));
                    (0, u.useEffect)(() => {
                        r(e => {
                            var n, o;
                            let {
                                fromToken: i,
                                toToken: a
                            } = e, r = eT.a.areSameAddress(null == i ? void 0 : i.address, null == t ? void 0 : null === (n = t.fromToken) || void 0 === n ? void 0 : n.address), l = eT.a.areSameAddress(null == a ? void 0 : a.address, null == t ? void 0 : null === (o = t.toToken) || void 0 === o ? void 0 : o.address);
                            return r && l ? e : e1.u5.getSwapTokensInitialValues(t)
                        })
                    }, [t]);
                    let s = (0, u.useMemo)(() => e1.u5.getSwapTokensInitialErrors(a), [a]),
                        d = (0, u.useMemo)(() => ({
                            getFromAmount: o,
                            setGetFromAmount: i
                        }), [o]);
                    return (0, l.jsx)(eC.J9, {
                        onSubmit: () => void 0,
                        initialValues: a,
                        initialErrors: s,
                        enableReinitialize: !0,
                        children: e => (0, l.jsx)(eS.qO, {
                            value: d,
                            children: (0, l.jsx)(e2, {
                                className: n,
                                ...e
                            })
                        })
                    })
                };
            (i = r || (r = {})).SWAP = "SWAP", i.ON_RAMP = "ON_RAMP";
            let e8 = [{
                    id: r.SWAP,
                    label: "flooz-web.trade.trade-tokens.swap-title",
                    priority: 100
                }, {
                    id: r.ON_RAMP,
                    label: "flooz-web.trade.trade-tokens.on-ramp-title",
                    priority: 100
                }],
                e7 = e => {
                    let {
                        initialSelectedTab: t,
                        swapDisabled: n,
                        onRampDisabled: o,
                        renderFloozConnect: i,
                        buyCryptoParams: a,
                        swapTokensParams: s,
                        className: v
                    } = e, {
                        t: k
                    } = (0, c.$G)(), [h, T] = (0, u.useState)(t !== r.ON_RAMP || o ? r.SWAP : r.ON_RAMP), x = (0, u.useCallback)(e => T(e), []), g = !n && !o, {
                        initialValues: N,
                        swapTokensContext: b
                    } = (0, w.s)(s), {
                        tokenToBuy: _,
                        buyCryptoContext: j
                    } = y(a);
                    return (0, u.useEffect)(() => {
                        let {
                            ON_RAMP: e,
                            SWAP: n
                        } = r;
                        T(t !== e || o ? n : e)
                    }, [o, t]), (0, l.jsxs)(f.m.Container, {
                        selectedTabId: h,
                        onTabSelected: x,
                        useCustomNav: !0,
                        className: d()("trade-tokens", {
                            "trade-tokens--with-nav": g
                        }, v),
                        tabEntries: e8,
                        children: [(0, l.jsxs)(p.P, {
                            gap: "200",
                            direction: "row",
                            justifyContent: "space-between",
                            alignItems: "center",
                            children: [g ? (0, l.jsx)(f.m.Nav, {
                                onTabSelected: x,
                                className: "trade-tokens__tabs-nav"
                            }) : (0, l.jsx)(m.X, {
                                size: "h5",
                                className: "trade-tokens__heading",
                                children: k("flooz-web.trade.trade-tokens.".concat(!n || n && o ? "swap" : "on-ramp", "-title"))
                            }), i && (0, l.jsx)(eE, {
                                multiChainContracts: null == s ? void 0 : s.multiChainContracts
                            })]
                        }), (0, l.jsx)(f.m.Tab, {
                            id: r.SWAP,
                            children: (0, l.jsx)(eq.Wn, {
                                value: b,
                                children: (0, l.jsx)(e9, {
                                    initialValues: N,
                                    className: "trade-tokens__form"
                                })
                            })
                        }), (0, l.jsx)(f.m.Tab, {
                            id: r.ON_RAMP,
                            children: (0, l.jsx)($, {
                                value: j,
                                children: (0, l.jsx)(ew, {
                                    initialToken: _,
                                    className: "trade-tokens__form"
                                })
                            })
                        })]
                    })
                }
        },
        18819: function(e, t, n) {
            n.d(t, {
                w: function() {
                    return a
                }
            });
            var o = n(95263),
                i = n(65864);
            let a = {
                [o.Y.USD]: {
                    id: o.Y.USD,
                    icon: i.T.FIAT_USD,
                    symbol: "$"
                },
                [o.Y.EUR]: {
                    id: o.Y.EUR,
                    icon: i.T.FIAT_EUR,
                    symbol: "€"
                },
                [o.Y.GBP]: {
                    id: o.Y.GBP,
                    icon: i.T.FIAT_GBP,
                    symbol: "\xa3"
                },
                [o.Y.NGN]: {
                    id: o.Y.NGN,
                    icon: i.T.FIAT_NGN,
                    symbol: "₦"
                }
            }
        },
        31382: function(e, t, n) {
            n.d(t, {
                p: function() {
                    return a
                }
            });
            var o = n(99740),
                i = n(56352);
            let a = new class {
                constructor() {
                    this.getTokenToBuy = e => {
                        var t, n, i;
                        let {
                            token: a,
                            providerNetwork: r,
                            networkParam: l,
                            defaultNetwork: s = o.cU.BINANCE_MAINNET
                        } = e, d = null !== (i = null !== (n = null !== (t = null == a ? void 0 : a.network) && void 0 !== t ? t : l) && void 0 !== n ? n : r) && void 0 !== i ? i : s, c = o.Eu[d].nativeCurrency.address, u = null != a ? a.address : c;
                        return {
                            address: u,
                            network: d
                        }
                    }, this.appendUserEmailToBuyUrl = e => {
                        let {
                            rampProviderId: t,
                            buyUrl: n,
                            email: o
                        } = e, a = i.Q[t];
                        if (null == a || !a.emailFieldName) return n; {
                            var r;
                            let e = new URL(n);
                            return e.searchParams.set(null !== (r = a.emailFieldName) && void 0 !== r ? r : "", o), e.toString()
                        }
                    }
                }
            }
        },
        71115: function(e, t, n) {
            n.d(t, {
                q: function() {
                    return a
                }
            });
            var o = n(48228),
                i = n(2948);
            let a = e => (0, o.D)(e => i.x.waitTransaction(e), e)
        },
        44868: function(e, t, n) {
            var o, i;
            n.d(t, {
                H: function() {
                    return o
                }
            }), (i = o || (o = {})).ONE_DAY = "1d", i.ONE_WEEK = "1w", i.ONE_MONTH = "1m", i.ONE_YEAR = "1y", i.ALL = "all"
        },
        95263: function(e, t, n) {
            var o, i;
            n.d(t, {
                Y: function() {
                    return o
                }
            }), (i = o || (o = {})).USD = "USD", i.EUR = "EUR", i.GBP = "GBP", i.NGN = "NGN"
        },
        88956: function(e, t, n) {
            n.d(t, {
                p: function() {
                    return l
                }
            });
            var o = n(85945),
                i = n(48228),
                a = n(46223),
                r = n(19069);
            let l = e => {
                let t = (0, o.NL)();
                return (0, i.D)(e => a.W4.saveOnRampTransaction(e), { ...e,
                    onSuccess: (n, o, i) => {
                        var a;
                        t.invalidateQueries([r.b.ON_RAMP_ACTIVITIES]), t.removeQueries([r.b.ON_RAMP_QUOTE_LIST]), null == e || null === (a = e.onSuccess) || void 0 === a || a.call(e, n, o, i)
                    }
                })
            }
        },
        92738: function(e, t, n) {
            n.d(t, {
                G: function() {
                    return r
                }
            });
            var o = n(59403),
                i = n(46223),
                a = n(19069);
            let r = (e, t) => (0, o.N)(a.a.activities(e), t => {
                let {
                    pageParam: n
                } = t;
                return i.W4.getActivities({ ...e,
                    ...n
                })
            }, { ...t,
                getNextPageParam: i.W4.getReactQueryCursorPaginatedParams(e)
            })
        },
        45837: function(e, t, n) {
            n.d(t, {
                t: function() {
                    return r
                }
            });
            var o = n(36492),
                i = n(46223),
                a = n(19069);
            let r = (e, t) => (0, o.a)(a.a.referralId(e), () => i.W4.generateReferralId(e), t)
        },
        51401: function(e, t, n) {
            n.d(t, {
                I: function() {
                    return r
                }
            });
            var o = n(36492),
                i = n(46223),
                a = n(19069);
            let r = (e, t) => (0, o.a)(a.a.tokenPriceInfo(e), () => i.W4.getTokenPriceInfo(e), t)
        },
        62047: function(e, t, n) {
            n.d(t, {
                R: function() {
                    return r
                }
            });
            var o = n(36492),
                i = n(46223),
                a = n(19069);
            let r = (e, t) => (0, o.a)(a.a.tokenSecurity(e), () => i.W4.getTokenSecurityInfo(e), t)
        },
        33985: function(e, t, n) {
            n.d(t, {
                R: function() {
                    return u
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i),
                r = n(9264),
                l = n(67294),
                s = n(77902),
                d = n(65522);
            let c = new class {
                    constructor() {
                        this.minHeightProperty = "--sya-collapsible-text-min-height", this.shouldDisplayMoreButton = e => {
                            var t;
                            if (null == e) return !1;
                            let n = getComputedStyle(e).getPropertyValue(this.minHeightProperty).trim(),
                                o = Number(n.replace(/px\s*$/, "")),
                                i = null !== (t = null == e ? void 0 : e.clientHeight) && void 0 !== t ? t : 0;
                            return i > o
                        }
                    }
                },
                u = e => {
                    let {
                        className: t,
                        children: n
                    } = e, {
                        t: i
                    } = (0, r.$G)(), [u, m] = (0, l.useState)(!0), p = () => m(e => !e), [f, v] = (0, l.useState)(!1), k = l.useRef(null);
                    (0, l.useEffect)(() => {
                        v(c.shouldDisplayMoreButton(k.current))
                    }, []);
                    let h = i(u ? "flooz-web.shared.collapsible-text.more" : "flooz-web.shared.collapsible-text.less");
                    return f ? (0, o.jsxs)("div", {
                        className: a()("collapsible-text", t),
                        children: [(0, o.jsx)(d.z, {
                            isCollapsed: u,
                            keepElementInView: !0,
                            children: (0, o.jsx)("div", {
                                ref: k,
                                "data-testid": "children",
                                children: n
                            })
                        }), (0, o.jsx)(s.z, {
                            className: "collapsible-text__trigger",
                            variant: "text",
                            size: "m",
                            onClick: p,
                            children: h
                        })]
                    }) : (0, o.jsx)("div", {
                        ref: k,
                        children: n
                    })
                }
        },
        65522: function(e, t, n) {
            n.d(t, {
                z: function() {
                    return s
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i),
                r = n(1004);
            n(67294);
            let l = (e, t) => ({
                    expanded: {
                        height: "auto",
                        opacity: e ? 1 : void 0,
                        zIndex: 10,
                        display: "block"
                    },
                    collapsed: {
                        height: "var(--sya-collapsible-collapsed-height)",
                        opacity: e ? 0 : void 0,
                        zIndex: "auto",
                        overflow: "hidden",
                        transitionEnd: t ? void 0 : {
                            display: "none"
                        }
                    }
                }),
                s = e => {
                    let {
                        isCollapsed: t,
                        animateOpacity: n,
                        keepElementInView: i,
                        className: s,
                        children: d,
                        ...c
                    } = e;
                    return (0, o.jsx)(r.E.div, {
                        className: a()("collapsible", s),
                        initial: t ? "collapsed" : "expanded",
                        animate: t ? "collapsed" : "expanded",
                        variants: l(n, i),
                        transition: {
                            type: "spring",
                            damping: 20,
                            stiffness: 200
                        },
                        "aria-hidden": !i && t,
                        ...c,
                        children: d
                    })
                }
        },
        17139: function(e, t, n) {
            n.d(t, {
                S: function() {
                    return c
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i);
            n(67294);
            var r = n(76409),
                l = n(77902),
                s = n(33715),
                d = n(51275);
            let c = e => {
                let {
                    copyValue: t,
                    onValueCopied: n,
                    className: i,
                    contentClassName: c,
                    children: u
                } = e, m = async () => {
                    await r.C.copyValue({
                        value: t,
                        inputTargetSelector: ".copy-value"
                    }), d.F.notificationCopy(), null == n || n()
                };
                return (0, o.jsx)(l.z, {
                    variant: "text",
                    className: a()("copy-value", i),
                    onClick: m,
                    icon: s.T.COPY,
                    iconPosition: "right",
                    size: "m",
                    contentClassName: c,
                    children: u
                })
            }
        },
        68730: function(e, t, n) {
            n.d(t, {
                S: function() {
                    return o.S
                }
            });
            var o = n(17139)
        },
        25337: function(e, t, n) {
            n.d(t, {
                s: function() {
                    return r
                },
                v: function() {
                    return a
                }
            });
            var o = n(30120),
                i = n(44868);
            let a = {
                    [i.H.ONE_DAY]: {
                        from: o.ou.now().minus({
                            day: 1
                        }),
                        to: o.ou.now().endOf("day"),
                        key: i.H.ONE_DAY
                    },
                    [i.H.ONE_WEEK]: {
                        from: o.ou.now().minus({
                            days: 7
                        }).startOf("day"),
                        to: o.ou.now().endOf("day"),
                        key: i.H.ONE_WEEK
                    },
                    [i.H.ONE_MONTH]: {
                        from: o.ou.now().minus({
                            days: 30
                        }).startOf("day"),
                        to: o.ou.now().endOf("day"),
                        key: i.H.ONE_MONTH
                    },
                    [i.H.ONE_YEAR]: {
                        from: o.ou.now().minus({
                            years: 1
                        }),
                        to: o.ou.now().endOf("day"),
                        key: i.H.ONE_YEAR
                    },
                    [i.H.ALL]: {
                        from: o.ou.now().minus({
                            years: 5
                        }),
                        to: o.ou.now().plus({
                            years: 5
                        }),
                        key: i.H.ALL
                    }
                },
                r = a[i.H.ONE_DAY]
        },
        89154: function(e, t, n) {
            n.d(t, {
                F: function() {
                    return u
                },
                v: function() {
                    return c.v
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i),
                r = n(9264),
                l = n(67294),
                s = n(47885),
                d = n(11217),
                c = n(25337);
            let u = e => {
                let {
                    supportedDateRanges: t,
                    currentDateRange: n,
                    onDateRangeChange: i,
                    className: u
                } = e, {
                    t: m
                } = (0, r.$G)(), p = (0, l.useCallback)(e => null == t ? void 0 : t.includes(e), [t]), f = e => !p(e), v = e => e === (null == n ? void 0 : n.key), k = e => !v(e) && p(e);
                return (0, o.jsx)(s.P, {
                    className: a()("date-range-selection", u),
                    direction: "row",
                    gap: "50",
                    children: Object.keys(c.v).map(e => (0, o.jsxs)(l.Fragment, {
                        children: [v(e) && (0, o.jsx)("button", {
                            className: a()("date-range-selection__date", "date-range-selection__date--selected"),
                            children: m("flooz-web.shared.date-range-selection.".concat(e))
                        }), k(e) && (0, o.jsx)("button", {
                            onClick: () => i(c.v[e]),
                            className: a()("date-range-selection__date", "date-range-selection__date--enabled"),
                            children: m("flooz-web.shared.date-range-selection.".concat(e))
                        }), f(e) && (0, o.jsx)(d.u, {
                            tooltipContent: m("flooz-web.shared.date-range-selection.disabled-info"),
                            placement: "bottom",
                            mouseOnly: !1,
                            className: "date-range-selection__tooltip",
                            children: (0, o.jsx)("button", {
                                className: a()("date-range-selection__date", "date-range-selection__date--disabled"),
                                children: m("flooz-web.shared.date-range-selection.".concat(e))
                            })
                        }, e)]
                    }, e))
                })
            }
        },
        35613: function(e, t, n) {
            n.d(t, {
                w: function() {
                    return d
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i);
            let r = e => {
                let {
                    direction: t = "row",
                    children: n,
                    sRow: i,
                    className: r
                } = e;
                return (0, o.jsx)("div", {
                    className: a()("description-grid", "description-grid--direction-".concat(t), {
                        "description-grid--direction-row-s": i
                    }, r),
                    children: n
                })
            };
            n(67294);
            var l = n(55642);
            let s = e => {
                    let {
                        label: t,
                        value: n,
                        isLoading: i,
                        className: r
                    } = e;
                    return (0, o.jsxs)("div", {
                        className: a()("description-grid-item", r),
                        children: [(0, o.jsx)("span", {
                            className: "description-grid-item__label",
                            children: t
                        }), (0, o.jsx)("span", {
                            className: "description-grid-item__value",
                            children: i ? (0, o.jsx)(l.g, {}) : n
                        })]
                    })
                },
                d = {
                    Container: r,
                    Item: s
                }
        },
        34346: function(e, t, n) {
            n.d(t, {
                B: function() {
                    return o.B
                }
            });
            var o = n(62351)
        },
        62351: function(e, t, n) {
            n.d(t, {
                B: function() {
                    return l
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i);
            n(67294);
            var r = n(47885);
            let l = e => {
                let {
                    className: t,
                    readOnly: n,
                    children: i,
                    gap: l
                } = e;
                return (0, o.jsx)(r.P, {
                    direction: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: null != l ? l : "100",
                    className: a()("input-group", {
                        "input-group--readonly": n
                    }, t),
                    children: i
                })
            }
        },
        83797: function(e, t, n) {
            var o, i;
            n.d(t, {
                r: function() {
                    return o
                }
            }), (i = o || (o = {})).ERROR = "ERROR", i.LOADING = "LOADING", i.SPINNER = "SPINNER", i.SUCCESS = "SUCCESS", i.SWITCH = "SWITCH", i.VERIFIED_TOKEN = "VERIFIED_TOKEN"
        },
        41513: function(e, t, n) {
            n.d(t, {
                Fm: function() {
                    return i.F
                },
                ru: function() {
                    return o.r
                }
            });
            var o = n(83797),
                i = n(53800);
            n(11926)
        },
        53800: function(e, t, n) {
            n.d(t, {
                F: function() {
                    return s
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i),
                r = n(67294),
                l = n(11926);
            let s = e => {
                let {
                    animationParams: t,
                    className: n,
                    onClick: i,
                    ...s
                } = e, [d, c] = (0, r.useState)(null), {
                    playAnimation: u
                } = (0, l.x)({
                    container: d,
                    ...t
                }), m = (0, r.useCallback)(e => {
                    t.playOnClick && u(), null == i || i(e)
                }, [t.playOnClick, u, i]);
                return (0, o.jsx)("div", {
                    className: a()("lottie-animation", n),
                    ref: c,
                    onClick: m,
                    ...s
                })
            }
        },
        11926: function(e, t, n) {
            n.d(t, {
                x: function() {
                    return s
                }
            });
            var o = n(98234),
                i = n.n(o),
                a = n(67294),
                r = n(83797);
            let l = {
                    [r.r.ERROR]: "/assets/lottie/error.json",
                    [r.r.LOADING]: "/assets/lottie/loading.json",
                    [r.r.SPINNER]: "/assets/lottie/spinner.json",
                    [r.r.SUCCESS]: "/assets/lottie/success.json",
                    [r.r.SWITCH]: "/assets/lottie/switch.json",
                    [r.r.VERIFIED_TOKEN]: "/assets/lottie/verified-token.json"
                },
                s = e => {
                    let {
                        container: t,
                        loopsOnMount: n,
                        speed: o,
                        animation: r,
                        ...s
                    } = e, d = (0, a.useRef)(s), c = (0, a.useRef)(o), [u, m] = (0, a.useState)(), p = (0, a.useCallback)(e => {
                        e ? null == u || u.playSegments([0, e], !0) : null == u || u.goToAndPlay(0, !0)
                    }, [u]), f = (0, a.useCallback)(() => {
                        null == u || u.goToAndStop(0)
                    }, [u]);
                    return (0, a.useEffect)(() => {
                        if (!t) return;
                        let e = 0,
                            o = i().loadAnimation({
                                container: t,
                                renderer: "svg",
                                loop: !1,
                                autoplay: !1,
                                path: l[r],
                                ...d.current
                            });
                        return m(o), c.current && (null == o || o.setSpeed(c.current)), n && (e++, o.goToAndPlay(0, !0)), o.addEventListener("complete", () => {
                            n && e < n && (e++, o.goToAndPlay(0, !0))
                        }), () => {
                            o.destroy()
                        }
                    }, [r, t, n]), {
                        playAnimation: p,
                        resetAnimation: f,
                        animationItem: u
                    }
                }
        },
        24453: function(e, t, n) {
            n.d(t, {
                g: function() {
                    return o.g
                }
            });
            var o = n(16257)
        },
        16257: function(e, t, n) {
            n.d(t, {
                g: function() {
                    return d
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i);
            n(67294);
            var r = n(77902),
                l = n(33715),
                s = n(47885);
            let d = e => {
                let {
                    isSafe: t,
                    size: n,
                    showBackground: i,
                    onClick: d
                } = e, c = () => (0, o.jsx)(s.P, {
                    direction: "row",
                    alignItems: "center",
                    gap: "0",
                    children: (0, o.jsx)(l.J, {
                        className: a()("risk-badge", {
                            "risk-badge--small": "small" === n,
                            "risk-badge--large": "large" === n,
                            "risk-badge--with-background": !0 === i,
                            "risk-badge--safe": t,
                            "risk-badge--risky": !t
                        }),
                        icon: t ? l.T.SECURITY_SAFE : l.T.SECURITY_RISKY
                    })
                });
                return d ? (0, o.jsx)(r.z, {
                    onClick: d,
                    variant: "text",
                    size: "s",
                    children: c()
                }) : c()
            }
        },
        85795: function(e, t, n) {
            n.d(t, {
                v: function() {
                    return c
                }
            });
            var o = n(85893),
                i = n(94184),
                a = n.n(i),
                r = n(67294),
                l = n(47885),
                s = n(96942);
            let d = e => {
                    let {
                        activeStepIndex: t,
                        loadingStepIndex: n,
                        isHorizontal: i,
                        children: d,
                        className: c
                    } = e, {
                        COMPLETED: u,
                        IDLE: m,
                        ACTIVE: p,
                        LOADING: f
                    } = s.x;
                    return (0, o.jsx)(l.P, {
                        className: a()("stepper-container", c),
                        gap: "0",
                        alignItems: "start",
                        direction: i ? "row" : "column",
                        children: d.map((e, a) => {
                            let {
                                className: l,
                                ...s
                            } = e.props;
                            return (0, o.jsx)(r.Fragment, {
                                children: r.cloneElement(e, {
                                    index: a,
                                    status: a === t ? p : a < (null != t ? t : 0) ? u : a === n ? f : m,
                                    isLast: a === d.length - 1,
                                    isHorizontal: i,
                                    ...s
                                })
                            }, a)
                        })
                    })
                },
                c = {
                    Container: d,
                    Step: s.q
                }
        },
        96942: function(e, t, n) {
            n.d(t, {
                q: function() {
                    return u
                },
                x: function() {
                    return i
                }
            });
            var o, i, a = n(85893),
                r = n(94184),
                l = n.n(r),
                s = n(90544),
                d = n(33715),
                c = n(47885);
            (o = i || (i = {})).IDLE = "IDLE", o.ACTIVE = "ACTIVE", o.LOADING = "LOADING", o.COMPLETED = "COMPLETED", o.PENDING = "PENDING";
            let u = e => {
                let {
                    index: t,
                    status: n,
                    isLast: o,
                    isHorizontal: r,
                    children: u,
                    className: m,
                    onClick: p
                } = e, {
                    ACTIVE: f,
                    IDLE: v,
                    LOADING: k,
                    PENDING: h
                } = i;
                (0, s.k)(null != t, "Stepper.Step: component must be placed inside a Stepper.Container component to work properly");
                let T = n === k ? d.T.LOADING : d.T.CHECK;
                return (0, a.jsxs)(c.P, {
                    gap: "0",
                    direction: "column",
                    grow: "1",
                    shrink: "1",
                    alignItems: r ? "center" : "start",
                    className: l()("stepper-step", {
                        "stepper-step--active": n === f
                    }, {
                        "stepper-step--last": o
                    }, {
                        "stepper-step--horizontal": r
                    }, {
                        "stepper-step--clickable": null != p
                    }, m),
                    onClick: p,
                    children: [(0, a.jsxs)(c.P, {
                        gap: "50",
                        direction: r ? "column" : "row",
                        alignItems: r ? "center" : "baseline",
                        shrink: "1",
                        children: [n === h ? (0, a.jsx)(d.J, {
                            icon: d.T.SPINNER,
                            className: "stepper-step__spinner"
                        }) : n === f || n === v ? (0, a.jsx)("div", {
                            className: "stepper-step__index"
                        }) : (0, a.jsx)(d.J, {
                            className: l()("stepper-step__icon", "stepper-step__icon--".concat(T)),
                            icon: T
                        }), u]
                    }), !o && (0, a.jsx)("div", {
                        className: "stepper-step__separator"
                    })]
                })
            }
        },
        58565: function(e, t, n) {
            n.d(t, {
                $: function() {
                    return l
                }
            });
            var o = n(85893);
            n(67294);
            var i = n(9781),
                a = n(26315),
                r = n(19523);
            let l = e => {
                let {
                    value: t = ""
                } = e;
                return (0, o.jsx)(i.D, {
                    linkTarget: "_blank",
                    rehypePlugins: [a.Z, r.Z],
                    className: "string-parser",
                    children: t
                })
            }
        }
    }
]);