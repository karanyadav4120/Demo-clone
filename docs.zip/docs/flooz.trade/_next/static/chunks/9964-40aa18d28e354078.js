"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9964, 3402], {
        38138: function(e, t, n) {
            var r, o;
            n.d(t, {
                R: function() {
                    return r
                }
            }), (o = r || (r = {})).UNISWAP_V2 = "UNISWAP_V2", o.UNISWAP_V3 = "UNISWAP_V3", o.ERC_20 = "ERC_20", o.ERC_721 = "ERC_721", o.ERC_1155 = "ERC_1155", o.NATIVE = "NATIVE", o.OPENSEA = "OPENSEA", o.LOOKSRARE = "LOOKSRARE", o.GEMSWAP = "GEMSWAP", o.FLOOZ_MULTICHAIN_ROUTER = "FLOOZ_MULTICHAIN_ROUTER", o.UNKNOWN = "UNKNOWN"
        },
        17367: function(e, t, n) {
            var r, o;
            n.d(t, {
                f: function() {
                    return r
                }
            }), (o = r || (r = {})).LOW = "LOW", o.MEDIUM = "MEDIUM", o.HIGH = "HIGH"
        },
        75877: function(e, t, n) {
            n.d(t, {
                F: function() {
                    return l
                }
            });
            var r = n(36492),
                o = n(78010),
                a = n(6916);
            let l = (e, t) => (0, r.a)(o.a.swapQuote(e), () => a.J.getSwapQuote(e), t)
        },
        78010: function(e, t, n) {
            var r, o;
            n.d(t, {
                a: function() {
                    return a
                }
            }), (o = r || (r = {})).ALLOWANCE_APPROVAL = "TRADE_FLOOZ_API_ALLOWANCE_APPROVAL", o.CREATE = "TRADE_FLOOZ_API_CREATE", o.SWAP_QUOTE = "TRADE_FLOOZ_API_SWAP_QUOTE", o.CREATE_SWAP_TRANSACTION = "TRADE_FLOOZ_API_CREATE_SWAP_TRANSACTION", o.GAS_PRICES = "TRADE_FLOOZ_API_GAS_PRICES";
            let a = {
                allowanceApproval: e => [r.ALLOWANCE_APPROVAL, e],
                create: e => [r.CREATE, e],
                swapQuote: e => [r.SWAP_QUOTE, e],
                createSwapTransaction: e => [r.CREATE_SWAP_TRANSACTION, e],
                gasPrices: e => [r.GAS_PRICES, e]
            }
        },
        6916: function(e, t, n) {
            n.d(t, {
                J: function() {
                    return i
                }
            });
            var r, o, a = n(46223);
            (r = o || (o = {})).ALLOWANCE_APPROVAL = "/allowanceApproval", r.CREATE = "/create", r.CREATE_SWAP = "/create/swap", r.SWAP_QUOTE = "/create/swap/quote", r.GAS_PRICES = "/gasPrices";
            class l extends a.gN {
                constructor() {
                    super({
                        context: "/transactions"
                    }), this.getAllowanceApproval = async e => {
                        let {
                            body: t
                        } = e, {
                            data: n
                        } = await this.http.post(o.ALLOWANCE_APPROVAL, t);
                        return n
                    }, this.createTransaction = async e => {
                        let {
                            body: t
                        } = e, {
                            data: n
                        } = await this.safePost(o.CREATE, t);
                        return n
                    }, this.getSwapQuote = async e => {
                        let {
                            body: t
                        } = e, {
                            data: n
                        } = await this.http.post(o.SWAP_QUOTE, t);
                        return n.data
                    }, this.createSwapTransaction = async e => {
                        let {
                            body: t
                        } = e, {
                            data: n
                        } = await this.safePost(o.CREATE_SWAP, t);
                        return n
                    }, this.getGasPrices = async e => {
                        let {
                            queryParameters: t
                        } = e, {
                            data: n
                        } = await this.http.get(o.GAS_PRICES, {
                            params: t
                        });
                        return n
                    }
                }
            }
            let i = new l
        },
        87440: function(e, t, n) {
            n.d(t, {
                y: function() {
                    return E
                }
            });
            var r = n(82580),
                o = n(48791),
                a = n(99185),
                l = n(36492),
                i = n(78010),
                u = n(6916);
            let s = (e, t) => (0, l.a)(i.a.allowanceApproval(e), () => u.J.getAllowanceApproval(e), t),
                d = (e, t) => (0, l.a)(i.a.create(e), () => u.J.createTransaction(e), t);
            var A = n(58871),
                c = n(84085),
                T = n(24952);
            let E = e => {
                let {
                    logError: t
                } = e, {
                    selectedAccount: n
                } = (0, o.Z_)(), {
                    logException: l
                } = (0, a.I)(), {
                    values: i
                } = (0, r.u6)(), {
                    fromToken: u,
                    toToken: E
                } = i, N = c.u5.getSwapActionType({
                    fromToken: u,
                    toToken: E
                }), _ = e => {
                    let n = A.IT.APPROVAL_CHECK,
                        r = A.CB.buildSwapException({
                            functionName: n,
                            error: e,
                            formValues: {
                                fromToken: u
                            }
                        });
                    t && l(r)
                }, f = T.i.formValuesToAllowanceApprovalParams({
                    selectedAccount: n,
                    values: i
                }), {
                    data: O,
                    isFetching: m
                } = s(f, {
                    enabled: null != f,
                    onError: _
                }), v = N === c._k.SWAP && null != O && O.length > 0, R = T.i.formValuesToBuildAllowanceTxParams({
                    selectedAccount: n,
                    values: i
                }), {
                    data: P,
                    isFetching: S
                } = d(R, {
                    enabled: v && null != R,
                    onError: _
                }), I = v ? null == P ? void 0 : P.transaction : void 0;
                return {
                    allowanceTransaction: I,
                    isCheckingAllowance: m || S
                }
            }
        },
        21497: function(e, t, n) {
            n.d(t, {
                F: function() {
                    return T
                }
            });
            var r = n(82580),
                o = n(67294),
                a = n(48791),
                l = n(31821),
                i = n(99185),
                u = n(49981),
                s = n(75877),
                d = n(58871),
                A = n(5093),
                c = n(24952);
            let T = e => {
                let {
                    useRefetch: t,
                    disabled: n,
                    updateFormData: T
                } = e, {
                    values: E,
                    setFieldValue: N,
                    validateField: _
                } = (0, r.u6)(), {
                    selectedAccount: f
                } = (0, a.Z_)(), {
                    logException: O
                } = (0, i.I)(), {
                    getFromAmount: m
                } = (0, A.gI)(), v = e => {
                    if (!T) return;
                    let t = d.IT.GET_QUOTE,
                        n = d.CB.buildSwapException({
                            functionName: t,
                            formValues: E,
                            error: e
                        });
                    O(n)
                }, R = c.i.formValuesToSwapQuoteParams({
                    selectedAccount: f,
                    values: E,
                    getFromAmount: m
                }), P = (0, l.N)(R, 500), {
                    data: S,
                    isFetching: I
                } = (0, s.F)(P, {
                    enabled: null != P && !Boolean(n),
                    onError: v,
                    refetchInterval: t ? 1e4 : void 0,
                    retry: t ? 3 : void 0
                });
                return (0, o.useEffect)(() => {
                    if (!R && T) {
                        let e = m ? d.$M.FROM_TOKEN_AMOUNT : d.$M.TO_TOKEN_AMOUNT;
                        N(e, void 0)
                    }
                }, [R, N, m, T]), (0, o.useEffect)(() => {
                    let e = m ? d.$M.FROM_TOKEN_AMOUNT : d.$M.TO_TOKEN_AMOUNT,
                        t = m ? E.fromToken : E.toToken;
                    if (S && T) {
                        let n = u.a.fromBaseUnit(S.amount, null == t ? void 0 : t.decimals);
                        N(e, n), setTimeout(() => _(e))
                    }
                }, [S, E.fromToken, E.toToken, m, N, _, T]), {
                    isFetchingSwapQuote: I,
                    swapQuote: S
                }
            }
        },
        5093: function(e, t, n) {
            n.d(t, {
                gI: function() {
                    return l
                },
                qO: function() {
                    return a
                }
            });
            var r = n(67294);
            let o = (0, r.createContext)(void 0),
                a = o.Provider,
                l = () => {
                    let e = (0, r.useContext)(o);
                    return null != e ? e : {}
                }
        },
        34562: function(e, t, n) {
            n.d(t, {
                E8: function() {
                    return l
                },
                Wn: function() {
                    return a
                }
            });
            var r = n(67294);
            let o = (0, r.createContext)(void 0),
                a = o.Provider,
                l = () => {
                    let e = (0, r.useContext)(o);
                    if (!e) throw Error("swapTokensContext: the hook must be used inside an SwapTokensContextProvider to work properly.");
                    return e
                }
        },
        84085: function(e, t, n) {
            n.d(t, {
                _W: function() {
                    return a
                },
                _k: function() {
                    return l
                },
                u5: function() {
                    return c
                }
            });
            var r, o, a, l, i = n(69402),
                u = n(99740),
                s = n(49981),
                d = n(17367),
                A = n(58871);
            (r = a || (a = {})).TOKEN_AMOUNT_REQUIRED = "TOKEN_AMOUNT_REQUIRED", r.TOKEN_AMOUNT_INSUFFICIENT_BALANCE = "TOKEN_AMOUNT_INSUFFICIENT_BALANCE", r.TOKEN_FIELD_REQUIRED = "TOKEN_FIELD_REQUIRED", (o = l || (l = {})).SWAP = "SWAP", o.WRAP = "WRAP", o.UNWRAP = "UNWRAP", o.UNKNOWN = "UNKNOWN";
            let c = new class {
                constructor() {
                    var e, t, n;
                    this.minSwapBalance = s.a.toBaseUnit("0.01", u.U.decimals), this.validateTokenAmount = e => {
                        let {
                            amount: t,
                            isFromField: n = !1,
                            maxBalance: r = "0",
                            decimals: o = u.zo
                        } = e;
                        if (!this.validateStringAmount(t, o)) return a.TOKEN_AMOUNT_REQUIRED;
                        let l = s.a.toBaseUnit(t, o),
                            i = s.a.toBaseUnit(r, o);
                        if (n && l > i) return a.TOKEN_AMOUNT_INSUFFICIENT_BALANCE
                    }, this.validateStringAmount = function(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : u.zo;
                        if (null == e || 0 === e.length) return !1;
                        let n = s.a.toBaseUnit(e, t);
                        return n > 0
                    }, this.validateToken = e => {
                        if (!e) return a.TOKEN_FIELD_REQUIRED
                    }, this.getSwapSlippage = e => {
                        var t, n;
                        let {
                            fromToken: r,
                            toToken: o
                        } = e, a = Math.round((null !== (t = null == r ? void 0 : r.sellFees) && void 0 !== t ? t : 0) * 10) / 10, l = Math.round((null !== (n = null == o ? void 0 : o.buyFees) && void 0 !== n ? n : 0) * 10) / 10;
                        return a + l + 1
                    }, this.getSwapTokensInitialValues = r => {
                        var o, a;
                        return {
                            [A.$M.GAS_PRICE_LEVEL]: d.f.MEDIUM,
                            [A.$M.SLIPPAGE]: this.getSwapSlippage({
                                fromToken: null == r ? void 0 : r.fromToken,
                                toToken: null == r ? void 0 : r.toToken
                            }),
                            [A.$M.NETWORK]: null !== (n = null !== (t = null !== (e = null == r ? void 0 : r.network) && void 0 !== e ? e : null == r ? void 0 : null === (o = r.fromToken) || void 0 === o ? void 0 : o.network) && void 0 !== t ? t : null == r ? void 0 : null === (a = r.toToken) || void 0 === a ? void 0 : a.network) && void 0 !== n ? n : u.cU.BINANCE_MAINNET,
                            ...r
                        }
                    }, this.getSwapTokensInitialErrors = (e, t) => {
                        var n, r;
                        return {
                            [A.$M.FROM_TOKEN]: this.validateToken(null == e ? void 0 : e.fromToken),
                            [A.$M.TO_TOKEN]: this.validateToken(null == e ? void 0 : e.toToken),
                            [A.$M.FROM_TOKEN_AMOUNT]: this.validateTokenAmount({
                                amount: null == e ? void 0 : e.fromTokenAmount,
                                isFromField: !0,
                                maxBalance: t,
                                decimals: null == e ? void 0 : null === (n = e.fromToken) || void 0 === n ? void 0 : n.decimals
                            }),
                            [A.$M.TO_TOKEN_AMOUNT]: this.validateTokenAmount({
                                amount: null == e ? void 0 : e.toTokenAmount,
                                isFromField: !1,
                                decimals: null == e ? void 0 : null === (r = e.toToken) || void 0 === r ? void 0 : r.decimals
                            })
                        }
                    }, this.isFromField = e => e === A.$M.FROM_TOKEN || e === A.$M.FROM_TOKEN_AMOUNT, this.getSwapActionType = e => {
                        let {
                            fromToken: t,
                            toToken: n
                        } = e;
                        if (null == t || null == n) return l.UNKNOWN;
                        let {
                            wrappedTokenAddress: r
                        } = u.Eu[t.network], o = s.a.areSameAddress(n.address, r), a = s.a.areSameAddress(t.address, r);
                        return t.type === i.i.NATIVE && o ? l.WRAP : n.type === i.i.NATIVE && a ? l.UNWRAP : l.SWAP
                    }, this.getMaxAmount = e => {
                        let {
                            token: t,
                            amount: n = "0"
                        } = e;
                        if (t.type !== i.i.NATIVE) return n;
                        let r = s.a.toBaseUnit(n, t.decimals),
                            o = r - this.minSwapBalance;
                        return o > 0 ? s.a.fromBaseUnit(o, t.decimals) : "0"
                    }
                }
            }
        },
        24952: function(e, t, n) {
            n.d(t, {
                i: function() {
                    return A
                }
            });
            var r, o, a = n(69402),
                l = n(99740),
                i = n(49981),
                u = n(38138),
                s = n(17367);
            (r = o || (o = {})).TRANSFER = "TRANSFER", r.MINT = "MINT", r.APPROVAL = "APPROVAL", r.SWAP = "SWAP", r.NFT_SWAP = "NFT_SWAP", r.CONTRACT_INTERACTION = "CONTRACT_INTERACTION";
            var d = n(84085);
            let A = new class {
                constructor() {
                    this.formValuesToAllowanceApprovalParams = e => {
                        let {
                            selectedAccount: t,
                            values: n
                        } = e, {
                            fromToken: r,
                            fromTokenAmount: o
                        } = n;
                        if (null == t || null == r || null == o || r.type === a.i.NATIVE) return;
                        let u = i.a.toBaseUnit(o, r.decimals).toString(),
                            s = l.Eu[r.network].floozRouter,
                            {
                                address: d
                            } = r;
                        return {
                            body: {
                                userAddress: t,
                                spender: s,
                                tokenAddress: d,
                                amount: u
                            }
                        }
                    }, this.formValuesToBuildAllowanceTxParams = e => {
                        let {
                            selectedAccount: t,
                            values: n
                        } = e, {
                            fromToken: r
                        } = n;
                        if (null == t || null == r || r.type === a.i.NATIVE) return;
                        let i = {
                            to: r.address,
                            from: t,
                            network: r.network,
                            gasPriceLevel: s.f.MEDIUM,
                            contractType: a.i.ERC_20,
                            type: o.APPROVAL,
                            metadata: {
                                spender: l.Eu[r.network].floozRouter,
                                amount: "max"
                            }
                        };
                        return {
                            body: i
                        }
                    }, this.formValuesToSwapQuoteParams = e => {
                        let {
                            selectedAccount: t,
                            values: n,
                            getFromAmount: r
                        } = e, {
                            fromToken: o,
                            toToken: a,
                            gasPriceLevel: l,
                            slippage: s,
                            network: A,
                            toTokenAmount: c,
                            fromTokenAmount: T
                        } = n;
                        if (null == o || null == a) return;
                        let E = r && d.u5.validateStringAmount(c, a.decimals) || !r && d.u5.validateStringAmount(T, o.decimals);
                        if (null == l || !E) return;
                        let N = r ? void 0 : i.a.toBaseUnit(T, o.decimals),
                            _ = r ? i.a.toBaseUnit(c, a.decimals) : void 0,
                            f = {
                                buyCurrency: a.address,
                                sellCurrency: o.address,
                                buyAmount: null == _ ? void 0 : _.toString(),
                                sellAmount: null == N ? void 0 : N.toString(),
                                network: A,
                                gasPriceLevel: l,
                                contractType: u.R.FLOOZ_MULTICHAIN_ROUTER,
                                slippage: null != s ? s : 0,
                                userAddress: t
                            };
                        return {
                            body: f
                        }
                    }, this.formValuesToBuildSwapTxParams = e => {
                        let {
                            selectedAccount: t,
                            values: n,
                            referrer: r
                        } = e, o = this.formValuesToSwapQuoteParams({
                            selectedAccount: t,
                            values: n
                        });
                        if (null == t || null == o) return;
                        let a = null != r && !i.a.areSameAddress(r, t),
                            l = { ...o.body,
                                referee: a ? r : void 0
                            };
                        return {
                            body: l
                        }
                    }
                }
            }
        },
        50950: function(e, t, n) {
            n.d(t, {
                s: function() {
                    return d
                }
            });
            var r = n(67294),
                o = n(69484),
                a = n(48791),
                l = n(27766),
                i = n(49981),
                u = n(84085),
                s = n(46953);
            let d = e => {
                let {
                    toTokenAddress: t,
                    fromTokenAddress: n,
                    lockToToken: d,
                    toTokenAmount: A,
                    fromTokenAmount: c,
                    multiChainContracts: T,
                    network: E,
                    refId: N,
                    swapTokensContext: _,
                    quoteId: f,
                    isLoading: O
                } = null != e ? e : {}, {
                    providerNetwork: m
                } = (0, a.Z_)(), {
                    address: v
                } = (0, l.e)(N), R = E ? null == T ? void 0 : T[E] : void 0, P = null != t ? t : R, {
                    data: S,
                    isInitialLoading: I
                } = (0, o.d)({
                    pathParameters: {
                        tokenAddress: P
                    },
                    queryParameters: {
                        network: E
                    }
                }, {
                    enabled: null != P
                }), w = s.S.getSwapFromToken({
                    toToken: S,
                    fromTokenParam: n,
                    networkParam: E,
                    providerNetwork: m
                }), h = {
                    tokenAddress: w.address
                }, p = {
                    network: w.network
                }, {
                    data: k
                } = (0, o.d)({
                    pathParameters: h,
                    queryParameters: p
                }, {
                    enabled: null != w.address && null != w.address
                }), C = (0, r.useMemo)(() => ({
                    referrer: v,
                    quoteId: f,
                    lockToken: d ? P : void 0,
                    isLoading: I || Boolean(O),
                    ..._
                }), [v, P, I, O, _, d, f]), U = (0, r.useMemo)(() => {
                    let e = i.a.areSameAddress(null == k ? void 0 : k.address, null == S ? void 0 : S.address),
                        t = !isNaN(parseFloat(null != c ? c : "")),
                        n = !isNaN(parseFloat(null != A ? A : ""));
                    return u.u5.getSwapTokensInitialValues({
                        fromToken: e ? void 0 : k,
                        toToken: S,
                        fromTokenAmount: t ? c : void 0,
                        toTokenAmount: n ? A : void 0
                    })
                }, [k, S, c, A]);
                return {
                    swapTokensContext: C,
                    initialValues: U
                }
            }
        },
        46953: function(e, t, n) {
            n.d(t, {
                S: function() {
                    return a
                }
            });
            var r = n(99740),
                o = n(98671);
            let a = new class {
                constructor() {
                    this.getSwapFromToken = e => {
                        let {
                            toToken: t,
                            providerNetwork: n,
                            fromTokenParam: o,
                            networkParam: a,
                            defaultNetwork: l = r.cU.BINANCE_MAINNET
                        } = e;
                        if (o) return {
                            address: o,
                            network: a
                        };
                        if (t) {
                            let {
                                address: e
                            } = r.Eu[t.network].nativeCurrency;
                            return {
                                address: e,
                                network: t.network
                            }
                        }
                        if (a) {
                            let {
                                address: e
                            } = r.Eu[a].nativeCurrency;
                            return {
                                address: e,
                                network: a
                            }
                        }
                        let i = null != n ? n : l,
                            {
                                address: u
                            } = r.Eu[i].nativeCurrency;
                        return {
                            address: u,
                            network: i
                        }
                    }, this.getChartUrl = e => {
                        let {
                            networkParamName: t,
                            refIdParamName: n,
                            tokenDetailsRoute: a,
                            useExternalWebsite: l,
                            tokenAddress: i,
                            refId: u,
                            network: s
                        } = e, d = (0, o.G)(a, {
                            tokenAddress: i
                        }), A = new URLSearchParams([
                            [t, s]
                        ]);
                        u && A.append(n, u);
                        let c = "".concat(d, "?").concat(A.toString()),
                            T = l ? r.Eu[s].getTokenChartUrl(i) : c;
                        return T
                    }
                }
            }
        },
        51736: function(e, t, n) {
            n.d(t, {
                p: function() {
                    return a
                }
            });
            var r = n(48228),
                o = n(2948);
            let a = e => (0, r.D)(e => o.x.sendTransaction(e), e)
        },
        3402: function(e, t, n) {
            n.r(t), n.d(t, {
                ModalSwitchNetwork: function() {
                    return E
                },
                ModalSwitchNetworkQueryParams: function() {
                    return r
                }
            });
            var r, o = n(85893),
                a = n(9264),
                l = n(67294),
                i = n(99740),
                u = n(77902),
                s = n(33715),
                d = n(47885),
                A = n(79577),
                c = n(27722),
                T = n(48791);
            (r || (r = {})).REQUIRED_CHAIN = "requiredChain";
            let E = e => {
                let {
                    location: t
                } = e, {
                    modalHistory: n
                } = (0, c.N)(), {
                    setupProviderNetwork: E,
                    providerNetwork: N
                } = (0, T.Z_)(), {
                    t: _
                } = (0, a.$G)(), f = new URLSearchParams(t.search), O = f.get(r.REQUIRED_CHAIN), m = null != O ? O : i.cU.BINANCE_MAINNET;
                (0, l.useEffect)(() => {
                    m === N && n.back()
                }, [m, N, n]);
                let v = (0, l.useCallback)(() => {
                    E(m)
                }, [E, m]);
                return (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)(A.u.Header, {
                        title: _("flooz-web.shared.modal-switch-network.title", {
                            chain: i.Eu[m].label
                        })
                    }), (0, o.jsx)(A.u.Content, {
                        children: (0, o.jsxs)(d.P, {
                            gap: "200",
                            grow: "1",
                            children: [(0, o.jsx)(s.J, {
                                icon: i.Eu[m].logo,
                                className: "modal-switch-network__chain-logo"
                            }), (0, o.jsx)("p", {
                                className: "center-text",
                                children: _("flooz-web.shared.modal-switch-network.content", {
                                    chain: i.Eu[m].label
                                })
                            }), (0, o.jsx)(u.z, {
                                variant: "primary",
                                size: "xl",
                                onClick: v,
                                children: _("flooz-web.shared.modal-switch-network.cta")
                            })]
                        })
                    })]
                })
            }
        },
        99185: function(e, t, n) {
            n.d(t, {
                I: function() {
                    return i
                },
                M: function() {
                    return l
                }
            });
            var r = n(18472),
                o = n(67294),
                a = n(48791);
            let l = new class {
                    constructor() {
                        this.setEnabled = e => {
                            this.enabled = e
                        }, this.logException = (e, t) => {
                            this.enabled && r.Tb(e, t)
                        }, this.flush = e => r.yl(e), this.enabled = !1
                    }
                },
                i = () => {
                    let {
                        selectedAccount: e,
                        providerNetwork: t,
                        activeConnector: n
                    } = (0, a.Z_)(), r = (0, o.useCallback)(r => {
                        let {
                            exception: o,
                            context: a,
                            severity: i = "error"
                        } = r, u = {
                            id: null == e ? void 0 : e.toLowerCase()
                        };
                        l.logException(o, {
                            user: u,
                            tags: {
                                connector: n,
                                providerNetwork: t
                            },
                            contexts: a ? {
                                context: a
                            } : void 0,
                            level: i
                        })
                    }, [e, t, n]);
                    return {
                        logException: r
                    }
                }
        },
        27766: function(e, t, n) {
            n.d(t, {
                e: function() {
                    return u
                }
            });
            var r = n(36492),
                o = n(46223),
                a = n(19069);
            let l = (e, t) => (0, r.a)(a.a.decodeReferralId(e), () => o.W4.decodeReferralId(e), t);
            var i = n(60759);
            let u = e => {
                let t = i.Wl.get(i.mJ.referralId, !0),
                    n = null != e ? e : t,
                    {
                        data: r
                    } = l({
                        pathParameters: {
                            refIdOrAddress: n
                        }
                    }, {
                        enabled: null != n
                    });
                return {
                    address: null == r ? void 0 : r.address,
                    refId: n
                }
            }
        }
    }
]);