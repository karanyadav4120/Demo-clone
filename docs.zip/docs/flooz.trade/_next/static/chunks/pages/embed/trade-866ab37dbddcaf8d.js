(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4998], {
        61909: function(e, o, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/embed/trade", function() {
                return t(40729)
            }])
        },
        73318: function(e, o, t) {
            "use strict";
            t.d(o, {
                u: function() {
                    return l
                },
                q: function() {
                    return u.q
                }
            });
            var r = t(85893),
                n = t(67294);
            let a = e => {
                let {
                    primaryColor: o = "#824cf4",
                    backgroundColor: t = "#000000",
                    modalOverlayBackgroundColor: r = "rgba(0, 0, 0, 0.7)",
                    containerSelector: a
                } = e;
                (0, n.useEffect)(() => {
                    let e = a && document.querySelector(a) ? document.querySelector(a) : document.documentElement,
                        n = document.documentElement.style.getPropertyValue("--sya-color-primary"),
                        d = document.documentElement.style.getPropertyValue("--sya-color-primary-600"),
                        s = document.documentElement.style.getPropertyValue("--sya-color-body-background"),
                        u = document.documentElement.style.getPropertyValue("--sya-modal-container-overlay-background-color");
                    return e.style.setProperty("--sya-color-primary", o), e.style.setProperty("--sya-color-primary-600", o), e.style.setProperty("--sya-modal-container-overlay-background-color", r), e.style.setProperty("--sya-color-body-background", t), () => {
                        e.style.setProperty("--sya-color-primary", n), e.style.setProperty("--sya-color-primary-600", d), e.style.setProperty("--sya-color-body-background", s), e.style.setProperty("--sya-modal-container-overlay-background-color", u)
                    }
                }, [o, t, r, a])
            };
            var d = t(41303),
                s = t(66744),
                u = t(60623);
            let l = () => {
                var e;
                let {
                    onRampParams: o,
                    brandingParams: t,
                    swapParams: n,
                    generalParams: l
                } = (0, u.w)(), {
                    onRampDisabled: _,
                    onRampAsDefault: i
                } = o, {
                    swapDisabled: c
                } = n, {
                    network: A,
                    hideChartLink: R,
                    hideReferLink: m,
                    refId: p
                } = l, {
                    lightMode: T,
                    primaryColor: y,
                    backgroundColor: O,
                    roundedCorners: E,
                    padding: D
                } = t, N = !_ && (c || i) ? s.J.ON_RAMP : s.J.SWAP, P = {
                    toTokenAddress: n.swapToTokenAddress,
                    fromTokenAddress: n.swapFromTokenAddress,
                    lockToToken: n.swapLockToToken,
                    fromTokenAmount: n.swapFromTokenAmount,
                    toTokenAmount: n.swapToTokenAmount,
                    multiChainContracts: n.swapMultiChainContracts,
                    network: A,
                    refId: p,
                    swapTokensContext: {
                        hideChartLink: R,
                        hideReferLink: m,
                        isBuyCryptoDisabled: _,
                        hideOffRampLink: !0
                    }
                }, k = {
                    network: A,
                    tokenAddress: null !== (e = o.onRampTokenAddress) && void 0 !== e ? e : n.swapToTokenAddress,
                    currencyId: o.onRampCurrencyId,
                    defaultAmount: o.onRampDefaultAmount,
                    buyCryptoContext: {
                        hideChartLink: R,
                        hideReferLink: m,
                        hideOffRampLink: !0
                    }
                };
                return (0, d.d)(T), a({
                    primaryColor: y,
                    backgroundColor: O
                }), (0, r.jsx)("div", {
                    className: "embedded-trade-page",
                    style: {
                        borderRadius: E ? "".concat(E, "px") : void 0,
                        paddingLeft: D ? "".concat(D, "px") : void 0,
                        paddingRight: D ? "".concat(D, "px") : void 0
                    },
                    children: (0, r.jsx)(s.U, {
                        swapDisabled: c,
                        onRampDisabled: _,
                        initialSelectedTab: N,
                        swapTokensParams: P,
                        buyCryptoParams: k,
                        renderFloozConnect: !0
                    })
                })
            }
        },
        60623: function(e, o, t) {
            "use strict";
            t.d(o, {
                q: function() {
                    return n
                },
                w: function() {
                    return u
                }
            });
            var r, n, a = t(11163),
                d = t(94176),
                s = t(99740);
            (r = n || (n = {})).SWAP_DISABLED = "swapDisabled", r.SWAP_FROM_TOKEN_ADDRESS = "swapFromTokenAddress", r.SWAP_TO_TOKEN_ADDRESS = "swapToTokenAddress", r.SWAP_LOCK_TO_TOKEN = "swapLockToToken", r.SWAP_FROM_TOKEN_AMOUNT = "swapFromTokenAmount", r.SWAP_TO_TOKEN_AMOUNT = "swapToTokenAmount", r.ON_RAMP_DISABLED = "onRampDisabled", r.ON_RAMP_CURRENCY_ID = "onRampCurrencyId", r.ON_RAMP_TOKEN_ADDRESS = "onRampTokenAddress", r.ON_RAMP_DEFAULT_AMOUNT = "onRampDefaultAmount", r.ON_RAMP_AS_DEFAULT = "onRampAsDefault", r.REF_ID = "refId", r.NETWORK = "network", r.HIDE_CHART_LINK = "hideChartLink", r.HIDE_REFER_LINK = "hideReferLink", r.PRIMARY_COLOR = "primaryColor", r.BACKGROUND_COLOR = "backgroundColor", r.LIGHT_MODE = "lightMode", r.ROUNDED_CORNERS = "roundedCorners", r.PADDING = "padding";
            let u = () => {
                var e, o, t, r, u, l, _, i, c, A, R, m, p;
                let T = (0, a.useRouter)(),
                    {
                        networkParam: y
                    } = (0, d.UV)(),
                    O = new URLSearchParams(T.query),
                    E = null !== (e = O.get(n.REF_ID)) && void 0 !== e ? e : void 0,
                    D = "true" === O.get(n.HIDE_CHART_LINK),
                    N = "true" === O.get(n.HIDE_REFER_LINK),
                    P = "true" === O.get(n.SWAP_DISABLED),
                    k = null !== (o = O.get(n.SWAP_FROM_TOKEN_ADDRESS)) && void 0 !== o ? o : void 0,
                    g = null !== (t = O.get(n.SWAP_TO_TOKEN_ADDRESS)) && void 0 !== t ? t : void 0,
                    v = "true" === O.get(n.SWAP_LOCK_TO_TOKEN),
                    S = null !== (r = O.get(n.SWAP_FROM_TOKEN_AMOUNT)) && void 0 !== r ? r : void 0,
                    C = null !== (u = O.get(n.SWAP_TO_TOKEN_AMOUNT)) && void 0 !== u ? u : void 0,
                    f = s.si.reduce((e, o) => ({ ...e,
                        [o]: null !== (l = O.get("swapContract".concat(o.toUpperCase()))) && void 0 !== l ? l : void 0
                    }), {}),
                    w = "true" === O.get(n.ON_RAMP_DISABLED),
                    L = null !== (_ = O.get(n.ON_RAMP_CURRENCY_ID)) && void 0 !== _ ? _ : void 0,
                    M = null !== (i = O.get(n.ON_RAMP_TOKEN_ADDRESS)) && void 0 !== i ? i : void 0,
                    I = null !== (c = O.get(n.ON_RAMP_DEFAULT_AMOUNT)) && void 0 !== c ? c : void 0,
                    b = "true" === O.get(n.ON_RAMP_AS_DEFAULT),
                    K = null !== (A = O.get(n.PRIMARY_COLOR)) && void 0 !== A ? A : void 0,
                    U = null !== (R = O.get(n.BACKGROUND_COLOR)) && void 0 !== R ? R : void 0,
                    F = "true" === O.get(n.LIGHT_MODE),
                    h = null !== (m = O.get(n.ROUNDED_CORNERS)) && void 0 !== m ? m : void 0,
                    W = null !== (p = O.get(n.PADDING)) && void 0 !== p ? p : void 0;
                return {
                    generalParams: {
                        refId: E,
                        network: y,
                        hideChartLink: D,
                        hideReferLink: N
                    },
                    swapParams: {
                        swapDisabled: P,
                        swapFromTokenAddress: k,
                        swapToTokenAddress: g,
                        swapLockToToken: v,
                        swapMultiChainContracts: f,
                        swapFromTokenAmount: S,
                        swapToTokenAmount: C
                    },
                    onRampParams: {
                        onRampDisabled: w,
                        onRampCurrencyId: L,
                        onRampTokenAddress: M,
                        onRampDefaultAmount: I,
                        onRampAsDefault: b
                    },
                    brandingParams: {
                        primaryColor: K,
                        backgroundColor: U,
                        lightMode: F,
                        roundedCorners: h,
                        padding: W
                    }
                }
            }
        },
        40729: function(e, o, t) {
            "use strict";
            t.r(o), t.d(o, {
                __N_SSP: function() {
                    return n
                }
            });
            var r = t(73318),
                n = !0;
            o.default = r.u
        }
    },
    function(e) {
        e.O(0, [1028, 2580, 8608, 6888, 8006, 5142, 9853, 9964, 7397, 6744, 9774, 2888, 179], function() {
            return e(e.s = 61909)
        }), _N_E = e.O()
    }
]);