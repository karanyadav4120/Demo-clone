"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7397], {
        41262: function(e, t, r) {
            r.d(t, {
                R: function() {
                    return s
                }
            });
            var i = r(33715);
            let s = [{
                key: "discord",
                icon: i.T.SOCIAL_DISCORD,
                title: "Discord"
            }, {
                key: "instagram",
                icon: i.T.SOCIAL_INSTAGRAM,
                title: "Instagram"
            }, {
                key: "telegram",
                icon: i.T.SOCIAL_TELEGRAM,
                title: "Telegram"
            }, {
                key: "twitter",
                icon: i.T.SOCIAL_TWITTER,
                title: "Twitter"
            }, {
                key: "youtube",
                icon: i.T.SOCIAL_YOUTUBE,
                title: "YouTube"
            }, {
                key: "reddit",
                icon: i.T.SOCIAL_REDDIT,
                title: "Reddit"
            }]
        },
        19954: function(e, t, r) {
            r.d(t, {
                E: function() {
                    return u
                }
            });
            var i = r(85893);
            r(67294);
            var s = r(99740),
                n = r(79201),
                a = r(43829),
                l = r(77902),
                o = r(33715),
                c = r(47885),
                d = r(41262);
            let u = e => {
                let {
                    address: t,
                    network: r,
                    socialLinks: u
                } = e, g = r && t ? s.Eu[r] : void 0, p = d.R.filter(e => {
                    let {
                        key: t
                    } = e;
                    return a.s.isValidLink(null == u ? void 0 : u[t])
                });
                return (0, i.jsxs)(c.P, {
                    direction: "row",
                    wrap: "wrap",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "50",
                    children: [p.map(e => {
                        let {
                            key: t,
                            icon: r,
                            title: s
                        } = e;
                        return (0, i.jsx)(l.Z, {
                            variant: "text",
                            size: "xl",
                            icon: r,
                            href: u[t],
                            title: s,
                            target: "_blank"
                        }, t)
                    }), g && (0, i.jsx)(l.Z, {
                        variant: "text",
                        size: "l",
                        href: g.blockExplorer.getUrl(t, n.C.TOKEN),
                        icon: o.T.SOCIAL_ETH_SCAN,
                        title: g.label,
                        target: "_blank"
                    })]
                })
            }
        },
        47033: function(e, t, r) {
            r.d(t, {
                S: function() {
                    return d
                }
            });
            var i = r(85893),
                s = r(9264),
                n = r(67294),
                a = r(99185),
                l = r(84668),
                o = r(47885);
            class c extends n.Component {
                componentDidCatch(e, t) {
                    var r, i;
                    this.setState({
                        error: e
                    }), null === (i = (r = this.props).onError) || void 0 === i || i.call(r, e, t)
                }
                render() {
                    let {
                        children: e,
                        renderFallbackContent: t
                    } = this.props, {
                        error: r
                    } = this.state;
                    return r ? t(r) : e
                }
                constructor(...e) {
                    super(...e), this.state = {}
                }
            }
            let d = e => {
                let {
                    children: t
                } = e, {
                    logException: r
                } = (0, a.I)(), {
                    t: n
                } = (0, s.$G)(), d = e => {
                    r({
                        exception: e
                    })
                }, u = () => (0, i.jsxs)(o.P, {
                    className: "center-text",
                    direction: "column",
                    gap: "100",
                    alignItems: "center",
                    children: [(0, i.jsx)(l.X, {
                        size: "h1",
                        children: n("flooz-web.shared.error-boundary.title")
                    }), (0, i.jsx)(l.X, {
                        size: "h3",
                        children: n("flooz-web.shared.error-boundary.sub-title")
                    })]
                });
                return (0, i.jsx)(c, {
                    onError: d,
                    renderFallbackContent: u,
                    children: t
                })
            }
        },
        37397: function(e, t, r) {
            r.d(t, {
                C: function() {
                    return O
                }
            });
            var i, s = r(85893),
                n = r(94184),
                a = r.n(n),
                l = r(67294),
                o = r(44541),
                c = r(47033),
                d = r(28268);
            let u = (0, l.createContext)(void 0),
                g = u.Provider,
                p = () => {
                    let e = (0, l.useContext)(u);
                    if (!e) throw Error("usePageStructuredContext: the hook must be placed inside a PageStructuredContextProvider to work properly.");
                    return e
                },
                h = e => {
                    let {
                        hasWidget: t = !1,
                        isLoading: r = !1,
                        hasTabs: i = !1,
                        hasTabsMobile: n = !1,
                        className: u,
                        children: p,
                        ...h
                    } = e, x = (0, l.useMemo)(() => ({
                        hasWidget: t,
                        hasTabs: i,
                        hasTabsMobile: n,
                        isLoading: r
                    }), [t, i, n, r]);
                    return (0, s.jsxs)(g, {
                        value: x,
                        children: [(0, s.jsx)(d.N, { ...h
                        }), (0, s.jsx)(o.W, {
                            className: a()("page-structured-container", {
                                "page-structured-container--with-widget": t
                            }, {
                                "page-structured-container--with-tabs": i
                            }, {
                                "page-structured-container--with-tabs-mobile": n
                            }, {
                                "page-structured-container--with-sidebar": !0
                            }, u),
                            children: (0, s.jsx)(c.S, {
                                children: p
                            })
                        })]
                    })
                };
            var x = r(47885);
            let w = e => {
                let {
                    className: t,
                    children: r
                } = e, {
                    hasWidget: i,
                    hasTabs: n,
                    hasTabsMobile: l
                } = p();
                return (0, s.jsx)(x.P, {
                    gap: "200",
                    direction: "row",
                    alignItems: "start",
                    shrink: "1",
                    className: a()("page-structured-content", {
                        "page-structured-content--with-widget": i
                    }, {
                        "page-structured-content--with-tabs": n
                    }, {
                        "page-structured-content--with-tabs-mobile": l
                    }, t),
                    children: r
                })
            };
            var m = r(9264),
                v = r(11163),
                j = r(13915),
                C = r(98671),
                _ = r(76409),
                b = r(94176),
                T = r(10453),
                f = r(19954),
                k = r(77902),
                E = r(84668),
                z = r(33715),
                S = r(55642),
                y = r(1527),
                N = r(51275),
                P = r(17686),
                I = r(94162);
            let A = e => {
                let {
                    t
                } = (0, m.$G)(), r = (0, v.useRouter)(), {
                    routeHistory: i
                } = (0, b.UV)(), {
                    hasWidget: n,
                    hasTabs: o,
                    isLoading: c
                } = p(), {
                    parentPage: d,
                    displayLogo: u,
                    logo: g,
                    isVerified: h,
                    title: w,
                    titleCopyValue: A,
                    subtitle: L,
                    isSafe: F,
                    onSafeBadgeClick: R,
                    displayActions: D,
                    actions: O,
                    mainColumn: G,
                    share: U,
                    className: V,
                    children: X,
                    socials: $
                } = e, B = () => {
                    if (!d) return;
                    let e = 1 === i.length;
                    e ? r.push((0, C.G)(d)) : r.back()
                }, H = (0, l.useCallback)(() => {
                    _.C.copyValue({
                        value: A,
                        onValueCopied: N.F.notificationCopy
                    })
                }, [A]), W = (0, l.useCallback)(() => {
                    let {
                        url: e,
                        text: t
                    } = null != U ? U : {}, i = null != e ? e : r.asPath, s = "".concat("https://flooz.trade").concat(i);
                    _.C.shareUrl({
                        title: "Flooz.Trade",
                        url: i,
                        text: null != t ? t : "Check this out!",
                        fallbackCopyText: s,
                        onFallbackCopy: N.F.notificationCopy
                    })
                }, [r, U]), {
                    label: M,
                    value: Y,
                    delta: Z
                } = null != G ? G : {}, q = "string" == typeof Y ? parseFloat(Y) : null != Y ? Y : 0, K = j.z.formatNumber(q, {
                    fixedFractionDigits: 2,
                    useSuperscriptFormat: !0
                }), J = "string" == typeof Z ? parseFloat(Z) : Z, Q = J ? "".concat(j.z.formatNumber(J, {
                    withSign: !0,
                    fixedFractionDigits: 2
                }), "%") : void 0;
                return (0, s.jsx)(I.$.Container, {
                    className: a()("page-structured-overview", {
                        "page-structured-overview--with-widget": n
                    }, {
                        "page-structured-overview--with-tabs": o
                    }, V),
                    children: (0, s.jsxs)(x.P, {
                        gap: "100",
                        direction: "column",
                        children: [D && (0, s.jsxs)(x.P, {
                            gap: "100",
                            justifyContent: "space-between",
                            direction: "row-reverse",
                            children: [(0, s.jsxs)(x.P, {
                                direction: "row",
                                gap: "100",
                                children: [null == O ? void 0 : O.map(e => {
                                    let {
                                        id: t,
                                        label: r,
                                        variant: i = "text",
                                        size: n = "xl",
                                        ...a
                                    } = e;
                                    return (0, s.jsx)(k.z, {
                                        variant: i,
                                        size: n,
                                        ...a,
                                        children: r
                                    }, t)
                                }), (0, s.jsx)(k.z, {
                                    onClick: W,
                                    icon: z.T.SHARE,
                                    variant: "text",
                                    size: "xl"
                                })]
                            }), d && (0, s.jsx)(k.z, {
                                className: "page-structured-overview__back",
                                variant: "text",
                                size: "xl",
                                icon: z.T.CARET_LEFT,
                                onClick: B
                            })]
                        }), u && (0, s.jsxs)("div", {
                            className: "page-structured-overview__logo-wrapper",
                            children: [(void 0 === g || "string" == typeof g) && (0, s.jsx)(T.F, {
                                logo: g,
                                isLoading: c,
                                className: a()("page-structured-overview__logo")
                            }), l.isValidElement(g) && l.cloneElement(g, {
                                className: "page-structured-overview__logo"
                            }), h && (0, s.jsx)(P.F, {
                                className: "page-structured-overview__verified"
                            })]
                        }), (0, s.jsxs)(x.P, {
                            gap: "100",
                            direction: "row",
                            alignItems: "center",
                            wrap: "wrap",
                            shrink: "1",
                            rowGap: "0",
                            children: [(0, s.jsxs)(x.P, {
                                gap: "100",
                                direction: "row",
                                alignItems: "baseline",
                                wrap: "wrap",
                                shrink: "1",
                                rowGap: "0",
                                children: [(0, s.jsx)(E.X, {
                                    size: "h1",
                                    sSize: "h2",
                                    xsSize: "h3",
                                    as: "h1",
                                    onClick: c || null == A ? void 0 : H,
                                    ellipsis: !0,
                                    children: c ? (0, s.jsx)(S.g, {
                                        width: 200
                                    }) : w
                                }), L && (0, s.jsx)(E.X, {
                                    size: "h2",
                                    sSize: "h3",
                                    xsSize: "h4",
                                    color: "muted",
                                    children: L
                                })]
                            }), $ && (0, s.jsx)(f.E, {
                                socialLinks: $
                            })]
                        }), (null != X || null != G) && (0, s.jsxs)(x.P, {
                            className: "page-structured-overview__content",
                            direction: "column",
                            gap: "100",
                            children: [G && (0, s.jsxs)(x.P, {
                                gap: "0",
                                direction: "column",
                                children: [(0, s.jsx)(y.x, {
                                    size: "l",
                                    fontWeight: "bold",
                                    color: "muted",
                                    children: M
                                }), (0, s.jsxs)(x.P, {
                                    direction: "row",
                                    gap: "100",
                                    alignItems: "baseline",
                                    wrap: "wrap",
                                    rowGap: "0",
                                    shrink: "1",
                                    children: [(0, s.jsx)(E.X, {
                                        size: "h2",
                                        sSize: "h3",
                                        xsSize: "h4",
                                        ellipsis: !0,
                                        children: c ? (0, s.jsx)(S.g, {
                                            width: 90
                                        }) : "$".concat(K)
                                    }), Q && (0, s.jsx)(y.x, {
                                        size: "xl",
                                        color: (null != J ? J : 0) > 0 ? "success" : "muted",
                                        ellipsis: !0,
                                        children: Q
                                    })]
                                }), !1 === F && (0, s.jsx)(k.z, {
                                    onClick: R,
                                    icon: z.T.INFO,
                                    iconPosition: "right",
                                    className: "page-structured-overview__risky",
                                    variant: "primary",
                                    size: "m",
                                    children: (0, s.jsx)(y.x, {
                                        size: "m",
                                        children: t("flooz-web.shared.page-structured-overview.risky-token")
                                    })
                                })]
                            }), X]
                        })]
                    })
                })
            };
            var L = r(3188);
            (i || (i = {})).SELECTED_TAB = "selectedTab";
            let F = e => {
                let {
                    selectedTab: t,
                    defaultTab: r,
                    onTabChange: n,
                    tabEntries: o,
                    className: c,
                    children: d
                } = e, u = (0, v.useRouter)();
                (0, l.useEffect)(() => {
                    var e;
                    let t = new URLSearchParams(u.query),
                        s = null !== (e = t.get(i.SELECTED_TAB)) && void 0 !== e ? e : void 0;
                    n(null != s ? s : r)
                }, [u, r, n]);
                let g = (0, l.useCallback)(e => {
                    let t = new URLSearchParams(location.search);
                    t.set(i.SELECTED_TAB, e);
                    let r = u.asPath.split("?")[0];
                    u.replace("".concat(r, "?").concat(t.toString()), void 0, {
                        scroll: !1
                    }), n(e)
                }, [u, n]);
                return (0, s.jsx)(L.m.Container, {
                    className: a()("page-structured-tabs", c),
                    selectedTabId: null != t ? t : r,
                    onTabSelected: g,
                    variant: "sheet",
                    tabEntries: o,
                    children: d
                })
            };
            var R = r(70337);
            let D = e => {
                    let {
                        toggleLabel: t,
                        onMobileClick: r,
                        className: i,
                        hideMobileTrigger: n,
                        children: o,
                        additionalContent: c
                    } = e, {
                        isSDown: d
                    } = (0, R.Pf)(), [u, g] = (0, l.useState)(!1), p = () => g(e => !e);
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(k.z, {
                            className: a()("page-structured-widget__trigger", {
                                "page-structured-widget__trigger--hidden": u || n
                            }),
                            variant: "primary",
                            size: "xl",
                            icon: z.T.CARET_LEFT,
                            iconPosition: "left",
                            onClick: d ? r : p,
                            children: t
                        }), (0, s.jsx)("div", {
                            className: a()("page-structured-widget__overlay", {
                                "page-structured-widget__overlay--visible": u
                            })
                        }), (0, s.jsxs)(x.P, {
                            gap: c ? "150" : "0",
                            className: a()("page-structured-widget__column", {
                                "page-structured-widget__column--visible": u
                            }, i),
                            children: [(0, s.jsx)(I.$.Container, {
                                onDismissClick: p,
                                className: "page-structured-widget__column-widget",
                                children: o
                            }), c && (0, s.jsx)(x.P, {
                                gap: "200",
                                className: "page-structured-widget__column-extra",
                                children: c
                            })]
                        })]
                    })
                },
                O = {
                    Container: h,
                    Content: w,
                    Overview: A,
                    Tabs: F,
                    Widget: D
                }
        },
        94162: function(e, t, r) {
            r.d(t, {
                $: function() {
                    return h
                }
            });
            var i = r(85893),
                s = r(94184),
                n = r.n(s),
                a = r(67294),
                l = r(77902),
                o = r(33715),
                c = r(47885);
            let d = e => {
                let {
                    onDismissClick: t,
                    children: r,
                    className: s
                } = e;
                return (0, i.jsxs)(c.P, {
                    gap: "100",
                    direction: "column",
                    className: n()("widget-container", s),
                    children: [t && (0, i.jsx)(l.z, {
                        className: "widget-container__dismiss",
                        variant: "text",
                        size: "m",
                        icon: o.T.CARET_RIGHT,
                        onClick: t
                    }), r]
                })
            };
            var u = r(10453),
                g = r(84668);
            let p = e => {
                    let {
                        title: t,
                        titleLogo: r,
                        className: s,
                        children: l
                    } = e;
                    return (0, i.jsxs)(c.P, {
                        className: n()("widget-header", s),
                        gap: "100",
                        direction: "row",
                        justifyContent: "space-between",
                        children: [(0, i.jsxs)(c.P, {
                            direction: "row",
                            gap: "100",
                            alignItems: "center",
                            children: ["string" == typeof r && (0, i.jsx)(u.F, {
                                logo: r
                            }), a.isValidElement(r) && a.cloneElement(r), (0, i.jsx)(g.X, {
                                size: "h5",
                                children: t
                            })]
                        }), l]
                    })
                },
                h = {
                    Container: d,
                    Header: p
                }
        }
    }
]);