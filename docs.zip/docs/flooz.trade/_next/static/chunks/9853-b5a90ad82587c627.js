"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9853], {
        49749: function(e, t, o) {
            o.d(t, {
                k0: function() {
                    return a
                }
            });
            var n, _, r = o(99640);
            (n = _ || (_ = {})).TOKEN_SELECTED = "token_selected", n.QUOTE = "quote", n.ACTIVATE_GOD_MODE = "activate_god_mode", n.ON_RAMP_VIEW = "on_ramp_view", n.ON_RAMP_CONNECT_WALLET = "on_ramp_connect_wallet", n.ON_RAMP_WALLET_CONNECTED = "on_ramp_wallet_connected", n.ON_RAMP_HOW_TO_BUY_INFO = "on_ramp_how_to_buy_info", n.ON_RAMP_CLICK_BUY_BUTTON = "on_ramp_click_buy_button", n.ON_RAMP_BUY_ANY_EMAIL_ENTERED = "on_ramp_buy_any_email_entered", n.ON_RAMP_BUY_ANY_SUCCESS_RAMP_FLOW = "on_ramp_buy_any_success_ramp_flow", n.ON_RAMP_BUY_ANY_CHECK_ACTIVITY = "on_ramp_buy_any_check_activity", n.OFF_RAMP_OPEN_SELL_SCREEN = "off_ramp_open_sell_screen", n.APPROVE_SIGN_REQUEST = "approve_sign_request", n.APPROVE_SIGN_SUCCESS = "approve_sign_success", n.APPROVE_SIGN_REJECT = "approve_sign_reject", n.APPROVE_SIGN_ERROR = "approve_sign_error", n.APPROVE_ERROR = "approve_error", n.APPROVE_SUCCESS = "approve_success", n.SWAP = "swap", n.SWAP_SIGN_REQUEST = "swap_sign_request", n.SWAP_SIGN_REJECT = "swap_sign_reject", n.SWAP_SIGN_ERROR = "swap_sign_error", n.SWAP_ERROR = "swap_error", n.SWAP_SIGN_SUCCESS = "swap_sign_success";
            let a = new class {
                constructor() {
                    var e;
                    this.emitTokenSelected = e => {
                        let {
                            token: t
                        } = e;
                        r.I.emitEvent(_.TOKEN_SELECTED, {
                            token_network: t.network,
                            token_symbol: t.symbol,
                            token_address: t.address
                        })
                    }, this.emitSwap = e => {
                        var t, o;
                        let {
                            activity: n,
                            usdAmount: a
                        } = e;
                        r.I.emitEvent(_.SWAP, {
                            from_token_symbol: null === (t = n.tokenFrom) || void 0 === t ? void 0 : t.symbol,
                            to_token_symbol: null === (o = n.tokenTo) || void 0 === o ? void 0 : o.symbol,
                            swap_amount: a,
                            value: parseFloat(a)
                        })
                    }, this.emitSwapSignRequest = e => {
                        let {
                            fromTokenSymbol: t,
                            toTokenSymbol: o,
                            usdAmount: n,
                            isBuyAnyCrypto: a
                        } = e;
                        r.I.emitEvent(_.SWAP_SIGN_REQUEST, {
                            from_token_symbol: t,
                            to_token_symbol: o,
                            swap_amount: n,
                            value: parseFloat(n),
                            is_buy_any_crypto: a
                        })
                    }, this.emitSwapSignReject = e => {
                        let {
                            fromTokenSymbol: t,
                            toTokenSymbol: o,
                            usdAmount: n,
                            isBuyAnyCrypto: a,
                            error: i,
                            errorMessage: s
                        } = e;
                        r.I.emitEvent(_.SWAP_SIGN_REJECT, {
                            from_token_symbol: t,
                            to_token_symbol: o,
                            swap_amount: n,
                            value: parseFloat(n),
                            is_buy_any_crypto: a,
                            error: i,
                            error_message: s
                        })
                    }, this.emitSwapSignError = e => {
                        let {
                            fromTokenSymbol: t,
                            toTokenSymbol: o,
                            usdAmount: n,
                            isBuyAnyCrypto: a,
                            error: i,
                            errorMessage: s
                        } = e;
                        r.I.emitEvent(_.SWAP_SIGN_ERROR, {
                            from_token_symbol: t,
                            to_token_symbol: o,
                            swap_amount: n,
                            value: parseFloat(n),
                            is_buy_any_crypto: a,
                            error: i,
                            error_message: s
                        })
                    }, this.emitSwapError = e => {
                        let {
                            fromTokenSymbol: t,
                            toTokenSymbol: o,
                            usdAmount: n,
                            isBuyAnyCrypto: a,
                            error: i,
                            errorMessage: s
                        } = e;
                        r.I.emitEvent(_.SWAP_ERROR, {
                            from_token_symbol: t,
                            to_token_symbol: o,
                            swap_amount: n,
                            value: n ? parseFloat(n) : void 0,
                            is_buy_any_crypto: a,
                            error: i,
                            error_message: s
                        })
                    }, this.emitSwapSignSuccess = e => {
                        let {
                            fromTokenSymbol: t,
                            toTokenSymbol: o,
                            usdAmount: n,
                            isBuyAnyCrypto: a
                        } = e;
                        r.I.emitEvent(_.SWAP_SIGN_SUCCESS, {
                            from_token_symbol: t,
                            to_token_symbol: o,
                            swap_amount: n,
                            value: parseFloat(n),
                            is_buy_any_crypto: a
                        })
                    }, this.emitQuote = e => {
                        let {
                            fromToken: t,
                            toToken: o,
                            usdAmount: n
                        } = e;
                        r.I.emitEvent(_.QUOTE, {
                            from_token_symbol: t.symbol,
                            to_token_symbol: o.symbol,
                            swap_amount: n
                        })
                    }, this.emitActivateGodMode = () => {
                        r.I.emitEvent(_.ACTIVATE_GOD_MODE)
                    }, this.emitOnRampView = e => {
                        r.I.emitEvent(_.ON_RAMP_VIEW, this.onRampParamsToData(e))
                    }, this.emitOnRampConnectWallet = e => {
                        r.I.emitEvent(_.ON_RAMP_CONNECT_WALLET, this.onRampParamsToData(e))
                    }, this.emitOnRampWalletConnected = e => {
                        r.I.emitEvent(_.ON_RAMP_WALLET_CONNECTED, this.onRampParamsToData(e))
                    }, this.emitOnRampHowToBuyInfo = e => {
                        r.I.emitEvent(_.ON_RAMP_HOW_TO_BUY_INFO, this.onRampParamsToData(e))
                    }, this.emitOnRampClickBuyButton = e => {
                        r.I.emitEvent(_.ON_RAMP_CLICK_BUY_BUTTON, this.onRampParamsToData(e))
                    }, this.emitOnRampBuyAnyEmailEntered = e => {
                        r.I.emitEvent(_.ON_RAMP_BUY_ANY_EMAIL_ENTERED, this.onRampParamsToData(e))
                    }, this.emitOnRampBuyAnySuccessRampFlow = e => {
                        r.I.emitEvent(_.ON_RAMP_BUY_ANY_SUCCESS_RAMP_FLOW, this.onRampParamsToData(e))
                    }, this.emitOnRampBuyAnyCheckActivity = e => {
                        r.I.emitEvent(_.ON_RAMP_BUY_ANY_CHECK_ACTIVITY, this.onRampParamsToData(e))
                    }, this.emitOffRampOpenSellScreen = () => {
                        r.I.emitEvent(_.OFF_RAMP_OPEN_SELL_SCREEN, {})
                    }, this.emitApproveSignRequest = e => {
                        let {
                            tokenAddress: t,
                            isBuyAnyCrypto: o
                        } = e;
                        r.I.emitEvent(_.APPROVE_SIGN_REQUEST, {
                            token_address: t,
                            is_buy_any_crypto: o
                        })
                    }, this.emitApproveSignSuccess = e => {
                        let {
                            tokenAddress: t,
                            isBuyAnyCrypto: o
                        } = e;
                        r.I.emitEvent(_.APPROVE_SIGN_SUCCESS, {
                            token_address: t,
                            is_buy_any_crypto: o
                        })
                    }, this.emitApproveSignReject = e => {
                        let {
                            tokenAddress: t,
                            isBuyAnyCrypto: o,
                            error: n,
                            errorMessage: a
                        } = e;
                        r.I.emitEvent(_.APPROVE_SIGN_REJECT, {
                            token_address: t,
                            is_buy_any_crypto: o,
                            error: n,
                            error_message: a
                        })
                    }, this.emitApproveSignError = e => {
                        let {
                            tokenAddress: t,
                            isBuyAnyCrypto: o,
                            error: n,
                            errorMessage: a
                        } = e;
                        r.I.emitEvent(_.APPROVE_SIGN_ERROR, {
                            token_address: t,
                            is_buy_any_crypto: o,
                            error: n,
                            error_message: a
                        })
                    }, this.emitApproveError = e => {
                        let {
                            tokenAddress: t,
                            isBuyAnyCrypto: o,
                            error: n,
                            errorMessage: a
                        } = e;
                        r.I.emitEvent(_.APPROVE_ERROR, {
                            token_address: t,
                            is_buy_any_crypto: o,
                            error: n,
                            error_message: a
                        })
                    }, this.emitApproveSuccess = e => {
                        let {
                            tokenAddress: t,
                            isBuyAnyCrypto: o
                        } = e;
                        r.I.emitEvent(_.APPROVE_SUCCESS, {
                            token_address: t,
                            is_buy_any_crypto: o
                        })
                    }, this.onRampParamsToData = t => {
                        var o;
                        let {
                            token: n,
                            fiatAmount: _,
                            fiatId: r,
                            buyQuote: a
                        } = t;
                        return {
                            token_address: null == n ? void 0 : n.address,
                            token_symbol: null == n ? void 0 : n.symbol,
                            token_network: null == n ? void 0 : n.network,
                            is_token_supported: (null !== (e = null == n ? void 0 : null === (o = n.rampProviders) || void 0 === o ? void 0 : o.length) && void 0 !== e ? e : 0) > 0,
                            amount_in_fiat: _,
                            fiat_id: r,
                            provider: null == a ? void 0 : a.provider,
                            payment_type: null == a ? void 0 : a.paymentType,
                            is_best_choice: null == a ? void 0 : a.isBestChoice,
                            is_cheapest: null == a ? void 0 : a.isBestRate
                        }
                    }
                }
            }
        },
        32585: function(e, t, o) {
            o.d(t, {
                E: function() {
                    return a
                },
                U: function() {
                    return r
                }
            });
            var n = o(99740),
                _ = o(49261);
            let r = {
                    id: _.i.UNKNOWN,
                    name: "Something went wrong",
                    description: "You spotted an unknown error. Don't worry, we are working on a fix to make Flooz.Trade errorless.",
                    matcher: RegExp(/.*/),
                    log: !0
                },
                a = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.cU.BINANCE_MAINNET;
                    return [{
                        id: _.i.TRANSACTION_UNDERPRICED,
                        name: "Gas limit changed",
                        description: 'This occurred because the gas price was manually changed. Please use the "Speed" field for speeding up transactions.',
                        matcher: RegExp(/transaction underpriced/),
                        log: !0
                    }, {
                        id: _.i.PRICE_IMPACT_TOO_HIGH,
                        name: "Price impact too high",
                        description: "Try trading a smaller amount, or increase slippage tolerance via the settings icon and try again. This is caused by low liquidity.",
                        matcher: RegExp(/price impact too high/),
                        log: !0
                    }, {
                        id: _.i.EXPIRED,
                        name: "Transaction expired",
                        description: 'This happened because the transaction was not signed quick enough. Try hitting "confirm" quicker next time.',
                        matcher: RegExp(/expired/),
                        log: !0
                    }, {
                        id: _.i.INSUFFICIENT_OUTPUT,
                        name: "Wrong slippage tolerance",
                        description: "When your slippage tolerance is too low, your order may fail to execute because the price movement is too high. Try setting a higher slippage.",
                        matcher: RegExp(/INSUFFICIENT_OUTPUT|INSUFFICIENT_OUTPUT_AMOUNT|FloozRouter: REVERTED|INSUFFICIENT_A_AMOUNT|INSUFFICIENT_B_AMOUNT/),
                        log: !0
                    }, {
                        id: _.i.TRANSFER_FROM_FAILED,
                        name: "Cannot transfer tokens",
                        description: "This could be a problem with the token you are swapping. Please report this to the team so we can make Flooz.Trade errorless.",
                        matcher: RegExp(/TRANSFER_FROM_FAILED/),
                        log: !0
                    }, {
                        id: _.i.SLIPPAGE_TOO_LOW,
                        name: "Slippage too low",
                        description: "You are trying to swap a token but your slippage tolerance is too low. Try setting it a bit higher.",
                        matcher: RegExp(/FloozRouter: LOW_SLIPPAGE/),
                        log: !0
                    }, {
                        id: _.i.TRANSFER_FAILED,
                        name: "More tokens needed",
                        description: "Make sure you have enough tokens in your wallet. If you want to sell the maximum possible, try trading a lower amount.",
                        matcher: RegExp(/TRANSFER_FAILED/),
                        log: !0
                    }, {
                        id: _.i.INSUFFICIENT_USER_BALANCE,
                        name: "Fund your wallet",
                        description: "You need to add more ".concat(n.Eu[e].nativeCurrency.symbol, " to your wallet for this trade to go through, once you've added more ").concat(n.Eu[e].nativeCurrency.symbol, " please try again."),
                        matcher: RegExp(/INSUFFICIENT_USER_BALANCE|gas required exceeds allowance|insufficient funds for transfer/),
                        log: !0
                    }, {
                        id: _.i.PANCAKE_K_ERROR,
                        name: "Exchange error",
                        description: "We placed your trade on a decentralised exchange, however, they have rejected the trade. Please increase the slippage on your trade and try again.",
                        matcher: RegExp(/execution reverted: Pancake: K/),
                        log: !0
                    }, {
                        id: _.i.TRANSACTION_REVERTED,
                        name: "Blockchain error",
                        description: "We sent your transaction to the blockchain but it failed. This could be due to several reasons such as a large price movement, or not enough liquidity. Please try to place your trade again.",
                        matcher: RegExp(/transaction-reverted/),
                        log: !0
                    }, {
                        id: _.i.SELF_REFERRAL,
                        name: "Self referral",
                        description: "You cannot swap tokens using your own referral link. Please use another wallet and try again.",
                        matcher: RegExp(/FloozRouter: SELF_REFERRAL/),
                        log: !1
                    }, {
                        id: _.i.TRANSACTION_REJECTED,
                        name: "Transaction rejected",
                        description: "The transaction was rejected in your wallet. You can always try swapping your tokens again.",
                        matcher: RegExp(/User denied transaction signature|User canceled|cancelled|User rejected the transaction|user rejected transaction/),
                        log: !1
                    }]
                }
        },
        58871: function(e, t, o) {
            o.d(t, {
                $M: function() {
                    return r
                },
                CB: function() {
                    return l
                },
                IT: function() {
                    return a
                }
            });
            var n, _, r, a, i = o(29204),
                s = o(27187),
                E = o(32585);
            (n = r || (r = {})).FROM_TOKEN = "fromToken", n.TO_TOKEN = "toToken", n.FROM_TOKEN_AMOUNT = "fromTokenAmount", n.TO_TOKEN_AMOUNT = "toTokenAmount", n.GAS_PRICE_LEVEL = "gasPriceLevel", n.SLIPPAGE = "slippage", n.NETWORK = "network", (_ = a || (a = {})).GET_QUOTE = "GET_QUOTE", _.APPROVAL_CHECK = "APPROVAL_CHECK", _.APPROVAL_BUILD = "APPROVAL_BUILD", _.APPROVAL_SEND = "APPROVAL_SEND", _.APPROVAL_WAIT = "APPROVAL_WAIT", _.SWAP_TOKEN_BUILD = "SWAP_TOKEN_BUILD", _.SWAP_TOKEN_SEND = "SWAP_TOKEN_SEND", _.SWAP_TOKEN_WAIT = "SWAP_TOKEN_WAIT", _.UNKNOWN = "UNKNOWN";
            let l = new class {
                constructor() {
                    this.getSwapError = (e, t) => {
                        let o = this.parseErrorMessage(e),
                            n = (0, E.E)(t).find(e => e.matcher.exec(o));
                        return null != n ? n : E.U
                    }, this.buildSwapException = e => {
                        let {
                            functionName: t,
                            error: o,
                            formValues: n
                        } = e, _ = this.parseErrorMessage(o), r = null != (0, E.E)().find(e => e.matcher.exec(_));
                        return {
                            exception: o,
                            context: {
                                functionName: t,
                                parsedMessage: _,
                                formValues: n
                            },
                            severity: r ? "info" : "error"
                        }
                    }, this.parseErrorMessage = e => {
                        if (!e || null == e) return "Unknown error";
                        if (e instanceof i.d7) {
                            var t, o, n;
                            return null !== (n = null === (t = e.response) || void 0 === t ? void 0 : null === (o = t.data) || void 0 === o ? void 0 : o.message) && void 0 !== n ? n : e.message
                        }
                        return "object" == typeof e && s.Q.hasOwnProperty(e, "reason") && null != e.reason ? e.reason : "object" == typeof e && s.Q.hasOwnProperty(e, "message") ? e.message : "string" == typeof e ? e : JSON.stringify(e)
                    }
                }
            }
        },
        13484: function(e, t, o) {
            var n, _;
            o.d(t, {
                T: function() {
                    return n
                }
            }), (_ = n || (n = {})).BOUGHT_TOKEN = "BOUGHT_TOKEN", _.SENT_TOKEN = "SENT_TOKEN", _.SOLD_TOKEN = "SOLD_TOKEN", _.RECEIVED_TOKEN = "RECEIVED_TOKEN", _.APPROVAL = "APPROVAL", _.SWAP = "SWAP", _.MINTED_NFT = "MINTED_NFT", _.SENT_NFT = "SENT_NFT", _.RECEIVED_NFT = "RECEIVED_NFT", _.BOUGHT_NFT = "BOUGHT_NFT", _.SOLD_NFT = "SOLD_NFT", _.AIRDROP_NFT = "AIRDROP_NFT", _.CONTRACT_EXECUTION = "CONTRACT_EXECUTION"
        },
        49261: function(e, t, o) {
            var n, _;
            o.d(t, {
                i: function() {
                    return n
                }
            }), (_ = n || (n = {})).TRANSACTION_REJECTED = "TRANSACTION_REJECTED", _.TRANSACTION_UNDERPRICED = "TRANSACTION_UNDERPRICED", _.PRICE_IMPACT_TOO_HIGH = "PRICE_IMPACT_TOO_HIGH", _.EXPIRED = "EXPIRED", _.INSUFFICIENT_OUTPUT = "INSUFFICIENT_OUTPUT", _.TRANSFER_FROM_FAILED = "TRANSFER_FROM_FAILED", _.SLIPPAGE_TOO_LOW = "SLIPPAGE_TOO_LOW", _.TRANSFER_FAILED = "TRANSFER_FAILED", _.INSUFFICIENT_USER_BALANCE = "INSUFFICIENT_USER_BALANCE", _.PANCAKE_K_ERROR = "PANCAKE_K_ERROR", _.TRANSACTION_REVERTED = "TRANSACTION_REVERTED", _.SELF_REFERRAL = "SELF_REFERRAL", _.UNKNOWN = "UNKNOWN"
        }
    }
]);