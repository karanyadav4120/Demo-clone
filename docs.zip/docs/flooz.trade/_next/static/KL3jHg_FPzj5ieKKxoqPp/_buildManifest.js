self.__BUILD_MANIFEST = function(s, e, a, c, t, d, r, n, f, i, b, k) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [],
            fallback: []
        },
        "/_error": ["static/chunks/pages/_error-074db67cbfb28d5e.js"],
        "/embed/on-ramp": [a, d, c, r, s, t, n, f, e, i, "static/chunks/pages/embed/on-ramp-20b38378ae436cd0.js"],
        "/embed/ramp-success": ["static/chunks/pages/embed/ramp-success-f5d92d9f2e7d5596.js"],
        "/embed/swap": [a, d, c, r, s, t, n, f, e, i, "static/chunks/pages/embed/swap-d5efb226832fc4e6.js"],
        "/embed/swap/[tokenAddress]": [a, d, c, r, s, t, n, f, e, i, "static/chunks/pages/embed/swap/[tokenAddress]-07d1f014c6608c06.js"],
        "/embed/trade": [a, d, c, r, s, t, n, f, e, i, "static/chunks/pages/embed/trade-866ab37dbddcaf8d.js"],
        "/embedded/[tokenAddress]": [a, d, c, r, s, t, n, f, e, i, "static/chunks/pages/embedded/[tokenAddress]-877627ae200f179d.js"],
        "/nft/[collectionAddress]": [c, s, b, "static/chunks/pages/nft/[collectionAddress]-3a5e5a19b34fa542.js"],
        "/nft/[collectionAddress]/[id]": [b, "static/chunks/pages/nft/[collectionAddress]/[id]-7891e46f329b0ae7.js"],
        "/partners": [a, t, e, k, "static/chunks/pages/partners-db2fe0b7e9373647.js"],
        "/profile/[ensOrAddress]": [a, d, c, r, s, t, n, f, e, i, "static/chunks/6083-0dde6d3ef17e3221.js", "static/chunks/3439-c75d8e6a01f09ab5.js", "static/chunks/pages/profile/[ensOrAddress]-44f342553c2bbb99.js"],
        "/referral": [a, d, c, r, s, t, n, f, e, i, "static/chunks/pages/referral-d2486671329784bd.js"],
        "/sitemap.xml": ["static/chunks/pages/sitemap.xml-d85b6092b806fa37.js"],
        "/trade": [a, d, c, r, s, t, n, f, e, i, k, "static/chunks/pages/trade-aabdd02b57332463.js"],
        "/trade/[tokenAddress]": [a, d, c, r, s, t, n, f, e, i, "static/chunks/pages/trade/[tokenAddress]-33bc2b71c3f52b0f.js"],
        "/watchlist": [s, e, "static/chunks/pages/watchlist-5e97540a3c443a0c.js"],
        "/[...404Page]": ["static/chunks/pages/[...404Page]-054c93a9f9865b9d.js"],
        sortedPages: ["/_app", "/_error", "/embed/on-ramp", "/embed/ramp-success", "/embed/swap", "/embed/swap/[tokenAddress]", "/embed/trade", "/embedded/[tokenAddress]", "/nft/[collectionAddress]", "/nft/[collectionAddress]/[id]", "/partners", "/profile/[ensOrAddress]", "/referral", "/sitemap.xml", "/trade", "/trade/[tokenAddress]", "/watchlist", "/[...404Page]"]
    }
}("static/chunks/8006-79f27dac41453261.js", "static/chunks/7397-c6d58ba83b4cd65f.js", "static/chunks/a2c29f49-a295bbb9fdb43fe0.js", "static/chunks/8608-6bf1644f31f75c7e.js", "static/chunks/5142-0459e73881b2940e.js", "static/chunks/2580-1c5ddb1b2a1814c9.js", "static/chunks/6888-15ec31dee617775b.js", "static/chunks/9853-b5a90ad82587c627.js", "static/chunks/9964-40aa18d28e354078.js", "static/chunks/6744-5183bdfc7d7a1dab.js", "static/chunks/3265-901aeee7a56af62c.js", "static/chunks/9358-67b9f705af6434f5.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();